import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

/// Đổi URL này mỗi khi restart Colab (cloudflared cấp URL mới).
class ApiService {
  String baseUrl;

  ApiService({required this.baseUrl});

  /// MỚI - "Ký số xác thực yêu cầu" (HMAC Request Signing, xem
  /// `_verify_hmac_signature` trong app.py) - trả về map RỖNG nếu [secret]
  /// rỗng (TẮT tính năng này, giống hành vi cũ, KHÔNG gửi thêm header nào) -
  /// backend cũng tự bỏ qua kiểm tra nếu chưa đặt `MV_APP_HMAC_SECRET`, nên
  /// 2 bên luôn nhất quán dù bật hay tắt. [signedValue] PHẢI trùng đúng field
  /// backend dùng để tính lại chữ ký (vd `audio_filename` cho /generate-mv,
  /// `voice_name` cho /train-voice - xem app.py).
  Map<String, String> _hmacHeaders(String signedValue, String secret) {
    if (secret.isEmpty) return {};
    final timestamp = (DateTime.now().millisecondsSinceEpoch / 1000).toStringAsFixed(3);
    final message = utf8.encode('$timestamp:$signedValue');
    final signature = Hmac(sha256, utf8.encode(secret)).convert(message).toString();
    return {'X-Signature': signature, 'X-Timestamp': timestamp};
  }

  /// wss://... (hoặc ws://... nếu baseUrl không phải https) dùng cho RealtimeClient.
  String get wsUrl {
    final uri = Uri.parse(baseUrl);
    final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
    return uri.replace(scheme: scheme, path: '/ws/updates').toString();
  }

  Future<Map<String, dynamic>> generateMusic({
    required String prompt,
    String lyrics = '',
    double duration = 30,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-music'),
      body: {
        'prompt': prompt,
        'lyrics': lyrics,
        'duration': duration.toString(),
        'gpu_power': gpuPower.toString(),
        'num_variants': numVariants.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải 1 file nhạc mẫu lên server để DÙNG LẠI nhiều lần (phiên âm lời +
  /// cover) mà không phải upload lại 2-3 lần cho cùng 1 file. Trả về tên
  /// file trên server - dùng cho `transcribeLyrics()` và
  /// `remixMusic(sampleFilename: ...)`.
  Future<Map<String, dynamic>> uploadSampleAudio({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-sample-audio'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải audio từ 1 link YouTube về server - dùng khi chỉ có link, chưa có
  /// file nhạc trong tay. Trả về CÙNG dạng response với uploadSampleAudio()
  /// (`{"status", "filename"}`) - dùng tiếp giống hệt file tự upload.
  Future<Map<String, dynamic>> downloadYoutubeAudio({required String url}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/download-youtube-audio'),
      body: {'url': url},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phiên âm lời TỪ FILE NHẠC (đã có trên server qua uploadSampleAudio()
  /// hoặc downloadYoutubeAudio()) - dùng khi không có sẵn lời gốc để dán
  /// tay. Kết quả thường ở ngôn ngữ gốc bài hát - đưa tiếp vào
  /// translateLyrics() để có bản Việt.
  Future<Map<String, dynamic>> transcribeLyrics({required String sampleFilename, String languageHint = ''}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/transcribe-lyrics'),
      body: {'sample_filename': sampleFilename, 'language_hint': languageHint},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> remixMusic({
    File? sampleFile,
    String? sampleFilename, // MỚI - file ĐÃ CÓ SẴN trên server (upload trước hoặc từ YouTube) - dùng 1 trong 2, không phải cả 2
    String stylePrompt = '',
    String lyrics = '',
    double duration = 30,
    double similarity = 0.3,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    assert(sampleFile != null || sampleFilename != null, 'Cần có sampleFile hoặc sampleFilename');
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/remix-music'));
    req.fields['style_prompt'] = stylePrompt;
    req.fields['lyrics'] = lyrics;
    req.fields['duration'] = duration.toString();
    req.fields['similarity'] = similarity.toString();
    req.fields['gpu_power'] = gpuPower.toString();
    req.fields['num_variants'] = numVariants.toString();
    if (sampleFilename != null) {
      req.fields['sample_filename'] = sampleFilename;
    } else {
      req.files.add(await http.MultipartFile.fromPath('file', sampleFile!.path));
    }

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dịch/phóng tác lời bài hát (tiếng Hoa hay bất kỳ tiếng nào) sang lời
  /// Việt - dùng cho tính năng "cover thành lời Việt". Trả về BẢN NHÁP, cần
  /// người dùng xem/sửa lại trước khi dùng cho remixMusic(lyrics: ...) -
  /// KHÔNG phải bản dịch hoàn chỉnh dùng thẳng (model nhỏ, xem tài liệu kỹ thuật).
  Future<Map<String, dynamic>> translateLyrics({required String lyrics}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/translate-lyrics-to-vietnamese'),
      body: {'lyrics': lyrics},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<String>> getVoicePresets() async {
    final res = await http.get(Uri.parse('$baseUrl/voice-presets'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<String>.from(data['voices']);
  }

  /// MỚI - phục vụ luồng "Tạo từ ý tưởng" (mục 7v): người dùng đã có sẵn 1
  /// bài nhạc muốn dùng thẳng, KHÔNG cần AI tạo/biến tấu. CHỈ upload thẳng,
  /// không tốn GPU - khác `remixMusic()` (luôn chạy AI biến tấu qua ACE-Step).
  Future<Map<String, dynamic>> uploadMusic({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-music'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Upload file .pth giọng mới trực tiếp trong app - đỡ phải tự tay tải lên
  /// Google Drive qua giao diện Drive.
  Future<Map<String, dynamic>> uploadVoice({
    required File pthFile,
    required String voiceName,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-voice'));
    req.fields['voice_name'] = voiceName;
    req.files.add(await http.MultipartFile.fromPath('file', pthFile.path));

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tự huấn luyện giọng mới từ 1 file ghi âm - CHẠY NỀN (bất đồng bộ), trả
  /// về {status, job_id, voice_id} NGAY, theo dõi tiếp qua /progress (dùng
  /// ProgressPoller như /apply-voice) - KHÔNG đợi tới xong như uploadVoice().
  /// Có thể mất tới hàng chục phút - xem ghi chú trong app.py.
  Future<Map<String, dynamic>> trainVoice({
    required File audioFile,
    required String voiceName,
    int epochs = 50,
    String hmacSecret = '', // MỚI - xem _hmacHeaders(); để trống = không ký (mặc định)
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/train-voice'));
    req.fields['voice_name'] = voiceName;
    req.fields['epochs'] = epochs.toString();
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    req.headers.addAll(_hmacHeaders(voiceName, hmacSecret)); // phải ký ĐÚNG field voice_name, khớp app.py

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<Map<String, dynamic>>> getVideoStyles() async {
    // SỬA (mục 7zc2) - backend giờ trả về danh sách phong cách KÈM `label` và
    // `lipsync_ok` (trước chỉ trả về list tên id đơn giản) - đổi kiểu trả về
    // từ List<String> sang List<Map> để Flutter biết phong cách nào được
    // phép bật công tắc Lipsync.
    final res = await http.get(Uri.parse('$baseUrl/video-styles'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<Map<String, dynamic>>.from(data['styles']);
  }

  /// MỚI (mục 7zc2) - "Character Sheet": sinh RIÊNG 1 ảnh tham chiếu nhân vật
  /// để xem trước, KHÔNG bắt đầu tạo cả MV - dùng trước khi vào GeneratingScreen.
  Future<Map<String, dynamic>> generateCharacterReference({
    required String characterDesc,
    required String styleId,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-character-reference'),
      body: {'character_desc': characterDesc, 'style_id': styleId},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> applyVoice({
    required String audioFilename,
    required String voiceId,
    int gpuPower = 70,
    int pitchShift = 0,
    bool enableFormantShift = false, // MỚI - xem _apply_formant_shift trong app.py, TẮT mặc định (thử nghiệm)
    double formantQuefrencyMs = 1.5, // MỚI - chỉ có tác dụng khi enableFormantShift=true
    bool enableDeessing = false, // MỚI - xem _apply_deessing trong app.py, TẮT mặc định (thử nghiệm)
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/apply-voice'),
      body: {
        'audio_filename': audioFilename,
        'voice_id': voiceId,
        'gpu_power': gpuPower.toString(),
        'pitch_shift': pitchShift.toString(),
        'enable_formant_shift': enableFormantShift.toString(),
        'formant_quefrency_ms': formantQuefrencyMs.toString(),
        'enable_deessing': enableDeessing.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Bắt đầu (hoặc TIẾP TỤC nếu truyền [resumeJobId]) job tạo MV chạy nền.
  /// Trả về {status, job_id, scene_dir_id} NGAY - không đợi xong. Theo dõi
  /// tiếp qua RealtimeClient (WebSocket) - server sẽ tự đẩy tiến trình + file.
  Future<Map<String, dynamic>> generateMv({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    int gpuPower = 70,
    int numInferenceSteps = 20,
    double guidanceScale = 7.5,
    String? resumeJobId,
    String characterDesc = '',
    bool enableMotionCamera = true,
    List<String>? scenePrompts,
    String? videoBackend,
    String? characterReferenceFilename, // MỚI (mục 7zc2) - tái dùng ảnh đã xác nhận qua CharacterReferenceScreen
    bool enableLipsync = false, // MỚI (mục 7zc2) - backend tự bỏ qua nếu styleId không hỗ trợ
    String? lipsyncBackend, // MỚI (mục 7zc9) - "wav2lip" (mặc định server) hoặc "musetalk", xem getLipsyncBackends()
    String lyrics = '', // MỚI (mục 7zc4) - để trống thì backend tự bỏ qua bước sinh phụ đề động (karaoke)
    bool enableSceneContinuity = false, // MỚI (mục 7zc5) - backend tự bỏ qua nếu videoBackend không hỗ trợ
    bool enableColorMatch = true, // MỚI - "Color Grading" tự động, backend tự bỏ qua an toàn nếu lỗi
    bool enableSpeedRamping = false, // MỚI - "Beat-Reactive Speed Ramping" thử nghiệm, xem app.py
    bool enablePostFx = true, // MỚI - hiệu ứng hậu kỳ điện ảnh (vignette/grain/sharpen), xem post_processing_v2.py
    String postFxIntensity = 'light', // MỚI - "light" hoặc "strong", chỉ có ý nghĩa khi enablePostFx=true
    bool enableMotionSmoothing = false, // MỚI - làm mượt chuyển động (ffmpeg minterpolate, KHÔNG phải RIFE), tốn thời gian xử lý
    String motionSmoothingMethod = 'ffmpeg', // MỚI - "ffmpeg" hoặc "rife" (deep learning thật), chỉ có tác dụng khi enableMotionSmoothing=true
    bool enableRealesrganUpscale = false, // MỚI - upscale bằng Real-ESRGAN, CẦN backend đã cài thêm package + có GPU thật
    bool exportVertical = false, // MỚI - xuất thêm bản dọc 9:16 cho Shorts/TikTok/Reels
    String hmacSecret = '', // MỚI - xem _hmacHeaders(); để trống = không ký (mặc định)
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-mv'),
      headers: _hmacHeaders(audioFilename, hmacSecret), // phải ký ĐÚNG field audio_filename, khớp app.py
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'gpu_power': gpuPower.toString(),
        'num_inference_steps': numInferenceSteps.toString(),
        'guidance_scale': guidanceScale.toString(),
        if (resumeJobId != null) 'resume_job_id': resumeJobId,
        'character_desc': characterDesc,
        'enable_motion_camera': enableMotionCamera.toString(),
        if (scenePrompts != null) 'scene_prompts_json': jsonEncode(scenePrompts),
        if (videoBackend != null) 'video_backend': videoBackend,
        if (characterReferenceFilename != null) 'character_reference_filename': characterReferenceFilename,
        'enable_lipsync': enableLipsync.toString(),
        if (lipsyncBackend != null) 'lipsync_backend': lipsyncBackend,
        'lyrics': lyrics,
        'enable_scene_continuity': enableSceneContinuity.toString(),
        'enable_color_match': enableColorMatch.toString(),
        'enable_speed_ramping': enableSpeedRamping.toString(),
        'enable_post_fx': enablePostFx.toString(),
        'post_fx_intensity': postFxIntensity,
        'enable_motion_smoothing': enableMotionSmoothing.toString(),
        'motion_smoothing_method': motionSmoothingMethod,
        'enable_realesrgan_upscale': enableRealesrganUpscale.toString(),
        'export_vertical': exportVertical.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - bước "kịch bản cảnh" (storyboard/shot-list): trả về prompt GỢI Ý
  /// riêng cho từng cảnh (ghép style + character_desc + mood theo nhịp + đoạn
  /// lyric tương ứng nếu có) - CHỈ DÙNG CPU, không tốn GPU, gọi lại thoải mái.
  /// Người dùng xem/sửa rồi gửi lại qua generateMv(scenePrompts: ...).
  /// MỚI - cho người dùng ĐÃ CÓ SẴN kịch bản (file .txt, mỗi dòng = 1 cảnh)
  /// upload thẳng vào, BỎ QUA hoàn toàn bước dàn dựng tự động/LLM. Số dòng
  /// PHẢI khớp đúng số cảnh thật (xem `expected_scenes` trong response lỗi
  /// nếu không khớp) - gọi `analyzeBeats()` trước để biết trước số cảnh cần.
  Future<Map<String, dynamic>> parseStoryboardFile({
    required String audioFilename,
    required String styleId,
    required File scriptFile,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/parse-storyboard-file'));
    req.fields['audio_filename'] = audioFilename;
    req.fields['style_id'] = styleId;
    req.fields['beats_per_scene'] = beatsPerScene.toString();
    req.fields['max_scenes'] = maxScenes.toString();
    req.fields['character_desc'] = characterDesc;
    req.files.add(await http.MultipartFile.fromPath('script_file', scriptFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> buildStoryboard({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
    String lyrics = '',
    String? genre,
    bool useLlmScript = false,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/build-storyboard'),
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'character_desc': characterDesc,
        'lyrics': lyrics,
        if (genre != null) 'genre': genre,
        'use_llm_script': useLlmScript.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa nhanh (bản nháp)" - KHÁC repaintMusicSection() về bản chất: chỉ
  /// sinh 1 đoạn NGẮN rồi ghép crossfade vào bài gốc - RẺ hơn nhiều (chi phí
  /// tỉ lệ với độ dài đoạn sửa, không phải cả bài), nhưng có thể nghe ra "vết
  /// nối" nhẹ - dùng làm bản NHÁP để nghe thử lời/hướng mới trước khi tốn GPU
  /// làm bản hoàn chỉnh. Xem docstring đầy đủ ở app.py.
  Future<Map<String, dynamic>> quickEditMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/quick-edit-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lại 1 đoạn" (giống Suno/Udio): CHỈ sinh lại đúng khoảng
  /// [startTime, endTime] (giây), giữ nguyên phần còn lại của bài. Trả về
  /// file MỚI (không ghi đè bản gốc) để nghe thử/so sánh trước khi quyết
  /// định giữ bản nào - dùng `task_type="repaint"` của ACE-Step, xem docstring
  /// đầy đủ ở app.py.
  Future<Map<String, dynamic>> repaintMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/repaint-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lời, cố giữ giai điệu" (mục 7zb) - KHÁC repaintMusicSection():
  /// hàm này CHỈ ĐỔI LỜI, backend tự thử "giữ giai điệu" trước, tự rơi về
  /// cách thường nếu không khả dụng (xem `used_mode` trong kết quả trả về -
  /// `"edit"` hay `"repaint_fallback"`, CHƯA CHẠY THỬ để biết nhánh nào sẽ
  /// thật sự xảy ra). Dùng khi CHỈ muốn sửa vài chữ, không muốn đổi cả giai
  /// điệu/phong cách đoạn đó.
  Future<Map<String, dynamic>> editLyricsSection({
    required String audioFilename,
    required String newLyrics,
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/edit-lyrics-section'),
      body: {
        'audio_filename': audioFilename,
        'new_lyrics': newLyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - lấy danh sách backend video CÓ THẬT từ server (KHÔNG hardcode
  /// tên/label ở Flutter - đúng yêu cầu "phổ quát không hardcode"). Server
  /// thêm backend mới ở `VIDEO_BACKENDS` (app.py) là app TỰ THẤY ngay, không
  /// cần build lại APK.
  Future<Map<String, dynamic>> getVideoBackends() async {
    final res = await http.get(Uri.parse('$baseUrl/video-backends'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 7zc9) - lấy danh sách backend LIPSYNC CÓ THẬT từ server, THEO
  /// ĐÚNG pattern getVideoBackends() ở trên (KHÔNG hardcode tên/label ở
  /// Flutter). Server thêm backend mới ở `LIPSYNC_BACKENDS` (app.py) là app
  /// TỰ THẤY ngay, không cần build lại APK.
  Future<Map<String, dynamic>> getLipsyncBackends() async {
    final res = await http.get(Uri.parse('$baseUrl/lipsync-backends'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> getVideoGenres() async {
    final res = await http.get(Uri.parse('$baseUrl/video-genres'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phân tích nhịp NHANH (chỉ CPU) để xem trước ước tính số cảnh/tempo -
  /// dùng ở màn hình Xem lại TRƯỚC KHI tốn GPU tạo MV thật.
  Future<Map<String, dynamic>> analyzeBeats({
    required String audioFilename,
    int beatsPerScene = 4,
    int maxScenes = 8,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/analyze-beats'),
      body: {
        'audio_filename': audioFilename,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Yêu cầu huỷ job /generate-mv đang chạy. Không tức thời - job dừng ở
  /// lần kiểm tra cờ tiếp theo bên backend (thường vài giây sau).
  Future<Map<String, dynamic>> abortJob() async {
    final res = await http.post(Uri.parse('$baseUrl/abort-job'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dự phòng nếu không dùng được WebSocket: {job_id, stage, percent, detail,
  /// artifacts:[{filename,kind}], done, error}.
  Future<Map<String, dynamic>> getProgress() async {
    final res = await http.get(Uri.parse('$baseUrl/progress'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dự phòng: tải qua HTTP thường nếu cần (WebSocket đã đẩy file trực tiếp
  /// nên bình thường không cần gọi hàm này).
  String downloadUrl(String relativePath) => '$baseUrl/download/$relativePath';

  /// Dùng khi ĐANG Ở CHẾ ĐỘ DỰ PHÒNG (poll, không phải WebSocket) và cần tải
  /// file LỚN (vd MV cuối) - lấy link Google Drive thay vì gọi downloadUrl()
  /// trực tiếp cho file lớn (sẽ dính lại giới hạn 100MB/request của Cloudflare).
  Future<String?> getDriveLink(String relativePath) async {
    final res = await http.get(Uri.parse('$baseUrl/drive-link/$relativePath'));
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body);
    return data['drive_link'] as String?;
  }

  void _checkOk(http.Response res) {
    if (res.statusCode != 200) {
      throw Exception('API lỗi (${res.statusCode}): ${res.body}');
    }
  }
}
