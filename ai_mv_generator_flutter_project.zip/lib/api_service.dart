import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'l10n.dart';
import 'generation_settings.dart';

/// Đổi URL này mỗi khi restart Colab (cloudflared cấp URL mới).
class ApiService {
  String baseUrl;

  ApiService({required this.baseUrl});

  /// MỚI - "Ký số xác thực yêu cầu" (HMAC Request Signing, xem
  /// `_verify_hmac_signature` trong app.py) - trả về map RỖNG nếu [secret]
  /// rỗng (TẮT tính năng này, giống hành vi cũ, KHÔNG gửi thêm header nào) -
  /// backend cũng tự bỏ qua kiểm tra nếu chưa đặt `MV_APP_HMAC_SECRET`, nên
  /// 2 bên luôn nhất quán dù bật hay tắt. [signedValue] PHẢI trùng đúng field
  /// backend dùng để tính lại chữ ký (vd `audio_filename` cho /generate-mv,
  /// `voice_name` cho /train-voice - xem app.py).
  Map<String, String> _hmacHeaders(String signedValue, String secret) {
    if (secret.isEmpty) return {};
    final timestamp = (DateTime.now().millisecondsSinceEpoch / 1000).toStringAsFixed(3);
    final message = utf8.encode('$timestamp:$signedValue');
    final signature = Hmac(sha256, utf8.encode(secret)).convert(message).toString();
    return {'X-Signature': signature, 'X-Timestamp': timestamp};
  }

  /// MỚI (mục 49) - chữ ký THEO ĐƯỜNG DẪN cho mọi endpoint ghi KHÔNG có chữ ký riêng (PDF-2 mục 10.5: HMAC cho mọi endpoint). Backend chỉ KIỂM khi
  /// MV_APP_HMAC_ALL=1 (mặc định tắt); app LUÔN gửi (vô hại khi backend chưa kiểm). Ký `path:<đường dẫn>`, khớp mv_security.check_write_signature.
  Map<String, String> _pathSig(String path) => _hmacHeaders('path:$path', GenerationSettings.instance.hmacSecret);

  /// wss://... (hoặc ws://... nếu baseUrl không phải https) dùng cho RealtimeClient.
  String get wsUrl {
    final uri = Uri.parse(baseUrl);
    final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
    return uri.replace(scheme: scheme, path: '/ws/updates').toString();
  }

  Future<Map<String, dynamic>> generateMusic({
    required String prompt,
    String lyrics = '',
    double duration = 30,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-music'),
      headers: _pathSig('/generate-music'),
      body: {
        'prompt': prompt,
        'lyrics': lyrics,
        'duration': duration.toString(),
        'gpu_power': gpuPower.toString(),
        'num_variants': numVariants.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải 1 file nhạc mẫu lên server để DÙNG LẠI nhiều lần (phiên âm lời +
  /// cover) mà không phải upload lại 2-3 lần cho cùng 1 file. Trả về tên
  /// file trên server - dùng cho `transcribeLyrics()` và
  /// `remixMusic(sampleFilename: ...)`.
  /// MỚI (mục 27, PDF 2.5) - khớp cân bằng tần số của bản nhạc theo 1 bài tham chiếu đã tải bằng uploadSampleAudio(). Trả {status, file, info} hoặc {status:'error', note}.
  Future<Map<String, dynamic>> matchEqReference({
    required String audioFilename,
    required String referenceFilename,
    double strength = 0.5,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/match-eq-reference'),
      headers: _pathSig('/match-eq-reference'),
      body: {
        'audio_filename': audioFilename,
        'reference_filename': referenceFilename,
        'strength': strength.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 39) - mastering AI SonicMaster (TUỲ CHỌN, cài ở Cài đặt → Mô hình & công cụ). `preset` khớp khoá SONICMASTER_PRESETS của backend
  /// (balanced/vocal/reverb/warm/loud/denoise); `prompt` là lệnh tự do (thay preset). Trả {status:'ok', file, prompt} | {status:'not_installed'|'error', note}. Chạy có thể vài phút.
  Future<Map<String, dynamic>> sonicMaster({required String audioFilename, String preset = 'balanced', String prompt = ''}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/sonicmaster'),
      headers: _pathSig('/sonicmaster'),
      body: {
        'audio_filename': audioFilename,
        'preset': preset,
        if (prompt.trim().isNotEmpty) 'prompt': prompt.trim(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 39) - sổ dùng CỤC BỘ (không phải thanh toán): {status:'ok', today:{mv,scenes,gpu_minutes}, last_7_days:{...}, total:{...}, daily_limit, limit_mode}.
  Future<Map<String, dynamic>> getUsage() async {
    final res = await http.get(Uri.parse('$baseUrl/usage'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 27, PDF 9.2) - TUỲ CHỌN: kiểm tra nhận diện âm thanh (kiểu Content ID) qua ACRCloud trên backend. Backend trả 'not_configured' nếu chưa có
  /// tài khoản/khoá, 'need_confirm' nếu `confirmUpload` != true (vì ~15 giây nhạc/lượt được GỬI cho bên thứ ba), 'ok' kèm danh sách khớp.
  Future<Map<String, dynamic>> checkContentId({required String audioFilename, bool confirmUpload = false}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/check-content-id'),
      headers: _pathSig('/check-content-id'),
      body: {'audio_filename': audioFilename, 'confirm_upload': confirmUpload ? 'yes' : ''},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 29, PDF "MV triệu view cần gì" - tsondo/musicvision "rough cut + FCPXML") - xuất timeline FCPXML (BẢN DỰNG THÔ: các cảnh nối cứng + nhạc,
  /// không gồm chuyển cảnh/chỉnh màu/hiệu ứng của MV cuối) từ cảnh của job MỚI NHẤT trên backend, để dựng tiếp bằng DaVinci Resolve/Final Cut trên máy tính.
  /// File được ghi vào thư mục kết quả trên Google Drive của backend; app chỉ nhận tên file + thông tin.
  Future<Map<String, dynamic>> exportFcpxml({String? audioFilename}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/export-fcpxml'),
      headers: _pathSig('/export-fcpxml'),
      body: {'audio_filename': audioFilename ?? ''},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> uploadSampleAudio({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-sample-audio'));
    req.headers.addAll(_pathSig('/upload-sample-audio'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải audio từ 1 link YouTube về server - dùng khi chỉ có link, chưa có
  /// file nhạc trong tay. Trả về CÙNG dạng response với uploadSampleAudio()
  /// (`{"status", "filename"}`) - dùng tiếp giống hệt file tự upload.
  Future<Map<String, dynamic>> downloadYoutubeAudio({required String url}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/download-youtube-audio'),
      headers: _pathSig('/download-youtube-audio'),
      body: {'url': url},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phiên âm lời TỪ FILE NHẠC (đã có trên server qua uploadSampleAudio()
  /// hoặc downloadYoutubeAudio()) - dùng khi không có sẵn lời gốc để dán
  /// tay. Kết quả thường ở ngôn ngữ gốc bài hát - đưa tiếp vào
  /// translateLyrics() để có bản Việt.
  Future<Map<String, dynamic>> transcribeLyrics({required String sampleFilename, String languageHint = ''}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/transcribe-lyrics'),
      headers: _pathSig('/transcribe-lyrics'),
      body: {'sample_filename': sampleFilename, 'language_hint': languageHint},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> remixMusic({
    File? sampleFile,
    String? sampleFilename, // MỚI - file ĐÃ CÓ SẴN trên server (upload trước hoặc từ YouTube) - dùng 1 trong 2, không phải cả 2
    String stylePrompt = '',
    String lyrics = '',
    double duration = 30,
    double similarity = 0.3,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    assert(sampleFile != null || sampleFilename != null, 'Cần có sampleFile hoặc sampleFilename');
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/remix-music'));
    req.headers.addAll(_pathSig('/remix-music'));
    req.fields['style_prompt'] = stylePrompt;
    req.fields['lyrics'] = lyrics;
    req.fields['duration'] = duration.toString();
    req.fields['similarity'] = similarity.toString();
    req.fields['gpu_power'] = gpuPower.toString();
    req.fields['num_variants'] = numVariants.toString();
    if (sampleFilename != null) {
      req.fields['sample_filename'] = sampleFilename;
    } else {
      req.files.add(await http.MultipartFile.fromPath('file', sampleFile!.path));
    }

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dịch/phóng tác lời bài hát (tiếng Hoa hay bất kỳ tiếng nào) sang lời
  /// Việt - dùng cho tính năng "cover thành lời Việt". Trả về BẢN NHÁP, cần
  /// người dùng xem/sửa lại trước khi dùng cho remixMusic(lyrics: ...) -
  /// KHÔNG phải bản dịch hoàn chỉnh dùng thẳng (model nhỏ, xem tài liệu kỹ thuật).
  Future<Map<String, dynamic>> translateLyrics({required String lyrics}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/translate-lyrics-to-vietnamese'),
      headers: _pathSig('/translate-lyrics-to-vietnamese'),
      body: {'lyrics': lyrics},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<String>> getVoicePresets() async {
    final res = await http.get(Uri.parse('$baseUrl/voice-presets'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<String>.from(data['voices']);
  }

  /// MỚI - phục vụ luồng "Tạo từ ý tưởng" (mục 7v): người dùng đã có sẵn 1
  /// bài nhạc muốn dùng thẳng, KHÔNG cần AI tạo/biến tấu. CHỈ upload thẳng,
  /// không tốn GPU - khác `remixMusic()` (luôn chạy AI biến tấu qua ACE-Step).
  Future<Map<String, dynamic>> uploadMusic({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-music'));
    req.headers.addAll(_pathSig('/upload-music'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Upload file .pth giọng mới trực tiếp trong app - đỡ phải tự tay tải lên
  /// Google Drive qua giao diện Drive.
  Future<Map<String, dynamic>> uploadVoice({
    required File pthFile,
    required String voiceName,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-voice'));
    req.headers.addAll(_pathSig('/upload-voice'));
    req.fields['voice_name'] = voiceName;
    req.files.add(await http.MultipartFile.fromPath('file', pthFile.path));

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tự huấn luyện giọng mới từ 1 file ghi âm - CHẠY NỀN (bất đồng bộ), trả
  /// về {status, job_id, voice_id} NGAY, theo dõi tiếp qua /progress (dùng
  /// ProgressPoller như /apply-voice) - KHÔNG đợi tới xong như uploadVoice().
  /// Có thể mất tới hàng chục phút - xem ghi chú trong app.py.
  Future<Map<String, dynamic>> trainVoice({
    required File audioFile,
    required String voiceName,
    int epochs = 50,
    String hmacSecret = '', // MỚI - xem _hmacHeaders(); để trống = không ký (mặc định)
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/train-voice'));
    req.fields['voice_name'] = voiceName;
    req.fields['epochs'] = epochs.toString();
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    req.headers.addAll(_hmacHeaders(voiceName, hmacSecret)); // phải ký ĐÚNG field voice_name, khớp app.py

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<Map<String, dynamic>>> getVideoStyles() async {
    // SỬA (mục 7zc2) - backend giờ trả về danh sách phong cách KÈM `label` và
    // `lipsync_ok` (trước chỉ trả về list tên id đơn giản) - đổi kiểu trả về
    // từ List<String> sang List<Map> để Flutter biết phong cách nào được
    // phép bật công tắc Lipsync.
    final res = await http.get(Uri.parse('$baseUrl/video-styles'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<Map<String, dynamic>>.from(data['styles']);
  }

  /// MỚI (mục 7zc2) - "Character Sheet": sinh RIÊNG 1 ảnh tham chiếu nhân vật
  /// để xem trước, KHÔNG bắt đầu tạo cả MV - dùng trước khi vào GeneratingScreen.
  Future<Map<String, dynamic>> generateCharacterReference({
    required String characterDesc,
    required String styleId,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-character-reference'),
      headers: _pathSig('/generate-character-reference'),
      body: {'character_desc': characterDesc, 'style_id': styleId},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> applyVoice({
    required String audioFilename,
    required String voiceId,
    int gpuPower = 70,
    int pitchShift = 0,
    bool enableFormantShift = false, // MỚI - xem _apply_formant_shift trong app.py, TẮT mặc định (thử nghiệm)
    double formantQuefrencyMs = 1.5, // MỚI - chỉ có tác dụng khi enableFormantShift=true
    bool enableDeessing = false, // MỚI - xem _apply_deessing trong app.py, TẮT mặc định (thử nghiệm)
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/apply-voice'),
      headers: _pathSig('/apply-voice'),
      body: {
        'audio_filename': audioFilename,
        'voice_id': voiceId,
        'gpu_power': gpuPower.toString(),
        'pitch_shift': pitchShift.toString(),
        'enable_formant_shift': enableFormantShift.toString(),
        'formant_quefrency_ms': formantQuefrencyMs.toString(),
        'enable_deessing': enableDeessing.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Bắt đầu (hoặc TIẾP TỤC nếu truyền [resumeJobId]) job tạo MV chạy nền.
  /// Trả về {status, job_id, scene_dir_id} NGAY - không đợi xong. Theo dõi
  /// tiếp qua RealtimeClient (WebSocket) - server sẽ tự đẩy tiến trình + file.
  Future<Map<String, dynamic>> generateMv({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    int gpuPower = 70,
    int numInferenceSteps = 20,
    double guidanceScale = 7.5,
    String? resumeJobId,
    String characterDesc = '',
    bool enableMotionCamera = true,
    List<String>? scenePrompts,
    String? videoBackend,
    String? characterReferenceFilename, // MỚI (mục 7zc2) - tái dùng ảnh đã xác nhận qua CharacterReferenceScreen
    bool enableLipsync = false, // MỚI (mục 7zc2) - backend tự bỏ qua nếu styleId không hỗ trợ
    String? lipsyncBackend, // MỚI (mục 7zc9) - "wav2lip" (mặc định server) hoặc "musetalk", xem getLipsyncBackends()
    String lyrics = '', // MỚI (mục 7zc4) - để trống thì backend tự bỏ qua bước sinh phụ đề động (karaoke)
    bool enableSceneContinuity = false, // MỚI (mục 7zc5) - backend tự bỏ qua nếu videoBackend không hỗ trợ
    bool enableColorMatch = true, // MỚI - "Color Grading" tự động, backend tự bỏ qua an toàn nếu lỗi
    bool enableSpeedRamping = false, // MỚI - "Beat-Reactive Speed Ramping" thử nghiệm, xem app.py
    bool enablePostFx = true, // MỚI - hiệu ứng hậu kỳ điện ảnh (vignette/grain/sharpen), xem post_processing_v2.py
    String postFxIntensity = 'light', // MỚI - "light" hoặc "strong", chỉ có ý nghĩa khi enablePostFx=true
    bool enableMotionSmoothing = false, // MỚI - làm mượt chuyển động (ffmpeg minterpolate, KHÔNG phải RIFE), tốn thời gian xử lý
    String motionSmoothingMethod = 'ffmpeg', // MỚI - "ffmpeg" hoặc "rife" (deep learning thật), chỉ có tác dụng khi enableMotionSmoothing=true
    bool enableRealesrganUpscale = false, // MỚI - upscale bằng Real-ESRGAN, CẦN backend đã cài thêm package + có GPU thật
    bool exportVertical = false, // MỚI - xuất thêm bản dọc 9:16 cho Shorts/TikTok/Reels
    String redoScenes = '', // MỚI (mục 23) - "0,2,5" (0-based): sinh lại các cảnh này khi resume, chỉ có nghĩa khi có resumeJobId
    bool redoFollowing = false, // MỚI (mục 23) - tạo lại cả các cảnh phía sau
    List<String>? sceneCameras, // MỚI (mục 23) - camera riêng từng cảnh, '' = tự động (khoá khớp CAMERA_CHOICES backend)
    String burnInLyrics = '', // MỚI (mục 23) - '' (tắt) | 'plain' | 'karaoke' - khắc phụ đề lời hát vào video, cần có `lyrics`
    bool structureSnap = false, // MỚI (mục 23, THỬ NGHIỆM) - dịch ranh giới cảnh về ranh giới đoạn bài hát
    String watermarkText = '', // MỚI (mục 25) - chữ watermark đóng lên video, '' = tắt
    bool fxMotionBlur = false, // MỚI (mục 26) - mờ chuyển động nhẹ (trộn khung)
    bool fxLightLeak = false, // MỚI (mục 26) - mảng sáng ấm trôi chậm
    bool fxBloom = false, // MỚI (mục 26) - phát sáng vùng sáng
    String exportPreset = '', // MỚI (mục 26) - '' (tắt) | 'youtube_1080p'
    String colorLook = '', // MỚI (mục 49) - '' (tắt) | 'warm' | 'cool' | 'teal_orange' | 'faded_film' - look màu cuối
    String upscaleFaceMode = 'skip', // MỚI (mục 26) - 'skip' (mặc định) | 'protect' (thử nghiệm)
    String settingDesc = '', // MỚI (mục 26) - bối cảnh cố định gắn vào prompt mọi cảnh
    Map<int, String>? userClips, // MỚI (mục 26) - {chỉ số cảnh: tên file từ uploadUserClip()} - cảnh tự quay thay cảnh AI
    String controlVideoFilename = '', // MỚI (mục 30) - tên file từ uploadControlVideo(); '' = không điều khiển chuyển động (chỉ Wan-VACE dùng)
    String lorasJson = '', // MỚI (mục 31) - GenerationSettings.lorasJson: LoRA người dùng đã chọn
    String comfyWorkflow = '', // MỚI (mục 31) - tên workflow ComfyUI (chỉ khi công nghệ video là comfyui)
    Map<int, String>? sceneReferenceImages, // MỚI (mục 39) - {chỉ số cảnh: tên file từ uploadSceneReference()} - ảnh bố cục riêng từng cảnh (chỉ Wan-VACE)
    String hmacSecret = '', // MỚI - xem _hmacHeaders(); để trống = không ký (mặc định)
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-mv'),
      headers: _hmacHeaders(audioFilename, hmacSecret), // phải ký ĐÚNG field audio_filename, khớp app.py
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'gpu_power': gpuPower.toString(),
        'num_inference_steps': numInferenceSteps.toString(),
        'guidance_scale': guidanceScale.toString(),
        if (resumeJobId != null) 'resume_job_id': resumeJobId,
        'character_desc': characterDesc,
        'enable_motion_camera': enableMotionCamera.toString(),
        if (scenePrompts != null) 'scene_prompts_json': jsonEncode(scenePrompts),
        if (videoBackend != null) 'video_backend': videoBackend,
        if (characterReferenceFilename != null) 'character_reference_filename': characterReferenceFilename,
        'enable_lipsync': enableLipsync.toString(),
        if (lipsyncBackend != null) 'lipsync_backend': lipsyncBackend,
        'lyrics': lyrics,
        'enable_scene_continuity': enableSceneContinuity.toString(),
        'enable_color_match': enableColorMatch.toString(),
        'enable_speed_ramping': enableSpeedRamping.toString(),
        'enable_post_fx': enablePostFx.toString(),
        'post_fx_intensity': postFxIntensity,
        'enable_motion_smoothing': enableMotionSmoothing.toString(),
        'motion_smoothing_method': motionSmoothingMethod,
        'enable_realesrgan_upscale': enableRealesrganUpscale.toString(),
        'export_vertical': exportVertical.toString(),
        if (redoScenes.isNotEmpty) 'redo_scenes': redoScenes,
        'redo_following': redoFollowing.toString(),
        if (sceneCameras != null) 'scene_cameras_json': jsonEncode(sceneCameras),
        'burn_in_lyrics': burnInLyrics,
        'structure_snap': structureSnap.toString(),
        if (watermarkText.trim().isNotEmpty) 'watermark_text': watermarkText.trim(),
        'fx_motion_blur': fxMotionBlur.toString(),
        'fx_light_leak': fxLightLeak.toString(),
        'fx_bloom': fxBloom.toString(),
        if (exportPreset.isNotEmpty) 'export_preset': exportPreset,
        if (colorLook.isNotEmpty) 'color_look': colorLook,
        'upscale_face_mode': upscaleFaceMode,
        if (settingDesc.trim().isNotEmpty) 'setting_desc': settingDesc.trim(),
        if (userClips != null && userClips.isNotEmpty)
          'user_clips': jsonEncode(userClips.map((k, v) => MapEntry(k.toString(), v))),
        if (controlVideoFilename.trim().isNotEmpty) 'control_video_filename': controlVideoFilename.trim(),
        if (lorasJson.isNotEmpty) 'loras_json': lorasJson,
        if (comfyWorkflow.trim().isNotEmpty) 'comfy_workflow': comfyWorkflow.trim(),
        if (sceneReferenceImages != null && sceneReferenceImages.isNotEmpty)
          'scene_reference_images': jsonEncode(sceneReferenceImages.map((k, v) => MapEntry(k.toString(), v))),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - bước "kịch bản cảnh" (storyboard/shot-list): trả về prompt GỢI Ý
  /// riêng cho từng cảnh (ghép style + character_desc + mood theo nhịp + đoạn
  /// lyric tương ứng nếu có) - CHỈ DÙNG CPU, không tốn GPU, gọi lại thoải mái.
  /// Người dùng xem/sửa rồi gửi lại qua generateMv(scenePrompts: ...).
  /// MỚI - cho người dùng ĐÃ CÓ SẴN kịch bản (file .txt, mỗi dòng = 1 cảnh)
  /// upload thẳng vào, BỎ QUA hoàn toàn bước dàn dựng tự động/LLM. Số dòng
  /// PHẢI khớp đúng số cảnh thật (xem `expected_scenes` trong response lỗi
  /// nếu không khớp) - gọi `analyzeBeats()` trước để biết trước số cảnh cần.
  Future<Map<String, dynamic>> parseStoryboardFile({
    required String audioFilename,
    required String styleId,
    required File scriptFile,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/parse-storyboard-file'));
    req.headers.addAll(_pathSig('/parse-storyboard-file'));
    req.fields['audio_filename'] = audioFilename;
    req.fields['style_id'] = styleId;
    req.fields['beats_per_scene'] = beatsPerScene.toString();
    req.fields['max_scenes'] = maxScenes.toString();
    req.fields['character_desc'] = characterDesc;
    req.files.add(await http.MultipartFile.fromPath('script_file', scriptFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> buildStoryboard({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
    String lyrics = '',
    String? genre,
    bool useLlmScript = false,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/build-storyboard'),
      headers: _pathSig('/build-storyboard'),
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'character_desc': characterDesc,
        'lyrics': lyrics,
        if (genre != null) 'genre': genre,
        'use_llm_script': useLlmScript.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa nhanh (bản nháp)" - KHÁC repaintMusicSection() về bản chất: chỉ
  /// sinh 1 đoạn NGẮN rồi ghép crossfade vào bài gốc - RẺ hơn nhiều (chi phí
  /// tỉ lệ với độ dài đoạn sửa, không phải cả bài), nhưng có thể nghe ra "vết
  /// nối" nhẹ - dùng làm bản NHÁP để nghe thử lời/hướng mới trước khi tốn GPU
  /// làm bản hoàn chỉnh. Xem docstring đầy đủ ở app.py.
  Future<Map<String, dynamic>> quickEditMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/quick-edit-music-section'),
      headers: _pathSig('/quick-edit-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lại 1 đoạn" (giống Suno/Udio): CHỈ sinh lại đúng khoảng
  /// [startTime, endTime] (giây), giữ nguyên phần còn lại của bài. Trả về
  /// file MỚI (không ghi đè bản gốc) để nghe thử/so sánh trước khi quyết
  /// định giữ bản nào - dùng `task_type="repaint"` của ACE-Step, xem docstring
  /// đầy đủ ở app.py.
  Future<Map<String, dynamic>> repaintMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/repaint-music-section'),
      headers: _pathSig('/repaint-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lời, cố giữ giai điệu" (mục 7zb) - KHÁC repaintMusicSection():
  /// hàm này CHỈ ĐỔI LỜI, backend tự thử "giữ giai điệu" trước, tự rơi về
  /// cách thường nếu không khả dụng (xem `used_mode` trong kết quả trả về -
  /// `"edit"` hay `"repaint_fallback"`, CHƯA CHẠY THỬ để biết nhánh nào sẽ
  /// thật sự xảy ra). Dùng khi CHỈ muốn sửa vài chữ, không muốn đổi cả giai
  /// điệu/phong cách đoạn đó.
  Future<Map<String, dynamic>> editLyricsSection({
    required String audioFilename,
    required String newLyrics,
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/edit-lyrics-section'),
      headers: _pathSig('/edit-lyrics-section'),
      body: {
        'audio_filename': audioFilename,
        'new_lyrics': newLyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - lấy danh sách backend video CÓ THẬT từ server (KHÔNG hardcode
  /// tên/label ở Flutter - đúng yêu cầu "phổ quát không hardcode"). Server
  /// thêm backend mới ở `VIDEO_BACKENDS` (app.py) là app TỰ THẤY ngay, không
  /// cần build lại APK.
  Future<Map<String, dynamic>> getVideoBackends() async {
    final res = await http.get(Uri.parse('$baseUrl/video-backends'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 7zc9) - lấy danh sách backend LIPSYNC CÓ THẬT từ server, THEO
  /// ĐÚNG pattern getVideoBackends() ở trên (KHÔNG hardcode tên/label ở
  /// Flutter). Server thêm backend mới ở `LIPSYNC_BACKENDS` (app.py) là app
  /// TỰ THẤY ngay, không cần build lại APK.
  Future<Map<String, dynamic>> getLipsyncBackends() async {
    final res = await http.get(Uri.parse('$baseUrl/lipsync-backends'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> getVideoGenres() async {
    final res = await http.get(Uri.parse('$baseUrl/video-genres'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phân tích nhịp NHANH (chỉ CPU) để xem trước ước tính số cảnh/tempo -
  /// dùng ở màn hình Xem lại TRƯỚC KHI tốn GPU tạo MV thật.
  Future<Map<String, dynamic>> analyzeBeats({
    required String audioFilename,
    int beatsPerScene = 4,
    int maxScenes = 8,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/analyze-beats'),
      headers: _pathSig('/analyze-beats'),
      body: {
        'audio_filename': audioFilename,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Yêu cầu huỷ job /generate-mv đang chạy. Không tức thời - job dừng ở
  /// lần kiểm tra cờ tiếp theo bên backend (thường vài giây sau).
  Future<Map<String, dynamic>> abortJob() async {
    final res = await http.post(Uri.parse('$baseUrl/abort-job'), headers: _pathSig('/abort-job'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  // ---------------- MỚI (mục 26) ----------------

  /// Ước lượng thời gian tạo MV TRƯỚC khi bấm tạo - CHỈ dựa trên thời gian THẬT của các lần tạo trước (cùng backend video).
  /// Trả {status, seconds (null nếu chưa có số đo), samples, basis, warn, warn_hours}. KHÔNG bịa số khi chưa có dữ liệu.
  Future<Map<String, dynamic>> estimateJob({required int numScenes, String? videoBackend, int gpuPower = 70}) async {
    final uri = Uri.parse('$baseUrl/estimate-job').replace(queryParameters: {
      'num_scenes': numScenes.toString(),
      if (videoBackend != null) 'video_backend': videoBackend,
      'gpu_power': gpuPower.toString(),
    });
    final res = await http.get(uri);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải 1 clip TỰ QUAY lên server để dùng thay cảnh AI. Trả {status:'ok', filename, duration_s, width, height} hoặc
  /// {status:'error', note}. Giới hạn 300MB/clip; server kiểm tra có luồng hình và dài >= 0.5 giây.
  Future<Map<String, dynamic>> uploadUserClip({required File clipFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-user-clip'));
    req.headers.addAll(_pathSig('/upload-user-clip'));
    req.files.add(await http.MultipartFile.fromPath('file', clipFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 39, PDF-2 mục 8.2) - tải 1 ảnh tham chiếu BỐ CỤC cho MỘT cảnh. Trả {status:'ok', filename, width, height} hoặc {status:'error', note}. Backend đổi sang PNG, thu nhỏ tối đa 1024px.
  Future<Map<String, dynamic>> uploadSceneReference({required File imageFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-scene-reference'));
    req.headers.addAll(_pathSig('/upload-scene-reference'));
    req.files.add(await http.MultipartFile.fromPath('file', imageFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 31) - LoRA do người dùng thêm. Chỗ để thêm file: thư mục `loras/` trên Google Drive của backend (chép .safetensors vào đó, không giới hạn dung lượng)
  /// hoặc tải lên từ app (tới ~90MB). Trả {status:'ok', dir, loras:[{file,size_mb,name,base,weight,trigger,note}], backend_base, max_per_mv}.
  Future<Map<String, dynamic>> listLoras() async {
    final res = await http.get(Uri.parse('$baseUrl/loras'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> uploadLora({required File loraFile, String base = 'any', String trigger = '', String name = ''}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-lora'));
    req.headers.addAll(_pathSig('/upload-lora'));
    req.fields['base'] = base;
    req.fields['trigger'] = trigger;
    req.fields['name'] = name;
    req.files.add(await http.MultipartFile.fromPath('file', loraFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> setLoraMeta({required String file, String? name, String? base, String? trigger, double? weight}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/lora-meta'),
      headers: _pathSig('/lora-meta'),
      body: {
        'file': file,
        if (name != null) 'name': name,
        if (base != null) 'base': base,
        if (trigger != null) 'trigger': trigger,
        if (weight != null) 'weight': weight.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> deleteLora(String file) async {
    final res = await http.post(Uri.parse('$baseUrl/delete-lora'), headers: _pathSig('/delete-lora'), body: {'file': file});
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 31) - danh sách workflow ComfyUI trong thư mục `comfy_workflows/` trên Drive + ComfyUI có đang chạy không.
  /// Trả {status:'ok', dir, comfy_running, workflows:[{name,has_map,title,kind,inputs}]}.
  Future<Map<String, dynamic>> listComfyWorkflows() async {
    final res = await http.get(Uri.parse('$baseUrl/comfy/workflows'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 33) - ĐIỀU KHIỂN COLAB TỪ APP (module backend control_extra.py + control_router_extra.py). Trạng thái tổng hợp: model từng khe, ComfyUI,
  /// API miễn phí (KHÔNG có API key), tác vụ nền. Chỉ ĐỌC nên không cần khoá HMAC. Trả {status:'ok', busy, hmac_enabled, models, comfy, cloud, tasks, download_kinds, downloaded, comfy_args_allowed}.
  Future<Map<String, dynamic>> controlStatus() async {
    final res = await http.get(Uri.parse('$baseUrl/control/status'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 35) - KIỂM TRA MÔI TRƯỜNG trước khi cài/chạy: git, ffmpeg, uv, ổ đĩa, GPU, kết nối tới HuggingFace/GitHub/PyTorch, khoá HMAC.
  /// Chỉ ĐỌC. Trả {status:'ok', checks:[{id,label,level:'ok'|'warn'|'error',detail}]}.
  Future<Map<String, dynamic>> controlPreflight() async {
    final res = await http.get(Uri.parse('$baseUrl/control/preflight'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 53) - THỬ khoá Pexels/Pixabay đang đặt (GET /stock-test-keys; mỗi khoá 1 truy vấn nhỏ, không tải video, không trả khoá về app).
  /// Trả {status:'ok', results:[{provider, configured, ok, message}]}; lỗi: {status:'error', note}.
  Future<Map<String, dynamic>> getStockKeyTest() async {
    final res = await http.get(Uri.parse('$baseUrl/stock-test-keys'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 53) - mẫu \"một chạm\" theo thể loại nhạc (GET /mv-templates). Trả {status:'ok', templates:[{id,label,description,music_prompt,genres,moods,style_id,video_genre}]}.
  Future<Map<String, dynamic>> getMvTemplates() async {
    final res = await http.get(Uri.parse('$baseUrl/mv-templates'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 52) - KIỂM TRA GIẤY PHÉP các khe model TRƯỚC khi tạo MV (backend hỏi Hugging Face, tối đa ~30 giây, rồi đối chiếu danh sách giấy phép đã đọc).
  /// Chỉ ĐỌC. Trả {status:'ok', commercial_mode:bool, rows:[{slot,id,status,license,reasons,online}], notes:[String]}; lỗi: {status:'error', note}. KHÔNG phải tư vấn pháp lý.
  Future<Map<String, dynamic>> getLicenseAudit() async {
    final res = await http.get(Uri.parse('$baseUrl/license-audit'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 33) - chi tiết 1 tác vụ nền (tải file, cài ComfyUI) kèm nhật ký. Trả {status:'ok', task:{id,status,progress,note,logs,...}}.
  Future<Map<String, dynamic>> controlTask(String taskId) async {
    final res = await http.get(Uri.parse('$baseUrl/control/task/$taskId'));
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 33) - mọi thao tác GHI/CHẠY (đổi model, cài/bật ComfyUI, tải file model, lưu API key...). Backend BẮT BUỘC khoá HMAC: chữ ký tính trên chuỗi
  /// 'control:<action>' (action khớp từng endpoint, vd 'model-select', 'comfy-start', 'download', 'cloud-config') - cùng cơ chế /generate-mv. [path] là phần sau '/control/'.
  /// Trả map backend ({status:'ok'|'error', note, code?: 'hmac_required'|'bad_signature'|'busy', ...}).
  Future<Map<String, dynamic>> controlPost(String action, String path, Map<String, String> body, String hmacSecret) async {
    final res = await http.post(
      Uri.parse('$baseUrl/control/$path'),
      headers: _hmacHeaders('control:$action', hmacSecret),
      body: body,
    );
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 33) - đặt workflow ComfyUI từ điện thoại (thay vì chép file vào Drive): [workflowFile] = JSON xuất bằng "Save (API Format)", [mappingFile] = <tên>.map.json (tuỳ chọn).
  /// Backend kiểm hợp lệ trước khi lưu. Trả {status:'ok', name, has_map} hoặc {status:'error', note, problems}.
  /// MỚI (mục 38): nhận cả workflow dạng GIAO DIỆN (file RuneXX/Kijai công bố) - backend tự chuyển sang dạng API (cần ComfyUI đang chạy); [autoMap] = true và không kèm
  /// [mappingFile] -> backend TỰ ĐOÁN ánh xạ và trả `auto_map_notes` (mỗi quyết định 1 dòng, người dùng chịu trách nhiệm kiểm lại) + `converted`/`convert_report`.
  Future<Map<String, dynamic>> uploadComfyWorkflow({required String name, required File workflowFile, File? mappingFile, bool autoMap = false}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/comfy/upload-workflow'));
    req.headers.addAll(_pathSig('/comfy/upload-workflow'));
    req.fields['name'] = name;
    req.fields['auto_map'] = autoMap ? 'true' : 'false';
    req.files.add(await http.MultipartFile.fromPath('workflow', workflowFile.path));
    if (mappingFile != null) {
      req.files.add(await http.MultipartFile.fromPath('mapping', mappingFile.path));
    }
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  /// MỚI (mục 30) - ĐO ĐỘ RÕ LỜI: backend nhận dạng lại giọng hát của file nhạc đã sinh (Demucs + Qwen3-ASR) rồi so với `lyrics` đã nhập.
  /// Trả {status:'ok', clarity_pct, cer, cer_toneless, tone_penalty_pct, verdict, transcribed} hoặc {status:'error', note}. Tốn vài chục giây GPU
  /// (không chạy khi backend đang bận). Dùng TRƯỚC khi tạo video để biết lời tiếng Việt có hát ra đủ rõ không.
  Future<Map<String, dynamic>> checkLyricClarity({
    required String audioFilename,
    required String lyrics,
    String languageHint = 'vi',
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/lyric-clarity'),
      headers: _pathSig('/lyric-clarity'),
      body: {'audio_filename': audioFilename, 'lyrics': lyrics, 'language_hint': languageHint},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI (mục 30) - tải video THAM CHIẾU CHUYỂN ĐỘNG (vũ đạo/góc máy) cho Wan-VACE: mỗi cảnh lấy 1 đoạn video này, tách thành khung cạnh (canny) để điều khiển
  /// chuyển động nhưng giữ nhân vật/phong cách của bạn. Trả {status:'ok', filename, duration_s, ...} hoặc {status:'error', note}. Giới hạn dung lượng như clip tự quay.
  Future<Map<String, dynamic>> uploadControlVideo({required File videoFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-control-video'));
    req.headers.addAll(_pathSig('/upload-control-video'));
    req.files.add(await http.MultipartFile.fromPath('file', videoFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// "Gói đăng bài": tiêu đề gợi ý + mô tả có chapter + hashtag + nhắc khai báo nội dung AI của YouTube. Không tốn GPU.
  /// Trả {status, titles, description, hashtags, chapters, disclosure_note, text}.
  Future<Map<String, dynamic>> getPublishKit({
    required String sceneDirId,
    required String title,
    String lyrics = '',
    String styleLabel = '',
    String channel = '',
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/publish-kit'),
      headers: _pathSig('/publish-kit'),
      body: {
        'scene_dir_id': sceneDirId,
        'title': title,
        'lyrics': lyrics,
        'style_label': styleLabel,
        'channel': channel,
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Thumbnail 1280x720 có tiêu đề (JPEG). Ném Exception với lời nhắn của server nếu không tạo được.
  Future<List<int>> getTitledThumbnail({required String sceneDirId, required String title, String subtitle = ''}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/titled-thumbnail'),
      headers: _pathSig('/titled-thumbnail'),
      body: {'scene_dir_id': sceneDirId, 'title': title, 'subtitle': subtitle},
    );
    if (res.statusCode != 200) {
      var note = trv('Lỗi {0}', [res.statusCode]);
      try {
        note = (jsonDecode(res.body)['note'] as String?) ?? note;
      } catch (_) {}
      throw Exception(note);
    }
    return res.bodyBytes;
  }

  /// Dự phòng nếu không dùng được WebSocket: {job_id, stage, percent, detail,
  /// artifacts:[{filename,kind}], done, error, notes:[String] (mục 39: tính năng bị tắt/bỏ qua giữa chừng)}.
  Future<Map<String, dynamic>> getProgress() async {
    final res = await http.get(Uri.parse('$baseUrl/progress'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dự phòng: tải qua HTTP thường nếu cần (WebSocket đã đẩy file trực tiếp
  /// nên bình thường không cần gọi hàm này).
  String downloadUrl(String relativePath) => '$baseUrl/download/$relativePath';

  /// Dùng khi ĐANG Ở CHẾ ĐỘ DỰ PHÒNG (poll, không phải WebSocket) và cần tải
  /// file LỚN (vd MV cuối) - lấy link Google Drive thay vì gọi downloadUrl()
  /// trực tiếp cho file lớn (sẽ dính lại giới hạn 100MB/request của Cloudflare).
  Future<String?> getDriveLink(String relativePath) async {
    final res = await http.get(Uri.parse('$baseUrl/drive-link/$relativePath'));
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body);
    return data['drive_link'] as String?;
  }

  void _checkOk(http.Response res) {
    if (res.statusCode != 200) {
      throw Exception(trv('API lỗi ({0}): {1}', [res.statusCode, res.body]));
    }
  }
}
