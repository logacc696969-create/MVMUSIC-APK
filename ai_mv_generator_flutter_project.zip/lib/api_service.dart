import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// Đổi URL này mỗi khi restart Colab (cloudflared cấp URL mới).
class ApiService {
  String baseUrl;

  ApiService({required this.baseUrl});

  /// wss://... (hoặc ws://... nếu baseUrl không phải https) dùng cho RealtimeClient.
  String get wsUrl {
    final uri = Uri.parse(baseUrl);
    final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
    return uri.replace(scheme: scheme, path: '/ws/updates').toString();
  }

  Future<Map<String, dynamic>> generateMusic({
    required String prompt,
    String lyrics = '',
    double duration = 30,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-music'),
      body: {
        'prompt': prompt,
        'lyrics': lyrics,
        'duration': duration.toString(),
        'gpu_power': gpuPower.toString(),
        'num_variants': numVariants.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải 1 file nhạc mẫu lên server để DÙNG LẠI nhiều lần (phiên âm lời +
  /// cover) mà không phải upload lại 2-3 lần cho cùng 1 file. Trả về tên
  /// file trên server - dùng cho `transcribeLyrics()` và
  /// `remixMusic(sampleFilename: ...)`.
  Future<Map<String, dynamic>> uploadSampleAudio({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-sample-audio'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tải audio từ 1 link YouTube về server - dùng khi chỉ có link, chưa có
  /// file nhạc trong tay. Trả về CÙNG dạng response với uploadSampleAudio()
  /// (`{"status", "filename"}`) - dùng tiếp giống hệt file tự upload.
  Future<Map<String, dynamic>> downloadYoutubeAudio({required String url}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/download-youtube-audio'),
      body: {'url': url},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phiên âm lời TỪ FILE NHẠC (đã có trên server qua uploadSampleAudio()
  /// hoặc downloadYoutubeAudio()) - dùng khi không có sẵn lời gốc để dán
  /// tay. Kết quả thường ở ngôn ngữ gốc bài hát - đưa tiếp vào
  /// translateLyrics() để có bản Việt.
  Future<Map<String, dynamic>> transcribeLyrics({required String sampleFilename, String languageHint = ''}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/transcribe-lyrics'),
      body: {'sample_filename': sampleFilename, 'language_hint': languageHint},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> remixMusic({
    File? sampleFile,
    String? sampleFilename, // MỚI - file ĐÃ CÓ SẴN trên server (upload trước hoặc từ YouTube) - dùng 1 trong 2, không phải cả 2
    String stylePrompt = '',
    String lyrics = '',
    double duration = 30,
    double similarity = 0.3,
    int gpuPower = 70,
    int numVariants = 1,
  }) async {
    assert(sampleFile != null || sampleFilename != null, 'Cần có sampleFile hoặc sampleFilename');
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/remix-music'));
    req.fields['style_prompt'] = stylePrompt;
    req.fields['lyrics'] = lyrics;
    req.fields['duration'] = duration.toString();
    req.fields['similarity'] = similarity.toString();
    req.fields['gpu_power'] = gpuPower.toString();
    req.fields['num_variants'] = numVariants.toString();
    if (sampleFilename != null) {
      req.fields['sample_filename'] = sampleFilename;
    } else {
      req.files.add(await http.MultipartFile.fromPath('file', sampleFile!.path));
    }

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dịch/phóng tác lời bài hát (tiếng Hoa hay bất kỳ tiếng nào) sang lời
  /// Việt - dùng cho tính năng "cover thành lời Việt". Trả về BẢN NHÁP, cần
  /// người dùng xem/sửa lại trước khi dùng cho remixMusic(lyrics: ...) -
  /// KHÔNG phải bản dịch hoàn chỉnh dùng thẳng (model nhỏ, xem tài liệu kỹ thuật).
  Future<Map<String, dynamic>> translateLyrics({required String lyrics}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/translate-lyrics-to-vietnamese'),
      body: {'lyrics': lyrics},
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<String>> getVoicePresets() async {
    final res = await http.get(Uri.parse('$baseUrl/voice-presets'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<String>.from(data['voices']);
  }

  /// MỚI - phục vụ luồng "Tạo từ ý tưởng" (mục 7v): người dùng đã có sẵn 1
  /// bài nhạc muốn dùng thẳng, KHÔNG cần AI tạo/biến tấu. CHỈ upload thẳng,
  /// không tốn GPU - khác `remixMusic()` (luôn chạy AI biến tấu qua ACE-Step).
  Future<Map<String, dynamic>> uploadMusic({required File audioFile}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-music'));
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Upload file .pth giọng mới trực tiếp trong app - đỡ phải tự tay tải lên
  /// Google Drive qua giao diện Drive.
  Future<Map<String, dynamic>> uploadVoice({
    required File pthFile,
    required String voiceName,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload-voice'));
    req.fields['voice_name'] = voiceName;
    req.files.add(await http.MultipartFile.fromPath('file', pthFile.path));

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Tự huấn luyện giọng mới từ 1 file ghi âm - CHẠY NỀN (bất đồng bộ), trả
  /// về {status, job_id, voice_id} NGAY, theo dõi tiếp qua /progress (dùng
  /// ProgressPoller như /apply-voice) - KHÔNG đợi tới xong như uploadVoice().
  /// Có thể mất tới hàng chục phút - xem ghi chú trong app.py.
  Future<Map<String, dynamic>> trainVoice({
    required File audioFile,
    required String voiceName,
    int epochs = 50,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/train-voice'));
    req.fields['voice_name'] = voiceName;
    req.fields['epochs'] = epochs.toString();
    req.files.add(await http.MultipartFile.fromPath('file', audioFile.path));

    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<List<String>> getVideoStyles() async {
    final res = await http.get(Uri.parse('$baseUrl/video-styles'));
    _checkOk(res);
    final data = jsonDecode(res.body);
    return List<String>.from(data['styles']);
  }

  Future<Map<String, dynamic>> applyVoice({
    required String audioFilename,
    required String voiceId,
    int gpuPower = 70,
    int pitchShift = 0,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/apply-voice'),
      body: {
        'audio_filename': audioFilename,
        'voice_id': voiceId,
        'gpu_power': gpuPower.toString(),
        'pitch_shift': pitchShift.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Bắt đầu (hoặc TIẾP TỤC nếu truyền [resumeJobId]) job tạo MV chạy nền.
  /// Trả về {status, job_id, scene_dir_id} NGAY - không đợi xong. Theo dõi
  /// tiếp qua RealtimeClient (WebSocket) - server sẽ tự đẩy tiến trình + file.
  Future<Map<String, dynamic>> generateMv({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    int gpuPower = 70,
    int numInferenceSteps = 20,
    double guidanceScale = 7.5,
    String? resumeJobId,
    String characterDesc = '',
    bool enableMotionCamera = true,
    List<String>? scenePrompts,
    String? videoBackend,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/generate-mv'),
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'gpu_power': gpuPower.toString(),
        'num_inference_steps': numInferenceSteps.toString(),
        'guidance_scale': guidanceScale.toString(),
        if (resumeJobId != null) 'resume_job_id': resumeJobId,
        'character_desc': characterDesc,
        'enable_motion_camera': enableMotionCamera.toString(),
        if (scenePrompts != null) 'scene_prompts_json': jsonEncode(scenePrompts),
        if (videoBackend != null) 'video_backend': videoBackend,
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - bước "kịch bản cảnh" (storyboard/shot-list): trả về prompt GỢI Ý
  /// riêng cho từng cảnh (ghép style + character_desc + mood theo nhịp + đoạn
  /// lyric tương ứng nếu có) - CHỈ DÙNG CPU, không tốn GPU, gọi lại thoải mái.
  /// Người dùng xem/sửa rồi gửi lại qua generateMv(scenePrompts: ...).
  /// MỚI - cho người dùng ĐÃ CÓ SẴN kịch bản (file .txt, mỗi dòng = 1 cảnh)
  /// upload thẳng vào, BỎ QUA hoàn toàn bước dàn dựng tự động/LLM. Số dòng
  /// PHẢI khớp đúng số cảnh thật (xem `expected_scenes` trong response lỗi
  /// nếu không khớp) - gọi `analyzeBeats()` trước để biết trước số cảnh cần.
  Future<Map<String, dynamic>> parseStoryboardFile({
    required String audioFilename,
    required String styleId,
    required File scriptFile,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/parse-storyboard-file'));
    req.fields['audio_filename'] = audioFilename;
    req.fields['style_id'] = styleId;
    req.fields['beats_per_scene'] = beatsPerScene.toString();
    req.fields['max_scenes'] = maxScenes.toString();
    req.fields['character_desc'] = characterDesc;
    req.files.add(await http.MultipartFile.fromPath('script_file', scriptFile.path));
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> buildStoryboard({
    required String audioFilename,
    required String styleId,
    int beatsPerScene = 4,
    int maxScenes = 8,
    String characterDesc = '',
    String lyrics = '',
    String? genre,
    bool useLlmScript = false,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/build-storyboard'),
      body: {
        'audio_filename': audioFilename,
        'style_id': styleId,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
        'character_desc': characterDesc,
        'lyrics': lyrics,
        if (genre != null) 'genre': genre,
        'use_llm_script': useLlmScript.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa nhanh (bản nháp)" - KHÁC repaintMusicSection() về bản chất: chỉ
  /// sinh 1 đoạn NGẮN rồi ghép crossfade vào bài gốc - RẺ hơn nhiều (chi phí
  /// tỉ lệ với độ dài đoạn sửa, không phải cả bài), nhưng có thể nghe ra "vết
  /// nối" nhẹ - dùng làm bản NHÁP để nghe thử lời/hướng mới trước khi tốn GPU
  /// làm bản hoàn chỉnh. Xem docstring đầy đủ ở app.py.
  Future<Map<String, dynamic>> quickEditMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/quick-edit-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lại 1 đoạn" (giống Suno/Udio): CHỈ sinh lại đúng khoảng
  /// [startTime, endTime] (giây), giữ nguyên phần còn lại của bài. Trả về
  /// file MỚI (không ghi đè bản gốc) để nghe thử/so sánh trước khi quyết
  /// định giữ bản nào - dùng `task_type="repaint"` của ACE-Step, xem docstring
  /// đầy đủ ở app.py.
  Future<Map<String, dynamic>> repaintMusicSection({
    required String audioFilename,
    required String prompt,
    String lyrics = '',
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/repaint-music-section'),
      body: {
        'audio_filename': audioFilename,
        'prompt': prompt,
        'lyrics': lyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - "Sửa lời, cố giữ giai điệu" (mục 7zb) - KHÁC repaintMusicSection():
  /// hàm này CHỈ ĐỔI LỜI, backend tự thử "giữ giai điệu" trước, tự rơi về
  /// cách thường nếu không khả dụng (xem `used_mode` trong kết quả trả về -
  /// `"edit"` hay `"repaint_fallback"`, CHƯA CHẠY THỬ để biết nhánh nào sẽ
  /// thật sự xảy ra). Dùng khi CHỈ muốn sửa vài chữ, không muốn đổi cả giai
  /// điệu/phong cách đoạn đó.
  Future<Map<String, dynamic>> editLyricsSection({
    required String audioFilename,
    required String newLyrics,
    required double startTime,
    required double endTime,
    int gpuPower = 70,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/edit-lyrics-section'),
      body: {
        'audio_filename': audioFilename,
        'new_lyrics': newLyrics,
        'start_time': startTime.toString(),
        'end_time': endTime.toString(),
        'gpu_power': gpuPower.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// MỚI - lấy danh sách backend video CÓ THẬT từ server (KHÔNG hardcode
  /// tên/label ở Flutter - đúng yêu cầu "phổ quát không hardcode"). Server
  /// thêm backend mới ở `VIDEO_BACKENDS` (app.py) là app TỰ THẤY ngay, không
  /// cần build lại APK.
  Future<Map<String, dynamic>> getVideoBackends() async {
    final res = await http.get(Uri.parse('$baseUrl/video-backends'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> getVideoGenres() async {
    final res = await http.get(Uri.parse('$baseUrl/video-genres'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Phân tích nhịp NHANH (chỉ CPU) để xem trước ước tính số cảnh/tempo -
  /// dùng ở màn hình Xem lại TRƯỚC KHI tốn GPU tạo MV thật.
  Future<Map<String, dynamic>> analyzeBeats({
    required String audioFilename,
    int beatsPerScene = 4,
    int maxScenes = 8,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/analyze-beats'),
      body: {
        'audio_filename': audioFilename,
        'beats_per_scene': beatsPerScene.toString(),
        'max_scenes': maxScenes.toString(),
      },
    );
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Yêu cầu huỷ job /generate-mv đang chạy. Không tức thời - job dừng ở
  /// lần kiểm tra cờ tiếp theo bên backend (thường vài giây sau).
  Future<Map<String, dynamic>> abortJob() async {
    final res = await http.post(Uri.parse('$baseUrl/abort-job'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dự phòng nếu không dùng được WebSocket: {job_id, stage, percent, detail,
  /// artifacts:[{filename,kind}], done, error}.
  Future<Map<String, dynamic>> getProgress() async {
    final res = await http.get(Uri.parse('$baseUrl/progress'));
    _checkOk(res);
    return jsonDecode(res.body);
  }

  /// Dự phòng: tải qua HTTP thường nếu cần (WebSocket đã đẩy file trực tiếp
  /// nên bình thường không cần gọi hàm này).
  String downloadUrl(String relativePath) => '$baseUrl/download/$relativePath';

  /// Dùng khi ĐANG Ở CHẾ ĐỘ DỰ PHÒNG (poll, không phải WebSocket) và cần tải
  /// file LỚN (vd MV cuối) - lấy link Google Drive thay vì gọi downloadUrl()
  /// trực tiếp cho file lớn (sẽ dính lại giới hạn 100MB/request của Cloudflare).
  Future<String?> getDriveLink(String relativePath) async {
    final res = await http.get(Uri.parse('$baseUrl/drive-link/$relativePath'));
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body);
    return data['drive_link'] as String?;
  }

  void _checkOk(http.Response res) {
    if (res.statusCode != 200) {
      throw Exception('API lỗi (${res.statusCode}): ${res.body}');
    }
  }
}
