import 'package:flutter/material.dart';

/// MỚI (mục 24) - nơi DUY NHẤT dựng theme của app, tách khỏi main.dart để có thể THAY THẾ bằng bản dùng
/// Dynamic Color (màu theo hình nền Android 12+) mà không đụng main.dart.
///
/// FILE NÀY là bản MẶC ĐỊNH, KHÔNG phụ thuộc thêm gói nào: màu cố định từ 1 màu hạt giống (như trước).
/// Bản Dynamic Color nằm ở `tools/app_theme_dynamic.dart.txt` (đuôi .txt để KHÔNG bị biên dịch) và chỉ
/// được chép đè vào file này khi chạy workflow thủ công với tuỳ chọn "dynamic_color" (xem build.yml). Lý do
/// tách: gói `dynamic_color` có bản 2.x mới chuyển sang `material_ui`, chưa biết bản Flutter stable nào
/// GitHub Actions sẽ dùng - thêm thẳng vào pubspec có thể gây lỗi "version solving failed" làm hỏng
/// MỌI lần build, nên chỉ bật khi bạn chủ động thử.
ThemeData buildLightTheme() {
  return ThemeData(
    colorSchemeSeed: Colors.deepPurple,
    useMaterial3: true,
    // Predictive Back (Android 13+) - cần cờ android:enableOnBackInvokedCallback trong AndroidManifest (build.yml làm).
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: <TargetPlatform, PageTransitionsBuilder>{
        TargetPlatform.android: PredictiveBackPageTransitionsBuilder(),
      },
    ),
  );
}

/// Dựng app với theme tương ứng. Bản mặc định chỉ gọi `builder` với theme cố định.
Widget buildThemedApp(Widget Function(ThemeData theme) builder) {
  return builder(buildLightTheme());
}
