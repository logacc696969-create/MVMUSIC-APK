import 'api_service.dart';

/// MỚI - cờ TOÀN APP đánh dấu "hiện có ít nhất 1 job nặng đang chạy trên GPU
/// Colab" (tạo nhạc/MV HOẶC train giọng RVC), KHÔNG phụ thuộc màn hình nào
/// đang mở. Trước đây `HomeScreen._confirmIfBusy()` chỉ kiểm tra được
/// `ProjectHistoryStore` (đúng cho job tạo MV, vì có ghi "in_progress"), lại
/// KHÔNG biết gì về job "Tự train giọng" ở `voice_screen.dart` - trong khi
/// job đó cũng chạy CLI subprocess RVC thật (vài chục phút) và cũng tự poll
/// chung 1 endpoint /progress - nếu người dùng thoát VoiceScreen giữa lúc
/// train (không có cách huỷ job train qua UI) rồi bấm "Tạo dự án mới", 2 job
/// nặng sẽ chạy chung 1 GPU T4 VÀ giẫm lên chung 1 `progress_tracker` phía
/// backend (xem app.py/progress_tracker.py) - y hệt rủi ro đã sửa 1 phần ở
/// HomeScreen, chỉ khác nguồn gốc job.
///
/// Đây chỉ là ĐÈN BÁO ở phía app (mất tác dụng nếu tự tắt app khỏi RAM giữa
/// chừng) - không thay thế cho 1 khoá thật ở backend (app.py) nếu muốn chặn
/// tuyệt đối, nhưng đủ để chặn phần lớn thao tác vô tình trong lúc app vẫn
/// đang mở.
class BackendBusyTracker {
  BackendBusyTracker._();

  static bool isBusy = false;
  static String? label; // vd "Đang train giọng...", "Đang tạo MV..." - hiển thị trong cảnh báo

  static void markBusy(String activityLabel) {
    isBusy = true;
    label = activityLabel;
  }

  static void markFree() {
    isBusy = false;
    label = null;
  }

  /// MỚI (lượt audit sau 7zc17, ĐÍNH CHÍNH cho chính nhận định SAI trước đó
  /// - xem HANDOFF_TECHNICAL_SUMMARY.md mục 7zc17/7zc18) - dùng thay
  /// `markFree()` trong các nhánh `catch` khi request KHỞI ĐỘNG job (vd
  /// `trainVoice()`, `generateMv()`) bị lỗi - vì lỗi đó KHÔNG chứng minh
  /// được job chưa bắt đầu ở backend: request CÓ THỂ đã tới server và
  /// server ĐÃ bắt đầu chạy job thật, chỉ là RESPONSE trên đường VỀ client
  /// bị mất (timeout/rớt mạng phía client) - đây là tình huống
  /// at-most-once/at-least-once kinh điển của HTTP, không có cách nào phân
  /// biệt "request chưa tới server" với "request tới rồi, response mất"
  /// chỉ dựa vào timeout phía client.
  ///
  /// Cách giải quyết: gọi thêm 1 lần `GET /progress` để HỎI THẲNG backend
  /// "có job nào đang thực sự chạy không" - nếu `stage` khác "idle" VÀ
  /// `done` khác `true`, nghĩa là CÓ 1 job đang chạy thật (dù client tưởng
  /// request lỗi) -> GIỮ NGUYÊN cờ busy, không markFree(). Ngược lại (job
  /// thật sự không chạy hoặc đã xong) -> markFree() an toàn.
  ///
  /// Nếu chính lần verify này CŨNG lỗi (mạng vẫn hoàn toàn không dùng
  /// được) -> fallback về hành vi CŨ (markFree() luôn) - chấp nhận rủi ro
  /// nhỏ còn sót (đây là giới hạn thật, không có cách nào chắc chắn 100%
  /// khi hoàn toàn mất kết nối tới server để hỏi bất kỳ điều gì).
  static Future<void> markFreeAfterVerify(ApiService api) async {
    try {
      final p = await api.getProgress();
      final stillRunning = (p['stage'] as String? ?? 'idle') != 'idle' && p['done'] != true;
      if (stillRunning) {
        // Job THẬT SỰ đang chạy ở backend - KHÔNG markFree(), chỉ cập nhật
        // lại label cho khớp thực tế (đề phòng label cũ đã sai/rỗng).
        label ??= 'Đang xử lý (mất kết nối theo dõi, job vẫn chạy trên server)...';
        isBusy = true;
        return;
      }
    } catch (_) {
      // Lần verify cũng lỗi - không còn cách nào chắc chắn hơn, rơi về
      // hành vi CŨ bên dưới.
    }
    markFree();
  }
}
