/// MỚI - cờ TOÀN APP đánh dấu "hiện có ít nhất 1 job nặng đang chạy trên GPU
/// Colab" (tạo nhạc/MV HOẶC train giọng RVC), KHÔNG phụ thuộc màn hình nào
/// đang mở. Trước đây `HomeScreen._confirmIfBusy()` chỉ kiểm tra được
/// `ProjectHistoryStore` (đúng cho job tạo MV, vì có ghi "in_progress"), lại
/// KHÔNG biết gì về job "Tự train giọng" ở `voice_screen.dart` - trong khi
/// job đó cũng chạy CLI subprocess RVC thật (vài chục phút) và cũng tự poll
/// chung 1 endpoint /progress - nếu người dùng thoát VoiceScreen giữa lúc
/// train (không có cách huỷ job train qua UI) rồi bấm "Tạo dự án mới", 2 job
/// nặng sẽ chạy chung 1 GPU T4 VÀ giẫm lên chung 1 `progress_tracker` phía
/// backend (xem app.py/progress_tracker.py) - y hệt rủi ro đã sửa 1 phần ở
/// HomeScreen, chỉ khác nguồn gốc job.
///
/// Đây chỉ là ĐÈN BÁO ở phía app (mất tác dụng nếu tự tắt app khỏi RAM giữa
/// chừng) - không thay thế cho 1 khoá thật ở backend (app.py) nếu muốn chặn
/// tuyệt đối, nhưng đủ để chặn phần lớn thao tác vô tình trong lúc app vẫn
/// đang mở.
class BackendBusyTracker {
  BackendBusyTracker._();

  static bool isBusy = false;
  static String? label; // vd "Đang train giọng...", "Đang tạo MV..." - hiển thị trong cảnh báo

  static void markBusy(String activityLabel) {
    isBusy = true;
    label = activityLabel;
  }

  static void markFree() {
    isBusy = false;
    label = null;
  }
}
