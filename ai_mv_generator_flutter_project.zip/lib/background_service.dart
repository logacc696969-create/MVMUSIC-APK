import 'dart:async';
import 'dart:convert';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:http/http.dart' as http;

/// Foreground Service THẬT của Android - giữ cho việc theo dõi % tạo MV vẫn
/// tiếp tục ngay cả khi màn hình khoá hoặc người dùng chuyển sang app khác,
/// hiện % trực tiếp trên thanh thông báo (giống app nghe nhạc chạy nền).
///
/// LƯU Ý QUAN TRỌNG: job tạo MV THẬT chạy trên GPU Colab, hoàn toàn không
/// phụ thuộc điện thoại - service này CHỈ có nhiệm vụ tự poll % + cập nhật
/// thông báo lúc app ở nền. Nó KHÔNG tự tải file cảnh/MV về máy trong lúc ở
/// nền (việc đó vẫn để màn hình chính (generating_screen.dart) lo, tự đồng
/// bộ tải bù ngay khi app quay lại foreground qua _resyncAfterResume) - để
/// tránh rủi ro ghi file / xin quyền Ảnh (gal) từ 1 isolate nền tách biệt,
/// vốn dễ vỡ hơn nhiều so với chạy trong UI isolate chính.
Future<void> initializeBackgroundService() async {
  final service = FlutterBackgroundService();
  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onServiceStart,
      autoStart: false, // chỉ bật đúng lúc bắt đầu tạo MV, xem generating_screen.dart
      autoStartOnBoot: false,
      isForegroundMode: true,
      notificationChannelId: 'mv_generation_channel',
      initialNotificationTitle: 'AI MV Generator',
      initialNotificationContent: 'Đang chuẩn bị...',
      foregroundServiceNotificationId: 8888,
      foregroundServiceTypes: [AndroidForegroundType.dataSync],
    ),
    iosConfiguration: IosConfiguration(autoStart: false, onForeground: onServiceStart),
  );
}

@pragma('vm:entry-point')
void onServiceStart(ServiceInstance service) {
  String? progressUrl;
  Timer? pollTimer;

  // Màn hình chính gửi URL của GET /progress ngay sau khi bắt đầu job -
  // service không tự biết địa chỉ backend (đổi mỗi lần mở Colab lại).
  service.on('setEndpoint').listen((event) {
    progressUrl = event?['progressUrl'] as String?;
  });

  service.on('stopService').listen((event) {
    pollTimer?.cancel();
    service.stopSelf();
  });

  pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
    final url = progressUrl;
    if (url == null) return;
    try {
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final p = jsonDecode(res.body) as Map<String, dynamic>;
      final percent = (p['percent'] as num?)?.toInt() ?? 0;
      final detail = (p['detail'] as String?) ?? '';
      final done = p['done'] == true;
      final error = p['error'];

      if (service is AndroidServiceInstance) {
        service.setForegroundNotificationInfo(
          title: error != null
              ? 'Lỗi khi tạo MV'
              : done
                  ? 'Đã tạo MV xong!'
                  : 'Đang tạo MV... $percent%',
          content: detail.isEmpty ? 'Đang xử lý trên GPU remote...' : detail,
        );
      }

      // Đẩy dữ liệu về UI isolate NẾU màn hình chính đang mở (nó tự bỏ qua
      // nếu không lắng nghe) - để cập nhật % ngay cả khi biến _wsClient bị
      // Android treo tạm thời trong lúc mới quay lại foreground.
      service.invoke('update', {
        'percent': percent,
        'detail': detail,
        'done': done,
        'error': error,
      });

      if (done) pollTimer?.cancel();
    } catch (_) {
      // Mạng chập chờn lúc đang ở nền - bỏ qua, tự thử lại ở lượt poll kế tiếp.
    }
  });
}
