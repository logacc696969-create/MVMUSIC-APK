import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'l10n.dart';
/// MỚI (mục 23) - hỏi người dùng XÁC NHẬN MỘT LẦN (lưu bền) trước các thao tác dễ vi phạm quyền
/// người khác: huấn luyện/tải giọng nhái, dùng âm thanh/video có bản quyền. Trả về true nếu đã
/// từng đồng ý hoặc vừa đồng ý; false nếu người dùng từ chối (nơi gọi phải DỪNG thao tác).
///
/// ĐÂY LÀ LỜI NHẮC + GHI NHẬN XÁC NHẬN, KHÔNG phải cơ chế kỹ thuật chặn vi phạm và KHÔNG phải
/// tư vấn pháp lý. Nếu đọc/ghi cài đặt cục bộ lỗi thì trả true (cho đi tiếp): lời nhắc này không
/// phải ranh giới bảo mật nên không được phép làm người dùng bị kẹt vì lỗi lưu trữ.
/// Thu hồi: PrivacyScreen có nút "Đặt lại các xác nhận" (xoá mọi khoá `consent_*`).
Future<bool> ensureConsent(
  BuildContext context, {
  required String key,
  required String title,
  required String message,
}) async {
  final prefsKey = 'consent_${key}_v1';
  try {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(prefsKey) == true) return true;
    if (!context.mounted) return false;
    bool checked = false;
    final accepted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(message, style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 8),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                value: checked,
                onChanged: (v) => setLocal(() => checked = v ?? false),
                title: Text(tr('Tôi xác nhận và chịu trách nhiệm về việc này'), style: TextStyle(fontSize: 13)),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Không đồng ý'))),
            ElevatedButton(
              onPressed: checked ? () => Navigator.pop(ctx, true) : null,
              child: Text(tr('Đồng ý và tiếp tục')),
            ),
          ],
        ),
      ),
    );
    if (accepted == true) {
      await prefs.setBool(prefsKey, true);
      return true;
    }
    return false;
  } catch (_) {
    return true;
  }
}

/// Xoá mọi xác nhận đã lưu (để lần sau hỏi lại). Trả về số mục đã xoá.
Future<int> resetAllConsents() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys().where((k) => k.startsWith('consent_')).toList();
    for (final k in keys) {
      await prefs.remove(k);
    }
    return keys.length;
  } catch (_) {
    return 0;
  }
}

const String kConsentVoiceTitle = 'Xác nhận quyền dùng giọng nói';
const String kConsentVoiceMessage =
    'Tính năng này tạo một mô hình bắt chước giọng nói từ file âm thanh bạn chọn. Chỉ dùng giọng '
    'của chính bạn, hoặc giọng của người đã cho phép rõ ràng. Không dùng để mạo danh người khác '
    'hay đánh lừa người nghe. MV tạo ra được gắn nhãn "AI-generated" trong metadata file.';

const String kConsentAudioTitle = 'Xác nhận quyền dùng âm thanh';
const String kConsentAudioMessage =
    'File nhạc/âm thanh bạn tải lên hoặc lấy từ YouTube có thể có bản quyền. Chỉ dùng nội dung của '
    'bạn hoặc nội dung bạn được phép sử dụng/chuyển thể. Việc đăng MV lên nền tảng khác là trách '
    'nhiệm của bạn.';
