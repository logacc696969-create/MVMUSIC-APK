import 'dart:io';
import 'dart:ui' show PlatformDispatcher;
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'crashlytics_support.dart';
import 'error_reporter.dart';

/// MỚI (mục 23) - NHẬT KÝ LỖI CỤC BỘ: ghi mọi lỗi Flutter/lỗi chưa bắt vào 1 file trong máy
/// (giữ tối đa ~200KB, tự cắt bỏ nửa cũ). Tự gửi nó về CHÍNH backend của bạn (không tới ai khác) nếu bật - xem `crash_sync.dart` (mục 56). Đây KHÔNG phải Crashlytics/Sentry
/// (cần tài khoản Firebase/DSN của bạn - chưa có): thay vào đó người dùng mở "Nhật ký lỗi" ở
/// Cài đặt và bấm Chia sẻ để gửi file cho người sửa lỗi. Không bắt được crash ở tầng native
/// (vd app bị Android giết) - chỉ lỗi phía Dart.
class CrashLog {
  CrashLog._();

  static const int _maxBytes = 200 * 1024;
  static File? _file;

  static Future<File> file() async {
    final cached = _file;
    if (cached != null) return cached;
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/crash_log.txt');
    _file = f;
    return f;
  }

  /// Gọi 1 lần trong main() SAU WidgetsFlutterBinding.ensureInitialized().
  static void install() {
    final previous = FlutterError.onError;
    FlutterError.onError = (FlutterErrorDetails details) {
      if (previous != null) previous(details); // giữ hành vi mặc định (in ra console)
      record('FlutterError', details.exceptionAsString(), details.stack);
    };
    PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
      record('Uncaught', error.toString(), stack);
      return false; // false = chưa "nuốt" lỗi, hệ thống vẫn xử lý mặc định
    };
  }

  /// Ghi 1 mục lỗi. KHÔNG BAO GIỜ ném lỗi ra ngoài (ghi log lỗi mà gây lỗi mới là vô nghĩa).
  static Future<void> record(String kind, String message, StackTrace? stack) async {
    try {
      final f = await file();
      final entry = '[${DateTime.now().toIso8601String()}] $kind: $message\n${stack ?? ''}\n---\n';
      await f.writeAsString(entry, mode: FileMode.append, flush: true);
      ErrorReporter.report(kind, message, stack); // MỚI (mục 27) - TUỲ CHỌN, mặc định không làm gì (DSN rỗng); tự nuốt lỗi, không chờ
      recordCrashlyticsError(kind, message, stack); // MỚI (mục 27) - bản mặc định RỖNG; chỉ có tác dụng khi build bật Crashlytics
      if (await f.length() > _maxBytes) {
        final text = await f.readAsString();
        await f.writeAsString(text.substring(text.length ~/ 2));
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  static Future<String> read() async {
    try {
      final f = await file();
      if (!await f.exists()) return '';
      return await f.readAsString();
    } catch (_) {
      return '';
    }
  }

  static Future<void> clear() async {
    try {
      final f = await file();
      if (await f.exists()) await f.delete();
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }
}
