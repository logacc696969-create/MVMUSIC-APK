import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';

import 'api_service.dart';
import 'crash_log.dart';
import 'generation_settings.dart';

/// MỚI (mục 56) - BÁO LỖI TỰ ĐỘNG về CHÍNH backend của bạn, KHÔNG cần tài khoản/khoá nào (Firebase Crashlytics và Sentry đều bắt bạn tự tạo tài khoản rồi dán khoá/DSN;
/// tra cứu cho thấy Firebase CLI tạo được dự án + lấy `google-services.json` bằng lệnh nhưng BƯỚC ĐĂNG NHẬP tài khoản Google thì không thể tự động).
/// Cách hoạt động: lần đầu một lệnh gọi backend thành công (xem `ApiService.onReachable`), nếu nhật ký lỗi cục bộ (`CrashLog`) có nội dung MỚI so với lần đã gửi thì
/// gửi nó lên `/client-crash-log`; backend ghi vào `mv_app_output/crash_reports/` trên Drive của bạn. Tự chạy, mặc định BẬT (tắt được ở Cài đặt), chỉ gửi tới backend của
/// bạn - không tới ai khác. GIỚI HẠN: chỉ lỗi phía Dart (như CrashLog); chỉ gửi được khi app còn kết nối được backend; nếu app sập NGAY lúc khởi động trước khi từng
/// kết nối thì nhật ký chờ tới lần kết nối kế tiếp. Không bao giờ ném lỗi và không bao giờ ghi lỗi mới vào CrashLog (tránh vòng lặp). CHƯA biên dịch/chạy thật.
/// MỚI (mục 60) - mã ENGINE của Flutter dùng để build app này (CI truyền bằng `--dart-define=MV_ENGINE_REV=<mã>`, xem build.yml); rỗng khi build thủ công/không biết.
/// Được ghi vào báo cáo lỗi gửi lên backend để hướng dẫn lấy tên hàm của libflutter.so in ra ĐÚNG đường dẫn ký hiệu (Google bắt đăng nhập trình duyệt để tải nên không tự tải được).
const String kEngineRevision = String.fromEnvironment('MV_ENGINE_REV');

class CrashSync {
  CrashSync._();

  /// Hàm THUẦN (mục 60): chuỗi mô tả thiết bị gửi kèm báo cáo. Tiếng Anh trung tính; chỉ thêm `engine` khi biết mã (40 ký tự hex).
  static String deviceDescription(String os, String osVersion, String dartVersion, String engineRevision) {
    final engine = RegExp(r'^[0-9a-f]{40}$').hasMatch(engineRevision) ? ' | engine $engineRevision' : '';
    return '$os $osVersion | dart $dartVersion$engine';
  }

  static const String prefsKey = 'crash_sync_last_v1';
  static const Duration minGap = Duration(minutes: 5);
  static const int maxChars = 200000;
  static bool _busy = false;
  static DateTime? _lastTry;

  /// Băm FNV-1a 32 bit - đủ để biết nội dung đổi hay chưa (không dùng cho bảo mật).
  static int fnv1a(String s) {
    var h = 0x811c9dc5;
    for (final c in s.codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h;
  }

  /// "Chữ ký" nội dung nhật ký: độ dài:băm. Đổi nội dung -> đổi chữ ký.
  static String signature(String text) => '${text.length}:${fnv1a(text).toRadixString(16)}';

  /// Quyết định có nên gửi không. Hàm THUẦN (không đọc đồng hồ/đĩa) để kiểm thử được.
  static bool shouldUpload({
    required bool enabled,
    required String log,
    required String? lastSignature,
    required DateTime now,
    required DateTime? lastTry,
    Duration gap = minGap,
  }) {
    if (!enabled) return false;
    if (log.trim().isEmpty) return false;
    if (lastSignature == signature(log)) return false; // chưa có gì mới từ lần gửi trước
    if (lastTry != null && now.difference(lastTry) < gap) return false; // vừa thử xong (kể cả thất bại) - đợi một lúc
    return true;
  }

  /// Giữ phần CUỐI (lỗi mới nhất) nếu quá dài.
  static String tail(String log, {int max = maxChars}) => log.length <= max ? log : log.substring(log.length - max);

  /// Gắn vào `ApiService.onReachable` (xem main.dart): chạy nền, không chờ, không ném lỗi.
  static void onReachable(ApiService api) {
    maybeUpload(api).catchError((Object _) {});
  }

  static Future<void> maybeUpload(ApiService api, {DateTime? now}) async {
    if (_busy) return;
    _busy = true; // đặt TRƯỚC khi gửi: chính lệnh gửi cũng gọi onReachable -> phải bị chặn để không lặp
    try {
      final enabled = GenerationSettings.instance.autoUploadCrashLog;
      if (!enabled) return;
      final log = await CrashLog.read();
      final prefs = await SharedPreferences.getInstance();
      final t = now ?? DateTime.now();
      if (!shouldUpload(enabled: enabled, log: log, lastSignature: prefs.getString(prefsKey), now: t, lastTry: _lastTry)) return;
      _lastTry = t;
      await api.uploadCrashLog(
          log: tail(log),
          device: deviceDescription(Platform.operatingSystem, Platform.operatingSystemVersion, Platform.version.split(' ').first, kEngineRevision));
      await prefs.setString(prefsKey, signature(log));
    } catch (_) {
      // cố ý nuốt lỗi - KHÔNG ghi vào CrashLog (gửi lỗi mà sinh lỗi mới thì vô tận)
    } finally {
      _busy = false;
    }
  }
}
