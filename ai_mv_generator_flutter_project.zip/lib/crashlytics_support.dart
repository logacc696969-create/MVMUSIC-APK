/// BẢN MẶC ĐỊNH (RỖNG) - KHÔNG làm gì và KHÔNG phụ thuộc gói Firebase nào, để build thường không đổi (mục 27).
/// Muốn bật Firebase Crashlytics: chạy workflow "Build APK" thủ công, tích chọn `crashlytics` (cần secret GOOGLE_SERVICES_JSON) - workflow sẽ chép
/// tools/crashlytics_support.dart.txt đè lên file này, thêm gói firebase_core + firebase_crashlytics và 2 plugin Gradle. Lỗi Dart vẫn luôn được ghi vào CrashLog
/// (và Sentry nếu bạn dán DSN); Crashlytics chỉ là kênh bổ sung.
Future<void> initCrashlytics() async {}

void recordCrashlyticsError(String kind, String message, StackTrace? stack) {}
