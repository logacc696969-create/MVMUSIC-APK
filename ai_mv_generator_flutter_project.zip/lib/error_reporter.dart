import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Phân tích Sentry DSN dạng `scheme://<khoá_công_khai>@<host>[:cổng]/[tiền_tố/]<project_id>`.
class SentryDsn {
  final String scheme;
  final String publicKey;
  final String host; // gồm cả cổng nếu có
  final String projectId;
  final String pathPrefix; // thường rỗng

  const SentryDsn(this.scheme, this.publicKey, this.host, this.projectId, this.pathPrefix);

  /// `POST <url>` theo https://develop.sentry.dev/sdk/envelopes (endpoint `/api/<project_id>/envelope/`).
  String get envelopeUrl => '$scheme://$host$pathPrefix/api/$projectId/envelope/';

  String get authHeader => 'Sentry sentry_version=7, sentry_key=$publicKey, sentry_client=mv-app/1.0';
}

/// MỚI (mục 27, PDF 10.2/crash analytics) - BÁO LỖI TỰ ĐỘNG TUỲ CHỌN tới Sentry bằng chính DSN CỦA BẠN. MẶC ĐỊNH TẮT (DSN rỗng = không gửi gì).
/// KHÔNG dùng gói `sentry_flutter` (gói đó kéo thêm SDK native + ràng buộc phiên bản Dart có thể làm hỏng bản build chưa từng biên dịch);
/// thay vào đó gửi thẳng JSON theo giao thức envelope công khai của Sentry bằng `http` có sẵn. Giới hạn: chỉ lỗi phía Dart (như CrashLog),
/// KHÔNG có crash native, KHÔNG có breadcrumbs/ảnh chụp. Nội dung gửi: loại lỗi, thông điệp, stack trace Dart, phiên bản app - KHÔNG gửi nhạc, lời,
/// prompt hay file nào. Giao thức đối chiếu với tài liệu develop.sentry.dev; CHƯA gửi thử thật lần nào (cần DSN của bạn) và CHƯA biên dịch.
class ErrorReporter {
  ErrorReporter._();

  static const String prefsKey = 'error_report_dsn_v1';
  static String dsn = '';
  static final List<DateTime> _sent = <DateTime>[];
  static final Map<String, DateTime> _lastByMessage = <String, DateTime>{};

  static SentryDsn? parseDsn(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    final uri = Uri.tryParse(text);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http') || uri.host.isEmpty) return null;
    final key = uri.userInfo.split(':').first;
    final segments = uri.pathSegments.where((s) => s.isNotEmpty).toList();
    if (key.isEmpty || segments.isEmpty) return null;
    final projectId = segments.last;
    final prefix = segments.length > 1 ? '/${segments.sublist(0, segments.length - 1).join('/')}' : '';
    final host = uri.hasPort ? '${uri.host}:${uri.port}' : uri.host;
    return SentryDsn(uri.scheme, key, host, projectId, prefix);
  }

  static String newEventId([Random? rng]) {
    final r = rng ?? Random.secure();
    return List<String>.generate(32, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  /// Envelope = 3 dòng JSON: header envelope, header item, nội dung sự kiện (https://develop.sentry.dev/sdk/envelopes).
  static String buildEnvelope({
    required String eventId,
    required DateTime now,
    required String kind,
    required String message,
    String? stack,
    String release = 'ai_mv_generator',
  }) {
    final ts = now.toUtc().toIso8601String();
    final header = jsonEncode(<String, dynamic>{'event_id': eventId, 'sent_at': ts});
    final item = jsonEncode(<String, dynamic>{'type': 'event'});
    final event = jsonEncode(<String, dynamic>{
      'event_id': eventId,
      'timestamp': ts,
      'platform': 'other',
      'level': 'error',
      'logger': 'mv-app',
      'release': release,
      'message': <String, dynamic>{'formatted': '$kind: $message'},
      'tags': <String, dynamic>{'kind': kind},
      'extra': <String, dynamic>{'stack': (stack ?? '').length > 6000 ? (stack ?? '').substring(0, 6000) : (stack ?? '')},
    });
    return '$header\n$item\n$event';
  }

  /// Giới hạn chống "bão" lỗi: tối đa 20 báo cáo/phiên, cách nhau >= 5 giây, cùng 1 thông điệp không gửi lại trong 5 phút.
  static bool allowSend(String message, DateTime now) {
    if (_sent.length >= 20) return false;
    if (_sent.isNotEmpty && now.difference(_sent.last).inSeconds < 5) return false;
    final last = _lastByMessage[message];
    if (last != null && now.difference(last).inMinutes < 5) return false;
    return true;
  }

  static Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      dsn = prefs.getString(prefsKey) ?? '';
    } catch (_) {}
  }

  static Future<void> setDsn(String value) async {
    dsn = value.trim();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(prefsKey, dsn);
    } catch (_) {}
  }

  /// KHÔNG BAO GIỜ ném lỗi và không gọi lại CrashLog (tránh vòng lặp lỗi). DSN rỗng/sai -> không làm gì.
  static Future<void> report(String kind, String message, StackTrace? stack) async {
    try {
      final parsed = parseDsn(dsn);
      if (parsed == null) return;
      final now = DateTime.now();
      if (!allowSend(message, now)) return;
      _sent.add(now);
      _lastByMessage[message] = now;
      final body = buildEnvelope(
        eventId: newEventId(),
        now: now,
        kind: kind,
        message: message,
        stack: stack?.toString(),
      );
      await http
          .post(
            Uri.parse(parsed.envelopeUrl),
            headers: <String, String>{
              'Content-Type': 'application/x-sentry-envelope',
              'X-Sentry-Auth': parsed.authHeader,
            },
            body: body,
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }
}
