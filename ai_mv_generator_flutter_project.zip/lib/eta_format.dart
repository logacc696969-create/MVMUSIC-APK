import 'l10n.dart';

/// MỚI (mục 26) - định dạng thời lượng (giây) thành chữ dễ đọc (mục 46: dịch qua trv() - tiếng Việt mặc định, tiếng Anh khi chọn English), dùng cho ETA ở GeneratingScreen
/// và ước lượng trước khi tạo ở ReviewScreen. Hàm thuần, có test ở test/eta_format_test.dart.
String formatDuration(int seconds) {
  if (seconds < 0) seconds = 0;
  if (seconds < 90) return trv('{0} giây', [seconds]);
  final minutes = (seconds / 60).round();
  if (minutes < 90) return trv('{0} phút', [minutes]);
  final h = seconds ~/ 3600;
  final m = ((seconds % 3600) / 60).round();
  if (m == 60) return trv('{0} giờ', [h + 1]);
  return m == 0 ? trv('{0} giờ', [h]) : trv('{0} giờ {1} phút', [h, m]);
}
