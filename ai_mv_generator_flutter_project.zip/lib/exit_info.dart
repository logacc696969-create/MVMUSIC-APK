import 'dart:io';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'crash_log.dart';
import 'foreground_marker.dart';

/// MỚI (mục 57) - LÝ DO APP BỊ TẮT (không cần tài khoản/cloud nào): đọc từ hệ điều hành Android 11+ (`ApplicationExitInfo`, qua cầu nối Kotlin ở `MainActivity` - xem
/// `tools/MainActivity.kt.txt` và bước tương ứng trong `build.yml`) vì sao tiến trình app lần trước CHẾT, rồi ghi vào `CrashLog`; `CrashSync` tự gửi về backend.
/// Bắt được thứ mà CrashLog của Dart KHÔNG bắt được: crash NATIVE, ANR, lỗi khởi tạo, bị Android giết khi đang làm việc (thiếu RAM/tín hiệu). Chạy ở LẦN MỞ APP KẾ TIẾP nên
/// vẫn ghi nhận được lỗi làm app sập ngay lúc khởi động. GIỚI HẠN: chỉ Android 11+ (dưới đó danh sách rỗng); chỉ có lý do/tín hiệu/mức quan trọng, KHÔNG có stack native;
/// nếu `build.yml` không patch được MainActivity thì kênh không tồn tại và hàm này im lặng không làm gì. Không bao giờ ném lỗi. CHƯA biên dịch/chạy thật.
/// MỞ RỘNG mục 58 (khắc phục 2 giới hạn của mục 57): (1) DẤU VẾT: crash native -> tombstone protobuf (Android 12+, base64, backend giải mã thành backtrace), ANR -> thread dump văn bản;
/// lỗi JAVA/Kotlin trong plugin -> stack do bộ xử lý lỗi cài ở MainActivity (`takeJavaCrash`). (2) Android DƯỚI 11 hoặc không có cầu nối: `ForegroundMarker` phát hiện "chết khi đang ở tiền cảnh".
class ExitInfoReporter {
  ExitInfoReporter._();

  static const MethodChannel _channel = MethodChannel('mv/exit_info');
  static const String prefsKey = 'exit_info_last_ts_v1';

  /// Luôn đáng ghi: chắc chắn là sự cố của app.
  static const Set<String> alwaysReport = {'CRASH', 'CRASH_NATIVE', 'ANR', 'INITIALIZATION_FAILURE', 'EXCESSIVE_RESOURCE_USAGE'};

  /// Chỉ đáng ghi khi app đang LÀM VIỆC lúc bị giết (mức quan trọng <= [busyImportanceMax]: tiền cảnh/dịch vụ). Bị giết lúc đã nằm trong bộ nhớ đệm là chuyện thường ngày, không ghi.
  static const Set<String> onlyWhenBusy = {'SIGNALED', 'LOW_MEMORY'};
  static const int busyImportanceMax = 300; // IMPORTANCE_SERVICE; nhỏ hơn = quan trọng hơn (100 = tiền cảnh)
  static const int maxPerLaunch = 5;
  static const int firstRunLookbackDays = 7;
  static const int maxAnrChars = 6000;

  static int _int(Object? v) => v is int ? v : (v is num ? v.toInt() : 0);
  static String _str(Object? v) => v is String ? v : (v == null ? '' : v.toString());

  /// Hàm THUẦN: có đáng ghi không.
  static bool isNoteworthy(String reason, int importance) {
    if (alwaysReport.contains(reason)) return true;
    if (onlyWhenBusy.contains(reason)) return importance > 0 && importance <= busyImportanceMax;
    return false;
  }

  /// Hàm THUẦN: chọn các mục MỚI (timestamp > [lastSeenMs]) và đáng ghi, mới nhất trước, tối đa [max].
  static List<Map<String, dynamic>> selectNew(List<Map<String, dynamic>> raw, int lastSeenMs, {int max = maxPerLaunch}) {
    final out = raw
        .where((e) => _int(e['timestamp']) > lastSeenMs && isNoteworthy(_str(e['reason']), _int(e['importance'])))
        .toList();
    out.sort((a, b) => _int(b['timestamp']).compareTo(_int(a['timestamp'])));
    return out.length > max ? out.sublist(0, max) : out;
  }

  /// Hàm THUẦN: một dòng mô tả cho nhật ký.
  static String format(Map<String, dynamic> e) {
    final ts = _int(e['timestamp']);
    final at = ts > 0 ? DateTime.fromMillisecondsSinceEpoch(ts).toIso8601String() : '?';
    var desc = _str(e['description']);
    if (desc.length > 300) desc = desc.substring(0, 300);
    // Dòng NHẬT KÝ CHẨN ĐOÁN (không hiện trên giao diện) nên viết tiếng Anh trung tính, dễ đọc bằng máy - không đi qua tr().
    final line = 'previous process exit: reason=${_str(e['reason'])} status=${_int(e['status'])} importance=${_int(e['importance'])} '
        'process=${_str(e['processName'])} rss=${_int(e['rss'])} at=$at desc=$desc';
    // MỚI (mục 58) - ANR: kèm thread dump văn bản (cắt để không làm nhật ký phình to)
    var anr = _str(e['traceText']);
    if (anr.length > maxAnrChars) anr = anr.substring(0, maxAnrChars);
    return anr.isEmpty ? line : '$line\n--- ANR thread dump ---\n$anr';
  }

  /// Hàm THUẦN (mục 58): dòng nhật ký cho tombstone native (base64) - backend nhận ra `b64=` và giải mã. Rỗng nếu không có dấu vết.
  static String tombstoneLine(Map<String, dynamic> e) {
    final b64 = _str(e['traceB64']);
    if (b64.isEmpty) return '';
    return 'ts=${_int(e['timestamp'])} bytes=${b64.length * 3 ~/ 4} b64=$b64';
  }

  /// Gọi 1 lần khi mở app (xem main.dart). Chạy nền, không bao giờ ném lỗi. Thứ tự: (1) lý do app chết do Android báo (11+), (2) stack lỗi Java lần trước,
  /// (3) nếu KHÔNG có (1) (Android dưới 11 hoặc không có cầu nối) thì dùng [ForegroundMarker.reportPrevious].
  static Future<void> collect() async {
    if (!Platform.isAndroid) return;
    final sdk = await _sdkInt();
    final exitInfo = hasExitInfoApi(sdk);
    if (exitInfo) {
      await _collectExitReasons();
    }
    await _collectJavaCrash();
    final xcrashCount = await _collectXcrash(); // MỚI (mục 60) - Android 11 trở xuống: crash native/ANR kèm backtrace có tên hàm do xCrash ghi
    if (!exitInfo) {
      // MỚI (mục 59) - kèm giờ cập nhật app và giờ khởi động máy (0 = không biết) để loại trừ báo thừa; (mục 60) đã có tombstone xCrash thì nguyên nhân ĐÃ BIẾT, không ghi thêm dòng "không rõ"
      await ForegroundMarker.reportPrevious(lastUpdateMs: await _lastUpdateMs() ?? 0, bootMs: await _bootMs() ?? 0, causeKnown: xcrashCount > 0);
    }
  }

  /// Hàm THUẦN (mục 58): Android có `ApplicationExitInfo` không (API 30 = Android 11).
  static bool hasExitInfoApi(int? sdk) => sdk != null && sdk >= 30;

  static Future<int?> _sdkInt() async {
    try {
      final v = await _channel.invokeMethod<int>('getSdkInt');
      return v;
    } catch (_) {
      return null; // không có cầu nối (build.yml không patch được) hoặc lỗi kênh
    }
  }

  static Future<int?> _lastUpdateMs() async {
    try {
      return await _channel.invokeMethod<int>('getLastUpdateTime');
    } catch (_) {
      return null;
    }
  }

  static Future<int?> _bootMs() async {
    try {
      return await _channel.invokeMethod<int>('getBootTime');
    } catch (_) {
      return null;
    }
  }

  /// Hàm THUẦN (mục 60): loại tombstone xCrash theo phần đuôi tên file (`tombstone_...__<tiến trình>.<native|anr|java>.xcrash`).
  static String xcrashKind(String fileName) {
    if (fileName.contains('.native.')) return 'native';
    if (fileName.contains('.anr.')) return 'anr';
    if (fileName.contains('.java.')) return 'java';
    return 'other';
  }

  /// Đọc các tombstone xCrash (tối đa 3 file mới nhất, mỗi file 40KB - cắt ở Kotlin) và ghi vào CrashLog dưới loại `xcrash-<native|anr|java|other>`.
  /// Trả số file đã ghi. Thiếu kênh/lỗi -> 0, không bao giờ ném lỗi.
  static Future<int> _collectXcrash() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('takeXcrashTombstones');
      if (raw == null || raw.isEmpty) return 0;
      var written = 0;
      for (final e in raw) {
        if (e is! Map) continue;
        final text = _str(e['text']);
        if (text.trim().isEmpty) continue;
        await CrashLog.record('xcrash-${xcrashKind(_str(e['name']))}', text, null);
        written++;
      }
      return written;
    } catch (_) {
      return 0;
    }
  }

  static Future<void> _collectJavaCrash() async {
    try {
      final text = await _channel.invokeMethod<String>('takeJavaCrash');
      if (text != null && text.trim().isNotEmpty) {
        await CrashLog.record('java-crash', text, null);
      }
    } catch (_) {
      // cố ý nuốt
    }
  }

  static Future<void> _collectExitReasons() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('getExitReasons');
      if (raw == null || raw.isEmpty) return;
      final entries = <Map<String, dynamic>>[];
      for (final e in raw) {
        if (e is Map) entries.add(e.map((k, v) => MapEntry(k.toString(), v)));
      }
      if (entries.isEmpty) return;
      final prefs = await SharedPreferences.getInstance();
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final stored = prefs.getInt(prefsKey) ?? 0;
      // Lần đầu (chưa có mốc): chỉ lấy các mục trong vài ngày gần đây, tránh đổ cả lịch sử cũ vào nhật ký.
      final lastSeen = stored > 0 ? stored : nowMs - const Duration(days: firstRunLookbackDays).inMilliseconds;
      final fresh = selectNew(entries, lastSeen);
      for (final e in fresh.reversed) {
        await CrashLog.record('exit-info', format(e), null);
        final tomb = tombstoneLine(e);
        if (tomb.isNotEmpty) {
          await CrashLog.record('exit-info-tombstone', tomb, null);
        }
      }
      var newest = stored;
      for (final e in entries) {
        final t = _int(e['timestamp']);
        if (t > newest) newest = t;
      }
      if (newest > stored) await prefs.setInt(prefsKey, newest);
    } on MissingPluginException {
      // build.yml không patch được MainActivity (hoặc chạy ngoài Android thật) - im lặng
    } on PlatformException {
      // cố ý nuốt
    } catch (_) {
      // cố ý nuốt - KHÔNG ghi lỗi mới vào CrashLog từ đường này
    }
  }
}
