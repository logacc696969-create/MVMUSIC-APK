import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'crash_log.dart';

import 'l10n.dart';
/// MỚI (mục 27, PDF 11.1) - ĐÁNH GIÁ + BÁO LỖI ngay trong app, KHÔNG cần máy chủ/tài khoản nào:
///   - đánh giá 1-5 sao + ghi chú được lưu CỤC BỘ (SharedPreferences, giữ 50 mục gần nhất);
///   - "Gửi phản hồi" mở menu chia sẻ của Android với 1 đoạn văn bản (đánh giá, tên file MV, ghi chú, phần cuối nhật ký lỗi) để BẠN CHỌN
///     gửi cho ai (Zalo/Telegram/email...). Không có gì tự gửi đi đâu cả.
/// Muốn gom phản hồi tự động về 1 nơi thì cần dịch vụ bên ngoài - xem `SENTRY_DSN` trong main.dart (tuỳ chọn).
/// CHƯA biên dịch/chạy thử (không có Dart SDK).
class FeedbackCard extends StatefulWidget {
  final String? mvFilename;
  const FeedbackCard({super.key, this.mvFilename});

  @override
  State<FeedbackCard> createState() => _FeedbackCardState();
}

class _FeedbackCardState extends State<FeedbackCard> {
  static const String _prefsKey = 'feedback_log_v1';
  int _rating = 0;
  final TextEditingController _noteCtrl = TextEditingController();

  @override
  void dispose() {
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_prefsKey);
      final List<dynamic> list = raw == null || raw.isEmpty ? <dynamic>[] : (jsonDecode(raw) as List<dynamic>);
      list.add(<String, dynamic>{
        'ts': DateTime.now().toIso8601String(),
        'rating': _rating,
        'mv': widget.mvFilename,
        'note': _noteCtrl.text.trim(),
      });
      final trimmed = list.length > 50 ? list.sublist(list.length - 50) : list;
      await prefs.setString(_prefsKey, jsonEncode(trimmed));
    } catch (_) {
      // lưu cục bộ lỗi thì bỏ qua - vẫn cho gửi
    }
  }

  Future<void> _send() async {
    final crash = await CrashLog.read();
    final tail = crash.length > 3000 ? crash.substring(crash.length - 3000) : crash;
    final text = 'Phản hồi AI MV Generator\n'
        'Đánh giá: ${_rating == 0 ? "(chưa chọn)" : "$_rating/5"}\n'
        'MV: ${widget.mvFilename ?? "?"}\n'
        'Ghi chú: ${_noteCtrl.text.trim().isEmpty ? "(không)" : _noteCtrl.text.trim()}\n\n'
        '--- Nhật ký lỗi gần nhất ---\n${tail.isEmpty ? "(trống)" : tail}';
    await _saveLocal();
    try {
      await Share.share(text, subject: 'Phản hồi AI MV Generator');
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Không mở được menu chia sẻ.'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Bạn thấy MV này thế nào?'), style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                for (int i = 1; i <= 5; i++)
                  IconButton(
                    // 48x48dp tối thiểu theo chuẩn cảm ứng Android (mặc định của IconButton)
                    tooltip: trv('Đánh giá {0} sao', [i]),
                    onPressed: () => setState(() => _rating = i),
                    icon: Icon(i <= _rating ? Icons.star : Icons.star_border, color: Colors.amber, semanticLabel: '$i sao'),
                  ),
              ],
            ),
            TextField(
              controller: _noteCtrl,
              maxLines: 2,
              decoration: InputDecoration(
                hintText: tr('Ghi chú / mô tả lỗi (không bắt buộc)'),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.tonalIcon(
                onPressed: _send,
                icon: const Icon(Icons.send),
                label: Text(tr('Gửi phản hồi / báo lỗi')),
              ),
            ),
            Text(
              tr('Sẽ mở menu chia sẻ - bạn chọn gửi cho ai. Không có gì tự động gửi đi.'),
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
