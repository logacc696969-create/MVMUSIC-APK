import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'crash_log.dart';

/// MỚI (mục 58) - PHÁT HIỆN "CHẾT KHI ĐANG Ở MÀN HÌNH" cho Android DƯỚI 11 (hoặc khi cầu nối Kotlin không có): trước Android 11 hệ điều hành KHÔNG lưu lý do app chết
/// (`ApplicationExitInfo` bắt đầu từ API 30). Cách thay thế KHÔNG cần quyền/thư viện: mỗi lần trạng thái vòng đời đổi, ghi "fg"/"bg" + giờ vào SharedPreferences. Người dùng
/// KHÔNG thể vuốt tắt app khi nó đang ở tiền cảnh (phải rời khỏi app trước -> ghi "bg"), nên nếu lần mở sau vẫn đọc thấy "fg" thì tiến trình đã chết KHI ĐANG ở tiền cảnh:
/// crash, ANR, bị giết hay mất nguồn - KHÔNG phân biệt được lý do (chỉ biết "chết đột ngột lúc đang dùng"). Cũng sinh ra khi cài đè APK lúc app đang mở (vô hại).
/// MỞ RỘNG mục 59: loại trừ 2 nguyên nhân KHÔNG phải lỗi app - cài/cập nhật APK lúc đang mở (so với `lastUpdateTime` của gói) và máy khởi động lại (so với giờ khởi động) - nhờ cầu nối Kotlin.
/// Không bao giờ ném lỗi. CHƯA biên dịch/chạy thật.
class ForegroundMarker with WidgetsBindingObserver {
  ForegroundMarker._();

  static final ForegroundMarker instance = ForegroundMarker._();
  static const String prefsKey = 'fg_marker_v1';
  static bool _started = false;

  /// Hàm THUẦN: chuỗi lưu trạng thái.
  static String encode(bool foreground, int nowMs) => '${foreground ? 'fg' : 'bg'}:$nowMs';

  /// Hàm THUẦN: lần trước app có chết khi đang ở tiền cảnh không.
  static bool diedInForeground(String? marker) => marker != null && marker.startsWith('fg:');

  /// Hàm THUẦN: giờ (ms) trong chuỗi, hoặc 0.
  static int timestampOf(String? marker) {
    if (marker == null) return 0;
    final i = marker.indexOf(':');
    return i < 0 ? 0 : (int.tryParse(marker.substring(i + 1)) ?? 0);
  }

  /// Hàm THUẦN: dòng nhật ký.
  static String describe(String marker) {
    final ts = timestampOf(marker);
    final at = ts > 0 ? DateTime.fromMillisecondsSinceEpoch(ts).toIso8601String() : '?';
    return 'previous process exit: reason=DIED_IN_FOREGROUND (the device was not restarted and the app was not updated since: crash, ANR or system kill; exact cause unknown; '
        'Android below 11 does not record exit reasons) last_seen=$at';
  }

  /// Hàm THUẦN (mục 59): phân loại lần chết trước. 'none' = không phải chết ở tiền cảnh; 'updated' = app được cài/cập nhật SAU lần cuối thấy (cài đè APK lúc đang mở - không phải lỗi);
  /// 'rebooted' = máy khởi động SAU lần cuối thấy (mất nguồn/khởi động lại - không phải lỗi của app); 'died' = tiến trình chết đột ngột dù máy vẫn chạy và app không bị cập nhật.
  /// [lastUpdateMs]/[bootMs] = 0 nghĩa là không biết (cầu nối vắng) -> không loại trừ được, coi là 'died'. [toleranceMs] bù độ lệch đồng hồ khi ước lượng giờ khởi động.
  static String classifyPrevious(String? marker, {int lastUpdateMs = 0, int bootMs = 0, int toleranceMs = 60000}) {
    if (!diedInForeground(marker)) return 'none';
    final seen = timestampOf(marker);
    if (lastUpdateMs > 0 && lastUpdateMs > seen) return 'updated';
    if (bootMs > 0 && bootMs > seen + toleranceMs) return 'rebooted';
    return 'died';
  }

  /// Gọi TRƯỚC [start]: nếu lần trước chết ở tiền cảnh thì phân loại rồi (chỉ khi là 'died') ghi vào CrashLog; luôn đặt lại thành "bg" để không báo lặp.
  /// [causeKnown] (mục 60): đã có tombstone xCrash cho lần chết này -> KHÔNG ghi thêm dòng "không rõ nguyên nhân", chỉ đặt lại mốc.
  static Future<void> reportPrevious({int lastUpdateMs = 0, int bootMs = 0, bool causeKnown = false}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final marker = prefs.getString(prefsKey);
      final kind = classifyPrevious(marker, lastUpdateMs: lastUpdateMs, bootMs: bootMs);
      if (kind == 'none') return;
      if (kind == 'died' && !causeKnown) {
        await CrashLog.record('exit-info', describe(marker!), null);
      }
      await prefs.setString(prefsKey, encode(false, timestampOf(marker)));
    } catch (_) {
      // cố ý nuốt
    }
  }

  /// Bắt đầu theo dõi vòng đời (gọi 1 lần, SAU [reportPrevious]).
  static void start() {
    if (_started) return;
    _started = true;
    try {
      WidgetsBinding.instance.addObserver(instance);
      final s = WidgetsBinding.instance.lifecycleState;
      _write(s == null || s == AppLifecycleState.resumed);
    } catch (_) {
      // cố ý nuốt
    }
  }

  static void _write(bool foreground) {
    SharedPreferences.getInstance()
        .then((p) => p.setString(prefsKey, encode(foreground, DateTime.now().millisecondsSinceEpoch)))
        .catchError((Object _) => false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _write(state == AppLifecycleState.resumed);
  }
}
