import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Cài đặt tham số tạo nhạc/MV, chỉnh trong SettingsScreen, áp dụng cho mọi
/// lần gọi API. Singleton đơn giản; từ mục 27 được lưu bền qua lần mở app (xem `load`/`save`/`startAutoSave`, trừ `hmacSecret`).
class GenerationSettings {
  GenerationSettings._();
  static final GenerationSettings instance = GenerationSettings._();

  /// "Công suất sử dụng GPU remote", 20-100 (%). ĐÂY LÀ 1 NÚT DUY NHẤT,
  /// không phải khái niệm lượng tử hoá/VRAM - người dùng chỉ cần hiểu: thấp
  /// hơn = GPU remote "làm việc nhẹ tay hơn" (nghỉ giữa các bước), lâu hơn
  /// nhưng ít bị Colab bóp/ngắt phiên hơn. Backend tự quyết định chi tiết kỹ
  /// thuật tương ứng (lượng tử hoá, offload...) - app không cần biết.
  int gpuPower = 70;

  double duration = 30; // giây - độ dài bản nhạc tạo ra
  double similarity = 0.3; // mức biến tấu khi tạo từ nhạc mẫu (thấp = khác nhiều)
  int beatsPerScene = 4; // số beat gộp thành 1 cảnh video
  int maxScenes = 8; // giới hạn số cảnh trong MV
  int numInferenceSteps = 20; // số bước khử nhiễu khi sinh mỗi cảnh video
  double guidanceScale = 7.5; // độ bám sát prompt khi sinh cảnh video

  /// Tuỳ chọn: mô tả nhân vật cố định (vd "cô gái tóc đen dài, áo khoác đỏ")
  /// dùng để: (a) sinh 1 ẢNH THAM CHIẾU nhân vật riêng, (b) khoá ảnh đó vào
  /// mọi cảnh qua IP-Adapter/VACE reference_images tuỳ backend đang chọn -
  /// cơ chế khoá danh tính THẬT (không phải mẹo prompt chữ như bản cũ). Để
  /// trống = không sinh ảnh tham chiếu, quay lại hành vi cũ.
  String characterDesc = '';

  /// Tự chọn kiểu chuyển động camera (zoom/lia) theo nhịp mạnh/nhẹ từng cảnh
  /// qua Motion LoRA - CHƯA CHẠY THỬ THẬT trên GPU thật, mặc định BẬT vì có
  /// cơ chế tự bỏ qua an toàn ở backend nếu tải LoRA lỗi. Tắt nếu thấy nạp
  /// model chậm hẳn hoặc muốn quay lại hành vi cũ.
  bool enableMotionCamera = true;

  /// MỚI (mục 7zc2) - Lipsync (khớp khẩu hình theo lời hát) - MẶC ĐỊNH TẮT
  /// (rủi ro cao nhất trong dự án, chỉ hoạt động thật khi style đang chọn có
  /// `lipsync_ok=true` - hiện chỉ có "nguoi_that_studio"). `style_screen.dart`
  /// tự đặt lại về false nếu người dùng đổi sang style không hỗ trợ.
  bool enableLipsync = false;

  /// MỚI (mục 7zc9) - backend Lipsync đang chọn - null = để server tự dùng
  /// mặc định (`DEFAULT_LIPSYNC_BACKEND` ở app.py, hiện là "wav2lip"). KHÔNG
  /// hardcode danh sách backend ở Flutter - `StyleScreen` tự lấy qua
  /// `getLipsyncBackends()` lúc mở màn, cùng pattern `videoBackend` bên
  /// dưới. Chỉ có ý nghĩa khi `enableLipsync == true`.
  String? lipsyncBackend;

  /// MỚI (mục 7zc5) - "Nối cảnh mượt" - lấy khung hình cuối cảnh trước làm
  /// điều kiện sinh cảnh sau, giảm giật/nhấp nháy bối cảnh. MẶC ĐỊNH TẮT
  /// (CHƯA test thật trên GPU) - chỉ có tác dụng thật khi `videoBackend` hỗ
  /// trợ (hiện chỉ "wan22") - `settings_screen.dart` tự đặt lại về false
  /// nếu đổi sang backend không hỗ trợ.
  bool enableSceneContinuity = false;

  /// Backend video đang chọn - null = để server tự dùng mặc định
  /// (`DEFAULT_VIDEO_BACKEND` ở app.py, hiện là "animatediff"). KHÔNG
  /// hardcode danh sách backend ở Flutter - `SettingsScreen` tự lấy qua
  /// `getVideoBackends()` lúc mở màn, giá trị này chỉ lưu ID người dùng đã
  /// chọn (String bất kỳ do server trả về, không phải enum cố định).
  String? videoBackend;

  /// Thể loại kịch bản MV cho /build-storyboard - null = server tự dùng mặc
  /// định ("narrative"). KHÔNG hardcode danh sách ở Flutter, cùng pattern
  /// videoBackend - StoryboardScreen tự lấy qua getVideoGenres() lúc mở màn.
  String? genre;

  /// Bật "kịch bản viết bằng LLM" (đọc lời bài hát, viết hành động/bối cảnh
  /// thật thay vì mẫu câu cố định) ở /build-storyboard - CẦN có lời bài hát
  /// (project.lyrics không rỗng) mới có tác dụng. Mặc định TẮT vì chạy CPU
  /// chậm hơn hệ mẫu câu tức thời, và CHƯA CHẠY THỬ THẬT (xem tài liệu kỹ
  /// thuật) - người dùng tự bật nếu muốn thử.
  bool useLlmScript = false;

  /// Tạo 2 bản nhạc (khác seed) để nghe thử và chọn - giống quy trình Suno/
  /// Udio. Mặc định TẮT (khác Motion LoRA) vì đây là request ĐỒNG BỘ (không
  /// chạy nền), 2 bản = gấp đôi thời gian giữ HTTP request/tốn GPU của 1 lần
  /// bấm "Tạo nhạc" - người dùng tự bật nếu chấp nhận đợi lâu hơn.
  bool generateVariants = false;

  /// MỚI - "Color Grading" tự động (khớp tông màu mọi cảnh theo cảnh mở đầu)
  /// - MẶC ĐỊNH BẬT vì backend luôn tự rơi về giữ nguyên màu gốc nếu lỗi
  /// (an toàn, không hỏng job) - tắt nếu muốn giữ đúng màu AI tự sinh, không
  /// can thiệp hậu kỳ.
  bool enableColorMatch = true;

  /// MỚI - "Beat-Reactive Speed Ramping" (THỬ NGHIỆM, TẮT mặc định): đổi nhẹ
  /// tốc độ phát mỗi cảnh (±6%) theo cường độ nhịp - xem ghi chú trong
  /// `_run_generate_mv_job` (app.py) về lý do đây là bản ĐƠN GIẢN, an toàn
  /// hơn ý tưởng "DTW per-frame" gốc.
  bool enableSpeedRamping = false;

  /// MỚI - "Formant Shifting" cho giọng RVC (THỬ NGHIỆM, TẮT mặc định) - xem
  /// `_apply_formant_shift` (app.py). Cần cài `stftpitchshift` ở Colab.
  bool enableFormantShift = false;
  double formantQuefrencyMs = 1.5;

  /// MỚI - "De-essing" (giảm tiếng xì/rít gió 4-8kHz, THỬ NGHIỆM, TẮT mặc
  /// định) - xem `_apply_deessing` (app.py). Khác Formant Shifting (2 kỹ
  /// thuật DSP riêng biệt dù PDF gốc gộp chung).
  bool enableDeessing = false;

  /// MỚI - Khoá bí mật dùng để ký HMAC cho 2 request tốn GPU nặng nhất
  /// (/generate-mv, /train-voice) - xem `_verify_hmac_signature` trong
  /// app.py. Để TRỐNG = KHÔNG ký gì cả (giống hành vi cũ) - backend cũng tự
  /// tắt kiểm tra nếu không đặt `MV_APP_HMAC_SECRET` ở Colab, nên chỉ cần
  /// điền ô này khi bạn ĐÃ đặt cùng 1 chuỗi bí mật ở Cell 2.7 của
  /// colab_setup.py - 2 bên PHẢI khớp NGUYÊN VĂN thì mới ký/xác minh đúng.
  String hmacSecret = '';

  /// MỚI (mục 34) - TUỲ CHỌN "ghi nhớ khoá HMAC trên máy này" (MẶC ĐỊNH TẮT - giữ quyết định cũ là không lưu). Bật thì khoá được lưu ở 2 khoá SharedPreferences RIÊNG
  /// (KHÔNG nằm trong toJson/prefsKey) để "Chia sẻ cài đặt" không bao giờ làm lộ khoá. Đổi lại: ai lấy được dữ liệu app trên máy (root/sao lưu) đọc được khoá.
  bool rememberHmac = false;
  static const String hmacRememberKey = 'hmac_remember_v1';
  static const String hmacSecretKey = 'hmac_secret_remembered_v1';

  /// Lưu/xoá khoá ghi nhớ theo cờ `rememberHmac` (tắt cờ hoặc khoá rỗng thì XOÁ sạch khỏi máy). Mọi lỗi bị nuốt.
  Future<void> saveHmacChoice() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (rememberHmac && hmacSecret.isNotEmpty) {
        await prefs.setBool(hmacRememberKey, true);
        await prefs.setString(hmacSecretKey, hmacSecret);
      } else {
        await prefs.remove(hmacRememberKey);
        await prefs.remove(hmacSecretKey);
      }
    } catch (_) {}
  }

  // ---- MỚI (BỔ SUNG dựa trên file "Phân_tích_MV_triệu_view_-_DeepSeek.pdf"
  // - xem post_processing_v2.py + CHANGELOG_NANG_CAP.md mục 10 phía backend) ----

  /// Hiệu ứng hậu kỳ điện ảnh (vignette + film grain + sharpen) - RẺ (chỉ
  /// ffmpeg filter, vài giây), backend tự bỏ qua an toàn nếu lỗi - MẶC ĐỊNH
  /// BẬT, cùng tinh thần `enableColorMatch` ở trên.
  bool enablePostFx = true;

  /// "light" (mặc định, khó nhận ra là có xử lý) hoặc "strong" (rõ hơn, hợp
  /// MV tối/kịch tính) - chỉ có ý nghĩa khi `enablePostFx == true`.
  String postFxIntensity = 'light';

  /// Làm mượt chuyển động (nội suy khung hình 24->48fps bằng ffmpeg
  /// `minterpolate`) - LƯU Ý đây KHÔNG PHẢI RIFE thật (model học sâu), chỉ
  /// là thuật toán cổ điển nhẹ hơn - xem cảnh báo trong post_processing_v2.py.
  /// MẶC ĐỊNH TẮT (khá tốn CPU trên MV nhiều cảnh, người dùng tự bật nếu
  /// chấp nhận đợi lâu hơn để đổi lấy chuyển động mượt hơn).
  bool enableMotionSmoothing = false;

  /// MỚI - "ffmpeg" (mặc định, thuật toán cổ điển, LUÔN sẵn có) hoặc "rife"
  /// (deep learning THẬT, chất lượng cao hơn hẳn - xem
  /// post_processing_v2.smooth_motion_interpolate_rife + rife_ifnet.py) -
  /// CHỈ có tác dụng khi `enableMotionSmoothing == true`. RIFE KHÔNG cần cài
  /// thêm package (chỉ cần file `rife_ifnet.py` có sẵn trong repo + torch,
  /// torch đã có sẵn qua Colab) - tự tải model 67MB lần đầu dùng.
  String motionSmoothingMethod = 'ffmpeg';

  /// MỚI - Upscale MV bằng Real-ESRGAN (xem
  /// post_processing_v2.upscale_video_realesrgan) - MẶC ĐỊNH TẮT: CẦN CÀI
  /// THÊM `pip install realesrgan basicsr` trên Colab (KHÔNG có sẵn mặc
  /// định, khác RIFE ở trên) VÀ rất chậm nếu Colab không có GPU thật (~48.7
  /// giây/khung hình đã đo trên CPU) - chỉ bật khi chắc chắn đã cài đủ +
  /// đang chạy GPU thật.
  bool enableRealesrganUpscale = false;

  /// Xuất THÊM 1 bản dọc 9:16 cho YouTube Shorts/TikTok/Instagram Reels
  /// (crop giữa khung - KHÔNG PHẢI "smart crop" dõi chủ thể) - KHÔNG thay
  /// thế bản ngang, chỉ tạo thêm 1 file/artifact riêng (kind
  /// "final_mv_vertical"). MẶC ĐỊNH TẮT (tốn thêm thời gian encode + dung
  /// lượng máy - người dùng tự bật nếu cần đăng lên nền tảng dọc).
  bool exportVertical = false;

  /// MỚI (mục 30, PDF-2 mục 4.1) - CHẾ ĐỘ NHANH: bỏ qua bước Đổi giọng và Storyboard/xem trước ảnh nhân vật (xem `quick_mode.dart`). Mặc định TẮT.
  bool quickMode = false;

  /// MỚI (mục 30, PDF-2 mục 4.2) - hiện CÀI ĐẶT NÂNG CAO (cảnh mượt, màu, tốc độ, hiệu ứng, upscale, xuất dọc/preset, phụ đề, watermark...).
  /// Mặc định TẮT cho người mới: ẩn UI chứ KHÔNG đổi giá trị đã lưu của các mục đó.
  bool expertMode = false;

  /// MỚI (mục 30, PDF "MV triệu view cần gì" - ReShot) - tên file video THAM CHIẾU CHUYỂN ĐỘNG đã tải lên backend (/upload-control-video), '' = không dùng.
  /// Chỉ Wan-VACE dùng (các công nghệ khác bỏ qua). File nằm ở Colab nên MẤT khi Colab khởi động lại - khi đó backend tự sinh không điều khiển.
  String controlVideoFilename = '';
  String controlVideoLabel = ''; // tên file gốc trên máy, chỉ để hiển thị

  /// MỚI (mục 31) - LoRA người dùng đã CHỌN: {tên file .safetensors trong thư mục loras trên Drive: trọng số}. Backend dùng tối đa 4 và tự bỏ qua LoRA không hợp họ model nền.
  Map<String, double> loraSelection = <String, double>{};

  /// MỚI (mục 31) - tên workflow ComfyUI đã chọn ('' = chưa chọn); chỉ dùng khi công nghệ video là "comfyui".
  String comfyWorkflow = '';

  /// JSON gửi backend: [{"file": "...", "weight": 0.8}], hoặc '' nếu không chọn LoRA nào.
  String get lorasJson => loraSelection.isEmpty
      ? ''
      : jsonEncode(loraSelection.entries.map((e) => <String, dynamic>{'file': e.key, 'weight': e.value}).toList());

  /// MỚI (mục 23) - khắc PHỤ ĐỀ LỜI BÀI HÁT vào chính video (để đăng lên YouTube/TikTok
  /// không cần app ngoài): '' = tắt (mặc định), 'plain' = chữ thường, 'karaoke' = tô sáng
  /// từng từ. CẦN đã nhập lời bài hát VÀ backend căn chỉnh được mốc thời gian (xem
  /// `_align_lyrics_to_audio`) - thiếu 1 trong 2 thì backend tự bỏ qua, MV vẫn ra bình thường.
  String burnInLyrics = '';

  /// MỚI (mục 23, THỬ NGHIỆM) - dịch ranh giới cảnh về ranh giới đoạn bài hát (verse/chorus)
  /// để cảnh đổi đúng lúc bài đổi đoạn. Mặc định TẮT: mới test trên audio tổng hợp, CHƯA kiểm
  /// chứng với nhạc thật. Chỉ có tác dụng với dự án MỚI (dự án tiếp tục dùng lại cảnh đã lưu).
  bool structureSnap = false;

  /// MỚI (mục 25) - chữ WATERMARK (tên kênh/bản quyền) đóng ở góc trên-phải video (cả bản dọc). '' = tắt.
  /// Backend rút gọn bằng "…" nếu chữ không vừa bề ngang khung (tối đa 60 ký tự).
  String watermarkText = '';

  // ---- MỚI (mục 26) - kỹ thuật còn lại từ file phân tích PDF; TẤT CẢ mặc định TẮT/không đổi hành vi cũ ----

  /// Mờ chuyển động nhẹ (trộn khung liền kề) - xem post_processing_v2.apply_extra_fx. Cường độ theo [postFxIntensity].
  bool fxMotionBlur = false;

  /// Mảng sáng ấm trôi chậm (light leak) trộn lên video.
  bool fxLightLeak = false;

  /// Phát sáng (bloom) quanh vùng sáng.
  bool fxBloom = false;

  /// Preset xuất cho nền tảng: '' = tắt (giữ file gốc), 'youtube_1080p' = phóng Lanczos lên 1920x1080 (không bịa chi tiết,
  /// an toàn với mặt người), gắn thẻ màu BT.709, moov ở đầu file... xem post_processing_v2.export_platform_preset.
  String exportPreset = '';
  /// MỚI (mục 49) - look màu CUỐI: '' (tắt) | warm | cool | teal_orange | faded_film (backend: post_processing_v2.COLOR_LOOKS).
  String colorLook = '';

  /// Khi bật upscale Real-ESRGAN mà video có mặt người: 'skip' (mặc định, bỏ qua upscale như trước) hoặc
  /// 'protect' (THỬ NGHIỆM - upscale AI cho nền, giữ bản Lanczos ở vùng mặt).
  String upscaleFaceMode = 'skip';

  /// Bối cảnh cố định cho cả MV (vd "quán cà phê ban đêm, đèn vàng") gắn vào prompt MỌI cảnh để các cảnh cùng địa điểm/thời điểm.
  String settingDesc = '';

  // ---- MỚI (mục 27) - LƯU BỀN cài đặt qua các lần mở app (trước đây đóng app là về mặc định) ----
  // Cách làm: KHÔNG sửa từng chỗ gán `GenerationSettings.instance.x = ...` rải rác ở các màn hình; thay vào đó
  // `load()` nạp 1 lần lúc khởi động (main.dart) và `startAutoSave()` lưu khi app xuống nền/đóng (vòng đời Android).
  // KHÔNG lưu `hmacSecret` (khoá bí mật - mỗi lần mở app phải nhập lại, có chủ ý). Giá trị lạ/sai kiểu/ngoài khoảng
  // (vd file cũ, bản app khác) bị bỏ qua hoặc kẹp về khoảng hợp lệ; lỗi đọc/ghi KHÔNG BAO GIỜ làm hỏng app.
  // CHƯA biên dịch/chạy thử (không có Dart SDK) - xem test/settings_persistence_test.dart.
  static const String prefsKey = 'generation_settings_v1';

  /// MỚI (mục 27) - ngôn ngữ giao diện: 'vi' (mặc định) hoặc 'en'; xem l10n.dart (mới dịch 1 phần, có hiệu lực khi mở lại app).
  String language = 'vi';

  /// MỚI (mục 27, PDF 11.3 "font size tuỳ chỉnh") - hệ số cỡ chữ của TOÀN app (0.85-1.4), nhân thêm lên cỡ chữ hệ thống. `main.dart` lắng nghe
  /// notifier này nên kéo thanh trượt ở màn Cài đặt có hiệu lực ngay, không cần khởi động lại.
  static final ValueNotifier<double> textScaleNotifier = ValueNotifier<double>(1.0);

  /// MỚI (mục 27) - chế độ giao diện: 'light' (MẶC ĐỊNH - đúng như trước), 'dark' hoặc 'system'. TUỲ CHỌN vì app có nhiều màu cố định (`Colors.grey`...)
  /// có thể hiển thị chưa đẹp ở chế độ tối - bạn thử và cho biết màn nào cần chỉnh. Đổi ngay không cần mở lại app (main.dart lắng nghe notifier này).
  static final ValueNotifier<String> themeModeNotifier = ValueNotifier<String>('light');
  String get themeMode => themeModeNotifier.value;
  set themeMode(String v) => themeModeNotifier.value = const ['light', 'dark', 'system'].contains(v) ? v : 'light';
  double get textScale => textScaleNotifier.value;
  set textScale(double v) => textScaleNotifier.value = v.clamp(0.85, 1.4).toDouble();

  /// MỚI (mục 54, PDF-2 §11.3 "Accessibility: ... chưa có high contrast mode") - TƯƠNG PHẢN CAO: MẶC ĐỊNH TẮT (giao diện như cũ). Bật thì `main.dart` dựng theme sáng/tối với
  /// `ColorScheme.fromSeed(contrastLevel: 1.0)` (màu chữ/nút/viền đậm hơn trên nền). Đổi ngay không cần mở lại app. GIỚI HẠN: chỉ đổi BẢNG MÀU theme - các chỗ dùng màu cố
  /// (`Colors.grey`...) vẫn giữ nguyên (chưa nhìn trên máy thật).
  static final ValueNotifier<bool> highContrastNotifier = ValueNotifier<bool>(false);
  bool get highContrast => highContrastNotifier.value;
  set highContrast(bool v) => highContrastNotifier.value = v;
  bool _autoSaveStarted = false;

  static int? _i(Object? v) => v is num ? v.toInt() : null;
  static double? _d(Object? v) => v is num ? v.toDouble() : null;
  static bool? _b(Object? v) => v is bool ? v : null;
  static String? _s(Object? v) => v is String ? v : null;
  static String? _e(Object? v, List<String> allowed) => v is String && allowed.contains(v) ? v : null;

  /// Các trường cần lưu (không gồm `hmacSecret`).
  Map<String, dynamic> toJson() => <String, dynamic>{
        'textScale': textScale,
        'language': language,
        'themeMode': themeMode,
        'highContrast': highContrast,
        'gpuPower': gpuPower,
        'duration': duration,
        'similarity': similarity,
        'beatsPerScene': beatsPerScene,
        'maxScenes': maxScenes,
        'numInferenceSteps': numInferenceSteps,
        'guidanceScale': guidanceScale,
        'characterDesc': characterDesc,
        'enableMotionCamera': enableMotionCamera,
        'enableLipsync': enableLipsync,
        'lipsyncBackend': lipsyncBackend,
        'enableSceneContinuity': enableSceneContinuity,
        'videoBackend': videoBackend,
        'genre': genre,
        'useLlmScript': useLlmScript,
        'generateVariants': generateVariants,
        'enableColorMatch': enableColorMatch,
        'enableSpeedRamping': enableSpeedRamping,
        'enableFormantShift': enableFormantShift,
        'formantQuefrencyMs': formantQuefrencyMs,
        'enableDeessing': enableDeessing,
        'enablePostFx': enablePostFx,
        'postFxIntensity': postFxIntensity,
        'enableMotionSmoothing': enableMotionSmoothing,
        'motionSmoothingMethod': motionSmoothingMethod,
        'enableRealesrganUpscale': enableRealesrganUpscale,
        'exportVertical': exportVertical,
        'quickMode': quickMode,
        'expertMode': expertMode,
        'controlVideoFilename': controlVideoFilename,
        'controlVideoLabel': controlVideoLabel,
        'loraSelection': loraSelection,
        'comfyWorkflow': comfyWorkflow,
        'burnInLyrics': burnInLyrics,
        'structureSnap': structureSnap,
        'watermarkText': watermarkText,
        'fxMotionBlur': fxMotionBlur,
        'fxLightLeak': fxLightLeak,
        'fxBloom': fxBloom,
        'exportPreset': exportPreset,
        'colorLook': colorLook,
        'upscaleFaceMode': upscaleFaceMode,
        'settingDesc': settingDesc,
      };

  /// Áp giá trị đã lưu lên các trường; trường thiếu/sai kiểu giữ nguyên giá trị hiện tại.
  void applyJson(Map<String, dynamic> j) {
    textScale = _d(j['textScale']) ?? textScale;
    language = _e(j['language'], const ['vi', 'en']) ?? language;
    themeMode = _e(j['themeMode'], const ['light', 'dark', 'system']) ?? themeMode;
    highContrast = _b(j['highContrast']) ?? highContrast;
    gpuPower = (_i(j['gpuPower']) ?? gpuPower).clamp(20, 100).toInt();
    duration = (_d(j['duration']) ?? duration).clamp(5.0, 600.0).toDouble();
    similarity = (_d(j['similarity']) ?? similarity).clamp(0.0, 1.0).toDouble();
    beatsPerScene = (_i(j['beatsPerScene']) ?? beatsPerScene).clamp(1, 64).toInt();
    maxScenes = (_i(j['maxScenes']) ?? maxScenes).clamp(1, 64).toInt();
    numInferenceSteps = (_i(j['numInferenceSteps']) ?? numInferenceSteps).clamp(1, 100).toInt();
    guidanceScale = (_d(j['guidanceScale']) ?? guidanceScale).clamp(0.0, 30.0).toDouble();
    characterDesc = _s(j['characterDesc']) ?? characterDesc;
    enableMotionCamera = _b(j['enableMotionCamera']) ?? enableMotionCamera;
    enableLipsync = _b(j['enableLipsync']) ?? enableLipsync;
    if (j.containsKey('lipsyncBackend')) lipsyncBackend = _s(j['lipsyncBackend']);
    enableSceneContinuity = _b(j['enableSceneContinuity']) ?? enableSceneContinuity;
    if (j.containsKey('videoBackend')) videoBackend = _s(j['videoBackend']);
    if (j.containsKey('genre')) genre = _s(j['genre']);
    useLlmScript = _b(j['useLlmScript']) ?? useLlmScript;
    generateVariants = _b(j['generateVariants']) ?? generateVariants;
    enableColorMatch = _b(j['enableColorMatch']) ?? enableColorMatch;
    enableSpeedRamping = _b(j['enableSpeedRamping']) ?? enableSpeedRamping;
    enableFormantShift = _b(j['enableFormantShift']) ?? enableFormantShift;
    formantQuefrencyMs = (_d(j['formantQuefrencyMs']) ?? formantQuefrencyMs).clamp(0.0, 10.0).toDouble();
    enableDeessing = _b(j['enableDeessing']) ?? enableDeessing;
    enablePostFx = _b(j['enablePostFx']) ?? enablePostFx;
    postFxIntensity = _e(j['postFxIntensity'], const ['light', 'strong']) ?? postFxIntensity;
    enableMotionSmoothing = _b(j['enableMotionSmoothing']) ?? enableMotionSmoothing;
    motionSmoothingMethod = _e(j['motionSmoothingMethod'], const ['ffmpeg', 'rife']) ?? motionSmoothingMethod;
    enableRealesrganUpscale = _b(j['enableRealesrganUpscale']) ?? enableRealesrganUpscale;
    exportVertical = _b(j['exportVertical']) ?? exportVertical;
    quickMode = _b(j['quickMode']) ?? quickMode;
    expertMode = _b(j['expertMode']) ?? expertMode;
    controlVideoFilename = _s(j['controlVideoFilename']) ?? controlVideoFilename; // mục 47: trước là `as String?` (ném TypeError khi sai kiểu, trái cam kết "sai kiểu thì bỏ qua")
    controlVideoLabel = _s(j['controlVideoLabel']) ?? controlVideoLabel;
    final ls = j['loraSelection'];
    if (ls is Map) {
      final m = <String, double>{};
      ls.forEach((k, v) {
        if (k is String && v is num) m[k] = v.toDouble();
      });
      loraSelection = m;
    }
    comfyWorkflow = _s(j['comfyWorkflow']) ?? comfyWorkflow;
    burnInLyrics = _e(j['burnInLyrics'], const ['', 'plain', 'karaoke']) ?? burnInLyrics;
    structureSnap = _b(j['structureSnap']) ?? structureSnap;
    watermarkText = _s(j['watermarkText']) ?? watermarkText;
    fxMotionBlur = _b(j['fxMotionBlur']) ?? fxMotionBlur;
    fxLightLeak = _b(j['fxLightLeak']) ?? fxLightLeak;
    fxBloom = _b(j['fxBloom']) ?? fxBloom;
    exportPreset = _e(j['exportPreset'], const ['', 'youtube_1080p']) ?? exportPreset;
    colorLook = _e(j['colorLook'], const ['', 'warm', 'cool', 'teal_orange', 'faded_film']) ?? colorLook;
    upscaleFaceMode = _e(j['upscaleFaceMode'], const ['skip', 'protect']) ?? upscaleFaceMode;
    settingDesc = _s(j['settingDesc']) ?? settingDesc;
  }

  /// Nạp cài đặt đã lưu (gọi 1 lần ở main.dart trước runApp). Mọi lỗi -> giữ mặc định.
  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool(hmacRememberKey) == true) {
        rememberHmac = true;
        hmacSecret = prefs.getString(hmacSecretKey) ?? hmacSecret;
      }
      final raw = prefs.getString(prefsKey);
      if (raw == null || raw.isEmpty) return;
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) applyJson(decoded);
    } catch (_) {
      // file lưu hỏng/không đọc được -> dùng mặc định, không chặn app
    }
  }

  /// Lưu cài đặt hiện tại. Mọi lỗi bị nuốt (không được làm hỏng luồng đang chạy).
  Future<void> save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(prefsKey, jsonEncode(toJson()));
    } catch (_) {}
  }

  /// Tự lưu khi app xuống nền / mất focus / bị đóng. Gọi nhiều lần cũng chỉ đăng ký 1 lần.
  void startAutoSave() {
    if (_autoSaveStarted) return;
    _autoSaveStarted = true;
    WidgetsBinding.instance.addObserver(_SettingsLifecycleSaver());
  }
}

class _SettingsLifecycleSaver with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      GenerationSettings.instance.save();
    }
  }
}
