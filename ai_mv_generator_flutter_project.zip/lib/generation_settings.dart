/// Cài đặt tham số tạo nhạc/MV, chỉnh trong SettingsScreen, áp dụng cho mọi
/// lần gọi API. Singleton đơn giản (chưa lưu bền qua lần mở app).
class GenerationSettings {
  GenerationSettings._();
  static final GenerationSettings instance = GenerationSettings._();

  /// "Công suất sử dụng GPU remote", 20-100 (%). ĐÂY LÀ 1 NÚT DUY NHẤT,
  /// không phải khái niệm lượng tử hoá/VRAM - người dùng chỉ cần hiểu: thấp
  /// hơn = GPU remote "làm việc nhẹ tay hơn" (nghỉ giữa các bước), lâu hơn
  /// nhưng ít bị Colab bóp/ngắt phiên hơn. Backend tự quyết định chi tiết kỹ
  /// thuật tương ứng (lượng tử hoá, offload...) - app không cần biết.
  int gpuPower = 70;

  double duration = 30; // giây - độ dài bản nhạc tạo ra
  double similarity = 0.3; // mức biến tấu khi tạo từ nhạc mẫu (thấp = khác nhiều)
  int beatsPerScene = 4; // số beat gộp thành 1 cảnh video
  int maxScenes = 8; // giới hạn số cảnh trong MV
  int numInferenceSteps = 20; // số bước khử nhiễu khi sinh mỗi cảnh video
  double guidanceScale = 7.5; // độ bám sát prompt khi sinh cảnh video

  /// Tuỳ chọn: mô tả nhân vật cố định (vd "cô gái tóc đen dài, áo khoác đỏ")
  /// dùng để: (a) sinh 1 ẢNH THAM CHIẾU nhân vật riêng, (b) khoá ảnh đó vào
  /// mọi cảnh qua IP-Adapter/VACE reference_images tuỳ backend đang chọn -
  /// cơ chế khoá danh tính THẬT (không phải mẹo prompt chữ như bản cũ). Để
  /// trống = không sinh ảnh tham chiếu, quay lại hành vi cũ.
  String characterDesc = '';

  /// Tự chọn kiểu chuyển động camera (zoom/lia) theo nhịp mạnh/nhẹ từng cảnh
  /// qua Motion LoRA - CHƯA CHẠY THỬ THẬT trên GPU thật, mặc định BẬT vì có
  /// cơ chế tự bỏ qua an toàn ở backend nếu tải LoRA lỗi. Tắt nếu thấy nạp
  /// model chậm hẳn hoặc muốn quay lại hành vi cũ.
  bool enableMotionCamera = true;

  /// MỚI (mục 7zc2) - Lipsync (khớp khẩu hình theo lời hát) - MẶC ĐỊNH TẮT
  /// (rủi ro cao nhất trong dự án, chỉ hoạt động thật khi style đang chọn có
  /// `lipsync_ok=true` - hiện chỉ có "nguoi_that_studio"). `style_screen.dart`
  /// tự đặt lại về false nếu người dùng đổi sang style không hỗ trợ.
  bool enableLipsync = false;

  /// MỚI (mục 7zc9) - backend Lipsync đang chọn - null = để server tự dùng
  /// mặc định (`DEFAULT_LIPSYNC_BACKEND` ở app.py, hiện là "wav2lip"). KHÔNG
  /// hardcode danh sách backend ở Flutter - `StyleScreen` tự lấy qua
  /// `getLipsyncBackends()` lúc mở màn, cùng pattern `videoBackend` bên
  /// dưới. Chỉ có ý nghĩa khi `enableLipsync == true`.
  String? lipsyncBackend;

  /// MỚI (mục 7zc5) - "Nối cảnh mượt" - lấy khung hình cuối cảnh trước làm
  /// điều kiện sinh cảnh sau, giảm giật/nhấp nháy bối cảnh. MẶC ĐỊNH TẮT
  /// (CHƯA test thật trên GPU) - chỉ có tác dụng thật khi `videoBackend` hỗ
  /// trợ (hiện chỉ "wan22") - `settings_screen.dart` tự đặt lại về false
  /// nếu đổi sang backend không hỗ trợ.
  bool enableSceneContinuity = false;

  /// Backend video đang chọn - null = để server tự dùng mặc định
  /// (`DEFAULT_VIDEO_BACKEND` ở app.py, hiện là "animatediff"). KHÔNG
  /// hardcode danh sách backend ở Flutter - `SettingsScreen` tự lấy qua
  /// `getVideoBackends()` lúc mở màn, giá trị này chỉ lưu ID người dùng đã
  /// chọn (String bất kỳ do server trả về, không phải enum cố định).
  String? videoBackend;

  /// Thể loại kịch bản MV cho /build-storyboard - null = server tự dùng mặc
  /// định ("narrative"). KHÔNG hardcode danh sách ở Flutter, cùng pattern
  /// videoBackend - StoryboardScreen tự lấy qua getVideoGenres() lúc mở màn.
  String? genre;

  /// Bật "kịch bản viết bằng LLM" (đọc lời bài hát, viết hành động/bối cảnh
  /// thật thay vì mẫu câu cố định) ở /build-storyboard - CẦN có lời bài hát
  /// (project.lyrics không rỗng) mới có tác dụng. Mặc định TẮT vì chạy CPU
  /// chậm hơn hệ mẫu câu tức thời, và CHƯA CHẠY THỬ THẬT (xem tài liệu kỹ
  /// thuật) - người dùng tự bật nếu muốn thử.
  bool useLlmScript = false;

  /// Tạo 2 bản nhạc (khác seed) để nghe thử và chọn - giống quy trình Suno/
  /// Udio. Mặc định TẮT (khác Motion LoRA) vì đây là request ĐỒNG BỘ (không
  /// chạy nền), 2 bản = gấp đôi thời gian giữ HTTP request/tốn GPU của 1 lần
  /// bấm "Tạo nhạc" - người dùng tự bật nếu chấp nhận đợi lâu hơn.
  bool generateVariants = false;

  /// MỚI - "Color Grading" tự động (khớp tông màu mọi cảnh theo cảnh mở đầu)
  /// - MẶC ĐỊNH BẬT vì backend luôn tự rơi về giữ nguyên màu gốc nếu lỗi
  /// (an toàn, không hỏng job) - tắt nếu muốn giữ đúng màu AI tự sinh, không
  /// can thiệp hậu kỳ.
  bool enableColorMatch = true;

  /// MỚI - "Beat-Reactive Speed Ramping" (THỬ NGHIỆM, TẮT mặc định): đổi nhẹ
  /// tốc độ phát mỗi cảnh (±6%) theo cường độ nhịp - xem ghi chú trong
  /// `_run_generate_mv_job` (app.py) về lý do đây là bản ĐƠN GIẢN, an toàn
  /// hơn ý tưởng "DTW per-frame" gốc.
  bool enableSpeedRamping = false;

  /// MỚI - "Formant Shifting" cho giọng RVC (THỬ NGHIỆM, TẮT mặc định) - xem
  /// `_apply_formant_shift` (app.py). Cần cài `stftpitchshift` ở Colab.
  bool enableFormantShift = false;
  double formantQuefrencyMs = 1.5;

  /// MỚI - "De-essing" (giảm tiếng xì/rít gió 4-8kHz, THỬ NGHIỆM, TẮT mặc
  /// định) - xem `_apply_deessing` (app.py). Khác Formant Shifting (2 kỹ
  /// thuật DSP riêng biệt dù PDF gốc gộp chung).
  bool enableDeessing = false;

  /// MỚI - Khoá bí mật dùng để ký HMAC cho 2 request tốn GPU nặng nhất
  /// (/generate-mv, /train-voice) - xem `_verify_hmac_signature` trong
  /// app.py. Để TRỐNG = KHÔNG ký gì cả (giống hành vi cũ) - backend cũng tự
  /// tắt kiểm tra nếu không đặt `MV_APP_HMAC_SECRET` ở Colab, nên chỉ cần
  /// điền ô này khi bạn ĐÃ đặt cùng 1 chuỗi bí mật ở Cell 2.7 của
  /// colab_setup.py - 2 bên PHẢI khớp NGUYÊN VĂN thì mới ký/xác minh đúng.
  String hmacSecret = '';

  // ---- MỚI (BỔ SUNG dựa trên file "Phân_tích_MV_triệu_view_-_DeepSeek.pdf"
  // - xem post_processing_v2.py + CHANGELOG_NANG_CAP.md mục 10 phía backend) ----

  /// Hiệu ứng hậu kỳ điện ảnh (vignette + film grain + sharpen) - RẺ (chỉ
  /// ffmpeg filter, vài giây), backend tự bỏ qua an toàn nếu lỗi - MẶC ĐỊNH
  /// BẬT, cùng tinh thần `enableColorMatch` ở trên.
  bool enablePostFx = true;

  /// "light" (mặc định, khó nhận ra là có xử lý) hoặc "strong" (rõ hơn, hợp
  /// MV tối/kịch tính) - chỉ có ý nghĩa khi `enablePostFx == true`.
  String postFxIntensity = 'light';

  /// Làm mượt chuyển động (nội suy khung hình 24->48fps bằng ffmpeg
  /// `minterpolate`) - LƯU Ý đây KHÔNG PHẢI RIFE thật (model học sâu), chỉ
  /// là thuật toán cổ điển nhẹ hơn - xem cảnh báo trong post_processing_v2.py.
  /// MẶC ĐỊNH TẮT (khá tốn CPU trên MV nhiều cảnh, người dùng tự bật nếu
  /// chấp nhận đợi lâu hơn để đổi lấy chuyển động mượt hơn).
  bool enableMotionSmoothing = false;

  /// MỚI - "ffmpeg" (mặc định, thuật toán cổ điển, LUÔN sẵn có) hoặc "rife"
  /// (deep learning THẬT, chất lượng cao hơn hẳn - xem
  /// post_processing_v2.smooth_motion_interpolate_rife + rife_ifnet.py) -
  /// CHỈ có tác dụng khi `enableMotionSmoothing == true`. RIFE KHÔNG cần cài
  /// thêm package (chỉ cần file `rife_ifnet.py` có sẵn trong repo + torch,
  /// torch đã có sẵn qua Colab) - tự tải model 67MB lần đầu dùng.
  String motionSmoothingMethod = 'ffmpeg';

  /// MỚI - Upscale MV bằng Real-ESRGAN (xem
  /// post_processing_v2.upscale_video_realesrgan) - MẶC ĐỊNH TẮT: CẦN CÀI
  /// THÊM `pip install realesrgan basicsr` trên Colab (KHÔNG có sẵn mặc
  /// định, khác RIFE ở trên) VÀ rất chậm nếu Colab không có GPU thật (~48.7
  /// giây/khung hình đã đo trên CPU) - chỉ bật khi chắc chắn đã cài đủ +
  /// đang chạy GPU thật.
  bool enableRealesrganUpscale = false;

  /// Xuất THÊM 1 bản dọc 9:16 cho YouTube Shorts/TikTok/Instagram Reels
  /// (crop giữa khung - KHÔNG PHẢI "smart crop" dõi chủ thể) - KHÔNG thay
  /// thế bản ngang, chỉ tạo thêm 1 file/artifact riêng (kind
  /// "final_mv_vertical"). MẶC ĐỊNH TẮT (tốn thêm thời gian encode + dung
  /// lượng máy - người dùng tự bật nếu cần đăng lên nền tảng dọc).
  bool exportVertical = false;
}
