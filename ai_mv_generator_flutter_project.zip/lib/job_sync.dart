import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'api_service.dart';
import 'project_data.dart';

/// MỚI (mục 69) - GIỮ BẢN SAO DỮ LIỆU JOB TRONG APP để "tiếp tục từ chỗ dừng" chạy được cả khi đổi tài khoản Colab / đổi GPU / Drive trống.
/// Backend tiếp tục job (`resume_job_id`) bằng cách đọc lại `scenes/<job>/scene_N.mp4` + `beats.json` + nhạc + ảnh tham chiếu trên Drive CỦA TÀI KHOẢN ĐANG DÙNG;
/// đổi tài khoản = Drive trống. Nên app giữ bản sao (vài MB/cảnh) ở thư mục VĨNH VIỄN `<tài liệu>/job_sync/<job>/` (KHÁC thư mục tạm bị hệ điều hành dọn) và ĐẨY LẠI
/// các tệp backend đang thiếu trước khi gọi tiếp tục. Tên/đường dẫn tương đối giữ NGUYÊN nên tham số dự án trong app vẫn hợp lệ.
/// Mọi hàm là "cố gắng hết sức": lỗi mạng/ổ đĩa bị nuốt (không bao giờ làm hỏng luồng tạo MV); trả số tệp đã xử lý để hiển thị nếu cần.
/// Giới hạn: không sao lưu cảnh tự quay đã tải lên backend (UPLOAD cục bộ của Colab); chỉ giữ [keepJobs] job gần nhất để khỏi đầy máy.
class JobSync {
  JobSync._();

  static const int keepJobs = 3;

  static Future<Directory> _root() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/job_sync');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  /// Đường dẫn tương đối hợp lệ để ghi ra đĩa cục bộ (chặn '..', tuyệt đối, '\\').
  static bool safeRel(String rel) {
    return rel.isNotEmpty && !rel.startsWith('/') && !rel.contains('..') && !rel.contains('\\');
  }

  /// Tệp "kèm theo" của dự án cần có để tiếp tục: nhạc (đã đổi giọng nếu có) + ảnh tham chiếu nhân vật.
  static List<String> extrasFor(ProjectData p) {
    final out = <String>[];
    for (final n in [p.voicedFilename, p.musicFilename]) {
      if (n != null && n.isNotEmpty && !out.contains(n)) out.add(n);
    }
    final ref = p.confirmedCharacterReferenceFilename;
    if (ref != null && ref.isNotEmpty) out.add('character_refs/$ref');
    return out;
  }

  /// Lưu một tệp của job (thường là cảnh vừa nhận qua kênh đẩy trực tiếp) vào thư mục vĩnh viễn.
  static Future<void> keep(String jobId, String rel, List<int> bytes) async {
    try {
      if (!safeRel(rel) || jobId.isEmpty || jobId.contains('/') || jobId.contains('..')) return;
      final root = await _root();
      final f = File('${root.path}/$jobId/$rel');
      await f.parent.create(recursive: true);
      await f.writeAsBytes(bytes, flush: true);
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  /// Tải về những tệp NHỎ còn thiếu trên máy mà backend đang có: beats.json/văn bản của job + nhạc + ảnh tham chiếu. Cảnh .mp4 không tải ở đây (đã nhận qua kênh đẩy).
  static Future<int> mirrorMeta(ApiService api, String jobId, List<String> extras) async {
    var n = 0;
    try {
      final root = await _root();
      final listing = await api.bundleList(jobId, extras);
      final wanted = <String>[];
      for (final f in (listing['files'] is List ? listing['files'] as List : <dynamic>[])) {
        if (f is Map && f['rel'] is String) {
          final rel = f['rel'] as String;
          if (rel.endsWith('.json') || rel.endsWith('.txt')) wanted.add(rel);
        }
      }
      for (final e in (listing['extras'] is List ? listing['extras'] as List : <dynamic>[])) {
        if (e is Map && e['rel'] is String && e['size'] is num && (e['size'] as num) > 0) wanted.add(e['rel'] as String);
      }
      for (final rel in wanted) {
        if (!safeRel(rel)) continue;
        final f = File('${root.path}/$jobId/$rel');
        if (await f.exists()) continue;
        try {
          final bytes = await api.downloadBytes(rel);
          await f.parent.create(recursive: true);
          await f.writeAsBytes(bytes, flush: true);
          n++;
        } catch (_) {
          // một tệp lỗi không chặn các tệp sau
        }
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
    return n;
  }

  /// Trước khi TIẾP TỤC job: so với backend đang kết nối và đẩy lên những tệp backend còn thiếu (backend mới/Drive trống). Backend không ghi đè tệp đã có.
  static Future<int> restoreToBackend(ApiService api, String jobId, List<String> extras) async {
    var n = 0;
    try {
      final root = await _root();
      final jobDir = Directory('${root.path}/$jobId');
      if (!await jobDir.exists()) return 0;
      final local = <String, File>{};
      await for (final e in jobDir.list(recursive: true)) {
        if (e is File) {
          final rel = e.path.substring(jobDir.path.length + 1);
          if (safeRel(rel)) local[rel] = e;
        }
      }
      if (local.isEmpty) return 0;
      final listing = await api.bundleList(jobId, extras);
      final have = <String>{};
      for (final key in ['files', 'extras']) {
        for (final f in (listing[key] is List ? listing[key] as List : <dynamic>[])) {
          if (f is Map && f['rel'] is String && f['size'] is num && (f['size'] as num) > 0) have.add(f['rel'] as String);
        }
      }
      for (final entry in local.entries) {
        if (have.contains(entry.key)) continue;
        try {
          final res = await api.bundleImport(entry.key, await entry.value.readAsBytes());
          if (res['saved'] == true) n++;
        } catch (_) {
          // một tệp lỗi không chặn các tệp sau
        }
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
    return n;
  }

  /// Giữ [keepJobs] job gần nhất (theo thời điểm sửa), xoá phần còn lại để khỏi đầy máy.
  static Future<void> prune({int keep = keepJobs}) async {
    try {
      final root = await _root();
      final dirs = <Directory>[];
      await for (final e in root.list()) {
        if (e is Directory && !e.path.split('/').last.startsWith('_')) dirs.add(e); // `_assets` (giọng/clip) KHÔNG nằm trong vòng dọn job
      }
      if (dirs.length <= keep) return;
      final stamped = <MapEntry<Directory, DateTime>>[];
      for (final d in dirs) {
        stamped.add(MapEntry(d, (await d.stat()).modified));
      }
      stamped.sort((a, b) => b.value.compareTo(a.value));
      for (final old in stamped.skip(keep)) {
        await old.key.delete(recursive: true);
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  // ------------------------------------------------------------------ TỆP ĐẦU VÀO của người dùng (giọng RVC, clip tự quay, ảnh/video tham chiếu)
  // Backend giữ chúng ở nơi MẤT khi Colab khởi động lại (clip/ảnh ở /content) hoặc ở Drive của tài khoản cũ (giọng). App giữ bản sao vĩnh viễn ở `<tài liệu>/job_sync/_assets/<loại>/<tên>`
  // và đẩy lại cái backend thiếu. Giọng RVC TỰ TRAIN do backend tạo nên app không có bản gốc: tải về từ backend khi nó còn sống (mirrorAssets).
  static const List<String> assetKinds = ['voices', 'user_clips', 'uploads'];
  static const int maxAssetBytes = 200 * 1024 * 1024; // khớp giới hạn backend; tệp lớn hơn bỏ qua

  static bool safeAssetRel(String rel) {
    final parts = rel.split('/');
    return safeRel(rel) && parts.length == 2 && assetKinds.contains(parts[0]) && parts[1].isNotEmpty && !parts[1].startsWith('.');
  }

  static Future<Directory> _assetsRoot() async {
    final root = await _root();
    final d = Directory('${root.path}/_assets');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<void> keepAssetBytes(String rel, List<int> bytes) async {
    try {
      if (!safeAssetRel(rel) || bytes.isEmpty || bytes.length > maxAssetBytes) return;
      final root = await _assetsRoot();
      final f = File('${root.path}/$rel');
      await f.parent.create(recursive: true);
      await f.writeAsBytes(bytes, flush: true);
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  /// Lưu bản sao một tệp người dùng vừa tải lên backend (clip, video điều khiển, giọng .pth) - tệp gốc có thể bị xoá khỏi bộ nhớ đệm của trình chọn tệp.
  static Future<void> keepAssetFile(String rel, File src) async {
    try {
      if (!safeAssetRel(rel) || await src.length() > maxAssetBytes) return;
      await keepAssetBytes(rel, await src.readAsBytes());
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  /// Backend có thể ĐÃ biến đổi tệp khi nhận (vd ảnh tham chiếu bố cục đổi sang PNG, thu nhỏ): lấy đúng bản backend đang giữ thay vì tệp gốc trên máy.
  static Future<void> keepAssetFromBackend(ApiService api, String rel) async {
    try {
      if (!safeAssetRel(rel)) return;
      await keepAssetBytes(rel, await api.bundleGet(rel));
    } catch (_) {
      // cố ý nuốt lỗi
    }
  }

  static Future<Map<String, int>> _localAssets() async {
    final out = <String, int>{};
    final root = await _assetsRoot();
    for (final kind in assetKinds) {
      final d = Directory('${root.path}/$kind');
      if (!await d.exists()) continue;
      await for (final e in d.list()) {
        if (e is File) {
          final rel = '$kind/${e.path.split('/').last}';
          if (safeAssetRel(rel)) out[rel] = await e.length();
        }
      }
    }
    return out;
  }

  /// Tải về các GIỌNG backend có mà máy chưa lưu (giọng tự train). Clip/ảnh không tải vì app luôn có bản gốc từ lúc tải lên.
  static Future<int> mirrorAssets(ApiService api) async {
    var n = 0;
    try {
      final local = await _localAssets();
      final backend = await api.bundleAssets();
      for (final a in backend) {
        final rel = a['rel'];
        final size = a['size'];
        if (rel is! String || !rel.startsWith('voices/') || local.containsKey(rel)) continue;
        if (size is num && (size <= 0 || size > maxAssetBytes)) continue;
        try {
          await keepAssetBytes(rel, await api.bundleGet(rel));
          n++;
        } catch (_) {
          // một giọng lỗi không chặn các giọng sau
        }
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
    return n;
  }

  /// Tên các tệp đầu vào máy có mà backend đang THIẾU (để hiện "còn thiếu N tệp" và để khôi phục).
  static Future<List<String>> missingAssets(ApiService api) async {
    try {
      final local = await _localAssets();
      if (local.isEmpty) return <String>[];
      final have = <String>{};
      for (final a in await api.bundleAssets()) {
        final rel = a['rel'];
        final size = a['size'];
        if (rel is String && size is num && size > 0) have.add(rel);
      }
      return <String>[for (final rel in local.keys) if (!have.contains(rel)) rel]..sort();
    } catch (_) {
      return <String>[];
    }
  }

  /// Đẩy lên backend những tệp đầu vào nó đang thiếu. Backend không ghi đè tệp đã có. Trả số tệp đã đẩy.
  static Future<int> restoreAssets(ApiService api) async {
    var n = 0;
    try {
      final root = await _assetsRoot();
      for (final rel in await missingAssets(api)) {
        try {
          final res = await api.bundleImport(rel, await File('${root.path}/$rel').readAsBytes());
          if (res['saved'] == true) n++;
        } catch (_) {
          // một tệp lỗi không chặn các tệp sau
        }
      }
    } catch (_) {
      // cố ý nuốt lỗi
    }
    return n;
  }
}
