import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'background_service.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  initializeBackgroundService(); // đăng ký service - CHƯA tự chạy (autoStart: false)
  // Khoá dọc: tránh xoay màn hình làm Android recreate Activity giữa lúc
  // GeneratingScreen đang giữ kết nối WebSocket - xoay ngang sẽ làm mất kết
  // nối đang chạy dở nếu không khoá orientation.
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then((_) => runApp(const MvApp()));
}

class MvApp extends StatelessWidget {
  const MvApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI MV Generator',
      theme: ThemeData(colorSchemeSeed: Colors.deepPurple, useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}
