import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'background_service.dart';
import 'app_theme.dart';
import 'api_service.dart';
import 'crash_log.dart';
import 'crash_sync.dart';
import 'exit_info.dart';
import 'foreground_marker.dart';
import 'crashlytics_support.dart';
import 'error_reporter.dart';
import 'generation_settings.dart';
import 'muted_color.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  installMutedGreyAutoRebuild(); // MỚI (mục 63b) - màn đang mở tự đổi màu xám khi đổi Tương phản cao / sáng-tối
  CrashLog.install(); // MỚI (mục 23) - ghi lỗi Dart vào nhật ký cục bộ (xem Cài đặt > Nhật ký lỗi)
  ApiService.onReachable = CrashSync.onReachable; // MỚI (mục 56) - tự gửi nhật ký lỗi mới về backend khi kết nối được
  // MỚI (mục 57/58) - ghi vào nhật ký lý do app bị tắt lần trước (crash native/ANR/bị giết/lỗi Java; Android dưới 11 thì phát hiện "chết ở tiền cảnh"), RỒI mới theo dõi vòng đời
  ExitInfoReporter.collect().catchError((Object _) {}).whenComplete(ForegroundMarker.start);
  initializeBackgroundService(); // đăng ký service - CHƯA tự chạy (autoStart: false)
  // Khoá dọc: tránh xoay màn hình làm Android recreate Activity giữa lúc
  // GeneratingScreen đang giữ kết nối WebSocket - xoay ngang sẽ làm mất kết
  // nối đang chạy dở nếu không khoá orientation.
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then((_) async {
    // MỚI (mục 27) - nạp cài đặt đã lưu (lỗi đọc -> giữ mặc định, không chặn app) và bật tự lưu khi app xuống nền.
    await GenerationSettings.instance.load();
    await ErrorReporter.load(); // MỚI (mục 27) - DSN báo lỗi tự động (tuỳ chọn, mặc định rỗng = tắt)
    await initCrashlytics(); // MỚI (mục 27) - bản mặc định rỗng; chỉ làm gì khi build bật Crashlytics (xem build.yml)
    GenerationSettings.instance.startAutoSave();
    runApp(const MvApp());
  });
}

class MvApp extends StatelessWidget {
  const MvApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MỚI (mục 24) - theme dựng ở lib/app_theme.dart (có thể thay bằng bản Dynamic Color khi build thủ công).
    return buildThemedApp(
      (theme) => ValueListenableBuilder<String>(
        // MỚI (mục 27) - chế độ sáng/tối TUỲ CHỌN (mặc định 'light' = như trước). Theme tối dựng ngay đây từ cùng màu hạt giống nên KHÔNG phụ thuộc app_theme.dart
        // (bản Dynamic Color thay thế file đó vẫn dùng được).
        valueListenable: GenerationSettings.themeModeNotifier,
        builder: (context, modeName, _) => ValueListenableBuilder<bool>(
        // MỚI (mục 54, PDF-2 §11.3) - tương phản cao: công tắc trong app (mặc định tắt) HOẶC hệ điều hành bật "tăng tương phản" (`highContrastTheme` tự được Flutter dùng).
        valueListenable: GenerationSettings.highContrastNotifier,
        builder: (context, highContrast, _) => MaterialApp(
        title: 'AI MV Generator',
        theme: highContrast ? _contrastTheme(Brightness.light, theme.pageTransitionsTheme) : theme,
        darkTheme: highContrast
            ? _contrastTheme(Brightness.dark, theme.pageTransitionsTheme)
            : ThemeData(
                colorSchemeSeed: Colors.deepPurple,
                brightness: Brightness.dark,
                useMaterial3: true,
                pageTransitionsTheme: theme.pageTransitionsTheme,
              ),
        highContrastTheme: _contrastTheme(Brightness.light, theme.pageTransitionsTheme),
        highContrastDarkTheme: _contrastTheme(Brightness.dark, theme.pageTransitionsTheme),
        themeMode: modeName == 'dark' ? ThemeMode.dark : (modeName == 'system' ? ThemeMode.system : ThemeMode.light),
        // MỚI (mục 27) - cỡ chữ tuỳ chỉnh (nhân thêm lên cỡ chữ hệ thống; đổi ngay khi kéo thanh trượt ở Cài đặt).
        builder: (context, child) => ValueListenableBuilder<double>(
          valueListenable: GenerationSettings.textScaleNotifier,
          builder: (context, scale, _) {
            final media = MediaQuery.of(context);
            final system = media.textScaler.scale(14.0) / 14.0;
            Widget content = child ?? const SizedBox.shrink();
            // MỚI (mục 27, PDF 11.4) - MÁY TÍNH BẢNG / màn rộng: giữ nội dung ở giữa, tối đa 720dp thay vì kéo giãn kín màn (điện thoại KHÔNG đổi gì).
            if (media.size.width > 840) {
              content = ColoredBox(
                color: Theme.of(context).scaffoldBackgroundColor,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: content),
                ),
              );
            }
            return MediaQuery(
              data: media.copyWith(textScaler: TextScaler.linear(system * scale)),
              child: content,
            );
          },
        ),
        home: const _StartGate(),
        ),
        ),
      ),
    );
  }
}

/// MỚI (mục 54) - theme TƯƠNG PHẢN CAO dựng ngay ở đây từ cùng màu hạt giống (KHÔNG phụ thuộc `app_theme.dart`, để bản Dynamic Color thay file đó vẫn biên dịch được).
/// `contrastLevel: 1.0` là mức tương phản cao nhất của `ColorScheme.fromSeed` (-1.0 thấp .. 0.0 chuẩn .. 1.0 cao).
ThemeData _contrastTheme(Brightness brightness, PageTransitionsTheme pageTransitions) {
  return ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple, brightness: brightness, contrastLevel: 1.0),
    useMaterial3: true,
    pageTransitionsTheme: pageTransitions,
  );
}

/// MỚI (mục 23) - cổng khởi động: lần đầu mở app hiện OnboardingScreen, các lần sau vào thẳng
/// HomeScreen. Lỗi đọc cài đặt -> vào thẳng HomeScreen (không bao giờ chặn người dùng).
class _StartGate extends StatefulWidget {
  const _StartGate();

  @override
  State<_StartGate> createState() => _StartGateState();
}

class _StartGateState extends State<_StartGate> {
  late final Future<bool> _doneFuture = _onboardingDone();

  Future<bool> _onboardingDone() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(OnboardingScreen.prefsKey) ?? false;
    } catch (_) {
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _doneFuture,
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Scaffold(body: SizedBox.shrink());
        return snapshot.data! ? const HomeScreen() : const OnboardingScreen();
      },
    );
  }
}
