/// MỚI (mục 69) - logic THUẦN (không phụ thuộc Flutter/plugin) để app lưu bản chụp cài đặt backend trên điện thoại và so với backend đang kết nối.
/// Bản chụp do backend gửi trong /control/status (khoá `manifest`, xem control_restore_extra.py): {v:1, env:{khoá:giá trị}, models:{khe:model}, features:[khoá tính năng đã cài]}.
/// Nguyên tắc: KHÔNG BAO GIỜ làm mất mục đã lưu chỉ vì backend đang kết nối trống (backend mới/đổi tài khoản) - muốn bỏ một mục phải do người dùng chủ động
/// (đặt lại model, bỏ cài đặt, hoặc "dùng cấu hình hiện tại làm bản gốc").
/// Chạy kiểm tra độc lập: `dart tools/manifest_merge_check.dart` (chỉ cần Dart SDK, không cần Flutter/pub).
class ManifestDiff {
  final List<String> env;
  final List<String> models;
  final List<String> features;
  const ManifestDiff(this.env, this.models, this.features);

  bool get isEmpty => env.isEmpty && models.isEmpty && features.isEmpty;
  int get total => env.length + models.length + features.length;
}

class ManifestMerge {
  static const int version = 1;

  static Map<String, dynamic> empty() => <String, dynamic>{'v': version, 'env': <String, dynamic>{}, 'models': <String, dynamic>{}, 'features': <dynamic>[]};

  static Map<String, String> _strMap(dynamic v) {
    final out = <String, String>{};
    if (v is Map) {
      v.forEach((k, val) {
        if (k is String && val is String) out[k] = val;
      });
    }
    return out;
  }

  static List<String> _strList(dynamic v) {
    final out = <String>[];
    if (v is List) {
      for (final e in v) {
        if (e is String) out.add(e);
      }
    }
    return out;
  }

  /// Chuẩn hoá về đúng cấu trúc (bỏ mục sai kiểu); null/sai phiên bản -> bản rỗng.
  static Map<String, dynamic> normalize(Map<String, dynamic>? m) {
    if (m == null || m['v'] != version) return empty();
    final feats = _strList(m['features']).toSet().toList()..sort();
    return <String, dynamic>{'v': version, 'env': _strMap(m['env']), 'models': _strMap(m['models']), 'features': feats};
  }

  static bool isEmpty(Map<String, dynamic>? m) {
    final n = normalize(m);
    return (n['env'] as Map).isEmpty && (n['models'] as Map).isEmpty && (n['features'] as List).isEmpty;
  }

  /// Giữ bản đã lưu, thêm/ghi đè bằng cái backend hiện có (tính năng: hợp của hai bên). Không xoá mục nào.
  static Map<String, dynamic> merge(Map<String, dynamic>? saved, Map<String, dynamic>? backend) {
    final a = normalize(saved);
    final b = normalize(backend);
    final env = <String, String>{...(a['env'] as Map<String, String>), ...(b['env'] as Map<String, String>)};
    final models = <String, String>{...(a['models'] as Map<String, String>), ...(b['models'] as Map<String, String>)};
    final feats = <String>{...(a['features'] as List<String>), ...(b['features'] as List<String>)}.toList()..sort();
    return <String, dynamic>{'v': version, 'env': env, 'models': models, 'features': feats};
  }

  static Map<String, dynamic> removeEnv(Map<String, dynamic>? saved, String key) {
    final n = normalize(saved);
    (n['env'] as Map<String, String>).remove(key);
    return n;
  }

  static Map<String, dynamic> removeModel(Map<String, dynamic>? saved, String slot) {
    final n = normalize(saved);
    (n['models'] as Map<String, String>).remove(slot);
    return n;
  }

  /// Những gì bản ĐÃ LƯU có mà backend hiện tại CHƯA có (khác giá trị cũng tính là thiếu): đây là thứ "Khôi phục" sẽ áp lại.
  static ManifestDiff diff(Map<String, dynamic>? saved, Map<String, dynamic>? backend) {
    final a = normalize(saved);
    final b = normalize(backend);
    final be = b['env'] as Map<String, String>;
    final bm = b['models'] as Map<String, String>;
    final bf = (b['features'] as List<String>).toSet();
    final env = <String>[for (final e in (a['env'] as Map<String, String>).entries) if (be[e.key] != e.value) e.key]..sort();
    final models = <String>[for (final e in (a['models'] as Map<String, String>).entries) if (bm[e.key] != e.value) e.key]..sort();
    final feats = <String>[for (final f in (a['features'] as List<String>)) if (!bf.contains(f)) f]..sort();
    return ManifestDiff(env, models, feats);
  }
}
