import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'manifest_merge.dart';

/// MỚI (mục 69) - lưu BẢN CHỤP CÀI ĐẶT backend trên điện thoại (SharedPreferences). Chỉ chứa: cài đặt nâng cao KHÔNG bí mật, khe model, tên tính năng đã cài
/// (backend đã loại giá trị bí mật khỏi bản chụp - xem control_restore_extra.py). KHÔNG chứa khoá API/khoá HMAC. Tách khỏi màn hình điều khiển để màn đó vẫn
/// không tự đụng SharedPreferences (việc ghi nhớ khoá HMAC là tuỳ chọn riêng của GenerationSettings.saveHmacChoice).
class ManifestStore {
  ManifestStore._();

  static const String key = 'control_manifest_v1';

  /// Bản đã lưu (đã chuẩn hoá); null nếu chưa lưu hoặc bản lưu hỏng.
  static Future<Map<String, dynamic>?> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(key);
      if (raw == null || raw.isEmpty) return null;
      final d = jsonDecode(raw);
      return d is Map ? ManifestMerge.normalize(Map<String, dynamic>.from(d)) : null;
    } catch (_) {
      return null;
    }
  }

  static Future<void> save(Map<String, dynamic> manifest) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(key, jsonEncode(manifest));
    } catch (_) {
      // cố ý nuốt lỗi: mất bản lưu chỉ làm mất tiện ích khôi phục, không ảnh hưởng việc tạo MV
    }
  }
}
