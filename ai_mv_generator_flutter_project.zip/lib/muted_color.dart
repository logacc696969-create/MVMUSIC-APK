import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';

import 'generation_settings.dart';

/// MỚI (mục 63, PDF-2 §11.3 / mục 54c) - màu xám CHỮ PHỤ/ICON PHỤ theo chế độ "Tương phản cao".
///
/// Trước đây ~110 chỗ dùng thẳng `Colors.grey` nên bật Tương phản cao chỉ đổi bảng màu theme, chữ phụ vẫn xám nhạt (khó đọc).
/// Khi Tương phản cao TẮT (mặc định) hàm này trả đúng `Colors.grey` nên giao diện KHÔNG đổi gì. Khi BẬT (công tắc trong app HOẶC hệ điều hành
/// bật "tăng tương phản"): nền sáng -> `grey.shade800` (đủ độ tương phản trên nền trắng), nền tối -> `grey.shade300`.
/// Là getter (không phải hằng) nên nơi dùng KHÔNG được nằm trong ngữ cảnh `const` - việc đổi hàng loạt được làm bằng bộ phân tích
/// `kiem_thu/dart_const_ctx.py` (gỡ `const` ở đúng các cha, bỏ qua chỗ không chắc) và có test khoá (`test_mv_v58.py`).
/// Màn ĐANG mở tự đổi màu ngay khi đổi công tắc (mục 63b): `installMutedGreyAutoRebuild()` (gọi 1 lần ở main()) nghe 2 công tắc + thay đổi
/// của hệ điều hành rồi ép dựng lại cả cây widget MỘT lần (mẫu `rebuildAllChildren` quen thuộc của cộng đồng Flutter; State được giữ nguyên, chỉ chạy lại build).
Color get mutedGrey {
  final dispatcher = PlatformDispatcher.instance;
  final highContrast = GenerationSettings.highContrastNotifier.value || dispatcher.accessibilityFeatures.highContrast;
  if (!highContrast) return Colors.grey;
  final mode = GenerationSettings.themeModeNotifier.value;
  final dark = mode == 'dark' || (mode == 'system' && dispatcher.platformBrightness == Brightness.dark);
  return dark ? Colors.grey.shade300 : Colors.grey.shade800;
}

bool _autoRebuildInstalled = false;

/// Đổi công tắc Tương phản cao / chế độ sáng-tối, hoặc hệ điều hành đổi tương phản/độ sáng -> dựng lại mọi widget MỘT lần (sau khung hiện tại).
/// Vì `mutedGrey` là getter toàn cục (không đăng ký phụ thuộc như `Theme.of(context)`), nếu không ép thì màn đang mở giữ màu cũ tới khi tự dựng lại.
/// An toàn gọi nhiều lần (chỉ cài 1 lần). Tốn kém nên CHỈ chạy khi đổi các công tắc hiếm này.
void installMutedGreyAutoRebuild() {
  if (_autoRebuildInstalled) return;
  _autoRebuildInstalled = true;
  final observer = _MutedGreyObserver();
  WidgetsBinding.instance.addObserver(observer);
  GenerationSettings.highContrastNotifier.addListener(_scheduleRebuildAll);
  GenerationSettings.themeModeNotifier.addListener(_scheduleRebuildAll);
}

class _MutedGreyObserver with WidgetsBindingObserver {
  @override
  void didChangeAccessibilityFeatures() => _scheduleRebuildAll();

  @override
  void didChangePlatformBrightness() => _scheduleRebuildAll();
}

void _scheduleRebuildAll() {
  final binding = WidgetsBinding.instance;
  binding.addPostFrameCallback((_) => _rebuildAllWidgets());
  binding.scheduleFrame(); // bảo đảm có khung để callback chạy kể cả khi không có gì khác cần vẽ
}

void _rebuildAllWidgets() {
  final root = WidgetsBinding.instance.rootElement;
  if (root == null) return;
  void rebuild(Element element) {
    element.markNeedsBuild();
    element.visitChildren(rebuild);
  }

  root.visitChildren(rebuild);
}
