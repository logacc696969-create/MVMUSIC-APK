import 'dart:async';
import 'api_service.dart';

/// Poll GET /progress mỗi giây trong lúc chờ 1 tác vụ dài (tạo nhạc, đổi
/// giọng, tạo MV) để hiển thị % và mô tả bước đang chạy trên UI.
class ProgressPoller {
  final ApiService api;
  final void Function(int percent, String stage, String detail) onUpdate;
  Timer? _timer;

  ProgressPoller({required this.api, required this.onUpdate});

  void start() {
    _timer = Timer.periodic(const Duration(seconds: 1), (_) async {
      try {
        final p = await api.getProgress();
        onUpdate(
          (p['percent'] as num?)?.toInt() ?? 0,
          p['stage'] as String? ?? '',
          p['detail'] as String? ?? '',
        );
      } catch (_) {
        // Bỏ qua lỗi tạm thời (mạng chập chờn) khi đang poll, không dừng luồng chính.
      }
    });
  }

  /// Dành cho job CHẠY NỀN bất đồng bộ (vd /train-voice, /generate-mv) - nơi
  /// gọi API endpoint chỉ trả về NGAY (job_id) chứ không tự chặn tới khi
  /// xong như /apply-voice đồng bộ. Hàm này tự poll /progress cho tới khi
  /// `done` = true (thành công HAY lỗi đều tính là done), rồi trả về map
  /// progress cuối cùng để nơi gọi tự kiểm tra `error`/`cancelled`. KHÔNG
  /// dùng start()/onUpdate ở đây - polling riêng, đơn giản hơn, không cần
  /// Timer vì gọi tuần tự trong 1 vòng lặp await.
  ///
  /// [shouldStop] MỚI (lượt audit sau 7zc19) - hàm này dùng vòng lặp
  /// `while(true)` (KHÁC `Timer.periodic` của `start()`/`stop()` phía trên)
  /// - KHÔNG CÓ CÁCH nào để "huỷ" 1 vòng lặp `while` đang chạy TỪ BÊN NGOÀI
  /// giống `Timer.cancel()`. Nếu widget gọi hàm này bị dispose GIỮA CHỪNG
  /// (trước khi server báo `done: true`), vòng lặp sẽ TIẾP TỤC gọi network
  /// mỗi [interval] giây CHO TỚI KHI done - lãng phí network/pin dù không
  /// crash (nơi gọi đã tự bọc `if (mounted)` quanh callback `onUpdate`).
  /// Truyền [shouldStop] (thường là `() => !mounted` từ widget gọi) để hàm
  /// tự kiểm tra ĐẦU MỖI VÒNG LẶP và thoát sớm nếu widget không còn cần
  /// theo dõi nữa - trả về map đặc biệt `{'done': false,
  /// '_cancelled_by_caller': true}` để nơi gọi phân biệt được đây là do chủ
  /// động huỷ, KHÔNG PHẢI lỗi thật hay job đã hoàn tất thật từ server.
  Future<Map<String, dynamic>> waitUntilDone({
    Duration interval = const Duration(seconds: 2),
    void Function(int percent, String detail)? onUpdate,
    bool Function()? shouldStop,
  }) async {
    while (true) {
      if (shouldStop?.call() == true) {
        return {'done': false, '_cancelled_by_caller': true};
      }
      Map<String, dynamic> p;
      try {
        p = await api.getProgress();
      } catch (_) {
        await Future.delayed(interval);
        continue; // mạng chập chờn - thử lại, không coi là lỗi cuối cùng
      }
      onUpdate?.call(
        (p['percent'] as num?)?.toInt() ?? 0,
        p['detail'] as String? ?? '',
      );
      if (p['done'] == true) return p;
      await Future.delayed(interval);
    }
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }
}
