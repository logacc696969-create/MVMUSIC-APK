import 'dart:io';

/// Gom toàn bộ lựa chọn của người dùng qua các bước, dùng chung 1 instance
/// truyền qua các màn hình trong luồng tạo 1 dự án MV.
class ProjectData {
  // Bước nhập liệu
  bool fromSample = false; // false = nhập text, true = tải nhạc mẫu
  String textPrompt = '';
  String lyrics = '';
  File? sampleFile;

  // Kết quả sau khi tạo nhạc
  String? musicFilename;

  // Bước chọn giọng hát (tuỳ chọn - null nghĩa là giữ nguyên, không đổi giọng)
  String? voiceId;
  String? voicedFilename;

  // Bước chọn phong cách MV
  String? styleId;

  /// Ước tính số cảnh (từ /analyze-beats ở màn Xem lại) - dùng để dựng lưới
  /// storyboard đúng kích thước ở màn Đang tạo. null nếu người dùng bỏ qua
  /// bước xem lại vì lý do gì đó (fallback: dùng maxScenes trong Settings).
  int? estimatedSceneCount;

  /// scene_dir_id trả về từ lần gọi /generate-mv gần nhất - dùng để RESUME
  /// (tiếp tục từ cảnh còn thiếu) nếu job bị ngắt giữa chừng, thay vì làm lại từ đầu.
  String? mvSceneDirId;

  /// Danh sách prompt RIÊNG cho từng cảnh, lấy từ StoryboardScreen (người
  /// dùng đã xem/sửa) - null nghĩa là bỏ qua bước storyboard, dùng lại hành
  /// vi CŨ (mọi cảnh dùng chung 1 style_prompt). Độ dài PHẢI khớp đúng số
  /// cảnh thật sự sinh ra ở /generate-mv (cùng audio + cùng
  /// beats_per_scene/max_scenes) - nếu lệch, backend tự bỏ qua và dùng lại
  /// style_prompt chung (an toàn, không crash).
  List<String>? scenePrompts;

  // Kết quả cuối
  String? mvFilename;

  /// File MV đã tải VỀ MÁY trong lúc job nền chạy (tải ngay khi vừa xong,
  /// không đợi hiển thị màn Kết quả mới tải) - null nếu chưa tải xong/lỗi.
  File? mvLocalFile;

  /// true nếu đã lưu thành công MV vào thư viện ảnh (Gallery) công khai của
  /// máy - false nếu lưu lỗi/chưa lưu (MV vẫn còn dùng được qua mvLocalFile,
  /// chỉ là chưa xuất hiện trong app Album ảnh hệ thống).
  bool savedToGallery = false;

  /// Đường dẫn LOCAL ảnh tham chiếu nhân vật ("character sheet") đã tải về
  /// trong lúc job chạy - null nếu job này không sinh (không có characterDesc,
  /// hoặc backend/model không hỗ trợ - xem tài liệu kỹ thuật mục 7zq/7zu).
  String? characterReferenceImagePath;

  /// Đường dẫn LOCAL các cảnh video đã tải về trong lúc job đang chạy nền.
  /// Dùng để hiển thị "đã lưu được X cảnh" khi mất kết nối giữa chừng, và có
  /// thể dùng tạm nếu job không hoàn tất được.
  final List<String> downloadedSceneFiles = [];
}
