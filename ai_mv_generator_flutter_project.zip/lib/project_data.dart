import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// Gom toàn bộ lựa chọn của người dùng qua các bước, dùng chung 1 instance
/// truyền qua các màn hình trong luồng tạo 1 dự án MV.
class ProjectData {
  /// MỚI - dọn các file cảnh .mp4 tạm (lưu ở getTemporaryDirectory() theo
  /// _saveAndRegister() trong generating_screen.dart) đã tải về trong các
  /// lần tạo MV TRƯỚC. Trước đây KHÔNG có bước dọn nào cả - vì các cảnh nhỏ
  /// được lưu vào thư mục tạm hệ thống (khác thư mục MV cuối, vốn đã chuyển
  /// vào thư mục vĩnh viễn), thư mục tạm sẽ phình to dần qua nhiều lần dùng
  /// app vì Android chỉ tự dọn cache khi máy sắp hết dung lượng.
  /// AN TOÀN: chỉ xoá đúng file khớp mẫu tên "scene_<số>.mp4" (theo
  /// _parseSceneIndex trong generating_screen.dart) - không đụng tới file
  /// preview_*/variant_*.wav tạm của review_screen.dart/variant_picker_screen.dart.
  /// Gọi khi: (1) bắt đầu 1 dự án MỚI ở HomeScreen (dọn rác từ job trước đã
  /// kết thúc), và (2) ngay sau khi tải xong MV cuối cùng của CHÍNH job này
  /// (không cần giữ lại các mảnh cảnh nữa vì đã có file MV hoàn chỉnh).
  static Future<void> purgeTemporaryScenes() async {
    try {
      final dir = await getTemporaryDirectory();
      if (!await dir.exists()) return;
      final sceneNamePattern = RegExp(r'scene_\d+\.mp4$');
      for (final entity in dir.listSync()) {
        if (entity is File && sceneNamePattern.hasMatch(entity.path)) {
          try {
            await entity.delete();
          } catch (_) {
            // 1 file lỗi xoá (đang mở/đang đọc) không nên chặn dọn các file còn lại.
          }
        }
      }
    } catch (_) {
      // Dọn rác là tác vụ tối ưu, không phải tác vụ bắt buộc - lỗi ở đây
      // (vd không truy cập được thư mục tạm) không nên ảnh hưởng luồng chính.
    }
  }

  // Bước nhập liệu
  bool fromSample = false; // false = nhập text, true = tải nhạc mẫu
  String textPrompt = '';
  String lyrics = '';
  File? sampleFile;

  // Kết quả sau khi tạo nhạc
  String? musicFilename;

  // Bước chọn giọng hát (tuỳ chọn - null nghĩa là giữ nguyên, không đổi giọng)
  String? voiceId;
  String? voicedFilename;

  // Bước chọn phong cách MV
  String? styleId;

  /// Ước tính số cảnh (từ /analyze-beats ở màn Xem lại) - dùng để dựng lưới
  /// storyboard đúng kích thước ở màn Đang tạo. null nếu người dùng bỏ qua
  /// bước xem lại vì lý do gì đó (fallback: dùng maxScenes trong Settings).
  int? estimatedSceneCount;

  /// scene_dir_id trả về từ lần gọi /generate-mv gần nhất - dùng để RESUME
  /// (tiếp tục từ cảnh còn thiếu) nếu job bị ngắt giữa chừng, thay vì làm lại từ đầu.
  String? mvSceneDirId;

  /// ID + ngày tạo của bản ghi lịch sử (`project_history.dart`) ứng với dự
  /// án này - null nếu đây là phiên MỚI (GeneratingScreen sẽ tự tạo lúc bắt
  /// đầu). CÓ GIÁ TRỊ khi dự án được TIẾP TỤC từ màn "Có dự án đang dang dở"
  /// (HomeScreen) - dùng LẠI đúng 2 giá trị này để `_persistHistory` cập
  /// nhật ĐÚNG bản ghi cũ, không tạo thêm 1 bản ghi trùng lặp cho cùng 1 dự án.
  String? historyId;
  DateTime? historyCreatedAt;

  /// Danh sách prompt RIÊNG cho từng cảnh, lấy từ StoryboardScreen (người
  /// dùng đã xem/sửa) - null nghĩa là bỏ qua bước storyboard, dùng lại hành
  /// vi CŨ (mọi cảnh dùng chung 1 style_prompt). Độ dài PHẢI khớp đúng số
  /// cảnh thật sự sinh ra ở /generate-mv (cùng audio + cùng
  /// beats_per_scene/max_scenes) - nếu lệch, backend tự bỏ qua và dùng lại
  /// style_prompt chung (an toàn, không crash).
  List<String>? scenePrompts;

  // Kết quả cuối
  String? mvFilename;

  /// File MV đã tải VỀ MÁY trong lúc job nền chạy (tải ngay khi vừa xong,
  /// không đợi hiển thị màn Kết quả mới tải) - null nếu chưa tải xong/lỗi.
  File? mvLocalFile;

  /// true nếu đã lưu thành công MV vào thư viện ảnh (Gallery) công khai của
  /// máy - false nếu lưu lỗi/chưa lưu (MV vẫn còn dùng được qua mvLocalFile,
  /// chỉ là chưa xuất hiện trong app Album ảnh hệ thống).
  bool savedToGallery = false;

  /// Đường dẫn LOCAL ảnh tham chiếu nhân vật ("character sheet") đã tải về
  /// trong lúc job chạy - null nếu job này không sinh (không có characterDesc,
  /// hoặc backend/model không hỗ trợ - xem tài liệu kỹ thuật mục 7zq/7zu).
  String? characterReferenceImagePath;

  /// MỚI (mục 7zc2) - tên file ảnh tham chiếu ĐÃ ĐƯỢC NGƯỜI DÙNG XEM VÀ XÁC
  /// NHẬN qua CharacterReferenceScreen (trước khi tạo MV) - truyền vào
  /// `/generate-mv` để backend TÁI SỬ DỤNG đúng ảnh này (không tự sinh ảnh
  /// MỚI/KHÁC) - null nếu bỏ qua bước xem trước (backend sẽ tự sinh như cũ).
  String? confirmedCharacterReferenceFilename;

  /// MỚI (mục 7zc4) - đường dẫn LOCAL file JSON mốc thời gian từng từ trong
  /// lời bài hát (dùng cho phụ đề chạy chữ kiểu karaoke ở ResultScreen) -
  /// null nếu job không sinh (không có lyrics, chưa cài công cụ align ở
  /// Colab, hoặc lỗi - xem `_align_lyrics_to_audio` trong app.py).
  String? lyricsTimestampsPath;

  /// MỚI - đường dẫn LOCAL ảnh thumbnail tự động chọn (khung nét nhất, sáng
  /// vừa phải - xem `select_best_thumbnail` trong post_processing_v2.py) -
  /// null nếu backend chưa cài post_processing_v2.py hoặc bước này lỗi
  /// (KHÔNG ảnh hưởng MV chính, chỉ đơn giản là không có thumbnail riêng).
  String? thumbnailImagePath;

  /// MỚI - file MV bản DỌC (9:16, cho Shorts/TikTok/Reels) đã tải về trong
  /// lúc job chạy - null nếu `exportVertical=false` hoặc bước này lỗi/chưa
  /// cài post_processing_v2.py. KHÔNG thay thế `mvLocalFile` (bản ngang) -
  /// đây là file THÊM, chỉ tồn tại khi người dùng chủ động bật tuỳ chọn này.
  File? mvVerticalLocalFile;

  /// Đường dẫn LOCAL các cảnh video đã tải về trong lúc job đang chạy nền.
  /// Dùng để hiển thị "đã lưu được X cảnh" khi mất kết nối giữa chừng, và có
  /// thể dùng tạm nếu job không hoàn tất được.
  final List<String> downloadedSceneFiles = [];
}
