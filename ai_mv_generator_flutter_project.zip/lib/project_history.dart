import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// 1 bản ghi lịch sử - lưu đủ thông tin để hiển thị + mở lại file MV nếu vẫn
/// còn trên máy (không giữ file nếu người dùng đã xoá thủ công).
class ProjectHistoryEntry {
  final DateTime createdAt;
  final String mvFilename;
  final String? mvLocalPath;
  final String? styleId;
  final bool fromSample;

  ProjectHistoryEntry({
    required this.createdAt,
    required this.mvFilename,
    required this.mvLocalPath,
    required this.styleId,
    required this.fromSample,
  });

  Map<String, dynamic> toJson() => {
        'createdAt': createdAt.toIso8601String(),
        'mvFilename': mvFilename,
        'mvLocalPath': mvLocalPath,
        'styleId': styleId,
        'fromSample': fromSample,
      };

  factory ProjectHistoryEntry.fromJson(Map<String, dynamic> json) => ProjectHistoryEntry(
        createdAt: DateTime.parse(json['createdAt'] as String),
        mvFilename: json['mvFilename'] as String,
        mvLocalPath: json['mvLocalPath'] as String?,
        styleId: json['styleId'] as String?,
        fromSample: json['fromSample'] as bool? ?? false,
      );
}

class ProjectHistoryStore {
  static const _key = 'project_history_v1';
  static const _maxEntries = 50; // tránh phình vô hạn qua thời gian

  static Future<List<ProjectHistoryEntry>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) {
          try {
            return ProjectHistoryEntry.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ProjectHistoryEntry>()
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt)); // mới nhất trước
  }

  static Future<void> add(ProjectHistoryEntry entry) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    raw.insert(0, jsonEncode(entry.toJson()));
    if (raw.length > _maxEntries) raw.removeRange(_maxEntries, raw.length);
    await prefs.setStringList(_key, raw);
  }
}
