import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// 1 bản ghi dự án - TRƯỚC ĐÂY (bản cũ) chỉ lưu vài trường tối thiểu, CHỈ
/// ghi lúc job đã XONG (xem result_screen.dart) - nghĩa là nếu app bị đóng
/// hẳn (không chỉ chạy nền) giữa lúc đang tạo MV, KHÔNG CÓ CÁCH NÀO tiếp
/// tục lại job đó nữa dù backend/Colab vẫn còn giữ đủ cảnh đã sinh trên
/// Drive - vì `mvSceneDirId` (thứ DUY NHẤT cần để bảo backend "tiếp tục job
/// X") chưa từng được lưu ra khỏi bộ nhớ tạm (RAM) của đúng phiên
/// GeneratingScreen đang chạy.
///
/// Bản MỚI: lưu ĐẦY ĐỦ thông tin cần cho 2 việc:
/// 1) TIẾP TỤC job dở dang sau khi mở lại app (cần status + mvSceneDirId +
///    đủ tham số gốc để dựng lại đúng request /generate-mv).
/// 2) SAO LƯU/PHỤC HỒI dự án (cần đủ metadata + đường dẫn file local để
///    đóng gói vào file zip - xem backup_screen.dart).
class ProjectHistoryEntry {
  final String id; // duy nhất - dùng để cập nhật (upsert) đúng bản ghi, không tạo trùng
  final DateTime createdAt;
  DateTime updatedAt;

  /// 'in_progress' | 'completed' | 'failed' | 'cancelled'
  String status;

  // Nguồn nhạc / lựa chọn đã dùng - đủ để DỰNG LẠI request /generate-mv khi resume
  final bool fromSample;
  String? musicFilename;
  String? voicedFilename;
  String? styleId;
  String? genre;
  String? videoBackend;
  String characterDesc;
  String lyrics;
  int? estimatedSceneCount;
  List<String>? scenePrompts;

  /// CHÌA KHOÁ để tiếp tục job dở dang - xem ghi chú đầu file.
  String? mvSceneDirId;

  // Kết quả / file local (có thể null nếu job chưa xong, hoặc file đã bị hệ
  // thống dọn khỏi thư mục tạm - xem ghi chú "kind" trong generating_screen.dart)
  String? mvFilename;
  String? mvLocalPath;
  String? characterReferenceImagePath;
  List<String> downloadedSceneFiles;

  ProjectHistoryEntry({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.status,
    required this.fromSample,
    this.musicFilename,
    this.voicedFilename,
    this.styleId,
    this.genre,
    this.videoBackend,
    this.characterDesc = '',
    this.lyrics = '',
    this.estimatedSceneCount,
    this.scenePrompts,
    this.mvSceneDirId,
    this.mvFilename,
    this.mvLocalPath,
    this.characterReferenceImagePath,
    List<String>? downloadedSceneFiles,
  }) : downloadedSceneFiles = downloadedSceneFiles ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'status': status,
        'fromSample': fromSample,
        'musicFilename': musicFilename,
        'voicedFilename': voicedFilename,
        'styleId': styleId,
        'genre': genre,
        'videoBackend': videoBackend,
        'characterDesc': characterDesc,
        'lyrics': lyrics,
        'estimatedSceneCount': estimatedSceneCount,
        'scenePrompts': scenePrompts,
        'mvSceneDirId': mvSceneDirId,
        'mvFilename': mvFilename,
        'mvLocalPath': mvLocalPath,
        'characterReferenceImagePath': characterReferenceImagePath,
        'downloadedSceneFiles': downloadedSceneFiles,
      };

  factory ProjectHistoryEntry.fromJson(Map<String, dynamic> json) => ProjectHistoryEntry(
        // Tương thích ngược: bản ghi CŨ (trước bản sửa này) không có "id" -
        // dùng mvFilename+createdAt làm id tạm, tránh crash khi đọc lịch sử cũ.
        id: json['id'] as String? ?? '${json['mvFilename']}_${json['createdAt']}',
        createdAt: DateTime.parse(json['createdAt'] as String),
        updatedAt: json['updatedAt'] != null ? DateTime.parse(json['updatedAt'] as String) : DateTime.parse(json['createdAt'] as String),
        status: json['status'] as String? ?? 'completed', // bản ghi CŨ chỉ được lưu lúc đã xong -> mặc định "completed" khi đọc lại
        fromSample: json['fromSample'] as bool? ?? false,
        musicFilename: json['musicFilename'] as String?,
        voicedFilename: json['voicedFilename'] as String?,
        styleId: json['styleId'] as String?,
        genre: json['genre'] as String?,
        videoBackend: json['videoBackend'] as String?,
        characterDesc: json['characterDesc'] as String? ?? '',
        lyrics: json['lyrics'] as String? ?? '',
        estimatedSceneCount: json['estimatedSceneCount'] as int?,
        scenePrompts: (json['scenePrompts'] as List?)?.map((e) => e as String).toList(),
        mvSceneDirId: json['mvSceneDirId'] as String?,
        mvFilename: json['mvFilename'] as String?,
        mvLocalPath: json['mvLocalPath'] as String?,
        characterReferenceImagePath: json['characterReferenceImagePath'] as String?,
        downloadedSceneFiles: (json['downloadedSceneFiles'] as List?)?.map((e) => e as String).toList() ?? [],
      );
}

class ProjectHistoryStore {
  static const _key = 'project_history_v2'; // đổi key (v1 -> v2) - cấu trúc đổi nhiều, tránh đọc nhầm dữ liệu cũ sai định dạng
  static const _maxEntries = 50; // tránh phình vô hạn qua thời gian

  static Future<List<ProjectHistoryEntry>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) {
          try {
            return ProjectHistoryEntry.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ProjectHistoryEntry>()
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt)); // cập nhật gần nhất lên đầu (không phải createdAt - job đang chạy dở cần nổi lên trên)
  }

  /// Thêm MỚI hoặc CẬP NHẬT (theo `id`) - THAY cho `add()` cũ (chỉ biết
  /// thêm) - cần để 1 dự án được LƯU NHIỀU LẦN qua vòng đời của nó (lúc bắt
  /// đầu -> in_progress, lúc xong -> completed), không tạo ra nhiều bản ghi
  /// trùng cho CÙNG 1 dự án.
  static Future<void> upsert(ProjectHistoryEntry entry) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final entries = raw
        .map((s) {
          try {
            return ProjectHistoryEntry.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ProjectHistoryEntry>()
        .toList();

    entries.removeWhere((e) => e.id == entry.id);
    entries.insert(0, entry);
    if (entries.length > _maxEntries) entries.removeRange(_maxEntries, entries.length);

    await prefs.setStringList(_key, entries.map((e) => jsonEncode(e.toJson())).toList());
  }

  static Future<void> delete(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final entries = raw
        .map((s) {
          try {
            return ProjectHistoryEntry.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ProjectHistoryEntry>()
        .where((e) => e.id != id)
        .toList();
    await prefs.setStringList(_key, entries.map((e) => jsonEncode(e.toJson())).toList());
  }
}
