import 'package:flutter/material.dart';

import 'api_service.dart';
import 'generation_settings.dart';
import 'project_data.dart';
import 'screens/style_screen.dart';
import 'screens/voice_screen.dart';

/// MỚI (mục 30, PDF "Phân tích MV triệu view" mục 4.1 - chế độ "Nhanh"): màn hình kế tiếp SAU KHI ĐÃ CÓ NHẠC.
/// Bình thường: Đổi giọng (VoiceScreen) -> Phong cách -> Xem lại -> Storyboard -> (Ảnh nhân vật) -> Tạo MV.
/// CHẾ ĐỘ NHANH (Cài đặt > "Chế độ Nhanh"): bỏ qua Đổi giọng (giữ nguyên giọng gốc, giống nút "Giữ nguyên" của màn đó); màn Xem lại
/// sẽ đi thẳng sang Tạo MV (bỏ Storyboard + xem trước ảnh nhân vật) - xem `ReviewScreen._next`. Tắt công tắc là về luồng đầy đủ như cũ.
MaterialPageRoute<void> routeAfterMusic(ApiService api, ProjectData project) {
  if (GenerationSettings.instance.quickMode) {
    project.voiceId = null; // = không đổi giọng (cùng giá trị VoiceScreen đặt khi chọn "Giữ nguyên")
    return MaterialPageRoute<void>(builder: (_) => StyleScreen(api: api, project: project));
  }
  return MaterialPageRoute<void>(builder: (_) => VoiceScreen(api: api, project: project));
}
