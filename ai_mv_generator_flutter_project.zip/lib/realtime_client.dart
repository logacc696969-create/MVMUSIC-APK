import 'dart:convert';
import 'dart:typed_data';
import 'package:web_socket_channel/web_socket_channel.dart';

/// MỚI (mục 55, PDF-1 "WebSocket production: tự động kết nối lại ở phía client + exponential backoff + jitter") - số lần nối lại tối đa trong 1 đợt rớt kết nối
/// (rxws cũng dùng 10). Hết số lần này app VẪN tiếp tục polling bình thường (không mất tiến trình), chỉ thôi thử nâng lại lên WebSocket theo giờ;
/// việc nâng lại khi đổi mạng (xem `generating_screen.dart::_startConnectivityListener`) vẫn hoạt động như cũ.
const int kMaxReconnectAttempts = 10;

/// Độ trễ trước lần nối lại thứ [attempt] (đếm từ 0): lùi theo cấp số nhân 2s, 4s, 8s, 16s, 32s rồi giữ TRẦN 60s, rồi nhân với hệ số nhiễu ngẫu nhiên ("jitter")
/// trong khoảng 0.75 .. 1.25 để nhiều máy cùng rớt không nối lại đúng một lúc. [jitterUnit] nằm trong [0, 1] (0.5 = không lệch; ngoài khoảng thì bị kẹp).
/// Hàm THUẦN - không đọc đồng hồ/ngẫu nhiên bên trong - để kiểm thử được (xem `test/realtime_reconnect_test.dart`).
Duration reconnectDelay(int attempt, double jitterUnit) {
  final a = attempt < 0 ? 0 : (attempt > 10 ? 10 : attempt);
  var baseSeconds = 2 << a; // 2 * 2^a
  if (baseSeconds > 60) baseSeconds = 60;
  final j = jitterUnit < 0 ? 0.0 : (jitterUnit > 1 ? 1.0 : jitterUnit);
  final factor = 0.75 + 0.5 * j;
  return Duration(milliseconds: (baseSeconds * 1000 * factor).round());
}

/// Kết nối tới /ws/updates của backend. Server CHỦ ĐỘNG đẩy 2 loại tin:
///  - {"type": "progress", ...}
///  - {"type": "artifact_ready", "delivery": "inline"|"drive_link", ...}
///    - delivery="inline": NGAY SAU header là 1 frame nhị phân chứa file đó
///      (dùng cho file nhỏ, vd từng cảnh video ~1-3MB).
///    - delivery="drive_link": header có kèm "drive_link" - KHÔNG có frame
///      nhị phân theo sau; app tự tải file từ link Google Drive đó (dùng
///      cho file MV cuối, có thể vượt giới hạn 100MB/request của Cloudflare
///      Quick Tunnel nên không gửi thẳng qua tunnel nữa).
class RealtimeClient {
  final String wsUrl;
  final void Function(Map<String, dynamic> progress) onProgress;
  final void Function(Map<String, dynamic> header, Uint8List bytes) onArtifactInline;
  final void Function(Map<String, dynamic> header, String driveLink) onArtifactLink;
  final void Function(Object? error)? onDisconnected;
  final void Function()? onHeartbeat; // MỚI - gọi mỗi khi nhận "ping" từ server (mỗi ~5s khi kết nối khoẻ)

  WebSocketChannel? _channel;
  Map<String, dynamic>? _pendingHeader;

  RealtimeClient({
    required this.wsUrl,
    required this.onProgress,
    required this.onArtifactInline,
    required this.onArtifactLink,
    this.onDisconnected,
    this.onHeartbeat,
  });

  void connect() {
    _channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    _channel!.stream.listen(
      _handleMessage,
      onDone: () => onDisconnected?.call(null),
      onError: (e) => onDisconnected?.call(e),
      cancelOnError: true,
    );
  }

  void _handleMessage(dynamic message) {
    if (message is String) {
      final data = jsonDecode(message) as Map<String, dynamic>;
      if (data['type'] == 'ping') {
        onHeartbeat?.call(); // MỚI - xem generating_screen.dart _resetHeartbeatWatchdog
        return;
      }
      if (data['type'] == 'progress') {
        onProgress(data);
      } else if (data['type'] == 'artifact_ready') {
        if (data['delivery'] == 'drive_link') {
          onArtifactLink(data, data['drive_link'] as String);
        } else {
          _pendingHeader = data; // chờ frame nhị phân kế tiếp
        }
      }
    } else if (message is List<int>) {
      if (_pendingHeader != null) {
        onArtifactInline(_pendingHeader!, Uint8List.fromList(message));
        _pendingHeader = null;
      }
    }
  }

  void close() {
    _channel?.sink.close();
    _channel = null;
  }
}
