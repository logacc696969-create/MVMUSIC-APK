import 'dart:convert';
import 'dart:typed_data';
import 'package:web_socket_channel/web_socket_channel.dart';

/// Kết nối tới /ws/updates của backend. Server CHỦ ĐỘNG đẩy 2 loại tin:
///  - {"type": "progress", ...}
///  - {"type": "artifact_ready", "delivery": "inline"|"drive_link", ...}
///    - delivery="inline": NGAY SAU header là 1 frame nhị phân chứa file đó
///      (dùng cho file nhỏ, vd từng cảnh video ~1-3MB).
///    - delivery="drive_link": header có kèm "drive_link" - KHÔNG có frame
///      nhị phân theo sau; app tự tải file từ link Google Drive đó (dùng
///      cho file MV cuối, có thể vượt giới hạn 100MB/request của Cloudflare
///      Quick Tunnel nên không gửi thẳng qua tunnel nữa).
class RealtimeClient {
  final String wsUrl;
  final void Function(Map<String, dynamic> progress) onProgress;
  final void Function(Map<String, dynamic> header, Uint8List bytes) onArtifactInline;
  final void Function(Map<String, dynamic> header, String driveLink) onArtifactLink;
  final void Function(Object? error)? onDisconnected;
  final void Function()? onHeartbeat; // MỚI - gọi mỗi khi nhận "ping" từ server (mỗi ~5s khi kết nối khoẻ)

  WebSocketChannel? _channel;
  Map<String, dynamic>? _pendingHeader;

  RealtimeClient({
    required this.wsUrl,
    required this.onProgress,
    required this.onArtifactInline,
    required this.onArtifactLink,
    this.onDisconnected,
    this.onHeartbeat,
  });

  void connect() {
    _channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    _channel!.stream.listen(
      _handleMessage,
      onDone: () => onDisconnected?.call(null),
      onError: (e) => onDisconnected?.call(e),
      cancelOnError: true,
    );
  }

  void _handleMessage(dynamic message) {
    if (message is String) {
      final data = jsonDecode(message) as Map<String, dynamic>;
      if (data['type'] == 'ping') {
        onHeartbeat?.call(); // MỚI - xem generating_screen.dart _resetHeartbeatWatchdog
        return;
      }
      if (data['type'] == 'progress') {
        onProgress(data);
      } else if (data['type'] == 'artifact_ready') {
        if (data['delivery'] == 'drive_link') {
          onArtifactLink(data, data['drive_link'] as String);
        } else {
          _pendingHeader = data; // chờ frame nhị phân kế tiếp
        }
      }
    } else if (message is List<int>) {
      if (_pendingHeader != null) {
        onArtifactInline(_pendingHeader!, Uint8List.fromList(message));
        _pendingHeader = null;
      }
    }
  }

  void close() {
    _channel?.sink.close();
    _channel = null;
  }
}
