import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../project_history.dart';

/// MỚI - "Chunk-Streaming giải nén backup" (NÂNG CẤP từ bản `compute()` +
/// `decodeBytes()` trước đó - lần này dùng ĐÚNG API streaming thật của gói
/// `archive`, đã xác nhận qua tài liệu chính thức + CHANGELOG, không đoán
/// mò): `InputFileStream` đọc file zip TỪ Ổ ĐĨA theo từng phần (không nạp
/// hết vào RAM như `File(...).readAsBytes()` cũ), `ZipDecoder().decodeStream()`
/// (CHÚ Ý: KHÔNG phải `decodeBuffer` - tên đó đã bị đổi thành `decodeStream`
/// kể từ bản 4.0 của gói `archive`, dự án này ghim `archive: ^4.1.0` nên
/// PHẢI dùng tên mới) đọc cấu trúc thư mục zip TRƯỚC (nhẹ), rồi
/// `file.writeContent(outputStream)` giải nén THẲNG ra đĩa từng file cần
/// dùng - KHÔNG giữ dữ liệu đã giải nén trong RAM ở bất kỳ bước nào.
///
/// PHẢI là hàm TOP-LEVEL (yêu cầu bắt buộc của `compute()` - chạy trong 1
/// Isolate tách biệt, không mang theo được tham chiếu `this`/context của UI
/// isolate).
///
/// Nhận vào `(zipPath, outputDir)` (dùng Record - cú pháp Dart 3, gọn hơn
/// tự định nghĩa 1 class tham số riêng). Tự đọc TOÀN BỘ file zip từ đường
/// dẫn (không nhận bytes qua tham số - khác bản trước - để KHÔNG bị buộc
/// phải đọc hết file vào RAM ở tầng gọi TRƯỚC KHI vào tới isolate).
///
/// Trả về 1 Map:
/// - 'manifest': nội dung manifest.json đã parse (JSON thuần, an toàn
///   truyền giữa Isolate) - file này thường nhỏ (chỉ text mô tả), ĐỌC HẲN
///   vào bộ nhớ là chấp nhận được, khác các file MV/ảnh nặng.
/// - 'extractedFilenames': `List<String>` tên các file ĐÃ ghi thành công ra
///   `outputDir` (để bên gọi biết file nào tồn tại thật trên đĩa, không cần
///   nhận lại bytes của chúng).
/// - 'error': String nếu lỗi, null nếu thành công.
Map<String, dynamic> _decodeBackupZipInIsolate((String, String) params) {
  final (zipPath, outputDir) = params;
  InputFileStream? inputStream;
  try {
    inputStream = InputFileStream(zipPath);
    final archive = ZipDecoder().decodeStream(inputStream);

    ArchiveFile? manifestArchiveFile;
    for (final f in archive) {
      if (f.isFile && f.name == 'manifest.json') manifestArchiveFile = f;
    }
    if (manifestArchiveFile == null) {
      return {'error': 'File này không phải file sao lưu hợp lệ (thiếu manifest.json).'};
    }

    final manifest = jsonDecode(utf8.decode(manifestArchiveFile.content as List<int>)) as Map<String, dynamic>;
    final entries = manifest['entries'] as List;

    final neededFilenames = <String>{};
    for (final rawEntry in entries) {
      final entryJson = Map<String, dynamic>.from(rawEntry as Map);
      final mvFile = entryJson['_backedUpMvFile'] as String?;
      final refFile = entryJson['_backedUpRefImageFile'] as String?;
      if (mvFile != null) neededFilenames.add(mvFile);
      if (refFile != null) neededFilenames.add(refFile);
    }

    final extractedFilenames = <String>[];
    for (final f in archive) {
      if (!f.isFile || !neededFilenames.contains(f.name)) continue;
      // An toàn: bỏ qua tên file có '..' (path traversal) - đúng khuyến cáo
      // bảo mật chính thức của gói archive khi tự ghi file theo tên trong zip.
      if (f.name.contains('..')) continue;
      OutputFileStream? outputStream;
      try {
        outputStream = OutputFileStream('$outputDir/${f.name}');
        f.writeContent(outputStream); // giải nén THẲNG ra đĩa, không giữ bytes trong RAM
        extractedFilenames.add(f.name);
      } finally {
        outputStream?.close();
      }
    }

    return {'manifest': manifest, 'extractedFilenames': extractedFilenames, 'error': null};
  } catch (e) {
    return {'error': 'File sao lưu bị hỏng hoặc không đọc được: $e'};
  } finally {
    inputStream?.close();
  }
}

/// Sao lưu/Phục hồi dự án - 2 HƯỚNG theo đúng yêu cầu:
/// 1) "Toàn bộ ứng dụng" = chọn TẤT CẢ bản ghi lịch sử.
/// 2) "Từng dự án cụ thể" = người dùng tự tick chọn 1 hoặc vài dự án.
///
/// Định dạng file sao lưu: 1 file .zip chứa `manifest.json` (danh sách bản
/// ghi lịch sử, dạng JSON) + các file local THẬT SỰ CÒN TỒN TẠI (MV cuối,
/// ảnh tham chiếu nhân vật - các file cảnh lẻ nằm ở thư mục TẠM của hệ điều
/// hành nên thường KHÔNG còn, xem ghi chú trong generating_screen.dart -
/// backup KHÔNG cố gắng lưu các file đó, chỉ lưu file MV cuối cùng là đủ).
///
/// CHƯA CHẠY THỬ THẬT (xem mục 7l trong tài liệu kỹ thuật).
class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  List<ProjectHistoryEntry> _entries = [];
  final Set<String> _selectedIds = {};
  bool _loading = true;
  bool _exporting = false;
  bool _importing = false;
  String? _statusMessage;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await ProjectHistoryStore.load();
    if (mounted) {
      setState(() {
        _entries = entries;
        _loading = false;
      });
    }
  }

  bool get _allSelected => _entries.isNotEmpty && _selectedIds.length == _entries.length;

  void _toggleSelectAll() {
    setState(() {
      if (_allSelected) {
        _selectedIds.clear();
      } else {
        _selectedIds
          ..clear()
          ..addAll(_entries.map((e) => e.id));
      }
    });
  }

  Future<void> _exportSelected() async {
    if (_selectedIds.isEmpty) return;
    setState(() {
      _exporting = true;
      _statusMessage = null;
    });
    try {
      final selected = _entries.where((e) => _selectedIds.contains(e.id)).toList();

      // Thư mục tạm để dựng cấu trúc trước khi nén - xoá sạch nếu có từ lần trước.
      final tempDir = await getTemporaryDirectory();
      final stagingDir = Directory('${tempDir.path}/backup_staging');
      if (stagingDir.existsSync()) stagingDir.deleteSync(recursive: true);
      stagingDir.createSync(recursive: true);
      final filesDir = Directory('${stagingDir.path}/files')..createSync();

      // Copy từng file THẬT SỰ CÒN TỒN TẠI vào thư mục files/ - đổi tên theo
      // id để tránh trùng tên giữa các dự án khác nhau, ghi lại tên mới vào
      // manifest để lúc phục hồi biết đường dẫn tương ứng.
      final manifestEntries = <Map<String, dynamic>>[];
      for (final e in selected) {
        final json = e.toJson();
        String? backedUpMvFile;
        String? backedUpRefImageFile;

        if (e.mvLocalPath != null && File(e.mvLocalPath!).existsSync()) {
          final ext = e.mvLocalPath!.split('.').last;
          backedUpMvFile = '${e.id}_mv.$ext';
          File(e.mvLocalPath!).copySync('${filesDir.path}/$backedUpMvFile');
        }
        if (e.characterReferenceImagePath != null && File(e.characterReferenceImagePath!).existsSync()) {
          final ext = e.characterReferenceImagePath!.split('.').last;
          backedUpRefImageFile = '${e.id}_ref.$ext';
          File(e.characterReferenceImagePath!).copySync('${filesDir.path}/$backedUpRefImageFile');
        }

        json['_backedUpMvFile'] = backedUpMvFile; // tên file TRONG zip, khác đường dẫn tuyệt đối cũ (máy khác/lần cài khác sẽ có đường dẫn khác)
        json['_backedUpRefImageFile'] = backedUpRefImageFile;
        manifestEntries.add(json);
      }

      final manifestFile = File('${stagingDir.path}/manifest.json');
      manifestFile.writeAsStringSync(jsonEncode({
        'app': 'ai_mv_generator',
        'backupVersion': 1,
        'exportedAt': DateTime.now().toIso8601String(),
        'entries': manifestEntries,
      }));

      final outputDir = await getApplicationDocumentsDirectory();
      final zipName = 'mv_backup_${DateTime.now().millisecondsSinceEpoch}.zip';
      final zipPath = '${outputDir.path}/$zipName';
      if (File(zipPath).existsSync()) File(zipPath).deleteSync();

      final encoder = ZipFileEncoder();
      encoder.create(zipPath);
      await encoder.addDirectory(stagingDir, includeDirName: false);
      encoder.close();

      stagingDir.deleteSync(recursive: true); // dọn thư mục tạm, chỉ giữ lại file zip

      if (!mounted) return;
      // LƯU Ý: dùng `Share.shareXFiles(...)` (API tĩnh CŨ) - KHÔNG dùng
      // `SharePlus.instance.share(ShareParams(...))` - đã tra cứu xác nhận
      // API đó chỉ tồn tại từ `share_plus` bản 11.0.0 trở lên, trong khi app
      // đang ghim `^10.0.0` (khoá <11.0.0, xem mục 7zl) - dùng nhầm API mới
      // sẽ lỗi biên dịch y hệt kiểu lỗi từng gặp với `file_picker`.
      await Share.shareXFiles([XFile(zipPath)], text: 'Sao lưu ${selected.length} dự án AI MV Generator');
      if (!mounted) return;
      setState(() => _statusMessage = '✓ Đã xuất file sao lưu (${selected.length} dự án) - chọn nơi lưu ở màn chia sẻ vừa mở.');
    } catch (e) {
      if (mounted) setState(() => _statusMessage = 'Lỗi khi xuất sao lưu: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _importFromFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    if (result == null || result.files.single.path == null) return;

    final zipPath = result.files.single.path!;

    // MỚI - "Chặn trước khi vỡ" + "Chunk-Streaming giải nén" (đã nâng cấp:
    // trước đây chỉ chặn kích thước + chạy compute() với decodeBytes() -
    // giờ đã xác nhận CHẮC CHẮN đúng API streaming thật của gói `archive`
    // (`InputFileStream`/`decodeStream`/`writeContent`, xem
    // `_decodeBackupZipInIsolate`) nên dùng luôn, không cần giữ giới hạn
    // 200MB như 1 giải pháp thay thế nữa - NHƯNG VẪN GIỮ ngưỡng này như 1
    // lưới an toàn bổ sung (CHƯA CHẠY THỬ THẬT trên thiết bị RAM thấp để
    // biết chắc streaming đã đủ an toàn ở mọi kích thước, giữ giới hạn rõ
    // ràng vẫn tốt hơn để trần không giới hạn khi chưa kiểm chứng).
    final zipSizeBytes = await File(zipPath).length();
    if (!mounted) return;
    const maxSafeZipBytes = 200 * 1024 * 1024; // 200MB - ngưỡng an toàn ước lượng, CHƯA đo thật trên thiết bị cụ thể nào
    if (zipSizeBytes > maxSafeZipBytes) {
      setState(() {
        _statusMessage = 'File sao lưu quá lớn (${(zipSizeBytes / 1024 / 1024).toStringAsFixed(0)}MB, '
            'giới hạn an toàn ${maxSafeZipBytes ~/ 1024 ~/ 1024}MB) - máy có thể bị hệ điều hành tự tắt '
            'app giữa chừng khi phục hồi. Hãy xuất file sao lưu MỚI với ÍT dự án hơn mỗi lần (bỏ chọn '
            'bớt ở màn Xuất) rồi phục hồi từng phần.';
      });
      return;
    }

    setState(() {
      _importing = true;
      _statusMessage = null;
    });
    try {
      // SỬA - dùng đúng API streaming thật đã xác nhận (`InputFileStream` +
      // `decodeStream` + `OutputFileStream`/`writeContent`, xem docstring
      // đầy đủ ở `_decodeBackupZipInIsolate`) - KHÔNG đọc `zipBytes` ở đây
      // nữa (khác bản trước) vì làm vậy vẫn phải nạp cả file zip vào RAM
      // TRƯỚC KHI vào isolate, mất hết ý nghĩa streaming. Isolate tự đọc
      // file zip THEO ĐƯỜNG DẪN và ghi thẳng file cần dùng ra
      // `docsDir.path`, không có bytes nào được truyền qua lại giữa 2 isolate.
      final docsDir = await getApplicationDocumentsDirectory();
      final decoded = await compute(_decodeBackupZipInIsolate, (zipPath, docsDir.path));
      if (!mounted) return;

      if (decoded['error'] != null) {
        setState(() => _statusMessage = decoded['error'] as String);
        return;
      }

      final manifest = decoded['manifest'] as Map<String, dynamic>;
      final extractedFilenames = (decoded['extractedFilenames'] as List).cast<String>().toSet();
      final entries = manifest['entries'] as List;

      int restoredCount = 0;

      for (final rawEntry in entries) {
        final entryJson = Map<String, dynamic>.from(rawEntry as Map);
        final backedUpMvFile = entryJson['_backedUpMvFile'] as String?;
        final backedUpRefImageFile = entryJson['_backedUpRefImageFile'] as String?;

        // File đã được isolate ghi THẲNG ra `docsDir.path/<tên file trong
        // zip>` rồi (xem `_decodeBackupZipInIsolate`) - ở đây chỉ cần trỏ
        // đường dẫn MỚI vào bản ghi, không cần đọc/ghi lại bytes gì nữa.
        if (backedUpMvFile != null && extractedFilenames.contains(backedUpMvFile)) {
          entryJson['mvLocalPath'] = '${docsDir.path}/$backedUpMvFile';
        }
        if (backedUpRefImageFile != null && extractedFilenames.contains(backedUpRefImageFile)) {
          entryJson['characterReferenceImagePath'] = '${docsDir.path}/$backedUpRefImageFile';
        }

        // Job "in_progress" phục hồi từ backup KHÔNG còn ý nghĩa "tiếp tục
        // ngay" (mvSceneDirId vẫn còn, NHƯNG đây có thể là máy/phiên khác -
        // để nguyên trạng thái, người dùng vẫn có thể bấm "Tiếp tục" ở màn
        // Lịch sử như bình thường nếu job đó thực sự còn tồn tại trên Drive).
        entryJson.remove('_backedUpMvFile');
        entryJson.remove('_backedUpRefImageFile');

        try {
          await ProjectHistoryStore.upsert(ProjectHistoryEntry.fromJson(entryJson));
          restoredCount++;
        } catch (_) {
          // 1 bản ghi lỗi (thiếu trường bắt buộc, hỏng JSON...) không nên chặn phục hồi các bản ghi còn lại.
        }
      }

      await _load();
      if (mounted) setState(() => _statusMessage = '✓ Đã phục hồi $restoredCount dự án.');
    } catch (e) {
      if (mounted) setState(() => _statusMessage = 'Lỗi khi phục hồi: $e');
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sao lưu & Phục hồi')),
      body: SafeArea(
        top: false,
        child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Phục hồi từ file sao lưu', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Text('Chọn 1 file .zip đã sao lưu trước đó (từ máy này hoặc máy khác).',
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _importing ? null : _importFromFile,
                        icon: _importing
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.file_open),
                        label: Text(_importing ? 'Đang phục hồi...' : 'Chọn file sao lưu (.zip)'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              children: [
                const Expanded(
                  child: Text('Chọn dự án để sao lưu', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                TextButton(
                  onPressed: _entries.isEmpty ? null : _toggleSelectAll,
                  child: Text(_allSelected ? 'Bỏ chọn tất cả' : 'Chọn tất cả (toàn bộ ứng dụng)'),
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _entries.isEmpty
                    ? const Center(child: Text('Chưa có dự án nào để sao lưu.', style: TextStyle(color: Colors.grey)))
                    : ListView.builder(
                        itemCount: _entries.length,
                        itemBuilder: (context, i) {
                          final e = _entries[i];
                          final hasMvFile = e.mvLocalPath != null && File(e.mvLocalPath!).existsSync();
                          final selected = _selectedIds.contains(e.id);
                          // KHÔNG dùng CheckboxListTile ở đây - cùng lỗi cắt
                          // chữ đã sửa ở HistoryScreen/SettingsScreen (tên
                          // file/mô tả có thể dài hơn 1 dòng).
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: InkWell(
                              onTap: () => setState(() {
                                if (selected) {
                                  _selectedIds.remove(e.id);
                                } else {
                                  _selectedIds.add(e.id);
                                }
                              }),
                              child: Padding(
                                padding: const EdgeInsets.all(8),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Checkbox(
                                      value: selected,
                                      onChanged: (v) => setState(() {
                                        if (v == true) {
                                          _selectedIds.add(e.id);
                                        } else {
                                          _selectedIds.remove(e.id);
                                        }
                                      }),
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(top: 12),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(e.mvFilename ?? e.musicFilename ?? 'Dự án chưa đặt tên'),
                                            const SizedBox(height: 2),
                                            Text(
                                              hasMvFile ? 'Có file MV để sao lưu' : 'Chỉ sao lưu thông tin (chưa có/không còn file MV)',
                                              style: const TextStyle(fontSize: 11, color: Colors.grey), // KHÔNG maxLines -> hiện đủ
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
          ),
          if (_statusMessage != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(_statusMessage!, style: TextStyle(color: _statusMessage!.startsWith('✓') ? Colors.green : Colors.red)),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: (_selectedIds.isEmpty || _exporting) ? null : _exportSelected,
                icon: _exporting
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.ios_share),
                label: Text(_exporting ? 'Đang đóng gói...' : 'Xuất bản sao lưu (${_selectedIds.length} dự án)'),
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }
}
