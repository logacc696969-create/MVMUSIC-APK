import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'generating_screen.dart';

/// MỚI (mục 7zc2) - "Character Sheet": sinh RIÊNG 1 ảnh tham chiếu nhân vật
/// để người dùng xem trước và xác nhận TRƯỚC KHI tốn GPU tạo cả MV.
///
/// TRƯỚC ĐÂY ảnh này chỉ hiện ở ResultScreen (SAU KHI cả MV đã tạo xong,
/// thường mất hơn chục phút) - nếu AI vẽ sai ý/lỗi mặt, người dùng phải bỏ cả
/// MV đi làm lại từ đầu, rất lãng phí GPU của phiên Colab free. Màn này cho
/// xem NGAY và có nút "Tạo lại" (không tốn gì ngoài đúng 1 lần sinh ảnh) nếu
/// chưa ưng, giữ đúng ảnh đã chọn khi bấm "Xác nhận, bắt đầu tạo MV" (backend
/// sẽ TÁI DÙNG đúng ảnh này, không sinh ảnh khác trong lúc tạo MV).
///
/// CHỈ hiện màn này nếu `GenerationSettings.instance.characterDesc` không
/// rỗng - `storyboard_screen.dart` tự bỏ qua màn này (đi thẳng
/// GeneratingScreen như cũ) nếu không có mô tả nhân vật.
class CharacterReferenceScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const CharacterReferenceScreen({super.key, required this.api, required this.project});

  @override
  State<CharacterReferenceScreen> createState() => _CharacterReferenceScreenState();
}

class _CharacterReferenceScreenState extends State<CharacterReferenceScreen> {
  bool _generating = true;
  String? _error;
  String? _referenceFilename;
  File? _localImageFile;

  @override
  void initState() {
    super.initState();
    _generate();
  }

  Future<void> _generate() async {
    setState(() {
      _generating = true;
      _error = null;
    });
    try {
      final result = await widget.api.generateCharacterReference(
        characterDesc: GenerationSettings.instance.characterDesc,
        styleId: widget.project.styleId!,
      );
      if (result['status'] != 'ok') {
        setState(() => _error = result['note']?.toString() ?? 'Không tạo được ảnh tham chiếu.');
        return;
      }
      final filename = result['reference_filename'] as String;
      final res = await http.get(Uri.parse(widget.api.downloadUrl('character_refs/$filename')));
      if (res.statusCode != 200) {
        setState(() => _error = 'Tạo ảnh xong nhưng tải về máy để xem bị lỗi (mã ${res.statusCode}).');
        return;
      }
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/char_ref_preview_${filename.replaceAll('/', '_')}');
      await file.writeAsBytes(res.bodyBytes);
      if (!mounted) return;
      setState(() {
        _referenceFilename = filename;
        _localImageFile = file;
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Lỗi tạo ảnh tham chiếu: $e');
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  void _confirmAndProceed() {
    widget.project.confirmedCharacterReferenceFilename = _referenceFilename;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: widget.project)),
    );
  }

  void _skipAndProceed() {
    // Bỏ qua bước xem trước (dù đã lỡ tạo 1 ảnh) - backend sẽ tự sinh ảnh
    // MỚI trong lúc tạo MV như hành vi CŨ (trước khi có màn hình này).
    widget.project.confirmedCharacterReferenceFilename = null;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: widget.project)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Xem trước nhân vật')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Đây là ảnh nhân vật sẽ xuất hiện xuyên suốt MV. Ưng thì bấm '
              '"Xác nhận" - chưa ưng thì bấm "Tạo lại" (chỉ tốn đúng 1 lần '
              'sinh ảnh, không tốn thời gian tạo cả MV).',
              style: TextStyle(fontSize: 13, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Center(
                child: _generating
                    ? const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 12),
                          Text('Đang tạo ảnh tham chiếu nhân vật...'),
                        ],
                      )
                    : _error != null
                        ? Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                          )
                        : _localImageFile != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.file(_localImageFile!, fit: BoxFit.contain),
                              )
                            : const Text('Không có ảnh để hiển thị.'),
              ),
            ),
            const SizedBox(height: 16),
            if (!_generating) ...[
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _generate,
                      child: const Text('Tạo lại'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _referenceFilename != null ? _confirmAndProceed : null,
                      child: const Text('Xác nhận, tạo MV'),
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: _skipAndProceed,
                child: const Text('Bỏ qua bước này, để backend tự sinh khi tạo MV'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
