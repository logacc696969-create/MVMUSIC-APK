import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../api_service.dart';
import '../generation_settings.dart';
import '../job_sync.dart';
import '../l10n.dart';
import '../manifest_merge.dart';
import '../manifest_store.dart';
import '../muted_color.dart';

/// MỚI (mục 33) - MÔ HÌNH & CÔNG CỤ: điều khiển Colab NGAY TRÊN APP, không phải mở Colab chạy ô nào nữa.
///  - Đổi model theo "khe" (LLM kịch bản, Wan2.2, VACE, AnimateDiff, ảnh nhân vật, nhạc ACE-Step) - có hiệu lực ngay, không khởi động lại backend.
///  - ComfyUI: cài, bật/tắt, thêm node, đặt workflow, tải file model (.safetensors/.gguf) về Drive.
///  - API MIỄN PHÍ (Groq / Gemini / OpenRouter / endpoint tương thích OpenAI) thay phần LLM + chép lời, có đường lui về model trên Colab.
/// Mọi thao tác GHI/CHẠY cần khoá HMAC (backend in khoá ở Bước 7 của notebook, dán 1 lần ở đầu màn này) vì địa chỉ Colab là công khai.
/// Backend: control_extra.py + control_router_extra.py. CHƯA biên dịch/chạy thử trên máy thật.
class ControlScreen extends StatefulWidget {
  final ApiService api;
  const ControlScreen({super.key, required this.api});

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  final s = GenerationSettings.instance;
  late final TextEditingController _hmacCtrl = TextEditingController(text: s.hmacSecret);
  final TextEditingController _dlUrlCtrl = TextEditingController();
  final TextEditingController _dlNameCtrl = TextEditingController();
  final TextEditingController _dlTokenCtrl = TextEditingController();

  Map<String, dynamic> _st = {};
  bool _loading = true;
  String? _error;
  String _busy = '';
  Timer? _timer;
  Map<String, dynamic>? _savedManifest; // mục 69: bản chụp cài đặt backend LƯU TRÊN MÁY này (xem manifest_store.dart) - để khôi phục lên backend mới
  ManifestDiff? _manifestDiff;
  int _assetsMissing = 0; // mục 69: số tệp đầu vào (giọng RVC/clip tự quay/ảnh tham chiếu) máy có mà backend đang thiếu
  DateTime? _assetsCheckedAt;
  String _dlKind = 'checkpoints';
  final Set<String> _comfyArgs = {};
  List<dynamic>? _preflight;
  Map<String, dynamic>? _license; // mục 52 - kết quả kiểm tra giấy phép model
  Map<String, dynamic>? _stockTest; // mục 53 - kết quả thử khoá Pexels/Pixabay

  @override
  void initState() {
    super.initState();
    _loadSavedManifest().then((_) => _reload());
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted && _busy.isEmpty && _hasRunningTask) _reload(silent: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _hmacCtrl.dispose();
    _dlUrlCtrl.dispose();
    _dlNameCtrl.dispose();
    _dlTokenCtrl.dispose();
    super.dispose();
  }

  Map<String, dynamic> _asMap(dynamic v) => v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
  List<dynamic> _asList(dynamic v) => v is List ? v : <dynamic>[];

  bool get _hasRunningTask {
    for (final t in _asList(_st['tasks'])) {
      if (t is Map && t['status'] == 'running') return true;
    }
    return _asMap(_st['comfy'])['installing'] == true;
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _reload({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final r = await widget.api.controlStatus();
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = null;
        _st = r;
      });
      unawaited(_afterStatus(r));
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        if (!silent) {
          _error = e.toString().contains('404')
              ? tr('Backend chưa có control_extra.py / control_router_extra.py (chép đủ file backend mới lên Colab rồi chạy lại Bước 7).')
              : trv('Không gọi được backend: {0}', [e]);
        }
      });
    }
  }

  /// Gọi 1 thao tác GHI/CHẠY (ký HMAC). Trả map kết quả nếu status ok, null nếu lỗi (đã hiện thông báo).
  Future<Map<String, dynamic>?> _post(String action, String path, Map<String, String> body) async {
    if (s.hmacSecret.isEmpty) {
      _snack(tr('Dán khoá bảo mật HMAC ở đầu màn này trước.'));
      return null;
    }
    setState(() => _busy = action);
    Map<String, dynamic>? result;
    try {
      final r = await widget.api.controlPost(action, path, body, s.hmacSecret);
      if (r['status'] == 'ok') {
        result = r;
        unawaited(_noteRemoval(action, body));
      } else {
        _snack((r['note'] as String?) ?? tr('Backend báo lỗi.'));
      }
    } catch (e) {
      _snack(trv('Không gọi được backend: {0}', [e]));
    }
    if (mounted) setState(() => _busy = '');
    return result;
  }

  // ------------------------------------------------------------------ model theo khe
  String _short(String p) => p.length <= 36 ? p : '…' + p.substring(p.length - 35);

  Future<void> _selectModel(String slot, String value, {bool verify = true, String token = ''}) async {
    final r = await _post('model-select', 'model/select', {'slot': slot, 'value': value, 'verify': verify ? 'true' : 'false', 'hf_token': token});
    if (r == null) return;
    final warn = (_asMap(r['result'])['warning'] ?? '').toString();
    _snack(warn.isEmpty ? tr('Đã đổi model. Có hiệu lực từ lần tạo tiếp theo.') : warn);
    await _reload(silent: true);
  }

  Future<void> _resetModel(String slot) async {
    final r = await _post('model-reset', 'model/reset', {'slot': slot});
    if (r == null) return;
    _snack(tr('Đã đặt lại model mặc định.'));
    await _reload(silent: true);
  }

  Future<void> _askModel(String slot) async {
    final valueCtrl = TextEditingController();
    final tokenCtrl = TextEditingController();
    bool verify = true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(tr('Đổi model')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tr('Tên repo HuggingFace dạng chủ/tên, ví dụ Qwen/Qwen2.5-1.5B-Instruct. Phải đúng định dạng của khe này (Diffusers cho video/ảnh/nhạc, transformers cho LLM).'),
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 8),
                TextField(controller: valueCtrl, decoration: InputDecoration(labelText: tr('chủ/tên-model'))),
                TextField(controller: tokenCtrl, obscureText: true, decoration: InputDecoration(labelText: tr('HuggingFace token (chỉ nếu repo gated)'))),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  value: verify,
                  onChanged: (v) => setD(() => verify = v ?? true),
                  title: Text(tr('Kiểm repo có tồn tại trên HuggingFace')),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Áp dụng'))),
          ],
        ),
      ),
    );
    final value = valueCtrl.text.trim();
    final token = tokenCtrl.text.trim();
    valueCtrl.dispose();
    tokenCtrl.dispose();
    if (ok != true || value.isEmpty || !mounted) return;
    await _selectModel(slot, value, verify: verify, token: token);
  }

  Widget _slotTile(String slot, Map<String, dynamic> m) {
    final current = (m['current'] ?? '').toString();
    final custom = m['custom'] == true;
    final tag = custom ? tr('đã đổi') : tr('mặc định');
    final presets = _asList(m['presets']).map((e) => e.toString()).toList();
    final locked = _busy.isNotEmpty || _st['busy'] == true;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text((m['label'] ?? slot).toString(), style: const TextStyle(fontWeight: FontWeight.w500)),
          Text((m['hint'] ?? '').toString(), style: TextStyle(fontSize: 11, color: mutedGrey)),
          const SizedBox(height: 2),
          Text(tr('Đang dùng') + ': ' + current + ' (' + tag + ')', style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final p in presets)
                if (p != current)
                  OutlinedButton(
                    onPressed: locked ? null : () => _selectModel(slot, p, verify: false),
                    child: Text(_short(p)),
                  ),
              TextButton(onPressed: locked ? null : () => _askModel(slot), child: Text(tr('Nhập tên khác…'))),
              if (custom) TextButton(onPressed: locked ? null : () => _resetModel(slot), child: Text(tr('Đặt lại mặc định'))),
            ],
          ),
          const Divider(height: 16),
        ],
      ),
    );
  }

  Widget _modelsCard() {
    final models = _asMap(_st['models']);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Model theo từng khe'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Đổi model ngay tại đây, không cần mở Colab. Có hiệu lực từ lần tạo tiếp theo; không đổi được khi backend đang chạy tác vụ GPU. Model mới được tải lần đầu khi dùng.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            for (final slot in models.keys) _slotTile(slot, _asMap(models[slot])),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ So sánh upscale (mục 68h)
  Future<void> _runUpscaleBenchmark(String methods) async {
    final r = await _post('upscale-benchmark', 'upscale/benchmark', {'methods': methods});
    if (r == null) return;
    _snack(tr('Đang so sánh các phương pháp upscale (vài phút). Xem kết quả ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Future<void> _showUpscaleBenchImage() async {
    final url = '${widget.api.baseUrl}/control/upscale/benchmark-image?ts=${DateTime.now().millisecondsSinceEpoch}';
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Image.network(
            url,
            errorBuilder: (c, e, st) => Text(tr('Chưa có ảnh so sánh - hãy chạy phép so sánh trước.')),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng')))],
      ),
    );
  }

  // ------------------------------------------------------------------ ComfyUI
  Future<void> _installComfy() async {
    final r = await _post('comfy-install', 'comfy/install', <String, String>{});
    if (r == null) return;
    _snack(tr('Đang cài ComfyUI (vài phút). Xem tiến độ ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Future<void> _startComfy() async {
    final r = await _post('comfy-start', 'comfy/start', {'extra_args': _comfyArgs.join(' ')});
    if (r == null) return;
    _snack(tr('Đang bật ComfyUI. Xem tiến độ ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Future<void> _stopComfy() async {
    final r = await _post('comfy-stop', 'comfy/stop', <String, String>{});
    if (r == null) return;
    _snack(tr('Đã tắt ComfyUI.'));
    await _reload(silent: true);
  }

  Future<void> _addNode() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Thêm node ComfyUI')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tr('Chỉ nhận link GitHub dạng https://github.com/chủ/repo. Node chạy MÃ PYTHON của tác giả - chỉ cài node bạn tin tưởng. Sau khi cài, TẮT rồi BẬT lại ComfyUI.'),
              style: const TextStyle(fontSize: 12),
            ),
            TextField(controller: ctrl, decoration: const InputDecoration(labelText: 'https://github.com/...')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Cài node'))),
        ],
      ),
    );
    final url = ctrl.text.trim();
    ctrl.dispose();
    if (ok != true || url.isEmpty || !mounted) return;
    final r = await _post('comfy-node', 'comfy/node', {'url': url});
    if (r == null) return;
    _snack(tr('Đang cài node. Xem tiến độ ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Future<String?> _askText({required String title, required String hint, String initial = ''}) async {
    final ctrl = TextEditingController(text: initial);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, decoration: InputDecoration(labelText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('OK')),
        ],
      ),
    );
    final value = ctrl.text.trim();
    ctrl.dispose();
    return ok == true ? value : null;
  }

  Future<void> _uploadWorkflow() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = picked?.files.single.path;
    if (path == null) return;
    if (!path.toLowerCase().endsWith('.json')) {
      _snack(tr('Chỉ nhận file .json (workflow xuất bằng Save (API Format)).'));
      return;
    }
    final base = path.split(Platform.pathSeparator).last;
    final guess = base.toLowerCase().endsWith('.json') ? base.substring(0, base.length - 5) : base;
    if (!mounted) return;
    final name = await _askText(title: tr('Tên workflow'), hint: tr('chỉ chữ/số/._-'), initial: guess);
    if (name == null || name.isEmpty || !mounted) return;
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(tr('Ánh xạ cho workflow')),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
            child: Text(
              tr('Ánh xạ cho app biết đặt prompt/seed/ảnh/nhạc vào node nào. "Tự đoán" đọc đồ thị và đề xuất - bạn chịu trách nhiệm kiểm lại từng dòng. Workflow dạng giao diện (file cộng đồng công bố) cần ComfyUI đang chạy để chuyển đổi.'),
              style: const TextStyle(fontSize: 12),
            ),
          ),
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'auto'), child: Text(tr('Tự đoán ánh xạ (khuyên dùng)'))),
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'file'), child: Text(tr('Chọn file ánh xạ'))),
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'none'), child: Text(tr('Bỏ qua (chạy nguyên bản)'))),
        ],
      ),
    );
    if (choice == null || !mounted) return;
    File? mapFile;
    if (choice == 'file') {
      final pm = await FilePicker.platform.pickFiles(type: FileType.any);
      final mp = pm?.files.single.path;
      if (mp != null) mapFile = File(mp);
    }
    setState(() => _busy = 'workflow');
    String message;
    List<String> notes = <String>[];
    try {
      final r = await widget.api.uploadComfyWorkflow(name: name, workflowFile: File(path), mappingFile: mapFile, autoMap: choice == 'auto');
      if (r['status'] == 'ok') {
        message = r['converted'] == true ? tr('Đã chuyển đổi và lưu workflow. Chọn nó ở Cài đặt → ComfyUI.') : tr('Đã lưu workflow. Chọn nó ở Cài đặt → ComfyUI.');
        notes = _asList(r['auto_map_notes']).map((e) => e.toString()).toList();
        final warns = _asList(_asMap(r['convert_report'])['warnings']).map((e) => e.toString()).toList();
        if (warns.isNotEmpty) notes = [...notes, ...warns];
      } else {
        message = (r['note'] as String?) ?? tr('Backend từ chối workflow này.');
      }
    } catch (e) {
      message = trv('Không tải được: {0}', [e]);
    }
    if (mounted) setState(() => _busy = '');
    _snack(message);
    if (notes.isNotEmpty && mounted) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('Kiểm lại ánh xạ tự đoán')),
          content: SingleChildScrollView(child: SelectableText(notes.join('\n\n'), style: const TextStyle(fontSize: 12))),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
    }
  }

  Widget _upscaleCard() {
    final locked = _busy.isNotEmpty || _st['busy'] == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Upscale AI: so sánh các phương pháp'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Chạy ngay trên Colab một phép đo có đáp án chuẩn (video mặt người, 3 mức nén) và cho PSNR/SSIM/độ nhấp nháy từng phương pháp, kèm ảnh so sánh. Kết quả hiện ở mục Tác vụ. Số đo không thay thế việc nhìn ảnh. Muốn cài trước SeedVR2: mục Tính năng phụ.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                ElevatedButton(
                  onPressed: locked ? null : () => _runUpscaleBenchmark('lanczos,x4plus,faithful'),
                  child: Text(tr('So sánh nhanh')),
                ),
                OutlinedButton(
                  onPressed: locked ? null : () => _runUpscaleBenchmark('lanczos,x4plus,faithful,faithful_swinir'),
                  child: Text(tr('So sánh kèm SwinIR')),
                ),
                OutlinedButton(
                  onPressed: locked ? null : () => _runUpscaleBenchmark('lanczos,faithful,seedvr2'),
                  child: Text(tr('So sánh kèm SeedVR2 (lâu)')),
                ),
                OutlinedButton(onPressed: _showUpscaleBenchImage, child: Text(tr('Xem ảnh so sánh'))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ Bản chụp cài đặt trên máy + khôi phục lên backend mới (mục 69)
  // Cài đặt/model/tính năng đã chọn nằm ở Drive + đĩa Colab nên đổi tài khoản/GPU là mất. App giữ bản chụp (backend gửi trong status['manifest']) và, khi backend đang
  // kết nối thiếu so với bản đã lưu, hiện nút Khôi phục. KHÔNG BAO GIỜ tự xoá mục đã lưu vì backend trống (xem manifest_merge.dart).
  Future<void> _loadSavedManifest() async {
    _savedManifest = await ManifestStore.load();
  }

  Future<void> _storeManifest() async {
    await ManifestStore.save(_savedManifest ?? ManifestMerge.empty());
  }

  Future<void> _afterStatus(Map<String, dynamic> r) async {
    final raw = r['manifest'];
    if (raw is! Map) return; // backend cũ chưa có control_restore_extra.py
    final backend = ManifestMerge.normalize(Map<String, dynamic>.from(raw));
    final saved = _savedManifest ?? ManifestMerge.empty();
    final d = ManifestMerge.diff(saved, backend);
    // chỉ HỢP NHẤT khi backend đã có đủ những gì đã lưu (hoặc chưa lưu gì): backend mới trống không được làm lệch bản đã lưu
    if (!ManifestMerge.isEmpty(backend) && (d.isEmpty || ManifestMerge.isEmpty(saved))) {
      final merged = ManifestMerge.merge(saved, backend);
      if (jsonEncode(merged) != jsonEncode(saved)) {
        _savedManifest = merged;
        await _storeManifest();
      }
    }
    if (mounted) setState(() => _manifestDiff = d);
    // tệp đầu vào: giãn cách 60 giây (màn này tự làm mới khi có tác vụ chạy); lỗi/không có khoá HMAC -> JobSync trả rỗng
    final now = DateTime.now();
    if (_assetsCheckedAt == null || now.difference(_assetsCheckedAt!).inSeconds >= 60) {
      _assetsCheckedAt = now;
      final missing = await JobSync.missingAssets(widget.api);
      if (mounted) setState(() => _assetsMissing = missing.length);
      unawaited(JobSync.mirrorAssets(widget.api));
    }
  }

  Future<void> _noteRemoval(String action, Map<String, String> body) async {
    if (action == 'model-reset' && body['slot'] != null) {
      _savedManifest = ManifestMerge.removeModel(_savedManifest, body['slot']!);
      await _storeManifest();
    } else if (action == 'env-unset' && body['key'] != null) {
      _savedManifest = ManifestMerge.removeEnv(_savedManifest, body['key']!);
      await _storeManifest();
    }
  }

  Future<void> _restoreManifest() async {
    final saved = _savedManifest;
    var msg = '';
    if (saved != null && !ManifestMerge.isEmpty(saved)) {
      final r = await _post('restore', 'restore', {'manifest': jsonEncode(saved)});
      if (r == null) return;
      final skipped = _asList(r['skipped']).length;
      final queued = r['task_id'] != null;
      msg = trv('Đã áp {0} cài đặt, {1} model. {2}{3}', [
        _asList(r['env_applied']).length,
        _asList(r['models_applied']).length,
        queued ? tr('Đang cài lại các tính năng thiếu - xem mục Tác vụ. ') : '',
        skipped > 0 ? trv('Bỏ qua {0} mục (không áp được).', [skipped]) : '',
      ]);
    }
    // giọng RVC / clip tự quay / ảnh tham chiếu máy đang giữ mà backend thiếu
    final pushed = await JobSync.restoreAssets(widget.api);
    if (pushed > 0) msg = '$msg ${trv('Đã đẩy lại {0} tệp giọng/clip/ảnh tham chiếu lên backend.', [pushed])}';
    if (msg.trim().isNotEmpty) _snack(msg.trim());
    _assetsCheckedAt = null;
    await _reload(silent: true);
  }

  Future<void> _adoptBackendManifest() async {
    final raw = _st['manifest'];
    _savedManifest = raw is Map ? ManifestMerge.normalize(Map<String, dynamic>.from(raw)) : ManifestMerge.empty();
    await _storeManifest();
    if (mounted) setState(() => _manifestDiff = ManifestDiff(const [], const [], const []));
  }

  String _featureLabel(String key) {
    for (final f in _asList(_st['features'])) {
      if (f is Map && f['key'] == key) return (f['label'] ?? key).toString();
    }
    return key;
  }

  // MỚI (mục 69) - "sức khoẻ" máy Colab (status['health']): GPU/VRAM, Drive trống, thời gian backend đã chạy. Trước đây app chỉ biết khi nó MẤT kết nối.
  Widget _healthLine() {
    final h = _st['health'];
    if (h is! Map) return const SizedBox.shrink();
    final parts = <String>[];
    final gpu = h['gpu'];
    if (gpu is Map && gpu['total_mb'] is num && gpu['used_mb'] is num) {
      parts.add(trv('GPU {0}: {1}/{2} GB', [gpu['name'] ?? '', ((gpu['used_mb'] as num) / 1024).toStringAsFixed(1), ((gpu['total_mb'] as num) / 1024).toStringAsFixed(1)]));
    }
    if (h['drive_free_gb'] is num) parts.add(trv('Drive trống {0} GB', [h['drive_free_gb']]));
    if (h['uptime_s'] is num) {
      final m = ((h['uptime_s'] as num) / 60).floor();
      parts.add(trv('backend chạy {0} giờ {1} phút', [m ~/ 60, m % 60]));
    }
    if (parts.isEmpty) return const SizedBox.shrink();
    final bool lowDrive = h['drive_free_gb'] is num && (h['drive_free_gb'] as num) < 2;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Text(
        parts.join(' · ') + (lowDrive ? ' - ${tr('Drive sắp đầy, hãy dọn dẹp trước khi tạo MV')}' : ''),
        style: TextStyle(fontSize: 12, color: lowDrive ? Colors.red : mutedGrey),
      ),
    );
  }

  Widget _restoreCard() {
    final d = _manifestDiff;
    final saved = _savedManifest ?? ManifestMerge.empty();
    final bool noSaved = ManifestMerge.isEmpty(saved);
    if (noSaved && _assetsMissing == 0) return const SizedBox.shrink();
    if ((d == null || d.isEmpty) && _assetsMissing == 0) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Text(
          trv('Cài đặt đã được lưu trên máy này ({0} cài đặt, {1} model, {2} tính năng): đổi tài khoản Colab hoặc GPU vẫn khôi phục được bằng một nút.', [
            (saved['env'] as Map).length,
            (saved['models'] as Map).length,
            (saved['features'] as List).length,
          ]),
          style: TextStyle(fontSize: 12, color: mutedGrey),
        ),
      );
    }
    final dd = d ?? ManifestDiff(const [], const [], const []);
    final featureNames = dd.features.isEmpty ? '' : ' (${dd.features.map(_featureLabel).join(', ')})';
    return Card(
      color: Colors.orange.shade50,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Backend này khác bản cài đặt đã lưu trên máy'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              trv('Còn thiếu: {0} cài đặt, {1} model, {2} tính năng{3}, {4} tệp giọng/clip/ảnh tham chiếu. Bấm Khôi phục để áp lại, cài lại các tính năng và đẩy lại các tệp (dùng khi đổi tài khoản Colab/GPU).', [
                dd.env.length,
                dd.models.length,
                dd.features.length,
                featureNames,
                _assetsMissing,
              ]),
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                ElevatedButton(onPressed: _busy.isNotEmpty ? null : _restoreManifest, child: Text(tr('Khôi phục tất cả'))),
                TextButton(onPressed: _adoptBackendManifest, child: Text(tr('Dùng cấu hình hiện tại làm bản gốc'))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ Chẩn đoán & kiểm thử (mục 69)
  // Chạy bộ xác minh colab_verify.py NGAY TRÊN BACKEND (không phải mở ô lệnh Colab). Danh mục lệnh + kết quả lần chạy cuối do backend gửi trong /control/status
  // (khoá 'diagnostics'), nên thêm lệnh mới ở backend là app tự hiện. Tiến độ/nhật ký/huỷ dùng thẻ Tác vụ có sẵn.
  Future<void> _runDiag(String id) async {
    final opts = <String, String>{};
    if (id == 'e2e') {
      // thử đúng công nghệ video bạn đang dùng (ComfyUI cần workflow nên để backend dùng mặc định)
      final vb = s.videoBackend;
      if (vb != null && vb.isNotEmpty && vb != 'comfyui') opts['backend'] = vb;
    }
    if (id == 'comfytest') {
      // ComfyUI cần biết thử workflow nào: lấy danh sách đã tải lên (bỏ workflow dùng nhạc theo cảnh vì phép thử này không có bài nhạc)
      String? wf;
      try {
        final lw = await widget.api.listComfyWorkflows();
        final names = _asList(lw['workflows']).where((w) => w is Map && w['uses_audio'] != true).map((w) => (w as Map)['name'].toString()).toList();
        if (names.isEmpty) {
          _snack(tr('Chưa có workflow nào (không dùng nhạc). Bấm "Tải workflow lên" ở thẻ ComfyUI trước.'));
          return;
        }
        if (!mounted) return;
        wf = await showDialog<String>(
          context: context,
          builder: (ctx) => SimpleDialog(
            title: Text(tr('Chọn workflow để thử')),
            children: [for (final n in names) SimpleDialogOption(onPressed: () => Navigator.pop(ctx, n), child: Text(n))],
          ),
        );
      } catch (e) {
        _snack(trv('Không lấy được danh sách workflow: {0}', [e]));
        return;
      }
      if (wf == null) return;
      opts['workflow'] = wf;
    }
    final r = await _post('diag-run', 'diag/run', {'command': id, 'options': jsonEncode(opts)});
    if (r == null) return;
    _snack(tr('Đã bắt đầu kiểm thử. Xem tiến độ và nhật ký ở mục Tác vụ (cuộn xuống).'));
    await _reload(silent: true);
  }

  Future<void> _showDiagImage(String name) async {
    final url = '${widget.api.baseUrl}/control/diag/artifact/$name?ts=${DateTime.now().millisecondsSinceEpoch}';
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Image.network(
            url,
            errorBuilder: (c, e, st) => Text(tr('Chưa có tệp này - hãy chạy phép thử trước.')),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng')))],
      ),
    );
  }

  Future<void> _showDiagText(String name) async {
    String text;
    try {
      text = await widget.api.controlDiagArtifactText(name);
    } catch (e) {
      text = trv('Không lấy được tệp: {0}', [e]);
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Kết quả kiểm thử')),
        content: SingleChildScrollView(child: SelectableText(text, style: const TextStyle(fontSize: 11, fontFamily: 'monospace'))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  Future<void> _showDiagResult(Map<String, dynamic> d, Map<String, dynamic> last) async {
    final details = _asList(last['details']).map((e) => e.toString()).toList();
    final tail = _asList(last['tail']).map((e) => e.toString()).toList();
    final artifacts = _asList(last['artifacts']).map((e) => e.toString()).toList();
    final text = [
      (last['headline'] ?? '').toString(),
      if (details.isNotEmpty) '',
      ...details,
      if (tail.isNotEmpty) '',
      ...tail,
    ].join('\n');
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text((d['label'] ?? '').toString()),
        content: SingleChildScrollView(child: SelectableText(text, style: const TextStyle(fontSize: 11, fontFamily: 'monospace'))),
        actions: [
          if (artifacts.contains('e2e_contact_sheet'))
            TextButton(onPressed: () => _showDiagImage('e2e_contact_sheet'), child: Text(tr('Ảnh 8 khung hình của MV thử'))),
          if (artifacts.contains('e2e_scoreboard'))
            TextButton(onPressed: () => _showDiagText('e2e_scoreboard'), child: Text(tr('Bảng chấm điểm'))),
          if (artifacts.contains('e2e_report'))
            TextButton(onPressed: () => _showDiagText('e2e_report'), child: Text(tr('Báo cáo chi tiết (JSON)'))),
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng'))),
        ],
      ),
    );
  }

  // MỚI (mục 69) - nhật ký backend (những gì in ra ô Colab): trước đây phải quay lại Colab để biết vì sao lỗi. Đọc qua POST có chữ ký (có thể chứa tên tệp/câu mô tả).
  Future<void> _showBackendLog() async {
    final r = await _post('log-read', 'log', {'lines': '400'});
    if (r == null) return;
    final lines = _asList(r['lines']).map((e) => e.toString()).toList();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Nhật ký backend (Colab)')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            reverse: true,
            child: SelectableText(
              lines.isEmpty ? tr('Chưa có nhật ký (backend cũ hoặc chưa bật ghi nhật ký).') : lines.join('\n'),
              style: const TextStyle(fontSize: 10, fontFamily: 'monospace'),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showBackendLog();
            },
            child: Text(tr('Làm mới')),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng'))),
        ],
      ),
    );
  }

  Widget _diagRow(Map<String, dynamic> d, bool locked) {
    final id = (d['id'] ?? '').toString();
    final last = d['last'] is Map ? Map<String, dynamic>.from(d['last'] as Map) : null;
    final bool heavy = d['gpu'] == true || d['server'] == true;
    final VoidCallback? onRun = locked ? null : () => _runDiag(id);
    String when = '';
    if (last != null && last['finished'] is num) {
      final t = DateTime.fromMillisecondsSinceEpoch(((last['finished'] as num) * 1000).round()).toLocal().toString();
      when = t.length >= 16 ? t.substring(0, 16) : t;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text((d['label'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.w500))),
              heavy ? OutlinedButton(onPressed: onRun, child: Text(tr('Chạy'))) : ElevatedButton(onPressed: onRun, child: Text(tr('Chạy'))),
            ],
          ),
          Text(
            trv('Dự kiến khoảng {0} phút. ', [d['minutes']]) + (d['desc'] ?? '').toString(),
            style: TextStyle(fontSize: 12, color: mutedGrey),
          ),
          if (last != null)
            Row(
              children: [
                Icon(last['ok'] == true ? Icons.check_circle : Icons.error, size: 16, color: last['ok'] == true ? Colors.green : Colors.red),
                const SizedBox(width: 6),
                Expanded(child: Text('${(last['headline'] ?? '').toString()}  ($when)', style: const TextStyle(fontSize: 12))),
                TextButton(onPressed: () => _showDiagResult(d, last), child: Text(tr('Chi tiết'))),
              ],
            ),
        ],
      ),
    );
  }

  Widget _diagCard() {
    final items = _asList(_st['diagnostics']);
    if (items.isEmpty) return const SizedBox.shrink();
    final locked = _busy.isNotEmpty || _st['busy'] == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Chẩn đoán & kiểm thử'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Chạy ngay trên Colab các phép kiểm tra và đo đạc (trước đây phải mở ô lệnh Colab): môi trường, chạy thử tính năng, đo tốc độ/VRAM và thử tạo MV 2 cảnh đầu-cuối. Nhật ký và tiến độ hiện ở mục Tác vụ; kết quả lần chạy cuối được nhớ ở đây. Phép đo GPU tạm khoá việc tạo MV.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton(onPressed: _showBackendLog, child: Text(tr('Xem nhật ký backend (Colab)'))),
            ),
            for (final d in items)
              if (d is Map) _diagRow(Map<String, dynamic>.from(d), locked),
          ],
        ),
      ),
    );
  }

  Widget _comfyCard() {
    final c = _asMap(_st['comfy']);
    final installed = c['installed'] == true;
    final running = c['running'] == true;
    final byApp = c['started_by_app'] == true;
    final installing = c['installing'] == true;
    final nodes = _asList(c['custom_nodes']).map((e) => e.toString()).toList();
    final allowed = _asList(_st['comfy_args_allowed']).map((e) => e.toString()).toList();
    final logTail = _asList(c['log_tail']).map((e) => e.toString()).toList();
    final locked = _busy.isNotEmpty;
    final String state = running ? tr('đang chạy') : (installed ? tr('đã cài, chưa bật') : tr('chưa cài'));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ComfyUI', style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Chạy model bất kỳ bằng workflow cộng đồng (LTX, Wan...) mà không sửa code. Khi bạn chọn công nghệ video ComfyUI, app TỰ BẬT nếu đã cài.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            Text(tr('Trạng thái') + ': ' + state),
            if (nodes.isNotEmpty) Text(tr('Node đã cài') + ': ' + nodes.join(', '), style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                if (!installed)
                  ElevatedButton(
                    onPressed: (locked || installing) ? null : _installComfy,
                    child: Text(installing ? tr('Đang cài...') : tr('Cài ComfyUI')),
                  ),
                if (installed && !running) ElevatedButton(onPressed: locked ? null : _startComfy, child: Text(tr('Bật ComfyUI'))),
                if (running && byApp) OutlinedButton(onPressed: locked ? null : _stopComfy, child: Text(tr('Tắt ComfyUI'))),
                if (installed) OutlinedButton(onPressed: (locked || installing) ? null : _addNode, child: Text(tr('Thêm node'))),
                OutlinedButton(onPressed: locked ? null : _uploadWorkflow, child: Text(tr('Tải workflow lên'))),
              ],
            ),
            if (running && !byApp)
              Text(tr('Đang chạy từ ô Colab nên app không tắt được.'), style: TextStyle(fontSize: 12, color: mutedGrey)),
            if (installed && !running && allowed.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(tr('Tuỳ chọn khi bật (hết VRAM thì chọn --lowvram):'), style: const TextStyle(fontSize: 12)),
              Wrap(
                spacing: 6,
                children: [
                  for (final a in allowed)
                    FilterChip(
                      label: Text(a, style: const TextStyle(fontSize: 11)),
                      selected: _comfyArgs.contains(a),
                      onSelected: (v) => setState(() {
                        if (v) {
                          _comfyArgs.add(a);
                        } else {
                          _comfyArgs.remove(a);
                        }
                      }),
                    ),
                ],
              ),
            ],
            if (installed && !running && logTail.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(logTail.join('\n'), style: TextStyle(fontSize: 10, color: mutedGrey, fontFamily: 'monospace')),
            ],
            const SizedBox(height: 4),
            Text(
              tr('Chọn workflow đang dùng ở Cài đặt → mục ComfyUI (nút Làm mới).'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ tải file model
  Future<void> _startDownload() async {
    final url = _dlUrlCtrl.text.trim();
    if (url.isEmpty) {
      _snack(tr('Dán link tải trực tiếp trước.'));
      return;
    }
    final r = await _post('download', 'download', {'url': url, 'kind': _dlKind, 'filename': _dlNameCtrl.text.trim(), 'hf_token': _dlTokenCtrl.text.trim()});
    if (r == null) return;
    _snack(tr('Đã bắt đầu tải. Xem tiến độ ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Widget _downloadCard() {
    final kinds = _asMap(_st['download_kinds']);
    final downloaded = _asList(_st['downloaded']);
    final String kind = kinds.containsKey(_dlKind) ? _dlKind : (kinds.isNotEmpty ? kinds.keys.first : _dlKind);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Tải model về Drive (cho ComfyUI)'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Dán link TRỰC TIẾP tới file .safetensors hoặc .gguf (HuggingFace: .../resolve/main/ten-file.safetensors). Không nhận .ckpt/.pt/.bin. Drive miễn phí chỉ 15 GB - app báo nếu không đủ chỗ.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            if (kinds.isNotEmpty)
              DropdownButton<String>(
                value: kind,
                isExpanded: true,
                items: [for (final k in kinds.keys) DropdownMenuItem<String>(value: k, child: Text(kinds[k].toString()))],
                onChanged: (v) => setState(() => _dlKind = v ?? _dlKind),
              ),
            TextField(controller: _dlUrlCtrl, decoration: const InputDecoration(labelText: 'Link https://...')),
            TextField(controller: _dlNameCtrl, decoration: InputDecoration(labelText: tr('Tên file lưu (để trống = lấy theo link)'))),
            TextField(controller: _dlTokenCtrl, obscureText: true, decoration: InputDecoration(labelText: tr('Token HuggingFace/CivitAI (chỉ nếu cần)'))),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: _busy.isNotEmpty ? null : _startDownload, child: Text(tr('Tải về Drive'))),
            if (downloaded.isNotEmpty)
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text(tr('File đã có') + ' (' + downloaded.length.toString() + ')', style: const TextStyle(fontSize: 13)),
                children: [
                  for (final d in downloaded)
                    if (d is Map) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text(d['name'].toString()), subtitle: Text(d['kind'].toString() + ' · ' + d['mb'].toString() + ' MB')),
                ],
              ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ API miễn phí
  Future<void> _setUse(String kind, String provider, Map<String, dynamic> providers) async {
    String consent = 'false';
    if (provider != 'none') {
      final p = _asMap(providers[provider]);
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('Gửi dữ liệu cho bên thứ ba?')),
          content: SingleChildScrollView(
            child: Text(
              tr('Lời bài hát / giọng hát sẽ được GỬI tới dịch vụ này để xử lý.') + '\n\n' + (p['privacy'] ?? '').toString(),
              style: const TextStyle(fontSize: 13),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Không'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Tôi đồng ý'))),
          ],
        ),
      );
      if (ok != true) return;
      consent = 'true';
    }
    final String field = kind == 'llm' ? 'llm_provider' : 'asr_provider';
    final r = await _post('cloud-use', 'cloud/use', {field: provider, 'consent': consent});
    if (r == null) return;
    _snack(provider == 'none' ? tr('Đã tắt, dùng model trên Colab.') : tr('Đã bật. Nếu API lỗi/hết hạn mức, app tự dùng model trên Colab.'));
    await _reload(silent: true);
  }

  Future<void> _configProvider(String id, Map<String, dynamic> p) async {
    final keyCtrl = TextEditingController();
    final baseCtrl = TextEditingController(text: (p['base_url'] ?? '').toString());
    final chatCtrl = TextEditingController(text: (p['chat_model'] ?? '').toString());
    final asrCtrl = TextEditingController(text: (p['asr_model'] ?? '').toString());
    final hasKey = p['has_key'] == true;
    final canAsr = p['asr'] == true;
    final keyUrl = (p['key_url'] ?? '').toString();
    final action = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text((p['label'] ?? id).toString()),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (keyUrl.isNotEmpty) SelectableText(tr('Lấy API key tại') + ': ' + keyUrl, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 4),
              Text((p['privacy'] ?? '').toString(), style: TextStyle(fontSize: 11, color: mutedGrey)),
              TextField(
                controller: keyCtrl,
                obscureText: true,
                decoration: InputDecoration(labelText: hasKey ? tr('API key (để trống = giữ key cũ)') : 'API key'),
              ),
              if (id == 'custom') TextField(controller: baseCtrl, decoration: const InputDecoration(labelText: 'Base URL (https://.../v1)')),
              TextField(controller: chatCtrl, decoration: InputDecoration(labelText: tr('Model chat (hoặc lưu key rồi bấm Chọn model)'))),
              if (canAsr) TextField(controller: asrCtrl, decoration: InputDecoration(labelText: tr('Model chép lời'))),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'cancel'), child: Text(tr('Huỷ'))),
          if (hasKey) TextButton(onPressed: () => Navigator.pop(ctx, 'delete'), child: Text(tr('Xoá key'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'save'), child: Text(tr('Lưu'))),
        ],
      ),
    );
    final body = <String, String>{
      'provider': id,
      'api_key': keyCtrl.text.trim(),
      'chat_model': chatCtrl.text.trim(),
      'asr_model': asrCtrl.text.trim(),
    };
    if (id == 'custom') body['base_url'] = baseCtrl.text.trim();
    keyCtrl.dispose();
    baseCtrl.dispose();
    chatCtrl.dispose();
    asrCtrl.dispose();
    if (!mounted) return;
    if (action == 'save') {
      final r = await _post('cloud-config', 'cloud/config', body);
      if (r == null) return;
      _snack(tr('Đã lưu.'));
    } else if (action == 'delete') {
      final r = await _post('cloud-delete-key', 'cloud/delete-key', {'provider': id});
      if (r == null) return;
      _snack(tr('Đã xoá key.'));
    } else {
      return;
    }
    await _reload(silent: true);
  }

  Future<void> _pickChatModel(String id) async {
    final r = await _post('cloud-models', 'cloud/models', {'provider': id, 'free_only': 'true'});
    if (r == null) return;
    final models = _asList(r['models']).map((e) => e.toString()).toList();
    if (models.isEmpty) {
      _snack(tr('Nhà cung cấp không trả về model nào (kiểm key/đuôi :free).'));
      return;
    }
    if (!mounted) return;
    final chosen = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(tr('Chọn model chat')),
        children: [
          SizedBox(
            width: double.maxFinite,
            height: 360,
            child: ListView(
              children: [
                for (final m in models) ListTile(dense: true, title: Text(m), onTap: () => Navigator.pop(ctx, m)),
              ],
            ),
          ),
        ],
      ),
    );
    if (chosen == null) return;
    final saved = await _post('cloud-config', 'cloud/config', {'provider': id, 'chat_model': chosen});
    if (saved == null) return;
    _snack(tr('Đã chọn model') + ': ' + chosen);
    await _reload(silent: true);
  }

  Future<void> _testProvider(String id, Map<String, dynamic> p) async {
    final kind = (p['chat_model'] ?? '').toString().isEmpty ? 'models' : 'chat';
    final r = await _post('cloud-test', 'cloud/test', {'provider': id, 'kind': kind});
    if (r == null) return;
    _snack((r['ok'] == true ? '✔ ' : '✘ ') + (r['note'] ?? '').toString());
  }

  Widget _useDropdown(String kind, String label, Map<String, dynamic> providers, String current) {
    final items = <DropdownMenuItem<String>>[
      DropdownMenuItem<String>(value: 'none', child: Text(tr('Model trên Colab (mặc định)'))),
    ];
    for (final id in providers.keys) {
      final p = _asMap(providers[id]);
      final supported = kind == 'llm' ? p['chat'] == true : p['asr'] == true;
      final ready = p['has_key'] == true && (kind == 'asr' || (p['chat_model'] ?? '').toString().isNotEmpty);
      if (supported && ready) items.add(DropdownMenuItem<String>(value: id, child: Text((p['label'] ?? id).toString(), overflow: TextOverflow.ellipsis)));
    }
    final value = items.any((e) => e.value == current) ? current : 'none';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13)),
        DropdownButton<String>(
          value: value,
          isExpanded: true,
          items: items,
          onChanged: _busy.isNotEmpty ? null : (v) => _setUse(kind, v ?? 'none', providers),
        ),
      ],
    );
  }

  Widget _cloudCard() {
    final cloud = _asMap(_st['cloud']);
    final providers = _asMap(cloud['providers']);
    final use = _asMap(cloud['use']);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('API miễn phí thay model trên Colab'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Dùng gói miễn phí của Groq / Gemini / OpenRouter cho phần viết kịch bản, phóng tác lời và chép lời - nhanh hơn, đỡ RAM/GPU Colab. Có giới hạn hạn mức, lời bài hát bị gửi cho bên thứ ba, và luôn có đường lui về model trên Colab khi API lỗi. Video/nhạc/giọng vẫn chạy trên Colab (chưa có API video miễn phí đáng tin).'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            _useDropdown('llm', tr('Viết kịch bản + phóng tác lời dùng'), providers, (use['llm'] ?? '').toString()),
            _useDropdown('asr', tr('Chép lời bài hát dùng'), providers, (use['asr'] ?? '').toString()),
            const Divider(),
            for (final id in providers.keys) _providerTile(id, _asMap(providers[id])),
          ],
        ),
      ),
    );
  }

  Widget _providerTile(String id, Map<String, dynamic> p) {
    final hasKey = p['has_key'] == true;
    final chat = (p['chat_model'] ?? '').toString();
    final locked = _busy.isNotEmpty;
    final String sub = hasKey ? (tr('Đã lưu key') + (chat.isEmpty ? '' : ' · ' + chat)) : tr('Chưa có key');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text((p['label'] ?? id).toString(), style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(sub, style: TextStyle(fontSize: 12, color: mutedGrey)),
          Wrap(
            spacing: 8,
            children: [
              TextButton(onPressed: locked ? null : () => _configProvider(id, p), child: Text(tr('Cấu hình'))),
              if (hasKey && p['chat'] == true) TextButton(onPressed: locked ? null : () => _pickChatModel(id), child: Text(tr('Chọn model chat'))),
              if (hasKey) TextButton(onPressed: locked ? null : () => _testProvider(id, p), child: Text(tr('Thử'))),
            ],
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ cài tính năng tuỳ chọn
  bool _kindRunning(String kind) {
    for (final t in _asList(_st['tasks'])) {
      if (t is Map && t['kind'] == kind && t['status'] == 'running') return true;
    }
    return false;
  }

  Future<void> _installFeature(Map<String, dynamic> f) async {
    final warning = (f['warning'] ?? '').toString();
    final minutes = (f['minutes'] ?? '').toString();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Cài') + ' ' + (f['label'] ?? '').toString() + '?'),
        content: SingleChildScrollView(
          child: Text(
            (minutes.isEmpty ? '' : tr('Mất khoảng') + ' ' + minutes + ' ' + tr('phút') + '. ') +
                tr('Cài trực tiếp lên Colab đang chạy; nếu lỗi, xem nhật ký ở mục Tác vụ.') +
                (warning.isEmpty ? '' : '\n\n' + warning),
            style: const TextStyle(fontSize: 13),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Cài'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final r = await _post('feature-install', 'feature/install', {'feature': (f['key'] ?? '').toString()});
    if (r == null) return;
    _snack(tr('Đang cài. Xem tiến độ ở mục Tác vụ.'));
    await _reload(silent: true);
  }

  Widget _featureTile(Map<String, dynamic> f) {
    final installed = f['installed'] == true;
    final manual = f['manual'] == true;
    final warning = (f['warning'] ?? '').toString();
    final busy = _busy.isNotEmpty || _kindRunning('feature_install');
    final verified = f['verified'];
    String broken = '';
    for (final m in _asList(f['missing'])) {
      if (m.toString().contains('tự kiểm thử')) broken = m.toString();
    }
    final String stateText = !installed
        ? tr('Chưa cài')
        : (verified == true ? tr('Đã cài · đã kiểm chạy thật') : (verified == false ? tr('Đã cài · CHƯA kiểm chạy thật') : tr('Đã cài')));
    final Color stateColor = !installed ? mutedGrey : (verified == false ? Colors.orange : Colors.green);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text((f['label'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.w500)),
          Text((f['desc'] ?? '').toString(), style: TextStyle(fontSize: 12, color: mutedGrey)),
          if (warning.isNotEmpty) Text(warning, style: const TextStyle(fontSize: 11, color: Colors.orange)),
          if (broken.isNotEmpty) Text(broken, style: const TextStyle(fontSize: 11, color: Colors.red)),
          Row(
            children: [
              Text(stateText, style: TextStyle(fontSize: 12, color: stateColor)),
              const Spacer(),
              if (!manual && !installed) OutlinedButton(onPressed: busy ? null : () => _installFeature(f), child: Text(tr('Cài'))),
              if (!manual && installed) TextButton(onPressed: busy ? null : () => _installFeature(f), child: Text(tr('Cài lại'))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _featuresCard() {
    final features = _asList(_st['features']);
    if (features.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Cài tính năng tuỳ chọn'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Thay cho việc dán ô lệnh trong Colab. Chưa chạy thử trên Colab thật - lỗi thì nhật ký hiện rõ. Chưa cài thì tính năng tương ứng tự bị bỏ qua khi tạo MV, không làm hỏng gì.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            for (final f in features)
              if (f is Map) _featureTile(Map<String, dynamic>.from(f)),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ cài đặt nâng cao (biến môi trường)
  Future<void> _askEnv(Map<String, dynamic> it) async {
    final key = (it['key'] ?? '').toString();
    final kind = (it['kind'] ?? 'text').toString();
    final choices = _asList(it['choices']).map((e) => e.toString()).toList();
    String? value;
    if (choices.isNotEmpty) {
      value = await showDialog<String>(
        context: context,
        builder: (ctx) => SimpleDialog(
          title: Text((it['label'] ?? key).toString()),
          children: [
            for (final c in choices)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, c),
                child: Text(kind == 'bool' ? (c == '1' ? '1 (' + tr('bật') + ')' : '0 (' + tr('tắt') + ')') : c),
              ),
          ],
        ),
      );
    } else {
      value = await _askText(
        title: (it['label'] ?? key).toString(),
        hint: kind == 'secret' ? tr('Giá trị bí mật (không hiện lại sau khi lưu)') : (it['help'] ?? '').toString(),
        initial: kind == 'secret' ? '' : (it['value'] ?? '').toString(),
      );
    }
    if (value == null || value.isEmpty || !mounted) return;
    final r = await _post('env-set', 'env/set', {'key': key, 'value': value});
    if (r == null) return;
    _snack(tr('Đã đặt - có hiệu lực ngay, không cần khởi động lại.'));
    await _reload(silent: true);
  }

  Future<void> _unsetEnv(String key) async {
    final r = await _post('env-unset', 'env/unset', {'key': key});
    if (r == null) return;
    _snack(tr('Đã xoá cài đặt.'));
    await _reload(silent: true);
  }

  Widget _envTile(Map<String, dynamic> it) {
    final kind = (it['kind'] ?? '').toString();
    final isSet = it['set'] == true;
    final source = (it['source'] ?? '').toString();
    final String state = !isSet
        ? tr('chưa đặt')
        : ((kind == 'secret' ? tr('đã đặt (ẩn)') : (it['value'] ?? '').toString()) + (source == 'colab' ? ' · ' + tr('đặt từ Colab') : ''));
    final locked = _busy.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text((it['label'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.w500)),
                Text(state, style: TextStyle(fontSize: 12, color: mutedGrey)),
              ],
            ),
          ),
          TextButton(onPressed: locked ? null : () => _askEnv(it), child: Text(tr('Đặt'))),
          if (source == 'app') TextButton(onPressed: locked ? null : () => _unsetEnv((it['key'] ?? '').toString()), child: Text(tr('Xoá'))),
        ],
      ),
    );
  }

  Widget _envCard() {
    final items = _asList(_st['env']);
    if (items.isEmpty) return const SizedBox.shrink();
    final children = <Widget>[];
    String lastGroup = '';
    for (final raw in items) {
      if (raw is! Map) continue;
      final it = Map<String, dynamic>.from(raw);
      final group = (it['group'] ?? '').toString();
      if (group != lastGroup) {
        lastGroup = group;
        children.add(Padding(padding: const EdgeInsets.only(top: 10, bottom: 2), child: Text(group, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))));
      }
      children.add(_envTile(it));
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Cài đặt nâng cao'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Thay cho việc sửa dòng os.environ ở Bước 5 của notebook. Có hiệu lực NGAY và được nhớ cho các phiên sau. Khoá/bí mật không bao giờ được gửi ngược về app.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            ...children,
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ tác vụ nền
  Future<void> _cancelTask(String id) async {
    final r = await _post('task-cancel', 'task/cancel', {'task_id': id});
    if (r == null) return;
    await _reload(silent: true);
  }

  Future<void> _showLogs(String id) async {
    String text;
    try {
      final r = await widget.api.controlTask(id);
      final t = _asMap(r['task']);
      final logs = _asList(t['logs']).map((e) => e.toString()).toList();
      text = logs.isEmpty ? tr('(chưa có nhật ký)') : logs.join('\n');
    } catch (e) {
      text = trv('Không lấy được nhật ký: {0}', [e]);
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Nhật ký tác vụ')),
        content: SingleChildScrollView(child: SelectableText(text, style: const TextStyle(fontSize: 11, fontFamily: 'monospace'))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  Widget _tasksCard() {
    final tasks = _asList(_st['tasks']);
    if (tasks.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Tác vụ'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            for (final t in tasks)
              if (t is Map) _taskTile(Map<String, dynamic>.from(t)),
          ],
        ),
      ),
    );
  }

  Widget _taskTile(Map<String, dynamic> t) {
    final status = (t['status'] ?? '').toString();
    final progress = (t['progress'] as num?)?.toDouble() ?? 0.0;
    final id = (t['id'] ?? '').toString();
    final String label = status == 'running'
        ? tr('đang chạy')
        : (status == 'done' ? tr('xong') : (status == 'cancelled' ? tr('đã huỷ') : tr('lỗi')));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text((t['title'] ?? '').toString() + ' - ' + label, style: const TextStyle(fontWeight: FontWeight.w500)),
          if (status == 'running') LinearProgressIndicator(value: progress > 0 ? progress / 100 : null),
          if ((t['note'] ?? '').toString().isNotEmpty) Text((t['note'] ?? '').toString(), style: TextStyle(fontSize: 12, color: status == 'error' ? Colors.red : mutedGrey)),
          Row(
            children: [
              TextButton(onPressed: () => _showLogs(id), child: Text(tr('Nhật ký'))),
              if (status == 'running') TextButton(onPressed: _busy.isNotEmpty ? null : () => _cancelTask(id), child: Text(tr('Huỷ'))),
            ],
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ kiểm tra môi trường
  Future<void> _runPreflight() async {
    setState(() => _busy = 'preflight');
    try {
      final r = await widget.api.controlPreflight();
      if (mounted) setState(() => _preflight = _asList(r['checks']));
    } catch (e) {
      _snack(trv('Không kiểm tra được: {0}', [e]));
    }
    if (mounted) setState(() => _busy = '');
  }

  Widget _preflightRow(Map<String, dynamic> c) {
    final level = (c['level'] ?? '').toString();
    final IconData icon = level == 'ok' ? Icons.check_circle : (level == 'warn' ? Icons.warning_amber : Icons.error);
    final Color color = level == 'ok' ? Colors.green : (level == 'warn' ? Colors.orange : Colors.red);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Expanded(child: Text((c['label'] ?? '').toString() + ': ' + (c['detail'] ?? '').toString(), style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
  }

  Widget _preflightCard() {
    final checks = _preflight;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Kiểm tra môi trường'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Chạy trước khi cài ComfyUI/tính năng: kiểm git, ffmpeg, ổ đĩa, GPU và kết nối tới HuggingFace/GitHub/PyTorch để biết trước vì sao cài có thể lỗi.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: _busy.isNotEmpty ? null : _runPreflight, child: Text(tr('Chạy kiểm tra'))),
            if (checks != null) ...[
              const SizedBox(height: 8),
              for (final c in checks)
                if (c is Map) _preflightRow(Map<String, dynamic>.from(c)),
            ],
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ kiểm tra giấy phép model (mục 52)
  Future<void> _runLicenseAudit() async {
    setState(() => _busy = 'license');
    try {
      final r = await widget.api.getLicenseAudit();
      if (mounted) setState(() => _license = r);
    } catch (e) {
      _snack(trv('Không kiểm tra được: {0}', [e]));
    }
    if (mounted) setState(() => _busy = '');
  }

  Widget _licenseRow(Map<String, dynamic> r) {
    final status = (r['status'] ?? '').toString();
    final IconData icon = status == 'noncommercial' ? Icons.error : (status == 'conditions' ? Icons.warning_amber : (status == 'unknown' ? Icons.help_outline : Icons.check_circle));
    final Color color = status == 'noncommercial' ? Colors.red : (status == 'conditions' ? Colors.orange : (status == 'unknown' ? mutedGrey : Colors.green));
    final slot = (r['slot'] ?? '').toString();
    final mid = (r['id'] ?? '').toString();
    final lic = (r['license'] ?? '').toString();
    final line = slot + ' (' + mid + '): ' + status + (lic.isEmpty ? '' : ' - ' + lic);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Expanded(child: Text(line, style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
  }

  Widget _licenseCard() {
    final r = _license;
    final rows = r == null ? <dynamic>[] : _asList(r['rows']);
    final notes = r == null ? <dynamic>[] : _asList(r['notes']);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Kiểm tra giấy phép model'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Hỏi Hugging Face về giấy phép của các model đang cấu hình (mất tối đa ~30 giây). Không phải tư vấn pháp lý; kết quả cũng hiện ở thẻ cam màn Kết quả sau mỗi MV.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: _busy.isNotEmpty ? null : _runLicenseAudit, child: Text(tr('Chạy kiểm tra giấy phép'))),
            if (r != null) ...[
              const SizedBox(height: 8),
              if (r['status'] != 'ok')
                Text((r['note'] ?? '').toString(), style: const TextStyle(fontSize: 12, color: Colors.red))
              else ...[
                Text(
                  trv('Đã kiểm {0} model.', [rows.length]) + ' ' + (r['commercial_mode'] == true ? tr('Chế độ thương mại an toàn: BẬT') : tr('Chế độ thương mại an toàn: tắt')),
                  style: const TextStyle(fontSize: 12),
                ),
                for (final x in rows)
                  if (x is Map) _licenseRow(Map<String, dynamic>.from(x)),
                if (notes.isEmpty) Text(tr('Không có cảnh báo giấy phép nào trong danh sách đã đọc.'), style: TextStyle(fontSize: 12, color: mutedGrey)),
                for (final n in notes)
                  Padding(padding: const EdgeInsets.only(top: 4), child: Text(n.toString(), style: const TextStyle(fontSize: 12, color: Colors.orange))),
              ],
            ],
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ thử khoá cảnh stock (mục 53)
  Future<void> _runStockKeyTest() async {
    setState(() => _busy = 'stockkey');
    try {
      final r = await widget.api.getStockKeyTest();
      if (mounted) setState(() => _stockTest = r);
    } catch (e) {
      _snack(trv('Không kiểm tra được: {0}', [e]));
    }
    if (mounted) setState(() => _busy = '');
  }

  Widget _stockKeyRow(Map<String, dynamic> r) {
    final ok = r['ok'] == true;
    final configured = r['configured'] == true;
    final IconData icon = ok ? Icons.check_circle : (configured ? Icons.error : Icons.help_outline);
    final Color color = ok ? Colors.green : (configured ? Colors.red : mutedGrey);
    final name = (r['provider'] ?? '').toString();
    final line = (name.isEmpty ? '' : name[0].toUpperCase() + name.substring(1)) + ': ' + (r['message'] ?? '').toString();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Expanded(child: Text(line, style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
  }

  Widget _stockKeyCard() {
    final r = _stockTest;
    final rows = r == null ? <dynamic>[] : _asList(r['results']);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Thử khoá cảnh stock (Pexels/Pixabay)'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Gửi 1 truy vấn thử cho mỗi khoá đã đặt (không tải video). Đặt khoá ở phần cài đặt bên dưới.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: _busy.isNotEmpty ? null : _runStockKeyTest, child: Text(tr('Thử khoá'))),
            if (r != null) ...[
              const SizedBox(height: 8),
              if (r['status'] != 'ok')
                Text((r['note'] ?? '').toString(), style: const TextStyle(fontSize: 12, color: Colors.red))
              else
                for (final x in rows)
                  if (x is Map) _stockKeyRow(Map<String, dynamic>.from(x)),
            ],
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ khoá bảo mật + khung màn
  Widget _hmacCard() {
    final enabled = _st['hmac_enabled'] == true;
    final missing = s.hmacSecret.isEmpty;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Khoá bảo mật (bắt buộc để điều khiển)'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              enabled
                  ? tr('Backend đã bật khoá HMAC. Dán khoá in ở Bước 7 trong Colab (khoá không đổi giữa các phiên; mặc định app không lưu khoá - bật ô ghi nhớ bên dưới nếu muốn).')
                  : tr('Backend CHƯA bật khoá HMAC nên các nút bên dưới bị từ chối. Chạy lại Bước 7 của notebook (đã bật khoá sẵn; khoá in ra cùng địa chỉ), rồi dán khoá vào đây.'),
              style: TextStyle(fontSize: 12, color: enabled ? mutedGrey : Colors.orange),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _hmacCtrl,
              obscureText: true,
              decoration: InputDecoration(border: const OutlineInputBorder(), hintText: tr('Khoá bí mật HMAC'), errorText: missing ? tr('Chưa có khoá - các nút điều khiển sẽ không chạy') : null),
              onChanged: (v) {
                setState(() => s.hmacSecret = v.trim());
                s.saveHmacChoice();
              },
            ),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: s.rememberHmac,
              onChanged: (v) {
                setState(() => s.rememberHmac = v ?? false);
                s.saveHmacChoice();
              },
              title: Text(tr('Ghi nhớ khoá trên máy này')),
              subtitle: Text(
                tr('Đỡ phải dán lại mỗi lần mở app, nhưng ai lấy được dữ liệu app trên máy này đọc được khoá. Tắt thì khoá bị xoá khỏi máy.'),
                style: const TextStyle(fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: () => _reload(), child: Text(tr('Thử lại'))),
            ],
          ),
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _reload,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (_busy.isNotEmpty) const LinearProgressIndicator(),
          if (_st['busy'] == true)
            Card(
              color: Colors.orange.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(tr('Backend đang chạy tác vụ GPU - đổi model tạm khoá cho tới khi xong.'), style: const TextStyle(fontSize: 13)),
              ),
            ),
          _hmacCard(),
          _healthLine(),
          _restoreCard(),
          _diagCard(),
          _preflightCard(),
          _licenseCard(),
          _stockKeyCard(),
          _modelsCard(),
          _comfyCard(),
          _downloadCard(),
          _featuresCard(),
          _upscaleCard(),
          _cloudCard(),
          _envCard(),
          _tasksCard(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('Mô hình & công cụ')),
        actions: [IconButton(icon: const Icon(Icons.refresh), tooltip: tr('Làm mới'), onPressed: () => _reload())],
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : _body(),
    );
  }
}
