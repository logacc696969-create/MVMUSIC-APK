import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../crash_log.dart';

import '../l10n.dart';
/// MỚI (mục 23) - xem/chia sẻ/xoá nhật ký lỗi cục bộ (xem `CrashLog`). Chỉ lỗi phía Dart.
class CrashLogScreen extends StatefulWidget {
  const CrashLogScreen({super.key});

  @override
  State<CrashLogScreen> createState() => _CrashLogScreenState();
}

class _CrashLogScreenState extends State<CrashLogScreen> {
  String? _text;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final t = await CrashLog.read();
    if (mounted) setState(() => _text = t);
  }

  Future<void> _share() async {
    final f = await CrashLog.file();
    if (await f.exists()) {
      await Share.shareXFiles([XFile(f.path)]);
    }
  }

  Future<void> _clear() async {
    await CrashLog.clear();
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    final text = _text;
    final isEmpty = text != null && text.trim().isEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('Nhật ký lỗi')),
        actions: [
          IconButton(
            tooltip: tr('Chia sẻ file nhật ký'),
            icon: const Icon(Icons.share),
            onPressed: isEmpty || text == null ? null : _share,
          ),
          IconButton(
            tooltip: tr('Xoá nhật ký'),
            icon: const Icon(Icons.delete_outline),
            onPressed: isEmpty || text == null ? null : _clear,
          ),
        ],
      ),
      body: text == null
          ? const Center(child: CircularProgressIndicator())
          : isEmpty
              ? Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      tr('Chưa ghi nhận lỗi nào.\n\nNhật ký chỉ nằm trong máy và chỉ gửi đi khi bạn bấm Chia sẻ.'),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(12),
                  child: SelectableText(text, style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                ),
    );
  }
}
