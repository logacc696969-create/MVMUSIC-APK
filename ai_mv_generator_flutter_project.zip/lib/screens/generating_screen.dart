import 'dart:async';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../realtime_client.dart';
import 'result_screen.dart';

/// Bắt đầu job tạo MV chạy nền trên Colab, ưu tiên nhận dữ liệu qua WebSocket
/// (server chủ động đẩy). Nếu WebSocket lỗi/mất kết nối/im lặng quá lâu
/// (watchdog) -> TỰ ĐỘNG chuyển sang polling GET /progress (không cần người
/// dùng bấm gì) - chỉ khi CẢ HAI đường đều thất bại mới báo lỗi hẳn.
class GeneratingScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const GeneratingScreen({super.key, required this.api, required this.project});

  @override
  State<GeneratingScreen> createState() => _GeneratingScreenState();
}

class _GeneratingScreenState extends State<GeneratingScreen> with WidgetsBindingObserver {
  int _percent = 0;
  String _stageDetail = 'Đang bắt đầu job trên GPU remote...';
  String? _error;
  bool _retrying = false;
  bool _usingFallbackPoll = false;

  RealtimeClient? _wsClient;
  Timer? _watchdog;
  Timer? _pollTimer;
  int _pollFailureStreak = 0;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  StreamSubscription<Map<String, dynamic>?>? _bgServiceSub;

  final Set<String> _seenArtifacts = {};
  int _sceneCount = 0;
  final Set<int> _completedSceneIndices = {}; // cho lưới storyboard
  final Map<int, String> _sceneFilePathByIndex = {}; // để mở xem trước khi tap ô đã xong

  bool _cancelling = false;
  bool _cancelled = false;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable(); // job dài vài phút -> giữ màn hình sáng, tránh Android ngủ app làm đứt WS
    WidgetsBinding.instance.addObserver(this); // để bắt lúc app quay lại foreground, xem _resyncAfterResume
    _startConnectivityListener();
    _startBackgroundService();
    _start();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    WidgetsBinding.instance.removeObserver(this);
    _bgServiceSub?.cancel();
    FlutterBackgroundService().invoke('stopService'); // tắt thông báo nền, không cần chạy tiếp nữa
    _wsClient?.close();
    _watchdog?.cancel();
    _pollTimer?.cancel();
    _connectivitySub?.cancel();
    super.dispose();
  }

  /// Bật Foreground Service THẬT của Android (xem background_service.dart) -
  /// giữ 1 thông báo hiện % trực tiếp trên thanh trạng thái, tự cập nhật dù
  /// màn hình khoá hay chuyển sang app khác - không chỉ trông chờ mỗi
  /// WakelockPlus (chỉ chống tắt màn hình, không đảm bảo Dart isolate chạy
  /// tiếp lúc thật sự ở nền).
  Future<void> _startBackgroundService() async {
    final bg = FlutterBackgroundService();
    await bg.startService();
    bg.invoke('setEndpoint', {'progressUrl': '${widget.api.baseUrl}/progress'});
    _bgServiceSub = bg.on('update').listen((event) {
      if (event == null) return;
      _handleProgressData(Map<String, dynamic>.from(event));
    });
  }

  /// Dù đã có Foreground Service (_startBackgroundService) giữ % cập nhật lúc
  /// ở nền, service đó KHÔNG tự tải file cảnh/MV về máy - nên vẫn cần đồng bộ
  /// lại đầy đủ (kèm tải bù artifact) NGAY khi app quay lại foreground, thay
  /// vì đợi watchdog 60s hoặc người dùng tự bấm "Thử lại".
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _resyncAfterResume();
    }
  }

  Future<void> _resyncAfterResume() async {
    if (!mounted || _error != null || _cancelled || _cancelling) return;
    try {
      final p = await widget.api.getProgress();
      _handleProgressData(p);

      final artifacts = (p['artifacts'] as List?) ?? [];
      for (final raw in artifacts) {
        final a = raw as Map;
        final filename = a['filename'] as String;
        final kind = a['kind'] as String;
        if (_seenArtifacts.contains(filename)) continue;
        _seenArtifacts.add(filename);
        await _downloadArtifactViaPollFallback(filename, kind);
      }

      // WebSocket có thể đã chết lặng lẽ trong lúc app ở nền mà không kịp gọi
      // onDisconnected -> chủ động chuyển dự phòng polling để chắc chắn vẫn
      // tiếp tục nhận cập nhật, thay vì trông chờ 1 kết nối có thể đã hỏng.
      if (!_usingFallbackPoll) {
        _switchToPollingFallback('Đồng bộ lại sau khi app quay lại từ nền');
      }
    } catch (_) {
      // Lỗi tạm thời lúc resync (mạng chưa kịp có) - timer định kỳ sẽ tự thử
      // lại sau, không cần xử lý gì thêm ở đây.
    }
  }

  /// Khi mạng RỚT RỒI CÓ LẠI trong lúc đang lỗi/đang ở chế độ dự phòng, thử
  /// kết nối lại NGAY thay vì đợi watchdog 60s hoặc người dùng tự bấm "Thử lại".
  void _startConnectivityListener() {
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      final hasConnection = results.any((r) => r != ConnectivityResult.none);
      if (!hasConnection) return;

      if (_error != null && !_retrying) {
        _retry();
      } else if (_usingFallbackPoll) {
        // Đang ở chế độ dự phòng (polling) nhưng mạng có vẻ đã ổn lại ->
        // thử nâng cấp lại lên WebSocket cho nhanh/nhẹ hơn.
        _pollTimer?.cancel();
        _connectWebSocket();
      }
    });
  }

  Future<void> _start() async {
    try {
      final audioFile = widget.project.voicedFilename ?? widget.project.musicFilename!;
      final s = GenerationSettings.instance;

      final started = await widget.api.generateMv(
        audioFilename: audioFile,
        styleId: widget.project.styleId!,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        gpuPower: s.gpuPower,
        numInferenceSteps: s.numInferenceSteps,
        guidanceScale: s.guidanceScale,
        resumeJobId: widget.project.mvSceneDirId,
        characterDesc: s.characterDesc,
        enableMotionCamera: s.enableMotionCamera,
        scenePrompts: widget.project.scenePrompts,
        videoBackend: s.videoBackend,
      );

      if (started['status'] == 'error') {
        setState(() => _error = started['note'] as String? ?? 'Không khởi động được job.');
        return;
      }
      widget.project.mvSceneDirId = started['scene_dir_id'] as String?;

      _connectWebSocket();
    } catch (e) {
      setState(() => _error = 'Không khởi động được job tạo MV: $e');
    }
  }

  // ---------- Đường CHÍNH: WebSocket ----------

  void _connectWebSocket() {
    _usingFallbackPoll = false;
    _wsClient = RealtimeClient(
      wsUrl: widget.api.wsUrl,
      onProgress: (p) {
        _resetWatchdog();
        _handleProgressData(p);
      },
      onArtifactInline: (header, bytes) {
        _resetWatchdog();
        final filename = header['filename'] as String;
        _seenArtifacts.add(filename); // để lúc resync (quay lại từ nền) khỏi tải trùng
        _saveAndRegister(bytes, filename, header['kind'] as String);
      },
      onArtifactLink: (header, link) {
        _resetWatchdog();
        final filename = header['filename'] as String;
        _seenArtifacts.add(filename); // để lúc resync (quay lại từ nền) khỏi tải trùng
        _downloadFromLink(link, filename, header['kind'] as String);
      },
      onDisconnected: (_) => _switchToPollingFallback('Kết nối WebSocket bị đóng'),
    );
    _wsClient!.connect();
    _resetWatchdog();
  }

  void _resetWatchdog() {
    _watchdog?.cancel();
    _watchdog = Timer(const Duration(seconds: 60), () {
      // Kết nối WS có thể vẫn "mở" nhưng server không phản hồi gì suốt 60s -
      // coi như treo, tự chuyển dự phòng thay vì đợi vô hạn.
      _switchToPollingFallback('Không nhận được phản hồi từ GPU remote trong 60 giây');
    });
  }

  // ---------- Đường DỰ PHÒNG: HTTP polling ----------

  void _switchToPollingFallback(String reason) {
    if (_usingFallbackPoll) return; // đã ở chế độ dự phòng rồi, khỏi chuyển lại
    _wsClient?.close();
    _watchdog?.cancel();
    _pollFailureStreak = 0;
    if (mounted) setState(() => _usingFallbackPoll = true);
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) => _pollOnce());
  }

  Future<void> _pollOnce() async {
    try {
      final p = await widget.api.getProgress();
      _pollFailureStreak = 0;
      _handleProgressData(p);

      final artifacts = (p['artifacts'] as List?) ?? [];
      for (final raw in artifacts) {
        final a = raw as Map;
        final filename = a['filename'] as String;
        final kind = a['kind'] as String;
        if (_seenArtifacts.contains(filename)) continue;
        _seenArtifacts.add(filename);
        _downloadArtifactViaPollFallback(filename, kind);
      }
    } catch (_) {
      _pollFailureStreak++;
      if (_pollFailureStreak >= 5) {
        _pollTimer?.cancel();
        if (mounted) {
          setState(() {
            _error = 'Mất kết nối với GPU remote (cả WebSocket lẫn HTTP polling đều thất bại) - '
                'Colab có thể đã bị ngắt phiên.\n\n'
                'Đã lưu được $_sceneCount cảnh về máy - không mất trắng dữ liệu. '
                'Mở lại Colab rồi bấm "Thử lại" để TIẾP TỤC từ cảnh còn thiếu.';
          });
        }
      }
    }
  }

  Future<void> _downloadArtifactViaPollFallback(String filename, String kind) async {
    try {
      if (kind == 'final_mv') {
        // File lớn -> không gọi /download/ trực tiếp (dính giới hạn 100MB
        // Cloudflare), lấy link Drive giống hệt đường WebSocket vẫn làm.
        final link = await widget.api.getDriveLink(filename);
        if (link == null) throw Exception('Không lấy được link Drive');
        await _downloadFromLink(link, filename, kind);
      } else {
        final res = await http.get(Uri.parse(widget.api.downloadUrl(filename)));
        if (res.statusCode != 200) throw Exception('Server lỗi ${res.statusCode}');
        await _saveAndRegister(res.bodyBytes, filename, kind);
      }
    } catch (_) {
      _seenArtifacts.remove(filename); // cho phép thử lại ở vòng poll sau
    }
  }

  // ---------- Xử lý chung (dùng cho cả 2 đường) ----------

  void _handleProgressData(Map<String, dynamic> p) {
    if (!mounted) return;
    setState(() {
      _percent = (p['percent'] as num?)?.toInt() ?? _percent;
      _stageDetail = p['detail'] as String? ?? _stageDetail;
    });

    if (p['error'] != null) {
      _wsClient?.close();
      _pollTimer?.cancel();
      setState(() => _error =
          'Lỗi từ server: ${p['error']}\n\nĐã lưu được $_sceneCount cảnh về máy trước khi lỗi.');
      return;
    }

    if (p['cancelled'] == true) {
      _wsClient?.close();
      _pollTimer?.cancel();
      setState(() {
        _cancelled = true;
        _cancelling = false;
      });
      return;
    }

    if (p['done'] == true && widget.project.mvLocalFile != null) {
      _wsClient?.close();
      _pollTimer?.cancel();
      _goToResult();
    }
  }

  Future<void> _downloadFromLink(String link, String filename, String kind) async {
    try {
      final res = await http.get(Uri.parse(link));
      if (res.statusCode != 200) throw Exception('Google Drive trả mã lỗi ${res.statusCode}');
      await _saveAndRegister(res.bodyBytes, filename, kind);
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Tải MV từ Google Drive thất bại: $e\n\n'
              'MV vẫn còn nguyên trên Drive (link: $link) - có thể mở link này bằng trình duyệt để tải thủ công.';
        });
      }
    }
  }

  /// File cảnh nhỏ -> thư mục TẠM (OS tự dọn khi máy thiếu chỗ, tránh phình
  /// dung lượng qua nhiều lần dùng app). File MV CUỐI -> thư mục vĩnh viễn.
  Future<void> _saveAndRegister(List<int> bytes, String filename, String kind) async {
    try {
      final localName = filename.replaceAll('/', '_');
      final dir = kind == 'final_mv'
          ? await getApplicationDocumentsDirectory()
          : await getTemporaryDirectory();
      final file = File('${dir.path}/$localName');
      await file.writeAsBytes(bytes);

      if (kind == 'final_mv') {
        widget.project.mvLocalFile = file;
        widget.project.mvFilename = filename.split('/').last;
        await _trySaveToGallery(file);
        if (mounted) setState(() {});
        _wsClient?.close();
        _pollTimer?.cancel();
        _goToResult();
      } else {
        widget.project.downloadedSceneFiles.add(file.path);
        _sceneCount = widget.project.downloadedSceneFiles.length;
        final idx = _parseSceneIndex(filename);
        if (idx != null) {
          _completedSceneIndices.add(idx);
          _sceneFilePathByIndex[idx] = file.path;
        }
        if (mounted) setState(() {});
      }
    } catch (_) {
      // Lỗi ghi file cục bộ (hiếm) - coi như cảnh chưa có, backend vẫn còn
      // file gốc trên Drive nên resume sau vẫn lấy lại được.
    }
  }

  /// "scenes/{scene_dir_id}/scene_3.mp4" -> 3
  int? _parseSceneIndex(String filename) {
    final match = RegExp(r'scene_(\d+)\.mp4$').firstMatch(filename);
    if (match == null) return null;
    return int.tryParse(match.group(1)!);
  }

  Future<void> _cancelJob() async {
    if (_cancelling || _cancelled || _error != null) return;
    setState(() => _cancelling = true);
    try {
      await widget.api.abortJob();
      // Không set _cancelled ngay ở đây - đợi xác nhận qua progress
      // (p['cancelled']==true) để chắc chắn backend đã thực sự dừng.
    } catch (e) {
      if (mounted) {
        setState(() {
          _cancelling = false;
          _error = 'Không gửi được yêu cầu huỷ: $e';
        });
      }
    }
  }

  /// Lưu MV vào thư viện ảnh (Album/Gallery) công khai của máy bằng package
  /// `gal` - để video xuất hiện trong app Ảnh/Gallery hệ thống, không chỉ nằm
  /// trong thư mục riêng của app. KHÔNG BẮT BUỘC phải thành công: nếu lỗi
  /// (từ chối quyền, thiết bị lạ...) app vẫn hoạt động bình thường qua
  /// mvLocalFile (Mở/Chia sẻ vẫn dùng được), chỉ là MV không tự vào Gallery.
  Future<void> _trySaveToGallery(File file) async {
    try {
      // Lưu vào album riêng 'AI MV Generator' (không phải thư mục Gallery mặc
      // định) -> dùng toAlbum: true cho khớp, đây là tham số THẬT của gal
      // (KHÔNG có tham số `type`/`GalAccessType` - bản trước ghi nhầm, API đó
      // chưa từng tồn tại trong package `gal` ở bất kỳ phiên bản nào).
      final hasAccess = await Gal.hasAccess(toAlbum: true);
      if (!hasAccess) {
        final granted = await Gal.requestAccess(toAlbum: true);
        if (!granted) return;
      }
      await Gal.putVideo(file.path, album: 'AI MV Generator');
      widget.project.savedToGallery = true;
    } catch (_) {
      widget.project.savedToGallery = false;
    }
  }

  void _goToResult() {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => ResultScreen(api: widget.api, project: widget.project)),
    );
  }

  Future<void> _retry() async {
    if (_retrying) return; // chặn bấm nhiều lần liên tiếp trong lúc đang xử lý
    setState(() {
      _retrying = true;
      _error = null;
      _cancelled = false;
      _cancelling = false;
      _usingFallbackPoll = false;
      _percent = 0;
    });
    await _start(); // widget.project.mvSceneDirId vẫn còn -> backend tự resume
    if (mounted) setState(() => _retrying = false);
  }

  @override
  Widget build(BuildContext context) {
    final showCancelButton = _error == null && !_cancelled;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Đang tạo MV'),
        actions: [
          if (showCancelButton)
            TextButton(
              onPressed: _cancelling ? null : _cancelJob,
              child: Text(
                _cancelling ? 'Đang huỷ...' : 'Huỷ',
                style: const TextStyle(color: Colors.white),
              ),
            ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _cancelled
              ? _buildCancelled()
              : _error != null
                  ? _buildError()
                  : _buildProgress(),
        ),
      ),
    );
  }

  Widget _buildStoryboard() {
    final total = widget.project.estimatedSceneCount ?? GenerationSettings.instance.maxScenes;
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: List.generate(total, (i) {
        final done = _completedSceneIndices.contains(i);
        return GestureDetector(
          onTap: done ? () => _previewScene(i) : null,
          child: Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: done ? Colors.green : Colors.grey.shade300,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              done ? Icons.check : null,
              size: 16,
              color: Colors.white,
            ),
          ),
        );
      }),
    );
  }

  /// Mở dialog phát thử video của 1 cảnh đã xong - chỉ tạo 1 VideoPlayerController
  /// tại thời điểm bấm (không tạo sẵn hàng loạt), tránh tốn tài nguyên nếu MV có
  /// nhiều cảnh (đúng tinh thần "chỉ render/khởi tạo cái đang cần xem").
  void _previewScene(int index) {
    final path = _sceneFilePathByIndex[index];
    if (path == null) return;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        child: _ScenePreviewPlayer(filePath: path, title: 'Cảnh ${index + 1}'),
      ),
    );
  }

  Widget _buildProgress() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (_cancelling) ...[
          const Icon(Icons.hourglass_top, color: Colors.orange, size: 32),
          const SizedBox(height: 8),
          const Text(
            'Đang dừng tiến trình trên máy chủ GPU remote...\n'
            'Cảnh đang xử lý dở sẽ hoàn tất trước khi dừng hẳn (vài chục giây).',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 20),
        ],
        SizedBox(
          width: 120,
          height: 120,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CircularProgressIndicator(value: _percent / 100, strokeWidth: 8),
              Text('$_percent%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        Text(_stageDetail, textAlign: TextAlign.center),
        const SizedBox(height: 16),
        _buildStoryboard(),
        const SizedBox(height: 8),
        Text('Đã nhận về máy: $_sceneCount cảnh', style: const TextStyle(color: Colors.grey)),
        if (_usingFallbackPoll) ...[
          const SizedBox(height: 8),
          const Text(
            'Đang dùng chế độ dự phòng (HTTP polling) vì WebSocket gặp sự cố - vẫn tiếp tục bình thường.',
            style: TextStyle(color: Colors.orange, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ],
    );
  }

  Widget _buildError() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.cloud_off, color: Colors.red, size: 48),
        const SizedBox(height: 12),
        Text(_error!, textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _retrying ? null : _retry,
          child: Text(_retrying ? 'Đang thử lại...' : 'Thử lại (tiếp tục từ chỗ dừng)'),
        ),
      ],
    );
  }

  Widget _buildCancelled() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.stop_circle, color: Colors.orange, size: 48),
        const SizedBox(height: 12),
        const Text(
          'Đã huỷ tạo MV theo yêu cầu.\nCác cảnh đã sinh trước đó vẫn còn trên Drive.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text('Đã nhận về máy: $_sceneCount cảnh', style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _retrying ? null : _retry,
          child: Text(_retrying ? 'Đang tiếp tục...' : 'Tiếp tục lại (không mất cảnh đã có)'),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => Navigator.pop(context), // quay lại màn Xem lại để chỉnh công suất/tham số
          child: const Text('Quay lại chỉnh cài đặt'),
        ),
      ],
    );
  }
}

/// Widget riêng cho việc phát 1 cảnh trong dialog xem trước - tách khỏi
/// GeneratingScreen để VideoPlayerController chỉ sống trong vòng đời của
/// dialog (tạo lúc mở, giải phóng lúc đóng), không ảnh hưởng tới state chính.
class _ScenePreviewPlayer extends StatefulWidget {
  final String filePath;
  final String title;

  const _ScenePreviewPlayer({required this.filePath, required this.title});

  @override
  State<_ScenePreviewPlayer> createState() => _ScenePreviewPlayerState();
}

class _ScenePreviewPlayerState extends State<_ScenePreviewPlayer> {
  VideoPlayerController? _controller;
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final controller = VideoPlayerController.file(File(widget.filePath));
      await controller.initialize();
      controller.play();
      controller.setLooping(true);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _ready = true;
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Không phát được cảnh này: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            )
          else if (_ready && _controller != null)
            AspectRatio(
              aspectRatio: _controller!.value.aspectRatio == 0 ? 1 : _controller!.value.aspectRatio,
              child: VideoPlayer(_controller!),
            )
          else
            const Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          const SizedBox(height: 8),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Đóng')),
        ],
      ),
    );
  }
}
