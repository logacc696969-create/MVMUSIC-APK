import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:permission_handler/permission_handler.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../api_service.dart';
import '../eta_format.dart';
import '../backend_busy_tracker.dart';
import '../generation_settings.dart';
import '../job_sync.dart';
import '../project_history.dart';
import '../project_data.dart';
import '../realtime_client.dart';
import 'result_screen.dart';

import '../l10n.dart';
import '../muted_color.dart';
/// Bắt đầu job tạo MV chạy nền trên Colab, ưu tiên nhận dữ liệu qua WebSocket
/// (server chủ động đẩy). Nếu WebSocket lỗi/mất kết nối/im lặng quá lâu
/// (watchdog) -> TỰ ĐỘNG chuyển sang polling GET /progress (không cần người
/// dùng bấm gì) - chỉ khi CẢ HAI đường đều thất bại mới báo lỗi hẳn.
class GeneratingScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const GeneratingScreen({super.key, required this.api, required this.project});

  @override
  State<GeneratingScreen> createState() => _GeneratingScreenState();
}

class _GeneratingScreenState extends State<GeneratingScreen> with WidgetsBindingObserver {
  // id ỔN ĐỊNH cho cả phiên - KHÔNG dùng mvSceneDirId làm id (nó chỉ có SAU
  // khi /generate-mv trả lời lần đầu, và về lý thuyết nếu server đổi hành vi
  // sau này có thể khác đi giữa chừng) - tạo 1 lần, dùng lại cho MỌI lần ghi
  // lịch sử của phiên này, đảm bảo upsert() luôn cập nhật ĐÚNG 1 bản ghi.
  late final String _historyId;
  late final DateTime _historyCreatedAt;
  int _percent = 0;
  String _stageDetail = tr('Đang bắt đầu job trên GPU remote...');
  String? _error;
  bool _retrying = false;
  bool _usingFallbackPoll = false;
  int? _etaSeconds; // MỚI (mục 26) - thời gian còn lại ước tính từ tốc độ % thực tế (backend tính); null = chưa đủ dữ liệu / backend cũ
  String _etaConfidence = 'none';

  RealtimeClient? _wsClient;
  Timer? _watchdog;
  Timer? _heartbeatWatchdog; // MỚI - xem _resetHeartbeatWatchdog
  Timer? _pollTimer;
  int _pollFailureStreak = 0;
  // MỚI (mục 55) - NỐI LẠI WebSocket khi đang ở chế độ dự phòng polling (xem _scheduleReconnect).
  Timer? _reconnectTimer;
  Timer? _probeTimeout;
  RealtimeClient? _probeClient; // kết nối THỬ - polling vẫn chạy song song cho tới khi nó nhận được tin đầu tiên
  int _reconnectAttempt = 0;
  final math.Random _rng = math.Random();
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  ConnectivityResult? _lastConnectivityType; // theo dõi ĐỔI LOẠI mạng (không chỉ mất/có) - xem _startConnectivityListener
  StreamSubscription<Map<String, dynamic>?>? _bgServiceSub;

  final Set<String> _seenArtifacts = {};
  int _sceneCount = 0;
  bool _syncMetaDone = false; // mục 69: đã tải beats.json/nhạc/ảnh tham chiếu về bản sao trên máy chưa (JobSync.mirrorMeta)
  final Set<int> _completedSceneIndices = {}; // cho lưới storyboard
  final Map<int, String> _sceneFilePathByIndex = {}; // để mở xem trước khi tap ô đã xong

  bool _cancelling = false;
  bool _cancelled = false;

  @override
  void initState() {
    super.initState();
    // id ỔN ĐỊNH cho cả phiên - KHÔNG dùng mvSceneDirId làm id (nó chỉ có
    // SAU khi /generate-mv trả lời lần đầu). Ưu tiên dùng lại
    // widget.project.historyId/historyCreatedAt NẾU CÓ (nghĩa là đây là
    // phiên TIẾP TỤC từ 1 dự án đang dang dở, xem HomeScreen) - để
    // _persistHistory cập nhật ĐÚNG bản ghi cũ thay vì tạo bản ghi mới trùng.
    _historyId = widget.project.historyId ?? DateTime.now().microsecondsSinceEpoch.toString();
    _historyCreatedAt = widget.project.historyCreatedAt ?? DateTime.now();
    // MỚI (mục 23) - ghi NGƯỢC về project để lần "tạo lại cảnh" từ ResultScreen cập nhật ĐÚNG
    // bản ghi lịch sử này thay vì tạo thêm 1 bản ghi trùng cho cùng 1 dự án.
    widget.project.historyId ??= _historyId;
    widget.project.historyCreatedAt ??= _historyCreatedAt;
    WakelockPlus.enable(); // job dài vài phút -> giữ màn hình sáng, tránh Android ngủ app làm đứt WS
    WidgetsBinding.instance.addObserver(this); // để bắt lúc app quay lại foreground, xem _resyncAfterResume
    _startConnectivityListener();
    _startBackgroundService();
    _start();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    WidgetsBinding.instance.removeObserver(this);
    _bgServiceSub?.cancel();
    FlutterBackgroundService().invoke('stopService'); // tắt thông báo nền, không cần chạy tiếp nữa
    _wsClient?.close();
    _watchdog?.cancel();
    _heartbeatWatchdog?.cancel();
    _pollTimer?.cancel();
    _cancelReconnect(); // MỚI (mục 55)
    _connectivitySub?.cancel();
    super.dispose();
  }

  /// Bật Foreground Service THẬT của Android (xem background_service.dart) -
  /// giữ 1 thông báo hiện % trực tiếp trên thanh trạng thái, tự cập nhật dù
  /// màn hình khoá hay chuyển sang app khác - không chỉ trông chờ mỗi
  /// WakelockPlus (chỉ chống tắt màn hình, không đảm bảo Dart isolate chạy
  /// tiếp lúc thật sự ở nền).
  Future<void> _startBackgroundService() async {
    await _requestIgnoreBatteryOptimizations(); // MỚI - xem docstring bên dưới
    final bg = FlutterBackgroundService();
    await bg.startService();
    bg.invoke('setEndpoint', {'progressUrl': '${widget.api.baseUrl}/progress'});
    _bgServiceSub = bg.on('update').listen((event) {
      if (event == null) return;
      _handleProgressData(Map<String, dynamic>.from(event));
    });
  }

  /// "Android Doze Mode Bypass" - xin miễn trừ tối ưu hoá pin, để Foreground
  /// Service (đã bật ở `background_service.dart`) ổn định hơn trên các hãng
  /// máy có trình quản lý pin RIÊNG khắt khe hơn chuẩn Android gốc
  /// (Samsung/Xiaomi...).
  ///
  /// AN TOÀN NGƯỢC: chỉ hiện popup hệ thống hỏi người dùng (không tự động
  /// bật) - người dùng có thể bấm "Không cho phép" mà KHÔNG ảnh hưởng tới
  /// việc tạo MV (chỉ giảm độ ổn định khi màn hình tắt lâu, không chặn
  /// job). Bọc try/catch - lỗi ở bước TUỲ CHỌN này không được cản trở việc
  /// bắt đầu tạo MV.
  ///
  /// LỊCH SỬ (đổi cách làm 2 LẦN, ghi lại để không thử lại đường cũ đã biết
  /// sai): (1) ban đầu định dùng `permission_handler` nhưng không xác nhận
  /// chắc tên hằng số API nên đã đổi hướng. (2) đổi sang `android_intent_plus`
  /// tự dựng Intent với action string thô của Android - NHƯNG hardcode
  /// `data: 'package:ai_mv_generator'` SAI so với applicationId THẬT
  /// (`com.example.ai_mv_generator`, suy ra từ `flutter create --project-name
  /// ai_mv_generator .` trong build.yml KHÔNG có cờ `--org` nên dùng org mặc
  /// định "com.example" - đã tra cứu xác nhận qua nhiều nguồn độc lập). Lỗi
  /// này xác định được qua đọc code + tài liệu, không cần chạy máy thật. (3)
  /// ĐANG DÙNG (lượt audit sau 7zc8): quay lại `permission_handler`
  /// (`Permission.ignoreBatteryOptimizations`) - lần này KHÔNG còn nghi ngờ
  /// tên API (đã xác nhận qua tài liệu chính thức pub.dev) - tự lấy
  /// applicationId qua context Android runtime, không cần biết trước chuỗi
  /// package name nào, tránh hẳn lớp lỗi hardcode ở bước (2).
  ///
  /// VẪN CHƯA CHẠY THỬ THẬT trên điện thoại - nên kiểm tra popup xin quyền
  /// có hiện đúng không sau khi cài APK mới.
  Future<void> _requestIgnoreBatteryOptimizations() async {
    try {
      final status = await Permission.ignoreBatteryOptimizations.status;
      if (!status.isGranted) {
        await Permission.ignoreBatteryOptimizations.request();
      }
    } catch (exc) {
      print('[_requestIgnoreBatteryOptimizations] Bỏ qua (lỗi hoặc không phải Android): $exc');
    }
  }

  /// Dù đã có Foreground Service (_startBackgroundService) giữ % cập nhật lúc
  /// ở nền, service đó KHÔNG tự tải file cảnh/MV về máy - nên vẫn cần đồng bộ
  /// lại đầy đủ (kèm tải bù artifact) NGAY khi app quay lại foreground, thay
  /// vì đợi watchdog 60s hoặc người dùng tự bấm "Thử lại".
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _resyncAfterResume();
    }
  }

  Future<void> _resyncAfterResume() async {
    if (!mounted || _error != null || _cancelled || _cancelling) return;
    try {
      final p = await widget.api.getProgress();
      _handleProgressData(p);

      final artifacts = (p['artifacts'] as List?) ?? [];
      for (final raw in artifacts) {
        final a = raw as Map;
        final filename = a['filename'] as String;
        final kind = a['kind'] as String;
        if (_seenArtifacts.contains(filename)) continue;
        _seenArtifacts.add(filename);
        await _downloadArtifactViaPollFallback(filename, kind);
      }

      // WebSocket có thể đã chết lặng lẽ trong lúc app ở nền mà không kịp gọi
      // onDisconnected -> chủ động chuyển dự phòng polling để chắc chắn vẫn
      // tiếp tục nhận cập nhật, thay vì trông chờ 1 kết nối có thể đã hỏng.
      if (!_usingFallbackPoll) {
        _switchToPollingFallback('Đồng bộ lại sau khi app quay lại từ nền');
      }
    } catch (_) {
      // Lỗi tạm thời lúc resync (mạng chưa kịp có) - timer định kỳ sẽ tự thử
      // lại sau, không cần xử lý gì thêm ở đây.
    }
  }

  /// Khi mạng RỚT RỒI CÓ LẠI trong lúc đang lỗi/đang ở chế độ dự phòng, thử
  /// kết nối lại NGAY thay vì đợi watchdog 60s hoặc người dùng tự bấm "Thử lại".
  void _startConnectivityListener() {
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      final hasConnection = results.any((r) => r != ConnectivityResult.none);
      // MỚI - phát hiện CHUYỂN LOẠI mạng (vd WiFi -> Mobile Data khi ra khỏi
      // nhà) - TRƯỚC ĐÂY chỉ xử lý 2 chiều "mất mạng"/"có mạng lại", không
      // xử lý chiều "vẫn có mạng nhưng đổi loại" - trường hợp này WebSocket
      // cũ thường rơi vào trạng thái "treo" (vẫn tưởng đang mở ở tầng Dart,
      // nhưng gói tin không còn tới do đổi hẳn đường truyền vật lý) - phải
      // đợi hết 60s watchdog mới tự chuyển dự phòng, trải nghiệm bị khựng
      // 1 khoảng không cần thiết. Chủ động chuyển ngay dự phòng (polling)
      // nếu phát hiện đổi loại mạng trong lúc đang dùng WebSocket - nhánh
      // "có mạng lại" bên dưới đã tự nâng cấp lại lên WebSocket khi ổn định.
      final currentType = hasConnection ? results.firstWhere((r) => r != ConnectivityResult.none) : null;
      final typeChanged = hasConnection &&
          _lastConnectivityType != null &&
          _lastConnectivityType != currentType &&
          !_usingFallbackPoll;
      _lastConnectivityType = currentType;
      if (typeChanged) {
        _switchToPollingFallback('Phát hiện đổi loại kết nối mạng (vd WiFi <-> 4G/5G)');
        return;
      }

      if (!hasConnection) return;

      if (_error != null && !_retrying) {
        _retry();
      } else if (_usingFallbackPoll) {
        // Đang ở chế độ dự phòng (polling) nhưng mạng có vẻ đã ổn lại ->
        // thử nâng cấp lại lên WebSocket cho nhanh/nhẹ hơn.
        _pollTimer?.cancel();
        _connectWebSocket();
      }
    });
  }

  Future<void> _start() async {
    // MỚI - báo bận NGAY khi bắt đầu thử tạo job (trước cả khi biết server có
    // nhận hay không) - nếu bị từ chối/lỗi ngay thì clear lại free bên dưới.
    BackendBusyTracker.markBusy(tr('Đang tạo MV...'));
    try {
      final audioFile = widget.project.voicedFilename ?? widget.project.musicFilename!;
      final s = GenerationSettings.instance;
      // MỚI (mục 27) - chế độ XEM TRƯỚC: chỉ N cảnh đầu; danh sách theo-cảnh (kịch bản, camera, cảnh tự quay) cắt đúng N phần tử vì backend BỎ QUA
      // danh sách có độ dài lệch số cảnh; không resume và không làm lại cảnh (đây là lần chạy thử mới tinh).
      final preview = widget.project.previewMaxScenes;

      // MỚI (mục 69) - tiếp tục job trên backend có thể là MỚI (đổi tài khoản Colab/GPU, Drive trống): đẩy lại cảnh/beats/nhạc/ảnh đã lưu trên máy mà backend còn thiếu
      // (backend không ghi đè tệp có sẵn nên an toàn cả khi backend cũ). Lỗi được nuốt trong JobSync - không bao giờ chặn việc tạo MV.
      final resumeId = widget.project.mvSceneDirId;
      if (preview == null && resumeId != null) {
        final pushed = await JobSync.restoreToBackend(widget.api, resumeId, JobSync.extrasFor(widget.project));
        if (pushed > 0 && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(trv('Đã đẩy lại {0} tệp đã lưu trên máy lên backend để tiếp tục từ chỗ dừng.', [pushed]))),
          );
        }
      }
      // clip tự quay / ảnh tham chiếu / giọng: backend mới (Drive trống, /content mới) thiếu thì đẩy lại từ bản sao trong app (backend không ghi đè tệp có sẵn)
      if (preview == null) await JobSync.restoreAssets(widget.api);
      unawaited(JobSync.prune());

      final started = await widget.api.generateMv(
        audioFilename: audioFile,
        styleId: widget.project.styleId!,
        beatsPerScene: s.beatsPerScene,
        maxScenes: preview ?? s.maxScenes,
        gpuPower: s.gpuPower,
        numInferenceSteps: s.numInferenceSteps,
        guidanceScale: s.guidanceScale,
        resumeJobId: preview != null ? null : widget.project.mvSceneDirId,
        characterDesc: s.characterDesc,
        enableMotionCamera: s.enableMotionCamera,
        scenePrompts: preview != null ? widget.project.scenePrompts?.take(preview).toList() : widget.project.scenePrompts,
        videoBackend: s.videoBackend,
        // MỚI (mục 7zc2) - nối 2 mắt xích còn thiếu: ảnh tham chiếu đã xác
        // nhận qua CharacterReferenceScreen (null nếu bỏ qua bước đó - backend
        // tự sinh ảnh mới như hành vi CŨ) + công tắc Lipsync (backend tự bỏ
        // qua nếu styleId không hỗ trợ, xem style_screen.dart).
        characterReferenceFilename: widget.project.confirmedCharacterReferenceFilename,
        enableLipsync: s.enableLipsync,
        lipsyncBackend: s.lipsyncBackend,
        lyrics: widget.project.lyrics,
        enableSceneContinuity: s.enableSceneContinuity,
        enableColorMatch: s.enableColorMatch,
        enableSpeedRamping: s.enableSpeedRamping,
        enablePostFx: s.enablePostFx,
        postFxIntensity: s.postFxIntensity,
        enableMotionSmoothing: s.enableMotionSmoothing,
        motionSmoothingMethod: s.motionSmoothingMethod,
        enableRealesrganUpscale: s.enableRealesrganUpscale,
        exportVertical: s.exportVertical,
        redoScenes: preview != null ? '' : widget.project.redoScenes,
        redoFollowing: preview != null ? false : widget.project.redoFollowing,
        sceneCameras: preview != null ? widget.project.sceneCameras?.take(preview).toList() : widget.project.sceneCameras,
        sceneFramings: preview != null ? widget.project.sceneFramings?.take(preview).toList() : widget.project.sceneFramings,
        burnInLyrics: s.burnInLyrics,
        structureSnap: s.structureSnap,
        watermarkText: s.watermarkText,
        fxMotionBlur: s.fxMotionBlur,
        fxLightLeak: s.fxLightLeak,
        fxBloom: s.fxBloom,
        exportPreset: s.exportPreset,
        colorLook: s.colorLook,
        upscaleFaceMode: s.upscaleFaceMode,
        settingDesc: s.settingDesc,
        userClips: preview != null
            ? <int, String>{for (final e in widget.project.userClips.entries) if (e.key < preview) e.key: e.value}
            : widget.project.userClips,
        sceneReferenceImages: preview != null
            ? <int, String>{for (final e in widget.project.sceneRefs.entries) if (e.key < preview) e.key: e.value}
            : widget.project.sceneRefs,
        controlVideoFilename: s.controlVideoFilename,
        lorasJson: s.lorasJson,
        comfyWorkflow: s.comfyWorkflow,
        hmacSecret: s.hmacSecret,
      );

      if (started['status'] == 'error') {
        BackendBusyTracker.markFree(); // job KHÔNG được backend nhận -> không có gì đang chạy để giữ cờ bận
        if (!mounted) return;
        setState(() => _error = started['note'] as String? ?? tr('Không khởi động được job.'));
        return;
      }
      // QUAN TRỌNG: từ đây job ĐÃ bắt đầu chạy THẬT ở backend (status khác
      // 'error') - nếu widget đã unmounted (người dùng rời màn hình đúng lúc
      // đang chờ response), KHÔNG được gọi `BackendBusyTracker.markFree()`
      // dù không còn UI nào theo dõi tiếp, vì backend VẪN đang thực sự bận
      // xử lý GPU cho job này - markFree() ở đây sẽ làm sai trạng thái "GPU
      // đang bận" hiển thị ở HomeScreen trong khi job vẫn đang chạy thật.
      widget.project.mvSceneDirId = started['scene_dir_id'] as String?;
      // MỚI (mục 23) - job ĐÃ nhận: xoá yêu cầu "tạo lại cảnh" để lần tự thử lại (nếu có) không xoá
      // luôn các cảnh vừa tạo xong.
      widget.project.redoScenes = '';
      widget.project.redoFollowing = false;
      await _persistHistory('in_progress'); // NGAY khi biết mvSceneDirId - đây là ĐIỂM SỚM NHẤT có đủ thông tin để tiếp tục job nếu app bị đóng hẳn từ đây trở đi (khác bản cũ - CHỈ lưu lúc đã XONG, xem project_history.dart)
      if (!mounted) return; // job vẫn chạy ở backend - chỉ dừng theo dõi ở PHÍA APP, không markFree()

      _connectWebSocket();
    } catch (e) {
      // SỬA (lượt audit sau 7zc17/7zc18/7zc19) - LÚC ĐẦU chỉ dừng ở mức
      // "xác minh rồi vẫn báo lỗi cho người dùng dù job có thể đang chạy
      // thật" (markFreeAfterVerify). Đã xét lại: đây KHÔNG phải 1 tính năng
      // mới nằm ngoài phạm vi, mà là hoàn thiện ĐÚNG cùng 1 lỗi - phần việc
      // còn thiếu là "join" lại job đang chạy thay vì chỉ sửa đúng 1 cờ nội
      // bộ trong khi UI vẫn nói sai với người dùng.
      //
      // exception ở đây (network timeout, connection refused...) KHÔNG
      // chứng minh được request CHƯA TỚI server - request CÓ THỂ đã tới và
      // server ĐÃ bắt đầu job thật, chỉ RESPONSE trên đường về bị mất (tình
      // huống at-most-once/at-least-once kinh điển của HTTP). Gọi
      // `GET /progress` MỘT LẦN để vừa XÁC MINH vừa LẤY LUÔN `job_id` cần
      // thiết để tiếp tục theo dõi (tránh gọi API 2 lần cho 2 việc riêng).
      //
      // `_connectWebSocket()` không cần biết trước job_id cụ thể nào - server
      // (theo `progress_tracker.py`) chỉ theo dõi ĐÚNG 1 job tại 1 thời điểm,
      // nên kết nối lại là ĐỦ để tự nhận đúng tiến trình của job đang chạy -
      // "reconnect" ở đây đơn giản hơn nhiều so với 1 tính năng mới thật sự.
      Map<String, dynamic>? p;
      try {
        p = await widget.api.getProgress();
      } catch (_) {
        p = null; // verify cũng lỗi (mất mạng hoàn toàn) - rơi xuống xử lý lỗi bên dưới, không còn cách nào chắc chắn hơn
      }

      // LƯU Ý null-safety: điều kiện `p != null` PHẢI nằm TRỰC TIẾP trong
      // câu lệnh `if` này (nối bằng `&&`), KHÔNG được tách qua 1 biến `bool`
      // trung gian - Dart chỉ tự "promote" `p` thành non-null bên trong khối
      // `if` khi kiểm tra null nằm ngay trong chính điều kiện đó (áp dụng cho
      // biến cục bộ). Tách qua biến trung gian sẽ mất promotion, gây lỗi
      // biên dịch "receiver can be null" ở mọi chỗ dùng `p['...']` bên dưới.
      if (p != null && (p['stage'] as String? ?? 'idle') != 'idle' && p['done'] != true) {
        // Job THẬT SỰ đang chạy ở backend dù request khởi động báo lỗi -
        // coi như khởi động THÀNH CÔNG, tiếp tục đúng luồng bình thường
        // thay vì báo lỗi sai cho người dùng.
        widget.project.mvSceneDirId = p['job_id'] as String?;
        await _persistHistory('in_progress');
        if (!mounted) return; // job vẫn chạy ở backend - chỉ dừng theo dõi ở PHÍA APP, không markFree() (cờ đã đúng "busy" từ đầu hàm, không cần set lại)
        BackendBusyTracker.markBusy(tr('Đang tạo MV...')); // đảm bảo cờ đúng (phòng trường hợp có nơi khác lỡ markFree() giữa chừng)
        _connectWebSocket();
        return;
      }

      // Job THẬT SỰ không chạy (verify xác nhận stage=='idle'/done==true,
      // hoặc verify chính nó cũng lỗi - mất mạng hoàn toàn) - markFree() an
      // toàn, báo lỗi cho người dùng như bình thường.
      BackendBusyTracker.markFree();
      if (!mounted) return;
      setState(() => _error = trv('Không khởi động được job tạo MV: {0}', [e]));
    }
  }

  /// Lưu (hoặc cập nhật) 1 bản ghi lịch sử - gọi ở NHIỀU thời điểm trong
  /// vòng đời job (bắt đầu/lỗi/huỷ/xong), KHÔNG CHỈ lúc xong như bản cũ - xem
  /// ghi chú đầu file `project_history.dart` để biết lý do đây là sửa THẬT
  /// cho khả năng "tiếp tục sau khi app bị đóng hẳn", không chỉ chạy nền.
  Future<void> _persistHistory(String status) async {
    final s = GenerationSettings.instance;
    try {
      await ProjectHistoryStore.upsert(ProjectHistoryEntry(
        id: _historyId,
        createdAt: _historyCreatedAt,
        updatedAt: DateTime.now(),
        status: status,
        fromSample: widget.project.fromSample,
        musicFilename: widget.project.musicFilename,
        voicedFilename: widget.project.voicedFilename,
        styleId: widget.project.styleId,
        genre: s.genre,
        videoBackend: s.videoBackend,
        characterDesc: s.characterDesc,
        lyrics: widget.project.lyrics,
        estimatedSceneCount: widget.project.estimatedSceneCount,
        scenePrompts: widget.project.scenePrompts,
        mvSceneDirId: widget.project.mvSceneDirId,
        mvFilename: widget.project.mvFilename,
        mvLocalPath: widget.project.mvLocalFile?.path,
        characterReferenceImagePath: widget.project.characterReferenceImagePath,
        // MỚI - 3 field trước đây bị bỏ sót khi lưu lịch sử (xem CHANGELOG
        // mục 11 + 15) - cùng cách lấy giá trị như mvLocalPath/
        // characterReferenceImagePath ở trên (đọc thẳng từ widget.project,
        // null nếu job chưa sinh/tính năng tắt - hoàn toàn bình thường).
        lyricsTimestampsPath: widget.project.lyricsTimestampsPath,
        thumbnailImagePath: widget.project.thumbnailImagePath,
        mvVerticalLocalPath: widget.project.mvVerticalLocalFile?.path,
        downloadedSceneFiles: widget.project.downloadedSceneFiles,
      ));
    } catch (_) {
      // Lỗi lưu lịch sử KHÔNG được làm gián đoạn job đang chạy - bỏ qua lặng lẽ, thử lại ở lần cập nhật tiếp theo.
    }
  }

  // ---------- Đường CHÍNH: WebSocket ----------

  void _connectWebSocket() {
    _cancelReconnect(); // MỚI (mục 55) - đường nâng cấp khác (đổi mạng/Thử lại) đã chiếm quyền: bỏ lần nối lại đang hẹn
    _usingFallbackPoll = false;
    _wsClient = RealtimeClient(
      wsUrl: widget.api.wsUrl,
      onProgress: (p) {
        _resetWatchdog();
        _handleProgressData(p);
      },
      onArtifactInline: (header, bytes) {
        _resetWatchdog();
        final filename = header['filename'] as String;
        _seenArtifacts.add(filename); // để lúc resync (quay lại từ nền) khỏi tải trùng
        _saveAndRegister(bytes, filename, header['kind'] as String);
      },
      onArtifactLink: (header, link) {
        _resetWatchdog();
        final filename = header['filename'] as String;
        _seenArtifacts.add(filename); // để lúc resync (quay lại từ nền) khỏi tải trùng
        _downloadFromLink(link, filename, header['kind'] as String);
      },
      onDisconnected: (_) => _switchToPollingFallback('Kết nối WebSocket bị đóng'),
      onHeartbeat: _resetHeartbeatWatchdog, // MỚI - xem _resetHeartbeatWatchdog bên dưới
    );
    _wsClient!.connect();
    _resetWatchdog();
    _resetHeartbeatWatchdog();
  }

  void _resetWatchdog() {
    _watchdog?.cancel();
    _watchdog = Timer(const Duration(seconds: 60), () {
      // Kết nối WS có thể vẫn "mở" nhưng server không phản hồi gì suốt 60s -
      // coi như treo, tự chuyển dự phòng thay vì đợi vô hạn.
      _switchToPollingFallback('Không nhận được phản hồi từ GPU remote trong 60 giây');
    });
  }

  // MỚI - "Heartbeat WebSocket tần suất cao" (BỔ SUNG cho watchdog 60s ở
  // trên, KHÔNG THAY THẾ): watchdog 60s reset MỖI KHI có tiến trình/artifact
  // thật - nhưng trong lúc chạy các bước KHÔNG có cập nhật tiến trình liên
  // tục (vd train giọng RVC 20-30 phút chỉ báo % thỉnh thoảng), 60s có thể
  // KHÔNG đủ để phát hiện mạng chập chờn giữa chừng (không phải do job vẫn
  // chạy, mà do đường truyền thực sự đã đứt). Ping/pong 5s/12s ở đây phát
  // hiện SỚM HƠN nhiều, không phụ thuộc job có đang phát tiến trình hay
  // không - vì server gửi ping ĐỀU ĐẶN bất kể job đang ở bước nào.
  void _resetHeartbeatWatchdog() {
    _heartbeatWatchdog?.cancel();
    _heartbeatWatchdog = Timer(const Duration(seconds: 12), () {
      _switchToPollingFallback('Heartbeat timeout - không nhận được tín hiệu ping từ server trong 12 giây');
    });
  }

  // ---------- Đường DỰ PHÒNG: HTTP polling ----------

  void _switchToPollingFallback(String reason) {
    if (_usingFallbackPoll) return; // đã ở chế độ dự phòng rồi, khỏi chuyển lại
    _wsClient?.close();
    _watchdog?.cancel();
    _heartbeatWatchdog?.cancel();
    _pollFailureStreak = 0;
    if (mounted) setState(() => _usingFallbackPoll = true);
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) => _pollOnce());
    _reconnectAttempt = 0; // MỚI (mục 55) - đợt rớt kết nối mới: đếm lại từ đầu
    _scheduleReconnect();
  }

  // ---------- MỚI (mục 55): NỐI LẠI WebSocket trong lúc vẫn polling ----------
  //
  // TRƯỚC ĐÂY: rớt WebSocket -> chuyển polling 2 giây/lần và KHÔNG BAO GIỜ dựng lại WebSocket trừ khi hệ điều hành báo đổi mạng (tin đẩy chủ động chỉ còn ở đầu job).
  // PDF-1 nêu kỹ thuật chuẩn: client tự nối lại với lùi theo cấp số nhân + nhiễu ngẫu nhiên (`reconnectDelay`, tối đa `kMaxReconnectAttempts` lần).
  // THIẾT KẾ "nối trước, ngắt sau": polling KHÔNG dừng cho tới khi kết nối thử nhận được tin ĐẦU TIÊN (ping 5 giây hoặc tiến trình) - nên không có khoảng trống không nhận
  // tin (khác đường nâng cấp khi đổi mạng: nó dừng polling TRƯỚC rồi mới nối, hở tối đa ~12 giây nếu nối hỏng). Lần thử thất bại/quá 10 giây im lặng -> đóng và hẹn lần sau.
  // Artifact nhận qua kết nối thử được lọc qua `_seenArtifacts` để không tải trùng với polling.
  // CHƯA biên dịch/chạy thật.

  bool _reconnectAllowed() =>
      mounted && _usingFallbackPoll && _error == null && !_cancelled && !_cancelling && widget.project.mvLocalFile == null;

  void _cancelReconnect() {
    _reconnectTimer?.cancel();
    _probeTimeout?.cancel();
    final probe = _probeClient;
    _probeClient = null; // gán null TRƯỚC khi đóng để onDisconnected của lần thử này biết mình đã bị huỷ
    probe?.close();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    if (!_reconnectAllowed() || _reconnectAttempt >= kMaxReconnectAttempts) return;
    _reconnectTimer = Timer(reconnectDelay(_reconnectAttempt, _rng.nextDouble()), _tryReconnectProbe);
  }

  void _tryReconnectProbe() {
    if (!_reconnectAllowed()) return;
    _reconnectAttempt++;
    _probeTimeout?.cancel();
    final previous = _probeClient;
    _probeClient = null;
    previous?.close();

    var active = false; // true = kết nối thử đã nhận tin đầu tiên và được nâng làm kết nối CHÍNH
    late final RealtimeClient probe;

    void promote() {
      if (active) return;
      if (!_reconnectAllowed() || !identical(_probeClient, probe)) {
        probe.close(); // trong lúc chờ, tình huống đã đổi (lỗi/huỷ/đã có đường khác) -> bỏ kết nối thử
        return;
      }
      active = true;
      _probeTimeout?.cancel();
      _pollTimer?.cancel(); // chỉ DỪNG polling ở đây - SAU KHI đã chắc chắn có tin qua WebSocket
      _wsClient?.close();
      _wsClient = probe;
      _probeClient = null;
      _reconnectAttempt = 0;
      if (mounted) setState(() => _usingFallbackPoll = false);
      _resetWatchdog();
      _resetHeartbeatWatchdog();
    }

    probe = RealtimeClient(
      wsUrl: widget.api.wsUrl,
      onProgress: (p) {
        promote();
        if (!active) return;
        _resetWatchdog();
        _handleProgressData(p);
      },
      onArtifactInline: (header, bytes) {
        promote();
        if (!active) return;
        _resetWatchdog();
        final filename = header['filename'] as String;
        if (_seenArtifacts.contains(filename)) return; // polling đã nhận/đang tải file này
        _seenArtifacts.add(filename);
        _saveAndRegister(bytes, filename, header['kind'] as String);
      },
      onArtifactLink: (header, link) {
        promote();
        if (!active) return;
        _resetWatchdog();
        final filename = header['filename'] as String;
        if (_seenArtifacts.contains(filename)) return;
        _seenArtifacts.add(filename);
        _downloadFromLink(link, filename, header['kind'] as String);
      },
      onDisconnected: (_) {
        if (active) {
          _switchToPollingFallback('Kết nối WebSocket (đã nối lại) bị đóng');
          return;
        }
        if (!identical(_probeClient, probe)) return; // lần thử này đã bị huỷ/thay thế - không hẹn thêm
        _probeClient = null;
        _probeTimeout?.cancel();
        _scheduleReconnect(); // lần thử hỏng -> hẹn lần sau (lùi dần)
      },
      onHeartbeat: () {
        promote();
        if (active) _resetHeartbeatWatchdog();
      },
    );
    _probeClient = probe;
    try {
      probe.connect();
    } catch (_) {
      _probeClient = null;
      _scheduleReconnect();
      return;
    }
    _probeTimeout = Timer(const Duration(seconds: 10), () {
      if (active || !identical(_probeClient, probe)) return;
      _probeClient = null;
      probe.close();
      _scheduleReconnect();
    });
  }

  Future<void> _pollOnce() async {
    try {
      final p = await widget.api.getProgress();
      _pollFailureStreak = 0;
      _handleProgressData(p);

      final artifacts = (p['artifacts'] as List?) ?? [];
      for (final raw in artifacts) {
        final a = raw as Map;
        final filename = a['filename'] as String;
        final kind = a['kind'] as String;
        if (_seenArtifacts.contains(filename)) continue;
        _seenArtifacts.add(filename);
        _downloadArtifactViaPollFallback(filename, kind);
      }
    } catch (_) {
      _pollFailureStreak++;
      if (_pollFailureStreak >= 5) {
        _pollTimer?.cancel();
        if (mounted) {
          setState(() {
            _error = trv('Mất kết nối với GPU remote (cả WebSocket lẫn HTTP polling đều thất bại) - '
                'Colab có thể đã bị ngắt phiên.\n\n'
                'Đã lưu được {0} cảnh về máy - không mất trắng dữ liệu. '
                'Mở lại Colab rồi bấm "Thử lại" để TIẾP TỤC từ cảnh còn thiếu.', [_sceneCount]);
          });
        }
      }
    }
  }

  Future<void> _downloadArtifactViaPollFallback(String filename, String kind) async {
    try {
      if (kind == 'final_mv' || kind == 'final_mv_vertical') {
        // File lớn (bản ngang HOẶC bản dọc MỚI - xem post_processing_v2.
        // export_vertical_crop, backend đã đổi điều kiện tương ứng ở
        // _broadcast_artifact_async) -> không gọi /download/ trực tiếp (dính
        // giới hạn 100MB Cloudflare), lấy link Drive giống hệt đường
        // WebSocket vẫn làm.
        final link = await widget.api.getDriveLink(filename);
        if (link == null) throw Exception('Không lấy được link Drive');
        await _downloadFromLink(link, filename, kind);
      } else {
        final res = await http.get(Uri.parse(widget.api.downloadUrl(filename)));
        if (res.statusCode != 200) throw Exception(trv('Server lỗi {0}', [res.statusCode]));
        await _saveAndRegister(res.bodyBytes, filename, kind);
      }
    } catch (_) {
      _seenArtifacts.remove(filename); // cho phép thử lại ở vòng poll sau
    }
  }

  // ---------- Xử lý chung (dùng cho cả 2 đường) ----------

  void _handleProgressData(Map<String, dynamic> p) {
    if (!mounted) return;
    setState(() {
      _percent = (p['percent'] as num?)?.toInt() ?? _percent;
      _stageDetail = p['detail'] as String? ?? _stageDetail;
      _etaSeconds = (p['eta_seconds'] as num?)?.toInt();
      _etaConfidence = p['eta_confidence'] as String? ?? 'none';
    });

    if (p['error'] != null) {
      _wsClient?.close();
      _pollTimer?.cancel();
      setState(() => _error =
          trv('Lỗi từ server: {0}\n\nĐã lưu được {1} cảnh về máy trước khi lỗi.', [p['error'], _sceneCount]));
      BackendBusyTracker.markFree(); // backend đã tự báo lỗi -> job THẬT SỰ đã dừng, không còn giữ GPU nữa
      _persistHistory('failed'); // vẫn giữ nguyên mvSceneDirId - các cảnh đã xong không mất, người dùng có thể mở lại từ History và bấm "Tiếp tục" thủ công dù trạng thái ghi "failed"
      return;
    }

    if (p['cancelled'] == true) {
      _wsClient?.close();
      _pollTimer?.cancel();
      setState(() {
        _cancelled = true;
        _cancelling = false;
      });
      BackendBusyTracker.markFree(); // backend xác nhận đã huỷ xong -> hết bận GPU
      _persistHistory('cancelled');
      return;
    }

    if (p['done'] == true && widget.project.mvLocalFile != null) {
      _wsClient?.close();
      _pollTimer?.cancel();
      _goToResult();
    }
  }

  Future<void> _downloadFromLink(String link, String filename, String kind) async {
    try {
      final res = await http.get(Uri.parse(link));
      if (res.statusCode != 200) throw Exception(trv('Google Drive trả mã lỗi {0}', [res.statusCode]));
      await _saveAndRegister(res.bodyBytes, filename, kind);
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = trv('Tải MV từ Google Drive thất bại: {0}\n\n'
              'MV vẫn còn nguyên trên Drive (link: {1}) - có thể mở link này bằng trình duyệt để tải thủ công.', [e, link]);
        });
      }
      // Backend đã báo done=true (job THẬT SỰ đã xong ở phía Colab) trước khi
      // gửi link Drive này - lỗi ở đây chỉ là lỗi TẢI VỀ MÁY cục bộ, không
      // phải job còn chạy - vẫn an toàn để hết bận GPU.
      BackendBusyTracker.markFree();
    }
  }

  /// File cảnh nhỏ -> thư mục TẠM (OS tự dọn khi máy thiếu chỗ, tránh phình
  /// dung lượng qua nhiều lần dùng app). File MV CUỐI -> thư mục vĩnh viễn.
  Future<void> _saveAndRegister(List<int> bytes, String filename, String kind) async {
    try {
      final localName = filename.replaceAll('/', '_');
      // MỚI - "final_mv_vertical" cũng là kết quả CUỐI CÙNG (không phải file
      // tạm) như "final_mv" - lưu vào thư mục vĩnh viễn, không phải thư mục
      // tạm (OS có thể tự xoá bất kỳ lúc nào).
      final dir = (kind == 'final_mv' || kind == 'final_mv_vertical')
          ? await getApplicationDocumentsDirectory()
          : await getTemporaryDirectory();
      final file = File('${dir.path}/$localName');
      await file.writeAsBytes(bytes);

      // MỚI (mục 69) - giữ bản sao CẢNH trong thư mục vĩnh viễn của app (thư mục tạm bị OS dọn và bị xoá khi MV xong) để tiếp tục được cả khi đổi tài khoản/GPU;
      // lần đầu cũng tải về beats.json + nhạc + ảnh tham chiếu (nhỏ) từ backend khi nó còn sống.
      final syncJob = widget.project.mvSceneDirId;
      if (kind != 'final_mv' && kind != 'final_mv_vertical' && syncJob != null && filename.startsWith('scenes/')) {
        unawaited(JobSync.keep(syncJob, filename, bytes));
        if (!_syncMetaDone) {
          _syncMetaDone = true;
          unawaited(JobSync.mirrorMeta(widget.api, syncJob, JobSync.extrasFor(widget.project)));
        }
      }

      if (kind == 'final_mv') {
        widget.project.mvLocalFile = file;
        widget.project.mvFilename = filename.split('/').last;
        await _trySaveToGallery(file);
        // MV cuối đã lưu xong vào thư mục vĩnh viễn -> các mảnh cảnh .mp4 tạm
        // của CHÍNH job này không còn cần giữ nữa, dọn ngay để đỡ tích rác.
        unawaited(ProjectData.purgeTemporaryScenes());
        BackendBusyTracker.markFree(); // job đã thật sự xong (thành công) -> hết bận GPU
        if (mounted) setState(() {});
        _wsClient?.close();
        _pollTimer?.cancel();
        _goToResult();
      } else if (kind == 'reference_image') {
        // BUG ĐÃ SỬA: trước đây rơi vào nhánh "else" bên dưới như 1 cảnh
        // thường, bị cộng nhầm vào downloadedSceneFiles -> số "Đã nhận về
        // máy: X cảnh" hiển thị THỪA 1 so với thực tế (ảnh tham chiếu không
        // phải 1 cảnh). Lưu riêng, không đụng vào bộ đếm cảnh.
        widget.project.characterReferenceImagePath = file.path;
        if (mounted) setState(() {});
      } else if (kind == 'lyrics_timestamps') {
        // MỚI (mục 7zc4) - file JSON mốc thời gian từng từ, dùng để
        // ResultScreen hiện phụ đề chạy chữ kiểu karaoke khi phát MV. Không
        // phải 1 cảnh video - lưu riêng, không đụng bộ đếm cảnh giống ảnh
        // tham chiếu ở trên.
        widget.project.lyricsTimestampsPath = file.path;
        if (mounted) setState(() {});
      } else if (kind == 'thumbnail') {
        // MỚI - ảnh thumbnail tự động chọn (xem post_processing_v2.
        // select_best_thumbnail) - lưu riêng, KHÔNG đụng bộ đếm cảnh, cùng
        // tinh thần "reference_image"/"lyrics_timestamps" ở trên (bug đã sửa
        // phía trên là ví dụ CHÍNH XÁC lỗi cần tránh lặp lại ở đây).
        widget.project.thumbnailImagePath = file.path;
        if (mounted) setState(() {});
      } else if (kind == 'final_mv_vertical') {
        // MỚI - bản dọc 9:16 (xem post_processing_v2.export_vertical_crop) -
        // KHÔNG gọi _goToResult()/đóng kết nối ở đây (khác "final_mv") - chỉ
        // lưu file, việc điều hướng/đóng kết nối do "final_mv" đảm nhiệm
        // (backend đảm bảo "final_mv_vertical" LUÔN gửi xong TRƯỚC "final_mv"
        // nhờ push_artifact(..., wait=True) - xem app.py).
        widget.project.mvVerticalLocalFile = file;
        if (mounted) setState(() {});
      } else {
        widget.project.downloadedSceneFiles.add(file.path);
        _sceneCount = widget.project.downloadedSceneFiles.length;
        final idx = _parseSceneIndex(filename);
        if (idx != null) {
          _completedSceneIndices.add(idx);
          _sceneFilePathByIndex[idx] = file.path;
        }
        if (mounted) setState(() {});
      }
    } catch (_) {
      // Lỗi ghi file cục bộ (hiếm) - coi như cảnh chưa có, backend vẫn còn
      // file gốc trên Drive nên resume sau vẫn lấy lại được.
    }
  }

  /// "scenes/{scene_dir_id}/scene_3.mp4" -> 3
  int? _parseSceneIndex(String filename) {
    final match = RegExp(r'scene_(\d+)\.mp4$').firstMatch(filename);
    if (match == null) return null;
    return int.tryParse(match.group(1)!);
  }

  Future<void> _cancelJob() async {
    if (_cancelling || _cancelled || _error != null) return;
    setState(() => _cancelling = true);
    try {
      await widget.api.abortJob();
      // Không set _cancelled ngay ở đây - đợi xác nhận qua progress
      // (p['cancelled']==true) để chắc chắn backend đã thực sự dừng.
    } catch (e) {
      if (mounted) {
        setState(() {
          _cancelling = false;
          _error = trv('Không gửi được yêu cầu huỷ: {0}', [e]);
        });
      }
    }
  }

  /// Lưu MV vào thư viện ảnh (Album/Gallery) công khai của máy bằng package
  /// `gal` - để video xuất hiện trong app Ảnh/Gallery hệ thống, không chỉ nằm
  /// trong thư mục riêng của app. KHÔNG BẮT BUỘC phải thành công: nếu lỗi
  /// (từ chối quyền, thiết bị lạ...) app vẫn hoạt động bình thường qua
  /// mvLocalFile (Mở/Chia sẻ vẫn dùng được), chỉ là MV không tự vào Gallery.
  Future<void> _trySaveToGallery(File file) async {
    try {
      // Lưu vào album riêng 'AI MV Generator' (không phải thư mục Gallery mặc
      // định) -> dùng toAlbum: true cho khớp, đây là tham số THẬT của gal
      // (KHÔNG có tham số `type`/`GalAccessType` - bản trước ghi nhầm, API đó
      // chưa từng tồn tại trong package `gal` ở bất kỳ phiên bản nào).
      final hasAccess = await Gal.hasAccess(toAlbum: true);
      if (!hasAccess) {
        final granted = await Gal.requestAccess(toAlbum: true);
        if (!granted) return;
      }
      await Gal.putVideo(file.path, album: 'AI MV Generator');
      widget.project.savedToGallery = true;
        HapticFeedback.mediumImpact(); // MỚI (mục 25) - rung nhẹ báo đã lưu vào thư viện ảnh
    } catch (_) {
      widget.project.savedToGallery = false;
    }
  }

  void _goToResult() {
    if (!mounted) return;
    _persistHistory('completed'); // không await - không chặn chuyển màn hình, lỗi lưu lịch sử (hiếm) không nên làm chậm trải nghiệm người dùng
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => ResultScreen(api: widget.api, project: widget.project)),
    );
  }

  Future<void> _retry() async {
    if (_retrying) return; // chặn bấm nhiều lần liên tiếp trong lúc đang xử lý
    setState(() {
      _retrying = true;
      _error = null;
      _cancelled = false;
      _cancelling = false;
      _usingFallbackPoll = false;
      _percent = 0;
    });
    await _start(); // widget.project.mvSceneDirId vẫn còn -> backend tự resume
    if (mounted) setState(() => _retrying = false);
  }

  /// MỚI - trước đây bấm nút/gesture back trong lúc job CHƯA xong (chưa lỗi,
  /// chưa huỷ) sẽ thoát màn hình NGAY, KHÔNG hỏi gì - job vẫn tiếp tục chạy
  /// thật trên GPU Colab phía sau (đây là 1 tính năng CÓ CHỦ Ý, để hỗ trợ
  /// "Tiếp tục sau" - xem HistoryScreen), nhưng người dùng dễ vô tình bấm
  /// back rồi quên mất, sau đó tạo dự án MỚI trong khi job cũ vẫn đang chiếm
  /// GPU (xem thêm cảnh báo mới ở HomeScreen._confirmIfBusy). Hộp thoại này
  /// biến việc thoát giữa chừng thành 1 LỰA CHỌN CÓ Ý THỨC thay vì vô tình.
  Future<void> _confirmLeaveWhileRunning() async {
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Job vẫn đang chạy')),
        content: Text(
          tr('MV chưa tạo xong. Nếu thoát mà không huỷ, job vẫn tiếp tục chạy '
          'trên GPU Colab - bạn có thể vào "Lịch sử dự án" để tiếp tục theo '
          'dõi sau. Chỉ nên thoát mà KHÔNG huỷ nếu bạn chắc chắn không tạo '
          'thêm dự án khác trong lúc job này còn chạy.'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'stay'), child: Text(tr('Ở lại'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'leave'), child: Text(tr('Thoát, để chạy nền'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'cancel_and_leave'), child: Text(tr('Huỷ job & thoát'))),
        ],
      ),
    );
    if (choice == 'cancel_and_leave') {
      unawaited(_cancelJob()); // fire-and-forget - đang thoát nên không cần đợi backend xác nhận
    }
    if ((choice == 'leave' || choice == 'cancel_and_leave') && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showCancelButton = _error == null && !_cancelled;
    final jobStillRunning = showCancelButton; // chưa lỗi, chưa huỷ => vẫn đang chạy thật trên GPU
    return PopScope(
      canPop: !jobStillRunning,
      // SỬA (mục 28): dùng `onPopInvokedWithResult` - tên tham số HIỆN HÀNH của PopScope (có từ Flutter 3.22;
      // docs.flutter.dev/release/breaking-changes/popscope-with-result: `onPopInvoked` đã bị đánh dấu lỗi thời
      // vì thay bằng `onPopInvokedWithResult(didPop, result)`). Lỗi build cũ ở bản stable 3.47.1
      // ("No named parameter with the name 'onPopInvokedWithPop'") là do TÊN SAI CHÍNH TẢ `...WithPop` - tên đó chưa từng tồn tại
      // trong Flutter - chứ không phải Flutter đổi/bỏ tham số như ghi chú cũ đã đoán. Bản dùng `onPopInvoked` vẫn biên dịch
      // (chỉ cảnh báo lỗi thời) nhưng có thể bị gỡ ở bản sau, nên đổi sang tên không lỗi thời.
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await _confirmLeaveWhileRunning();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(tr('Đang tạo MV')),
          actions: [
            if (showCancelButton)
              TextButton(
                onPressed: _cancelling ? null : _cancelJob,
                child: Text(
                  _cancelling ? tr('Đang huỷ...') : tr('Huỷ'),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
          ],
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: _cancelled
                ? _buildCancelled()
                : _error != null
                    ? _buildError()
                    : _buildProgress(),
          ),
        ),
      ),
    );
  }

  /// MỚI - "RepaintBoundary Layer Isolation": lưới ô vuông trạng thái từng
  /// cảnh (`_buildStoryboard`) được rebuild lại mỗi khi có 1 cảnh mới hoàn
  /// thành (setState trong callback tiến trình - có thể xảy ra khá thường
  /// xuyên với MV nhiều cảnh). Bọc trong `RepaintBoundary` để Flutter Engine
  /// tạo 1 lớp hiển thị (layer) RIÊNG cho lưới này - khi nó vẽ lại, KHÔNG kéo
  /// theo việc vẽ lại phần còn lại của màn hình (AppBar, nút Huỷ, text tiến
  /// trình...), giảm tải CPU/GPU vẽ lại không cần thiết trên máy cấu hình
  /// thấp, đặc biệt với MV nhiều cảnh (lưới càng lớn càng có lợi).
  Widget _buildStoryboard() {
    final total = widget.project.estimatedSceneCount ?? GenerationSettings.instance.maxScenes;
    return RepaintBoundary(
      child: Wrap(
        // mục 53: vùng chạm mỗi ô >= 48x48dp (khuyến nghị Material/PDF) - hình vẫn 28dp ở giữa, khoảng cách do vùng chạm đảm nhiệm
        spacing: 0,
        runSpacing: 0,
        alignment: WrapAlignment.center,
        children: List.generate(total, (i) {
          final done = _completedSceneIndices.contains(i);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: done ? () => _previewScene(i) : null,
            child: SizedBox(
              width: 48,
              height: 48,
              child: Center(
                child: Container(
                  width: 28,
                  height: 28,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: done ? Colors.green : Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(
                    done ? Icons.check : null,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  /// Mở dialog phát thử video của 1 cảnh đã xong - chỉ tạo 1 VideoPlayerController
  /// tại thời điểm bấm (không tạo sẵn hàng loạt), tránh tốn tài nguyên nếu MV có
  /// nhiều cảnh (đúng tinh thần "chỉ render/khởi tạo cái đang cần xem").
  void _previewScene(int index) {
    final path = _sceneFilePathByIndex[index];
    if (path == null) return;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        child: _ScenePreviewPlayer(filePath: path, title: trv('Cảnh {0}', [index + 1])),
      ),
    );
  }

  Widget _buildProgress() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (_cancelling) ...[
          const Icon(Icons.hourglass_top, color: Colors.orange, size: 32),
          const SizedBox(height: 8),
          Text(
            tr('Đang dừng tiến trình trên máy chủ GPU remote...\n'
            'Cảnh đang xử lý dở sẽ hoàn tất trước khi dừng hẳn (vài chục giây).'),
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 20),
        ],
        SizedBox(
          width: 120,
          height: 120,
          // MỚI - cô lập lớp vẽ của vòng tròn tiến trình (đổi giá trị liên
          // tục, thường xuyên nhất trong cả màn hình) khỏi phần còn lại - xem
          // ghi chú đầy đủ ở `_buildStoryboard`.
          child: RepaintBoundary(
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(value: _percent / 100, strokeWidth: 8, semanticsLabel: tr('Tiến trình tạo MV'), semanticsValue: '$_percent%'),
                Text('$_percent%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
        Text(_stageDetail, textAlign: TextAlign.center),
        if (_etaSeconds != null && _etaSeconds! > 0) ...[
          const SizedBox(height: 6),
          Text(
            trv('Còn khoảng {0}{1}', [formatDuration(_etaSeconds!), _etaConfidence == 'low' ? tr(' (ước lượng thô, sẽ chính xác dần)') : '']),
            style: TextStyle(fontSize: 12, color: mutedGrey),
            textAlign: TextAlign.center,
          ),
        ],
        const SizedBox(height: 16),
        _buildStoryboard(),
        const SizedBox(height: 8),
        Text(trv('Đã nhận về máy: {0} cảnh', [_sceneCount]), style: TextStyle(color: mutedGrey)),
        if (_usingFallbackPoll) ...[
          const SizedBox(height: 8),
          Text(
            tr('Đang dùng chế độ dự phòng (HTTP polling) vì WebSocket gặp sự cố - vẫn tiếp tục bình thường.'),
            style: TextStyle(color: Colors.orange, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ],
    );
  }

  Widget _buildError() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.cloud_off, color: Colors.red, size: 48),
        const SizedBox(height: 12),
        Text(_error!, textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _retrying ? null : _retry,
          child: Text(_retrying ? tr('Đang thử lại...') : tr('Thử lại (tiếp tục từ chỗ dừng)')),
        ),
      ],
    );
  }

  Widget _buildCancelled() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.stop_circle, color: Colors.orange, size: 48),
        const SizedBox(height: 12),
        Text(
          tr('Đã huỷ tạo MV theo yêu cầu.\nCác cảnh đã sinh trước đó vẫn còn trên Drive.'),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(trv('Đã nhận về máy: {0} cảnh', [_sceneCount]), style: TextStyle(color: mutedGrey)),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _retrying ? null : _retry,
          child: Text(_retrying ? tr('Đang tiếp tục...') : tr('Tiếp tục lại (không mất cảnh đã có)')),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => Navigator.pop(context), // quay lại màn Xem lại để chỉnh công suất/tham số
          child: Text(tr('Quay lại chỉnh cài đặt')),
        ),
      ],
    );
  }
}

/// Widget riêng cho việc phát 1 cảnh trong dialog xem trước - tách khỏi
/// GeneratingScreen để VideoPlayerController chỉ sống trong vòng đời của
/// dialog (tạo lúc mở, giải phóng lúc đóng), không ảnh hưởng tới state chính.
class _ScenePreviewPlayer extends StatefulWidget {
  final String filePath;
  final String title;

  const _ScenePreviewPlayer({required this.filePath, required this.title});

  @override
  State<_ScenePreviewPlayer> createState() => _ScenePreviewPlayerState();
}

class _ScenePreviewPlayerState extends State<_ScenePreviewPlayer> {
  VideoPlayerController? _controller;
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final controller = VideoPlayerController.file(File(widget.filePath));
      await controller.initialize();
      controller.play();
      controller.setLooping(true);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _ready = true;
      });
    } catch (e) {
      if (mounted) setState(() => _error = trv('Không phát được cảnh này: {0}', [e]));
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    // MỚI - "Tối ưu bộ nhớ đệm hình ảnh": sau khi đóng dialog xem trước,
    // native video decoder (ExoPlayer trên Android qua package video_player)
    // có thể để lại vài khung hình đã giải mã trong bộ nhớ đệm ảnh của
    // Flutter (`PaintingBinding.imageCache`) thêm vài giây - gọi `.clear()`
    // ép giải phóng NGAY, tránh cộng dồn bộ nhớ nếu người dùng mở/đóng xem
    // thử nhiều cảnh liên tiếp trên máy cấu hình thấp. API LÕI của Flutter
    // (package `painting`, ổn định từ rất lâu) - không phải đoán.
    //
    // KHÔNG dùng `SystemChannels.platform.invokeMethod('SystemNavigator.pop')`
    // như tài liệu gốc đề xuất - đã kiểm tra: đây là API dùng để THOÁT HẲN
    // ứng dụng (giống bấm nút Back ở màn hình gốc trên Android), gọi ở đây
    // sẽ vô tình ĐÓNG LUÔN CẢ APP thay vì chỉ đóng dialog xem trước - tài
    // liệu gốc dùng sai API cho mục đích này, mình bỏ qua phần đó.
    PaintingBinding.instance.imageCache.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            )
          else if (_ready && _controller != null)
            AspectRatio(
              aspectRatio: _controller!.value.aspectRatio == 0 ? 1 : _controller!.value.aspectRatio,
              child: VideoPlayer(_controller!),
            )
          else
            const Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          const SizedBox(height: 8),
          TextButton(onPressed: () => Navigator.pop(context), child: Text(tr('Đóng'))),
        ],
      ),
    );
  }
}
