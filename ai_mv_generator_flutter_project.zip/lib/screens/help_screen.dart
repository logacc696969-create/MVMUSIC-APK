import 'package:flutter/material.dart';

/// Màn hình Trợ giúp - hướng dẫn dùng app NGAY TRONG APP (khác
/// HUONG_DAN_CAI_DAT.md - file đó hướng dẫn CÀI ĐẶT/build app, còn màn này
/// hướng dẫn CÁCH DÙNG sau khi đã cài xong, mở trực tiếp trong app, không
/// cần tìm lại file riêng).
///
/// Dùng ExpansionTile cho từng mục - toàn bộ nội dung là TEXT THƯỜNG (không
/// đặt trong ListTile.title/subtitle bị giới hạn dòng) nên không bị cắt chữ
/// dù dài, đúng tinh thần vừa sửa ở SettingsScreen/StoryboardScreen.
class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trợ giúp - Cách dùng app')),
      body: SafeArea(
        top: false,
        child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: const [
          _HelpSection(
            icon: Icons.play_circle_outline,
            title: '1. Quy trình tổng quát',
            content:
                'Mỗi lần dùng app: (1) Mở Colab, chạy các cell theo đúng thứ tự để lấy '
                'URL backend mới - Colab free không giữ được lâu, mỗi lần dùng phải lấy '
                'URL mới. (2) Dán URL đó vào ô "Backend URL" trong app. (3) Chọn 1 trong '
                '2 cách bắt đầu: nhập ý tưởng để AI tự soạn nhạc, hoặc đưa 1 bài nhạc mẫu '
                'có sẵn để biến tấu/cover. (4) Xem/sửa kịch bản cảnh nếu muốn. (5) Bấm tạo '
                'MV, chờ - có thể tắt màn hình, chuyển sang app khác, tiến trình vẫn tiếp '
                'tục (xem mục 6 bên dưới).',
          ),
          _HelpSection(
            icon: Icons.music_note_outlined,
            title: '2. Hai cách bắt đầu: AI soạn nhạc hay dùng nhạc có sẵn',
            content:
                '"Tạo từ ý tưởng": mô tả nội dung bài hát bằng vài câu, chọn thể loại/tâm '
                'trạng, AI tự soạn cả nhạc và lời. Không cần biết nhạc lý gì cả.\n\n'
                '"Nhạc mẫu": đã có sẵn 1 bài nhạc (file trên máy, hoặc dán link YouTube), '
                'app biến tấu lại theo phong cách bạn mô tả, hoặc cover thành lời Việt '
                '(xem mục 5 bên dưới). Nếu chỉ muốn dùng đúng nguyên bài nhạc để làm MV, '
                'không cần AI đụng vào nhạc, cũng chọn được ở đây.',
          ),
          _HelpSection(
            icon: Icons.movie_creation_outlined,
            title: '3. Kịch bản cảnh & thể loại MV',
            content:
                'Trước khi tạo MV, app tự dựng 1 kịch bản (mỗi cảnh video ứng với 1 đoạn '
                'nhạc) - bạn có thể: (a) dùng thẳng kịch bản mẫu app tự soạn, (b) bật '
                '"Viết kịch bản bằng AI" để AI đọc lời bài hát và viết kịch bản riêng '
                '(chạy chậm hơn, cần đã có lời), (c) tự viết kịch bản của riêng bạn và '
                'tải file .txt lên, bỏ qua AI hoàn toàn. Chọn thêm 1 trong 4 "thể loại" '
                '(kể chuyện/biểu diễn/trừu tượng/thiên nhiên) để đổi hẳn phong cách dàn '
                'dựng. Mọi cảnh đều sửa được trực tiếp trên màn hình trước khi tạo thật.',
          ),
          _HelpSection(
            icon: Icons.face_retouching_natural,
            title: '4. Giữ nhân vật giống nhau xuyên suốt MV',
            content:
                'Nhập "Mô tả nhân vật cố định" ở màn Cài đặt (vd "cô gái tóc đen dài, áo '
                'khoác đỏ") - app sẽ tạo 1 ảnh nhân vật gốc rồi dùng ảnh đó làm khuôn mẫu '
                'cho mọi cảnh, giúp gương mặt/trang phục đỡ bị đổi khác giữa các cảnh. '
                'Ảnh gốc này hiện lại ở màn Kết quả sau khi MV xong.\n\n'
                'CHỈ hoạt động với 1 số công nghệ video nhất định (không phải tất cả) - '
                'nếu bạn điền mô tả nhân vật rồi chọn 1 công nghệ KHÔNG hỗ trợ ở mục '
                '"Công nghệ tạo video" trong Cài đặt, app sẽ hiện 1 khung cảnh báo màu '
                'cam ngay dưới ô nhập, báo rõ mô tả sẽ KHÔNG có tác dụng cho tới khi đổi '
                'lại công nghệ khác - không mất mô tả đã nhập, chỉ tạm thời không dùng '
                'được, đổi công nghệ lúc nào cũng dùng lại được ngay.',
          ),
          _HelpSection(
            icon: Icons.translate,
            title: '5. Cover nhạc nước ngoài thành lời Việt',
            content:
                'Ở màn "Nhạc mẫu": nếu bài mẫu là tiếng Hoa/nước ngoài, có khối "Cover '
                'lời Việt" - không cần có sẵn file nhạc (dán link YouTube, app tự tải), '
                'không cần có sẵn lời gốc (bấm "Lấy lời từ nhạc mẫu", app tự nghe và viết '
                'ra), rồi bấm "Dịch sang lời Việt" để có bản nháp lời Việt - LUÔN xem/sửa '
                'lại trước khi tạo, vì đây chỉ là bản nháp AI viết, không phải bản dịch '
                'hoàn chỉnh.',
          ),
          _HelpSection(
            icon: Icons.mic_external_on_outlined,
            title: '6. Đổi giọng hát (voice cover)',
            content:
                'Sau khi có nhạc (AI soạn hoặc nhạc mẫu), có thể đổi giọng hát sang 1 '
                'giọng khác ở màn Chọn giọng - chọn giọng có sẵn, tự upload file giọng '
                '".pth" của riêng bạn (kéo vào Google Drive theo đúng thư mục nếu upload '
                'trong app hay lỗi vì mạng yếu - xem HUONG_DAN_CAI_DAT.md), hoặc bấm "Tự '
                'train giọng từ file ghi âm" để app tự "học" 1 giọng mới từ file ghi âm của '
                'bạn (mất từ vài chục phút trở lên, nên dùng ghi âm sạch/rõ/càng dài càng '
                'tốt - bấm "Huỷ train" nếu muốn dừng giữa chừng, nhưng phần train dở dang '
                'sẽ KHÔNG giữ lại được, phải train lại từ đầu nếu muốn thử lại).',
          ),
          _HelpSection(
            icon: Icons.hourglass_top,
            title: '7. Tắt màn hình / chuyển app khác / GPU bị ngắt giữa chừng',
            content:
                'App KHÔNG cần phải mở màn hình liên tục lúc đang tạo MV - có thông báo '
                'hiện % tiến trình ngay cả khi khoá màn hình hoặc dùng app khác. Nếu '
                'Colab bị ngắt (GPU "sập") HOẶC bạn tắt hẳn app giữa chừng: mở lại app, '
                'vào "Lịch sử dự án" (hoặc banner cam ở màn chính nếu có việc đang dang '
                'dở), bấm "Tiếp tục" - các cảnh đã xong trước đó KHÔNG mất, chỉ sinh tiếp '
                'phần còn thiếu. Nhớ dán URL Colab MỚI vào app trước khi bấm Tiếp tục nếu '
                'bạn đã phải mở lại Colab.',
          ),
          _HelpSection(
            icon: Icons.cloud_sync_outlined,
            title: '8. Sao lưu & Phục hồi',
            content:
                'Vào biểu tượng ☁ ở màn chính - chọn "Chọn tất cả" (sao lưu toàn bộ ứng '
                'dụng) hoặc tự tick từng dự án cụ thể, xuất ra 1 file để lưu vào Google '
                'Drive/gửi đi. Dùng file đó để phục hồi lại trên máy này (sau khi cài lại '
                'app) hoặc trên điện thoại khác.',
          ),
          _HelpSection(
            icon: Icons.speed,
            title: '9. Thanh trượt "Công suất GPU" trong Cài đặt là gì',
            content:
                'Kéo xuống thấp nếu bạn hay bị Colab ngắt kết nối giữa chừng khi tạo MV - '
                'app sẽ dùng ít tài nguyên GPU hơn (chạy chậm hơn nhưng ổn định hơn, ít bị '
                'Colab tự bóp/ngắt vì dùng quá nhiều liên tục). Kéo lên cao nếu Colab của '
                'bạn ổn định, ưu tiên tốc độ.',
          ),
          _HelpSection(
            icon: Icons.face_retouching_natural,
            title: '10. Lipsync — khớp khẩu hình theo lời hát',
            content:
                'Bật công tắc "Khớp khẩu hình (Lipsync)" ở màn Chọn phong cách (Style) để '
                'AI tạo video có khẩu hình nhân vật khớp với lời hát. Tính năng này CHỈ có '
                'tác dụng với một số phong cách nhất định (vd "nguoi_that_studio") - app tự '
                'ẩn công tắc này nếu phong cách đang chọn không hỗ trợ. Mặc định TẮT vì đây '
                'là tính năng rủi ro cao, còn thử nghiệm, dễ lỗi hoặc không tự nhiên - '
                'khuyến nghị tạo thử 1 đoạn ngắn trước để đánh giá kết quả. Khi bật, có thể '
                'chọn thêm "Công nghệ Lipsync" nếu backend có nhiều lựa chọn - xem mục 14.',
          ),
          _HelpSection(
            icon: Icons.palette_outlined,
            title: '11. Cân bằng màu & Đổi tốc độ theo nhịp',
            content:
                '"Cân bằng màu (Color Grading)" trong Cài đặt: tự động khớp tông màu tất '
                'cả cảnh theo cảnh mở đầu - tránh MV bị lệch màu (vàng ấm ở cảnh này, xanh '
                'lạnh ở cảnh khác). Mặc định BẬT, an toàn - tự bỏ qua nếu lỗi. Tắt nếu '
                'muốn giữ đúng màu AI sinh ra không can thiệp.\n\n'
                '"Đổi tốc độ theo nhịp (thử nghiệm)": đổi nhẹ tốc độ phát mỗi cảnh (±6%) '
                'theo cường độ nhịp bài hát - đoạn dồn dập thì cảnh nhích nhanh hơn, đoạn '
                'êm dịu thì chậm lại. Mặc định TẮT (còn thử nghiệm, CHƯA kiểm chứng bằng '
                'mắt). Không làm lệch nhịp với nhạc vì không thay đổi tổng thời lượng cảnh.',
          ),
          _HelpSection(
            icon: Icons.graphic_eq_outlined,
            title: '12. Chỉnh formant & Giảm tiếng xì giọng hát',
            content:
                'Hai công tắc này xuất hiện ở màn Chọn giọng (sau khi đã chọn 1 giọng RVC), '
                'ngay dưới thanh dịch tông.\n\n'
                '"Chỉnh formant (thử nghiệm)": sửa giọng RVC bị "chóe"/nghẹt mũi khi âm '
                'vực lệch nhiều so với giọng gốc. Cần cài thêm thư viện stftpitchshift ở '
                'Colab (xem hướng dẫn trong colab_setup.py). CHƯA nghe thử thật - nên '
                'bật/tắt rồi so sánh trực tiếp trên 1 bài trước khi dùng thường xuyên. '
                'Có thể điều chỉnh thêm thông số Quefrency (mặc định 1.5ms) nếu kết quả '
                'chưa tự nhiên.\n\n'
                '"Giảm tiếng xì (thử nghiệm)": giảm nhẹ âm lượng ở dải tần 4-8kHz (tiếng '
                '"s", "x", "ch" bị rít gió khi chuyển giọng). Khác hoàn toàn với Formant - '
                'có thể bật cả 2 cùng lúc. CHƯA nghe thử thật.',
          ),
          _HelpSection(
            icon: Icons.preview_outlined,
            title: '13. Xem trước ảnh nhân vật trước khi tạo MV',
            content:
                'Nếu bạn đã điền "Mô tả nhân vật cố định" ở Cài đặt, app sẽ tự sinh 1 ảnh '
                'nhân vật gốc và hiện màn xem trước TRƯỚC khi bắt đầu tạo MV thật. Ở màn '
                'này bạn có thể: (a) bấm "Dùng ảnh này" để xác nhận và tiếp tục tạo MV với '
                'ảnh nhân vật này làm khuôn mẫu cho mọi cảnh, hoặc (b) bấm "Tạo lại" để '
                'sinh 1 ảnh khác (mỗi lần sinh có thể ra kết quả khác nhau dù cùng mô tả), '
                'hoặc (c) bấm "Bỏ qua" để tiếp tục tạo MV mà không khoá theo nhân vật cố '
                'định (như hành vi cũ). Ảnh này cũng hiện lại ở màn Kết quả sau khi MV xong.',
          ),
          _HelpSection(
            icon: Icons.compare_arrows,
            title: '14. Chọn công nghệ Lipsync (Wav2Lip hay MuseTalk)',
            content:
                'Khi đã bật Lipsync (mục 10) VÀ Colab của bạn cài từ 2 công nghệ trở lên, '
                'màn Chọn phong cách sẽ hiện thêm danh sách "Công nghệ Lipsync" để chọn.\n\n'
                '"Wav2Lip" (mặc định): nhẹ, cài đơn giản nhất, chạy được ngay cả khi GPU '
                'hạn chế. Chất lượng vừa phải - vùng miệng có thể hơi mờ vì đây là công '
                'nghệ khá cũ (từ 2020), đặc biệt rõ khi nhân vật cử động đầu nhiều.\n\n'
                '"MuseTalk" (mới hơn, THỬ NGHIỆM): vùng mặt sinh ra nét hơn hẳn Wav2Lip, '
                'nhưng cần cài thêm ở Colab (Cell riêng trong colab_setup.py, có thể mất '
                '10-20 phút) và CHƯA xác nhận tốc độ thật trên GPU miễn phí của Colab - có '
                'thể chạy chậm hơn Wav2Lip đáng kể. Nếu chưa cài, chọn công nghệ này sẽ tự '
                'động rơi về dùng bản MV gốc không có lipsync (không báo lỗi, không hỏng '
                'job) - kiểm tra kỹ Cell cài đặt trong colab_setup.py nếu muốn dùng thử.',
          ),
          SizedBox(height: 24),
        ],
        ),
      ),
    );
  }
}

class _HelpSection extends StatelessWidget {
  final IconData icon;
  final String title;
  final String content;

  const _HelpSection({required this.icon, required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: ExpansionTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text thường, KHÔNG đặt trong title/subtitle của ListTile nào -
          // không có giới hạn số dòng, dài bao nhiêu cũng hiện đủ, xuống
          // dòng tự nhiên theo chiều rộng màn hình.
          Text(content, style: const TextStyle(fontSize: 13, height: 1.4)),
        ],
      ),
    );
  }
}
