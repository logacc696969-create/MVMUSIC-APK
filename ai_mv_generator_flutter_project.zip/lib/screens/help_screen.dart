import 'package:flutter/material.dart';

/// Màn hình Trợ giúp - hướng dẫn dùng app NGAY TRONG APP (khác
/// HUONG_DAN_CAI_DAT.md - file đó hướng dẫn CÀI ĐẶT/build app, còn màn này
/// hướng dẫn CÁCH DÙNG sau khi đã cài xong, mở trực tiếp trong app, không
/// cần tìm lại file riêng).
///
/// Dùng ExpansionTile cho từng mục - toàn bộ nội dung là TEXT THƯỜNG (không
/// đặt trong ListTile.title/subtitle bị giới hạn dòng) nên không bị cắt chữ
/// dù dài, đúng tinh thần vừa sửa ở SettingsScreen/StoryboardScreen.
class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trợ giúp - Cách dùng app')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: const [
          _HelpSection(
            icon: Icons.play_circle_outline,
            title: '1. Quy trình tổng quát',
            content:
                'Mỗi lần dùng app: (1) Mở Colab, chạy các cell theo đúng thứ tự để lấy '
                'URL backend mới - Colab free không giữ được lâu, mỗi lần dùng phải lấy '
                'URL mới. (2) Dán URL đó vào ô "Backend URL" trong app. (3) Chọn 1 trong '
                '2 cách bắt đầu: nhập ý tưởng để AI tự soạn nhạc, hoặc đưa 1 bài nhạc mẫu '
                'có sẵn để biến tấu/cover. (4) Xem/sửa kịch bản cảnh nếu muốn. (5) Bấm tạo '
                'MV, chờ - có thể tắt màn hình, chuyển sang app khác, tiến trình vẫn tiếp '
                'tục (xem mục 6 bên dưới).',
          ),
          _HelpSection(
            icon: Icons.music_note_outlined,
            title: '2. Hai cách bắt đầu: AI soạn nhạc hay dùng nhạc có sẵn',
            content:
                '"Tạo từ ý tưởng": mô tả nội dung bài hát bằng vài câu, chọn thể loại/tâm '
                'trạng, AI tự soạn cả nhạc và lời. Không cần biết nhạc lý gì cả.\n\n'
                '"Nhạc mẫu": đã có sẵn 1 bài nhạc (file trên máy, hoặc dán link YouTube), '
                'app biến tấu lại theo phong cách bạn mô tả, hoặc cover thành lời Việt '
                '(xem mục 5 bên dưới). Nếu chỉ muốn dùng đúng nguyên bài nhạc để làm MV, '
                'không cần AI đụng vào nhạc, cũng chọn được ở đây.',
          ),
          _HelpSection(
            icon: Icons.movie_creation_outlined,
            title: '3. Kịch bản cảnh & thể loại MV',
            content:
                'Trước khi tạo MV, app tự dựng 1 kịch bản (mỗi cảnh video ứng với 1 đoạn '
                'nhạc) - bạn có thể: (a) dùng thẳng kịch bản mẫu app tự soạn, (b) bật '
                '"Viết kịch bản bằng AI" để AI đọc lời bài hát và viết kịch bản riêng '
                '(chạy chậm hơn, cần đã có lời), (c) tự viết kịch bản của riêng bạn và '
                'tải file .txt lên, bỏ qua AI hoàn toàn. Chọn thêm 1 trong 4 "thể loại" '
                '(kể chuyện/biểu diễn/trừu tượng/thiên nhiên) để đổi hẳn phong cách dàn '
                'dựng. Mọi cảnh đều sửa được trực tiếp trên màn hình trước khi tạo thật.',
          ),
          _HelpSection(
            icon: Icons.face_retouching_natural,
            title: '4. Giữ nhân vật giống nhau xuyên suốt MV',
            content:
                'Nhập "Mô tả nhân vật cố định" ở màn Cài đặt (vd "cô gái tóc đen dài, áo '
                'khoác đỏ") - app sẽ tạo 1 ảnh nhân vật gốc rồi dùng ảnh đó làm khuôn mẫu '
                'cho mọi cảnh, giúp gương mặt/trang phục đỡ bị đổi khác giữa các cảnh. '
                'Ảnh gốc này hiện lại ở màn Kết quả sau khi MV xong. Chỉ hoạt động với 1 '
                'số công nghệ video nhất định - chọn ở mục "Công nghệ tạo video" trong '
                'Cài đặt.',
          ),
          _HelpSection(
            icon: Icons.translate,
            title: '5. Cover nhạc nước ngoài thành lời Việt',
            content:
                'Ở màn "Nhạc mẫu": nếu bài mẫu là tiếng Hoa/nước ngoài, có khối "Cover '
                'lời Việt" - không cần có sẵn file nhạc (dán link YouTube, app tự tải), '
                'không cần có sẵn lời gốc (bấm "Lấy lời từ nhạc mẫu", app tự nghe và viết '
                'ra), rồi bấm "Dịch sang lời Việt" để có bản nháp lời Việt - LUÔN xem/sửa '
                'lại trước khi tạo, vì đây chỉ là bản nháp AI viết, không phải bản dịch '
                'hoàn chỉnh.',
          ),
          _HelpSection(
            icon: Icons.mic_external_on_outlined,
            title: '6. Đổi giọng hát (voice cover)',
            content:
                'Sau khi có nhạc (AI soạn hoặc nhạc mẫu), có thể đổi giọng hát sang 1 '
                'giọng khác ở màn Chọn giọng - chọn giọng có sẵn, hoặc tự upload file '
                'giọng ".pth" của riêng bạn (kéo vào Google Drive theo đúng thư mục nếu '
                'upload trong app hay lỗi vì mạng yếu - xem HUONG_DAN_CAI_DAT.md).',
          ),
          _HelpSection(
            icon: Icons.hourglass_top,
            title: '7. Tắt màn hình / chuyển app khác / GPU bị ngắt giữa chừng',
            content:
                'App KHÔNG cần phải mở màn hình liên tục lúc đang tạo MV - có thông báo '
                'hiện % tiến trình ngay cả khi khoá màn hình hoặc dùng app khác. Nếu '
                'Colab bị ngắt (GPU "sập") HOẶC bạn tắt hẳn app giữa chừng: mở lại app, '
                'vào "Lịch sử dự án" (hoặc banner cam ở màn chính nếu có việc đang dang '
                'dở), bấm "Tiếp tục" - các cảnh đã xong trước đó KHÔNG mất, chỉ sinh tiếp '
                'phần còn thiếu. Nhớ dán URL Colab MỚI vào app trước khi bấm Tiếp tục nếu '
                'bạn đã phải mở lại Colab.',
          ),
          _HelpSection(
            icon: Icons.cloud_sync_outlined,
            title: '8. Sao lưu & Phục hồi',
            content:
                'Vào biểu tượng ☁ ở màn chính - chọn "Chọn tất cả" (sao lưu toàn bộ ứng '
                'dụng) hoặc tự tick từng dự án cụ thể, xuất ra 1 file để lưu vào Google '
                'Drive/gửi đi. Dùng file đó để phục hồi lại trên máy này (sau khi cài lại '
                'app) hoặc trên điện thoại khác.',
          ),
          _HelpSection(
            icon: Icons.speed,
            title: '9. Thanh trượt "Công suất GPU" trong Cài đặt là gì',
            content:
                'Kéo xuống thấp nếu bạn hay bị Colab ngắt kết nối giữa chừng khi tạo MV - '
                'app sẽ dùng ít tài nguyên GPU hơn (chạy chậm hơn nhưng ổn định hơn, ít bị '
                'Colab tự bóp/ngắt vì dùng quá nhiều liên tục). Kéo lên cao nếu Colab của '
                'bạn ổn định, ưu tiên tốc độ.',
          ),
          SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _HelpSection extends StatelessWidget {
  final IconData icon;
  final String title;
  final String content;

  const _HelpSection({required this.icon, required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: ExpansionTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text thường, KHÔNG đặt trong title/subtitle của ListTile nào -
          // không có giới hạn số dòng, dài bao nhiêu cũng hiện đủ, xuống
          // dòng tự nhiên theo chiều rộng màn hình.
          Text(content, style: const TextStyle(fontSize: 13, height: 1.4)),
        ],
      ),
    );
  }
}
