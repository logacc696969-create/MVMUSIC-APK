import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../project_history.dart';
import 'generating_screen.dart';

class HistoryScreen extends StatefulWidget {
  final ApiService api;

  const HistoryScreen({super.key, required this.api});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<ProjectHistoryEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await ProjectHistoryStore.load();
    if (mounted) {
      setState(() {
        _entries = entries;
        _loading = false;
      });
    }
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final sameDay = dt.year == now.year && dt.month == now.month && dt.day == now.day;
    final time = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return sameDay ? 'Hôm nay, $time' : '${dt.day}/${dt.month}/${dt.year}, $time';
  }

  (IconData, Color, String) _statusVisual(ProjectHistoryEntry e, bool fileExists) {
    switch (e.status) {
      case 'in_progress':
        return (Icons.hourglass_top, Colors.orange, 'Đang tạo dở - bấm để tiếp tục');
      case 'failed':
        return (Icons.error_outline, Colors.red, 'Bị lỗi giữa chừng - bấm để thử tiếp tục');
      case 'cancelled':
        return (Icons.cancel_outlined, Colors.grey, 'Đã huỷ');
      default: // 'completed'
        return fileExists
            ? (Icons.movie, Colors.green, 'Đã xong')
            : (Icons.movie_outlined, Colors.grey, 'Đã xong - file không còn trên máy');
    }
  }

  /// Dựng lại 1 ProjectData TỪ bản ghi lịch sử đã lưu, kèm `historyId`/
  /// `historyCreatedAt` (để GeneratingScreen cập nhật ĐÚNG bản ghi này thay
  /// vì tạo bản ghi mới) - đây LÀ cơ chế "tiếp tục sau khi app bị đóng hẳn"
  /// mà trước đây KHÔNG làm được (xem ghi chú đầu project_history.dart).
  void _resumeEntry(ProjectHistoryEntry e) {
    final project = ProjectData()
      ..fromSample = e.fromSample
      ..musicFilename = e.musicFilename
      ..voicedFilename = e.voicedFilename
      ..styleId = e.styleId
      ..lyrics = e.lyrics
      ..estimatedSceneCount = e.estimatedSceneCount
      ..scenePrompts = e.scenePrompts
      ..mvSceneDirId = e.mvSceneDirId
      ..historyId = e.id
      ..historyCreatedAt = e.createdAt;

    // videoBackend/genre/characterDesc KHÔNG nằm trong ProjectData - chúng
    // là CÀI ĐẶT CHUNG (GenerationSettings, singleton toàn app), không phải
    // thuộc tính riêng từng dự án (lỗi build #56 xác nhận đúng NGAY chỗ này:
    // `characterDesc` cũng bị viết nhầm vào cascade ProjectData ở trên, dù
    // đã tự nhắc bài học y hệt cho videoBackend/genre ngay bên dưới - lần
    // này áp dụng cho cả 3, không sót). Nếu không khôi phục lại đúng các giá
    // trị này trước khi tiếp tục, job có thể vô tình dùng NHẦM cài đặt hiện
    // tại (nếu người dùng đã đổi cài đặt sau lần tạo dự án này) - các cảnh ĐÃ
    // xong (vd .gif từ AnimateDiff) ghép chung với cảnh MỚI sinh bằng backend
    // KHÁC (vd .mp4 từ Wan2.2) có thể lỗi lúc ghép video cuối.
    final s = GenerationSettings.instance;
    if (e.videoBackend != null) s.videoBackend = e.videoBackend;
    if (e.genre != null) s.genre = e.genre;
    s.characterDesc = e.characterDesc;

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: project)),
    ).then((_) => _load()); // quay lại màn này sau khi xong -> tải lại danh sách cho đúng trạng thái mới
  }

  Future<void> _confirmDelete(ProjectHistoryEntry e) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xoá khỏi lịch sử?'),
        content: const Text('Chỉ xoá bản ghi lịch sử, không xoá file MV đã lưu trên máy (nếu có).'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xoá')),
        ],
      ),
    );
    if (confirmed == true) {
      await ProjectHistoryStore.delete(e.id);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử dự án')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _entries.isEmpty
              ? const Center(
                  child: Text('Chưa có dự án nào được tạo.', style: TextStyle(color: Colors.grey)),
                )
              : ListView.builder(
                  itemCount: _entries.length,
                  itemBuilder: (context, i) {
                    final e = _entries[i];
                    final fileExists = e.mvLocalPath != null && File(e.mvLocalPath!).existsSync();
                    final (icon, color, statusLabel) = _statusVisual(e, fileExists);
                    final canResume = e.status == 'in_progress' || e.status == 'failed';

                    return ListTile(
                      leading: Icon(icon, color: color),
                      title: Text(e.mvFilename ?? e.musicFilename ?? e.voicedFilename ?? 'Dự án chưa đặt tên'),
                      subtitle: Text(
                        '${_formatDate(e.updatedAt)} · $statusLabel'
                        '${e.fromSample ? " · Từ nhạc mẫu" : " · Từ text"}'
                        '${e.styleId != null ? " · ${e.styleId}" : ""}',
                      ),
                      trailing: canResume
                          ? FilledButton.tonal(
                              onPressed: () => _resumeEntry(e),
                              child: const Text('Tiếp tục'),
                            )
                          : PopupMenuButton<String>(
                              onSelected: (v) {
                                if (v == 'delete') _confirmDelete(e);
                              },
                              itemBuilder: (_) => [
                                if (fileExists) const PopupMenuItem(value: 'open', child: Text('Mở')),
                                const PopupMenuItem(value: 'delete', child: Text('Xoá khỏi lịch sử')),
                              ],
                            ),
                      onTap: canResume
                          ? () => _resumeEntry(e)
                          : (fileExists ? () => OpenFilex.open(e.mvLocalPath!) : null),
                      onLongPress: () => _confirmDelete(e),
                    );
                  },
                ),
    );
  }
}
