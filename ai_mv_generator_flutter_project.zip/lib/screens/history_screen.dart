import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:photo_manager/photo_manager.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../project_history.dart';
import 'generating_screen.dart';

class HistoryScreen extends StatefulWidget {
  final ApiService api;

  const HistoryScreen({super.key, required this.api});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<ProjectHistoryEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // MỚI - "I/O bất đồng bộ lịch sử dự án": TRƯỚC ĐÂY `File(...).existsSync()`
  // (đồng bộ, chặn UI thread) được gọi TRONG `itemBuilder` - tức là chạy lại
  // MỖI LẦN widget rebuild (không chỉ 1 lần khi tải danh sách) - trên máy có
  // tốc độ đọc/ghi bộ nhớ chậm (eMMC đời cũ), việc này có thể làm khựng UI
  // khi cuộn/mở màn Lịch sử với nhiều dự án. Chuyển sang kiểm tra BẤT ĐỒNG BỘ
  // (`File(...).exists()`), chạy // SONG SONG cho mọi bản ghi qua
  // `Future.wait` NGAY KHI TẢI danh sách (1 lần), kết quả lưu vào map
  // `_fileExistsCache` để `itemBuilder` chỉ đọc lại (không tự đi kiểm tra đĩa
  // cứng nữa mỗi lần vẽ).
  final Map<String, bool> _fileExistsCache = {};

  Future<void> _load() async {
    final entries = await ProjectHistoryStore.load();
    final existsResults = await Future.wait(entries.map((e) async {
      if (e.mvLocalPath == null) return false;
      try {
        return await File(e.mvLocalPath!).exists();
      } catch (_) {
        return false;
      }
    }));
    if (mounted) {
      setState(() {
        _entries = entries;
        _fileExistsCache
          ..clear()
          ..addEntries(List.generate(entries.length, (i) => MapEntry(entries[i].id, existsResults[i])));
        _loading = false;
      });
    }
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final sameDay = dt.year == now.year && dt.month == now.month && dt.day == now.day;
    final time = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return sameDay ? 'Hôm nay, $time' : '${dt.day}/${dt.month}/${dt.year}, $time';
  }

  (IconData, Color, String) _statusVisual(ProjectHistoryEntry e, bool fileExists) {
    switch (e.status) {
      case 'in_progress':
        return (Icons.hourglass_top, Colors.orange, 'Đang tạo dở - bấm để tiếp tục');
      case 'failed':
        return (Icons.error_outline, Colors.red, 'Bị lỗi giữa chừng - bấm để thử tiếp tục');
      case 'cancelled':
        return (Icons.cancel_outlined, Colors.grey, 'Đã huỷ');
      default: // 'completed'
        return fileExists
            ? (Icons.movie, Colors.green, 'Đã xong')
            : (Icons.movie_outlined, Colors.grey, 'Đã xong - file không còn trên máy');
    }
  }

  /// Dựng lại 1 ProjectData TỪ bản ghi lịch sử đã lưu, kèm `historyId`/
  /// `historyCreatedAt` (để GeneratingScreen cập nhật ĐÚNG bản ghi này thay
  /// vì tạo bản ghi mới) - đây LÀ cơ chế "tiếp tục sau khi app bị đóng hẳn"
  /// mà trước đây KHÔNG làm được (xem ghi chú đầu project_history.dart).
  void _resumeEntry(ProjectHistoryEntry e) {
    final project = ProjectData()
      ..fromSample = e.fromSample
      ..musicFilename = e.musicFilename
      ..voicedFilename = e.voicedFilename
      ..styleId = e.styleId
      ..lyrics = e.lyrics
      ..estimatedSceneCount = e.estimatedSceneCount
      ..scenePrompts = e.scenePrompts
      ..mvSceneDirId = e.mvSceneDirId
      ..historyId = e.id
      ..historyCreatedAt = e.createdAt;

    // videoBackend/genre/characterDesc KHÔNG nằm trong ProjectData - chúng
    // là CÀI ĐẶT CHUNG (GenerationSettings, singleton toàn app), không phải
    // thuộc tính riêng từng dự án (lỗi build #56 xác nhận đúng NGAY chỗ này:
    // `characterDesc` cũng bị viết nhầm vào cascade ProjectData ở trên, dù
    // đã tự nhắc bài học y hệt cho videoBackend/genre ngay bên dưới - lần
    // này áp dụng cho cả 3, không sót). Nếu không khôi phục lại đúng các giá
    // trị này trước khi tiếp tục, job có thể vô tình dùng NHẦM cài đặt hiện
    // tại (nếu người dùng đã đổi cài đặt sau lần tạo dự án này) - các cảnh ĐÃ
    // xong (vd .gif từ AnimateDiff) ghép chung với cảnh MỚI sinh bằng backend
    // KHÁC (vd .mp4 từ Wan2.2) có thể lỗi lúc ghép video cuối.
    final s = GenerationSettings.instance;
    if (e.videoBackend != null) s.videoBackend = e.videoBackend;
    if (e.genre != null) s.genre = e.genre;
    s.characterDesc = e.characterDesc;

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: project)),
    ).then((_) => _load()); // quay lại màn này sau khi xong -> tải lại danh sách cho đúng trạng thái mới
  }

  Future<void> _confirmDelete(ProjectHistoryEntry e) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xoá khỏi lịch sử?'),
        content: const Text('Chỉ xoá bản ghi lịch sử, không xoá file MV đã lưu trên máy (nếu có).'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xoá')),
        ],
      ),
    );
    if (confirmed == true) {
      await ProjectHistoryStore.delete(e.id);
      _load();
    }
  }

  /// MỚI - "Khôi phục từ Thư viện ảnh": dùng khi file làm việc riêng của app
  /// (`mvLocalPath`, trong `getApplicationDocumentsDirectory()`) không còn
  /// (vd người dùng lỡ tay xoá cache/data app, cài lại app, hoặc chuyển máy)
  /// NHƯNG bản MV vẫn còn trong Thư viện ảnh của máy (do lúc tạo xong đã tự
  /// lưu vào album "AI MV Generator" qua package `gal`, xem
  /// generating_screen.dart `_trySaveToGallery`). Dò qua `photo_manager` -
  /// đọc bằng MediaStore (Android)/Photos (iOS) THẬT SỰ, không phụ thuộc
  /// đường dẫn file thô nên không bị ảnh hưởng bởi việc file cache/documents
  /// gốc còn hay mất.
  ///
  /// LƯU Ý PHẠM VI: đây là tính năng "tìm lại nếu còn", KHÔNG phải bằng
  /// chứng cho thấy `mvLocalPath` tự nhiên hay mất theo cơ chế nào - đọc kỹ
  /// code (`getApplicationDocumentsDirectory()`) thì thư mục riêng của app
  /// KHÔNG bị Android tự thu hồi quyền theo thời gian, chỉ mất khi người
  /// dùng chủ động xoá dữ liệu/gỡ app - nút này xử lý đúng những trường hợp
  /// đó, không phải "sửa lỗi Android" nào cả.
  ///
  /// CHƯA TEST TRÊN MÁY THẬT - logic dựa đúng theo tài liệu chính thức của
  /// `photo_manager` (API `PhotoManager.requestPermissionExtend`,
  /// `PhotoManager.getAssetPathList`, `AssetPathEntity.getAssetListRange`,
  /// `AssetEntity.titleAsync`/`.file`) nhưng chưa có cách chạy thử thật trên
  /// điện thoại Android/iOS ở đây - nên thử trên 1 MV cũ trước khi tin tưởng
  /// dùng thường xuyên.
  Future<void> _tryRecoverFromGallery(ProjectHistoryEntry e) async {
    if (e.mvFilename == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dự án này chưa có tên file MV để tìm lại.')),
      );
      return;
    }

    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cần quyền truy cập Thư viện ảnh để tìm lại MV.')),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        filterOption: FilterOptionGroup(
          // Lọc đúng theo tên album đã dùng lúc lưu (xem
          // generating_screen.dart: `Gal.putVideo(file.path, album: 'AI MV
          // Generator')`) - tránh phải quét TOÀN BỘ video trên máy.
        ),
      );
      AssetEntity? found;
      for (final album in albums) {
        if (album.name != 'AI MV Generator') continue;
        final assets = await album.getAssetListRange(start: 0, end: await album.assetCountAsync);
        for (final asset in assets) {
          final title = await asset.titleAsync;
          if (title == e.mvFilename) {
            found = asset;
            break;
          }
        }
        if (found != null) break;
      }

      if (!mounted) return;
      Navigator.of(context).pop(); // đóng dialog loading

      if (found == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không tìm thấy MV này trong Thư viện ảnh (có thể đã bị xoá khỏi cả 2 nơi).')),
        );
        return;
      }

      final recoveredFile = await found.file;
      if (recoveredFile == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tìm thấy trong Thư viện ảnh nhưng không đọc được file - thử mở trực tiếp bằng app Ảnh/Thư viện của máy.')),
        );
        return;
      }

      e.mvLocalPath = recoveredFile.path;
      await ProjectHistoryStore.upsert(e);
      _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã tìm lại MV từ Thư viện ảnh.')),
      );
    } catch (exc) {
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).popUntil((route) => route.isCurrent && route is! DialogRoute);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi tìm trong Thư viện ảnh: $exc')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử dự án')),
      body: SafeArea(
        top: false,
        child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _entries.isEmpty
              ? const Center(
                  child: Text('Chưa có dự án nào được tạo.', style: TextStyle(color: Colors.grey)),
                )
              : ListView.builder(
                  itemCount: _entries.length,
                  itemBuilder: (context, i) {
                    final e = _entries[i];
                    final fileExists = _fileExistsCache[e.id] ?? false;
                    final (icon, color, statusLabel) = _statusVisual(e, fileExists);
                    final canResume = e.status == 'in_progress' || e.status == 'failed';

                    // KHÔNG dùng ListTile ở đây nữa - subtitle (ngày + trạng
                    // thái + nguồn + tên style ghép lại) có thể dài, bị
                    // ListTile giới hạn số dòng mặc định cắt mất - đúng lỗi
                    // đã sửa ở SettingsScreen nhưng quên áp dụng luôn ở đây
                    // lúc mới viết màn này (người dùng phát hiện đúng - xin
                    // lỗi, đã rà lại và sửa).
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: InkWell(
                        onTap: canResume
                            ? () => _resumeEntry(e)
                            : (fileExists ? () => OpenFilex.open(e.mvLocalPath!) : null),
                        onLongPress: () => _confirmDelete(e),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(icon, color: color),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      e.mvFilename ?? e.musicFilename ?? e.voicedFilename ?? 'Dự án chưa đặt tên',
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${_formatDate(e.updatedAt)} · $statusLabel'
                                      '${e.fromSample ? " · Từ nhạc mẫu" : " · Từ text"}'
                                      '${e.styleId != null ? " · ${e.styleId}" : ""}',
                                      style: const TextStyle(fontSize: 12, color: Colors.grey), // KHÔNG maxLines/overflow -> hiện đủ, tự xuống dòng
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              canResume
                                  ? FilledButton.tonal(
                                      onPressed: () => _resumeEntry(e),
                                      child: const Text('Tiếp tục'),
                                    )
                                  : PopupMenuButton<String>(
                                      onSelected: (v) {
                                        if (v == 'delete') _confirmDelete(e);
                                        if (v == 'recover') _tryRecoverFromGallery(e);
                                      },
                                      itemBuilder: (_) => [
                                        if (fileExists) const PopupMenuItem(value: 'open', child: Text('Mở')),
                                        // MỚI - chỉ hiện khi file làm việc bị mất VÀ dự án này có tên file MV để dò
                                        if (!fileExists && e.mvFilename != null)
                                          const PopupMenuItem(value: 'recover', child: Text('Tìm trong Thư viện ảnh')),
                                        const PopupMenuItem(value: 'delete', child: Text('Xoá khỏi lịch sử')),
                                      ],
                                    ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
    );
  }
}
