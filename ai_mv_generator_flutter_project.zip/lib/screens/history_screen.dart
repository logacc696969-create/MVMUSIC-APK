import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import '../project_history.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<ProjectHistoryEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await ProjectHistoryStore.load();
    if (mounted) setState(() {
      _entries = entries;
      _loading = false;
    });
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final sameDay = dt.year == now.year && dt.month == now.month && dt.day == now.day;
    final time = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return sameDay ? 'Hôm nay, $time' : '${dt.day}/${dt.month}/${dt.year}, $time';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử dự án')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _entries.isEmpty
              ? const Center(
                  child: Text('Chưa có dự án nào được tạo.', style: TextStyle(color: Colors.grey)),
                )
              : ListView.builder(
                  itemCount: _entries.length,
                  itemBuilder: (context, i) {
                    final e = _entries[i];
                    final fileExists = e.mvLocalPath != null && File(e.mvLocalPath!).existsSync();
                    return ListTile(
                      leading: Icon(
                        fileExists ? Icons.movie : Icons.movie_outlined,
                        color: fileExists ? Colors.green : Colors.grey,
                      ),
                      title: Text(e.mvFilename),
                      subtitle: Text(
                        '${_formatDate(e.createdAt)} · ${e.fromSample ? "Từ nhạc mẫu" : "Từ text"}'
                        '${e.styleId != null ? " · ${e.styleId}" : ""}'
                        '${fileExists ? "" : " · File không còn trên máy"}',
                      ),
                      trailing: fileExists ? const Icon(Icons.play_arrow) : null,
                      onTap: fileExists ? () => OpenFilex.open(e.mvLocalPath!) : null,
                    );
                  },
                ),
    );
  }
}
