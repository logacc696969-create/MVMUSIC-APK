import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:share_plus/share_plus.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../project_history.dart';
import '../widgets/skeleton.dart';
import 'generating_screen.dart';
import 'video_with_lyrics_screen.dart';

import '../l10n.dart';
class HistoryScreen extends StatefulWidget {
  final ApiService api;

  const HistoryScreen({super.key, required this.api});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<ProjectHistoryEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // MỚI - "I/O bất đồng bộ lịch sử dự án": TRƯỚC ĐÂY `File(...).existsSync()`
  // (đồng bộ, chặn UI thread) được gọi TRONG `itemBuilder` - tức là chạy lại
  // MỖI LẦN widget rebuild (không chỉ 1 lần khi tải danh sách) - trên máy có
  // tốc độ đọc/ghi bộ nhớ chậm (eMMC đời cũ), việc này có thể làm khựng UI
  // khi cuộn/mở màn Lịch sử với nhiều dự án. Chuyển sang kiểm tra BẤT ĐỒNG BỘ
  // (`File(...).exists()`), chạy // SONG SONG cho mọi bản ghi qua
  // `Future.wait` NGAY KHI TẢI danh sách (1 lần), kết quả lưu vào map
  // `_fileExistsCache` để `itemBuilder` chỉ đọc lại (không tự đi kiểm tra đĩa
  // cứng nữa mỗi lần vẽ).
  final Map<String, bool> _fileExistsCache = {};

  // MỚI (CHANGELOG mục 21) - 3 file phụ đã được LƯU vào lịch sử từ mục 15
  // nhưng màn này từng KHÔNG đọc/hiển thị chúng (chỉ đọc `mvLocalPath`) -
  // dữ liệu lưu đúng nhưng người dùng không có cách nào mở lại thumbnail/
  // bản dọc 9:16/phụ đề chạy chữ của 1 dự án cũ. Dùng CÙNG nguyên tắc kiểm
  // tra BẤT ĐỒNG BỘ + cache ở trên (không gọi existsSync trong itemBuilder).
  final Map<String, bool> _thumbExistsCache = {};
  final Map<String, bool> _verticalExistsCache = {};
  final Map<String, bool> _lyricsExistsCache = {};

  Future<bool> _safeExists(String? path) async {
    if (path == null) return false;
    try {
      return await File(path).exists();
    } catch (_) {
      return false;
    }
  }

  Future<void> _load() async {
    final entries = await ProjectHistoryStore.load();
    // Khởi chạy CẢ 4 nhóm kiểm tra cùng lúc (mỗi nhóm lại chạy song song cho
    // mọi bản ghi) rồi mới đợi - không đợi tuần tự từng nhóm.
    final mvF = Future.wait(entries.map((e) => _safeExists(e.mvLocalPath)));
    final thumbF = Future.wait(entries.map((e) => _safeExists(e.thumbnailImagePath)));
    final verticalF = Future.wait(entries.map((e) => _safeExists(e.mvVerticalLocalPath)));
    final lyricsF = Future.wait(entries.map((e) => _safeExists(e.lyricsTimestampsPath)));
    final mvOk = await mvF;
    final thumbOk = await thumbF;
    final verticalOk = await verticalF;
    final lyricsOk = await lyricsF;
    if (mounted) {
      setState(() {
        _entries = entries;
        _fileExistsCache
          ..clear()
          ..addEntries(List.generate(entries.length, (i) => MapEntry(entries[i].id, mvOk[i])));
        _thumbExistsCache
          ..clear()
          ..addEntries(List.generate(entries.length, (i) => MapEntry(entries[i].id, thumbOk[i])));
        _verticalExistsCache
          ..clear()
          ..addEntries(List.generate(entries.length, (i) => MapEntry(entries[i].id, verticalOk[i])));
        _lyricsExistsCache
          ..clear()
          ..addEntries(List.generate(entries.length, (i) => MapEntry(entries[i].id, lyricsOk[i])));
        _loading = false;
      });
    }
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final sameDay = dt.year == now.year && dt.month == now.month && dt.day == now.day;
    final time = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return sameDay ? trv('Hôm nay, {0}', [time]) : '${dt.day}/${dt.month}/${dt.year}, $time';
  }

  (IconData, Color, String) _statusVisual(ProjectHistoryEntry e, bool fileExists) {
    switch (e.status) {
      case 'in_progress':
        return (Icons.hourglass_top, Colors.orange, tr('Đang tạo dở - bấm để tiếp tục'));
      case 'failed':
        return (Icons.error_outline, Colors.red, tr('Bị lỗi giữa chừng - bấm để thử tiếp tục'));
      case 'cancelled':
        return (Icons.cancel_outlined, Colors.grey, tr('Đã huỷ'));
      default: // 'completed'
        return fileExists
            ? (Icons.movie, Colors.green, tr('Đã xong'))
            : (Icons.movie_outlined, Colors.grey, tr('Đã xong - file không còn trên máy'));
    }
  }

  /// Dựng lại 1 ProjectData TỪ bản ghi lịch sử đã lưu, kèm `historyId`/
  /// `historyCreatedAt` (để GeneratingScreen cập nhật ĐÚNG bản ghi này thay
  /// vì tạo bản ghi mới) - đây LÀ cơ chế "tiếp tục sau khi app bị đóng hẳn"
  /// mà trước đây KHÔNG làm được (xem ghi chú đầu project_history.dart).
  void _resumeEntry(ProjectHistoryEntry e) {
    final project = ProjectData()
      ..fromSample = e.fromSample
      ..musicFilename = e.musicFilename
      ..voicedFilename = e.voicedFilename
      ..styleId = e.styleId
      ..lyrics = e.lyrics
      ..estimatedSceneCount = e.estimatedSceneCount
      ..scenePrompts = e.scenePrompts
      ..mvSceneDirId = e.mvSceneDirId
      ..historyId = e.id
      ..historyCreatedAt = e.createdAt;

    // videoBackend/genre/characterDesc KHÔNG nằm trong ProjectData - chúng
    // là CÀI ĐẶT CHUNG (GenerationSettings, singleton toàn app), không phải
    // thuộc tính riêng từng dự án (lỗi build #56 xác nhận đúng NGAY chỗ này:
    // `characterDesc` cũng bị viết nhầm vào cascade ProjectData ở trên, dù
    // đã tự nhắc bài học y hệt cho videoBackend/genre ngay bên dưới - lần
    // này áp dụng cho cả 3, không sót). Nếu không khôi phục lại đúng các giá
    // trị này trước khi tiếp tục, job có thể vô tình dùng NHẦM cài đặt hiện
    // tại (nếu người dùng đã đổi cài đặt sau lần tạo dự án này) - các cảnh ĐÃ
    // xong (vd .gif từ AnimateDiff) ghép chung với cảnh MỚI sinh bằng backend
    // KHÁC (vd .mp4 từ Wan2.2) có thể lỗi lúc ghép video cuối.
    final s = GenerationSettings.instance;
    if (e.videoBackend != null) s.videoBackend = e.videoBackend;
    if (e.genre != null) s.genre = e.genre;
    s.characterDesc = e.characterDesc;

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: project)),
    ).then((_) => _load()); // quay lại màn này sau khi xong -> tải lại danh sách cho đúng trạng thái mới
  }

  Future<void> _confirmDelete(ProjectHistoryEntry e) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Xoá khỏi lịch sử?')),
        content: Text(tr('Chỉ xoá bản ghi lịch sử, không xoá file MV đã lưu trên máy (nếu có).')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Xoá'))),
        ],
      ),
    );
    if (confirmed == true) {
      await ProjectHistoryStore.delete(e.id);
      _load();
    }
  }

  /// MỚI - "Khôi phục từ Thư viện ảnh": dùng khi file làm việc riêng của app
  /// (`mvLocalPath`, trong `getApplicationDocumentsDirectory()`) không còn
  /// (vd người dùng lỡ tay xoá cache/data app, cài lại app, hoặc chuyển máy)
  /// NHƯNG bản MV vẫn còn trong Thư viện ảnh của máy (do lúc tạo xong đã tự
  /// lưu vào album "AI MV Generator" qua package `gal`, xem
  /// generating_screen.dart `_trySaveToGallery`). Dò qua `photo_manager` -
  /// đọc bằng MediaStore (Android)/Photos (iOS) THẬT SỰ, không phụ thuộc
  /// đường dẫn file thô nên không bị ảnh hưởng bởi việc file cache/documents
  /// gốc còn hay mất.
  ///
  /// LƯU Ý PHẠM VI: đây là tính năng "tìm lại nếu còn", KHÔNG phải bằng
  /// chứng cho thấy `mvLocalPath` tự nhiên hay mất theo cơ chế nào - đọc kỹ
  /// code (`getApplicationDocumentsDirectory()`) thì thư mục riêng của app
  /// KHÔNG bị Android tự thu hồi quyền theo thời gian, chỉ mất khi người
  /// dùng chủ động xoá dữ liệu/gỡ app - nút này xử lý đúng những trường hợp
  /// đó, không phải "sửa lỗi Android" nào cả.
  ///
  /// CHƯA TEST TRÊN MÁY THẬT - logic dựa đúng theo tài liệu chính thức của
  /// `photo_manager` (API `PhotoManager.requestPermissionExtend`,
  /// `PhotoManager.getAssetPathList`, `AssetPathEntity.getAssetListRange`,
  /// `AssetEntity.titleAsync`/`.file`) nhưng chưa có cách chạy thử thật trên
  /// điện thoại Android/iOS ở đây - nên thử trên 1 MV cũ trước khi tin tưởng
  /// dùng thường xuyên.
  Future<void> _tryRecoverFromGallery(ProjectHistoryEntry e) async {
    if (e.mvFilename == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Dự án này chưa có tên file MV để tìm lại.'))),
      );
      return;
    }

    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Cần quyền truy cập Thư viện ảnh để tìm lại MV.'))),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        filterOption: FilterOptionGroup(
          // Lọc đúng theo tên album đã dùng lúc lưu (xem
          // generating_screen.dart: `Gal.putVideo(file.path, album: 'AI MV
          // Generator')`) - tránh phải quét TOÀN BỘ video trên máy.
        ),
      );
      AssetEntity? found;
      for (final album in albums) {
        if (album.name != 'AI MV Generator') continue;
        final assets = await album.getAssetListRange(start: 0, end: await album.assetCountAsync);
        for (final asset in assets) {
          final title = await asset.titleAsync;
          if (title == e.mvFilename) {
            found = asset;
            break;
          }
        }
        if (found != null) break;
      }

      if (!mounted) return;
      Navigator.of(context).pop(); // đóng dialog loading

      if (found == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Không tìm thấy MV này trong Thư viện ảnh (có thể đã bị xoá khỏi cả 2 nơi).'))),
        );
        return;
      }

      final recoveredFile = await found.file;
      if (recoveredFile == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Tìm thấy trong Thư viện ảnh nhưng không đọc được file - thử mở trực tiếp bằng app Ảnh/Thư viện của máy.'))),
        );
        return;
      }

      e.mvLocalPath = recoveredFile.path;
      await ProjectHistoryStore.upsert(e);
      _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Đã tìm lại MV từ Thư viện ảnh.'))),
      );
    } catch (exc) {
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).popUntil((route) => route.isCurrent && route is! DialogRoute);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(trv('Lỗi khi tìm trong Thư viện ảnh: {0}', [exc]))),
      );
    }
  }

  /// MỚI - ảnh đại diện của thẻ: dùng thumbnail tự chọn (post_processing_v2.
  /// select_best_thumbnail) nếu file còn trên máy, nếu không (dự án cũ chưa có
  /// thumbnail / file đã bị dọn / đang tạo dở) thì rơi về icon trạng thái như
  /// trước - KHÔNG bao giờ là ô trống hay lỗi đỏ. `cacheWidth` ép giải mã ảnh
  /// về kích thước nhỏ, tránh nạp ảnh gốc độ phân giải cao cho 1 ô 80px khi
  /// danh sách có nhiều dự án.
  Widget _buildLeading(ProjectHistoryEntry e, IconData icon, Color color) {
    final hasThumb = (_thumbExistsCache[e.id] ?? false) && e.thumbnailImagePath != null;
    if (!hasThumb) return Icon(icon, color: color);
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Image.file(
        File(e.thumbnailImagePath!),
        semanticLabel: tr('Ảnh đại diện của MV'),
        width: 80,
        height: 48,
        fit: BoxFit.cover,
        cacheWidth: 240,
        errorBuilder: (_, __, ___) => Icon(icon, color: color),
      ),
    );
  }

  void _playWithLyrics(ProjectHistoryEntry e) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VideoWithLyricsScreen(
          videoPath: e.mvLocalPath!,
          lyricsTimestampsPath: e.lyricsTimestampsPath,
        ),
      ),
    );
  }

  /// Xử lý lựa chọn trong menu "⋮" của 1 bản ghi. Mọi mục có trong
  /// `itemBuilder` bên dưới PHẢI có 1 nhánh ở đây - từng có mục "Mở" hiện ra
  /// mà bấm vào KHÔNG làm gì (không nhánh nào xử lý giá trị 'open').
  void _onMenuSelected(String action, ProjectHistoryEntry e) {
    switch (action) {
      case 'open':
        OpenFilex.open(e.mvLocalPath!);
        break;
      case 'share':
        Share.shareXFiles([XFile(e.mvLocalPath!)]);
        break;
      case 'open_vertical':
        OpenFilex.open(e.mvVerticalLocalPath!);
        break;
      case 'share_vertical':
        Share.shareXFiles([XFile(e.mvVerticalLocalPath!)]);
        break;
      case 'play_lyrics':
        _playWithLyrics(e);
        break;
      case 'recover':
        _tryRecoverFromGallery(e);
        break;
      case 'delete':
        _confirmDelete(e);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('Lịch sử dự án'))),
      body: SafeArea(
        top: false,
        child: _loading
          ? const SkeletonList()
          : _entries.isEmpty
              ? Center(
                  child: Text(tr('Chưa có dự án nào được tạo.'), style: TextStyle(color: Colors.grey)),
                )
              : RefreshIndicator(onRefresh: _load, child: ListView.builder(
 physics: const AlwaysScrollableScrollPhysics(),
                  itemCount: _entries.length,
                  itemBuilder: (context, i) {
                    final e = _entries[i];
                    final fileExists = _fileExistsCache[e.id] ?? false;
                    final hasVertical = _verticalExistsCache[e.id] ?? false;
                    final hasLyrics = _lyricsExistsCache[e.id] ?? false;
                    final (icon, color, statusLabel) = _statusVisual(e, fileExists);
                    final canResume = e.status == 'in_progress' || e.status == 'failed';

                    // KHÔNG dùng ListTile ở đây nữa - subtitle (ngày + trạng
                    // thái + nguồn + tên style ghép lại) có thể dài, bị
                    // ListTile giới hạn số dòng mặc định cắt mất - đúng lỗi
                    // đã sửa ở SettingsScreen nhưng quên áp dụng luôn ở đây
                    // lúc mới viết màn này (người dùng phát hiện đúng - xin
                    // lỗi, đã rà lại và sửa).
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: InkWell(
                        onTap: canResume
                            ? () => _resumeEntry(e)
                            : (fileExists ? () => OpenFilex.open(e.mvLocalPath!) : null),
                        onLongPress: () => _confirmDelete(e),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildLeading(e, icon, color),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      e.mvFilename ?? e.musicFilename ?? e.voicedFilename ?? tr('Dự án chưa đặt tên'),
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${_formatDate(e.updatedAt)} · $statusLabel'
                                      '${e.fromSample ? tr(" · Từ nhạc mẫu") : tr(" · Từ text")}'
                                      '${e.styleId != null ? " · ${e.styleId}" : ""}'
                                      '${hasVertical ? tr(" · Có bản dọc 9:16") : ""}',
                                      style: const TextStyle(fontSize: 12, color: Colors.grey), // KHÔNG maxLines/overflow -> hiện đủ, tự xuống dòng
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              canResume
                                  ? FilledButton.tonal(
                                      onPressed: () => _resumeEntry(e),
                                      child: Text(tr('Tiếp tục')),
                                    )
                                  : PopupMenuButton<String>(
                                      onSelected: (v) => _onMenuSelected(v, e),
                                      itemBuilder: (_) => [
                                        if (fileExists) PopupMenuItem(value: 'open', child: Text(tr('Mở'))),
                                        if (fileExists) PopupMenuItem(value: 'share', child: Text(tr('Chia sẻ'))),
                                        // MỚI - chỉ hiện khi file bản dọc 9:16 CÒN trên máy
                                        if (hasVertical) PopupMenuItem(value: 'open_vertical', child: Text(tr('Mở bản dọc (9:16)'))),
                                        if (hasVertical) PopupMenuItem(value: 'share_vertical', child: Text(tr('Chia sẻ bản dọc'))),
                                        // MỚI - cần CẢ file MV lẫn file mốc thời gian lời hát
                                        if (fileExists && hasLyrics)
                                          PopupMenuItem(value: 'play_lyrics', child: Text(tr('Phát kèm phụ đề chạy chữ'))),
                                        // chỉ hiện khi file làm việc bị mất VÀ dự án này có tên file MV để dò
                                        if (!fileExists && e.mvFilename != null)
                                          PopupMenuItem(value: 'recover', child: Text(tr('Tìm trong Thư viện ảnh'))),
                                        PopupMenuItem(value: 'delete', child: Text(tr('Xoá khỏi lịch sử'))),
                                      ],
                                    ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                )),
        ),
    );
  }
}
