import 'package:flutter/material.dart';
import '../api_service.dart';
import '../project_data.dart';
import 'history_screen.dart';
import 'idea_screen.dart';
import 'input_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _urlController = TextEditingController(text: 'https://xxxx.trycloudflare.com');

  void _startNewProject() {
    final api = ApiService(baseUrl: _urlController.text.trim());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => InputScreen(api: api, project: ProjectData()),
      ),
    );
  }

  void _startFromIdea() {
    final api = ApiService(baseUrl: _urlController.text.trim());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => IdeaScreen(api: api, project: ProjectData()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI MV Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Lịch sử dự án',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()));
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Cài đặt tạo dữ liệu',
            onPressed: () {
              final api = ApiService(baseUrl: _urlController.text.trim());
              Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(api: api)));
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.music_video, size: 72),
            const SizedBox(height: 16),
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: 'Backend URL (cloudflared)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _startNewProject,
                icon: const Icon(Icons.add),
                label: const Text('Tạo dự án mới'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: OutlinedButton.icon(
                onPressed: _startFromIdea,
                icon: const Icon(Icons.lightbulb_outline),
                label: const Text('Tạo từ ý tưởng (chưa cần rõ ràng)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
