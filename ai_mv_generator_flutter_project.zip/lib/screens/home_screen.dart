import 'package:flutter/material.dart';
import '../api_service.dart';
import '../project_data.dart';
import '../project_history.dart';
import 'backup_screen.dart';
import 'help_screen.dart';
import 'history_screen.dart';
import 'idea_screen.dart';
import 'input_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _urlController = TextEditingController(text: 'https://xxxx.trycloudflare.com');
  int _inProgressCount = 0; // hiện banner nếu > 0 - xem _checkInProgress()

  @override
  void initState() {
    super.initState();
    _checkInProgress();
  }

  /// Kiểm tra có dự án nào đang "in_progress"/"failed" (còn resume được)
  /// không - gọi mỗi lần màn hình này hiện lên (initState + mỗi lần quay lại
  /// từ màn khác) để phát hiện đúng dự án bị bỏ dở nếu app từng bị đóng hẳn
  /// giữa lúc đang tạo MV (xem ghi chú đầu project_history.dart).
  Future<void> _checkInProgress() async {
    final entries = await ProjectHistoryStore.load();
    final count = entries.where((e) => e.status == 'in_progress' || e.status == 'failed').length;
    if (mounted) setState(() => _inProgressCount = count);
  }

  /// MỚI - Colab free (theo colab_setup.py) chỉ nên xử lý 1 job GPU nặng
  /// tại 1 thời điểm - `progress_tracker.py` bên backend chỉ theo dõi ĐÚNG 1
  /// job (không có khoá chặn request thứ 2). Trước đây app KHÔNG cảnh báo gì
  /// nếu người dùng thoát khỏi màn "Đang tạo" bằng nút back (job trên Colab
  /// vẫn chạy tiếp, không bị huỷ) rồi bấm "Tạo dự án mới" ở đây - dễ vô tình
  /// gửi 2 lệnh tạo nặng cùng lúc, giẫm lên nhau trên cùng 1 GPU T4. Chặn lại
  /// bằng 1 hộp thoại xác nhận NẾU đang có dự án "in_progress"/"failed" chưa
  /// xử lý xong (đúng dữ liệu banner cam phía trên đang dùng).
  Future<bool> _confirmIfBusy() async {
    // MỚI - hỏi THẲNG backend qua GET /progress (nguồn sự thật đáng tin nhất -
    // không phụ thuộc lịch sử LOCAL hay cờ BackendBusyTracker trong bộ nhớ,
    // vốn mất trắng nếu app bị tắt hẳn rồi mở lại giữa lúc 1 job vẫn còn chạy
    // thật trên Colab). Best-effort: URL trống/sai/mạng lỗi -> bỏ qua bước
    // này, chỉ dựa vào _inProgressCount (lịch sử local) như cũ, KHÔNG chặn
    // oan người dùng chỉ vì đang gõ URL/mất mạng tạm thời.
    bool backendBusy = false;
    String backendStage = '';
    final url = _urlController.text.trim();
    if (url.isNotEmpty) {
      try {
        final p = await ApiService(baseUrl: url).getProgress().timeout(const Duration(seconds: 4));
        if (p['done'] != true && p['stage'] != null && p['stage'] != 'idle') {
          backendBusy = true;
          backendStage = p['stage'] as String? ?? '';
        }
      } catch (_) {
        // Không xác minh được - coi như không chắc bận, tránh chặn oan.
      }
    }

    if (_inProgressCount == 0 && !backendBusy) return true;
    final proceed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Đang có dự án dang dở'),
        content: Text(
          backendBusy
              ? 'Backend Colab đang THỰC SỰ xử lý 1 tác vụ khác (giai đoạn '
                '"$backendStage"). Tạo thêm dự án mới ngay bây giờ chắc chắn sẽ '
                'bị backend từ chối (hoặc tệ hơn nếu backend chưa kịp cập nhật) - '
                'đợi tác vụ đó xong hoặc báo lỗi rồi hãy thử lại.'
              : 'Bạn đang có $_inProgressCount dự án chưa hoàn tất. Nếu dự án đó vẫn '
                'còn chạy trên GPU Colab, tạo thêm dự án mới ngay bây giờ có thể khiến '
                '2 lệnh nặng chạy chung 1 GPU, dễ gây lỗi hoặc treo cả hai.\n\n'
                'Khuyên dùng: vào "Lịch sử dự án" kiểm tra/Tiếp tục dự án cũ trước, '
                'hoặc chắc chắn dự án cũ đã dừng hẳn (báo lỗi/hoàn tất) rồi hẵng tạo mới.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Để sau')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Vẫn tạo mới')),
        ],
      ),
    );
    return proceed == true;
  }

  void _startNewProject() async {
    if (!await _confirmIfBusy()) return;
    if (!mounted) return;
    await ProjectData.purgeTemporaryScenes(); // dọn rác cảnh tạm từ job trước
    if (!mounted) return;
    final api = ApiService(baseUrl: _urlController.text.trim());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => InputScreen(api: api, project: ProjectData()),
      ),
    );
  }

  void _startFromIdea() async {
    if (!await _confirmIfBusy()) return;
    if (!mounted) return;
    await ProjectData.purgeTemporaryScenes();
    if (!mounted) return;
    final api = ApiService(baseUrl: _urlController.text.trim());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => IdeaScreen(api: api, project: ProjectData()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI MV Generator'),
        // KHÔNG dùng hàng ngang 4 IconButton ở `actions` nữa - trên màn hình
        // hẹp, Row trong AppBar.actions KHÔNG tự cuộn/co lại khi tràn, nút ở
        // cuối (vd Sao lưu & Phục hồi) có thể bị đẩy ra ngoài rìa màn hình,
        // KHÔNG hiện ra dù code vẫn đúng - đây chính là lý do người dùng
        // không thấy nút Sao lưu/Phục hồi dù đã code xong. Đổi sang Drawer
        // (menu kéo từ cạnh trái) - không bao giờ tràn màn hình dù có thêm
        // bao nhiêu mục sau này, luôn cuộn được nếu danh sách dài.
      ),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text('AI MV Generator', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.help_outline),
                title: const Text('Trợ giúp - Cách dùng app'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Lịch sử dự án'),
                onTap: () {
                  Navigator.pop(context);
                  final api = ApiService(baseUrl: _urlController.text.trim());
                  Navigator.push(context, MaterialPageRoute(builder: (_) => HistoryScreen(api: api)))
                      .then((_) => _checkInProgress());
                },
              ),
              ListTile(
                leading: const Icon(Icons.cloud_sync_outlined),
                title: const Text('Sao lưu & Phục hồi'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupScreen()))
                      .then((_) => _checkInProgress());
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings),
                title: const Text('Cài đặt tạo dữ liệu'),
                onTap: () {
                  Navigator.pop(context);
                  final api = ApiService(baseUrl: _urlController.text.trim());
                  Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(api: api)));
                },
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_inProgressCount > 0)
              Card(
                color: Colors.orange.shade50,
                child: InkWell(
                  onTap: () {
                    final api = ApiService(baseUrl: _urlController.text.trim());
                    Navigator.push(context, MaterialPageRoute(builder: (_) => HistoryScreen(api: api)))
                        .then((_) => _checkInProgress());
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.hourglass_top, color: Colors.orange),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Có $_inProgressCount dự án đang tạo dở', style: const TextStyle(fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              const Text('Bấm để xem và tiếp tục - các cảnh đã xong vẫn còn nguyên trên Drive', style: TextStyle(fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right),
                      ],
                    ),
                  ),
                ),
              ),
            if (_inProgressCount > 0) const SizedBox(height: 16),
            const Icon(Icons.music_video, size: 72),
            const SizedBox(height: 16),
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: 'Backend URL (cloudflared)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _startNewProject,
                icon: const Icon(Icons.add),
                label: const Text('Tạo dự án mới'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: OutlinedButton.icon(
                onPressed: _startFromIdea,
                icon: const Icon(Icons.lightbulb_outline),
                label: const Text('Tạo từ ý tưởng (chưa cần rõ ràng)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
