import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../progress_poller.dart';
import '../project_data.dart';
import 'variant_picker_screen.dart';
import 'voice_screen.dart';

enum _MusicChoice { aiCompose, bringOwn }

/// Màn hình MỚI - "Tạo từ ý tưởng": khác `InputScreen` (yêu cầu mô tả PHONG
/// CÁCH nhạc rõ ràng), màn này chấp nhận input LỎNG LẺO hơn nhiều - 1 ý
/// tưởng thoáng qua ("về nỗi nhớ mùa hè") hoặc vài câu lời phác thảo, KHÔNG
/// cần cấu trúc/hoàn chỉnh. "Nhạc thì tuỳ chọn" có 2 CHIỀU (không chỉ 1):
///   (1) AI soạn nhạc HAY dùng nhạc có sẵn của mình (KHÔNG qua AI, không tốn
///       GPU) - `_MusicChoice`.
///   (2) NẾU chọn để AI soạn: có thể CHỌN THỂ LOẠI/GIAI ĐIỆU mong muốn (chip
///       đa lựa chọn, tuỳ chọn) thay vì chỉ dựa vào mỗi ý tưởng thô - vì 1 ý
///       tưởng ("về nỗi nhớ mùa hè") không tự nói lên được đây là ballad hay
///       EDM hay nhạc dân gian - người dùng CÓ THỂ chưa hình dung ra nhạc,
///       nhưng biết mình thích thể loại/giai điệu nào.
/// MV vẫn dựa trên ý tưởng/lời phác thảo qua bước Storyboard (mục 7s) dù
/// nhạc có phải AI tạo hay không.
///
/// KHÔNG có bước "làm rõ ý tưởng" bằng AI/LLM ở đây - dự án này không tích
/// hợp model ngôn ngữ tổng quát nào (chỉ có ACE-Step/AnimateDiff/RVC/Demucs,
/// đều là model chuyên biệt, không sinh văn bản tự do được) - ý tưởng gõ vào
/// được DÙNG THẲNG làm `prompt` (ACE-Step chấp nhận mô tả tự do, không bắt
/// buộc đúng cấu trúc "phong cách nhạc"), CỘNG THÊM thể loại/giai điệu đã
/// chọn (nếu có) nối vào cuối - không có bước "AI viết lại cho hay hơn".
class IdeaScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const IdeaScreen({super.key, required this.api, required this.project});

  @override
  State<IdeaScreen> createState() => _IdeaScreenState();
}

class _IdeaScreenState extends State<IdeaScreen> {
  final _ideaController = TextEditingController();
  _MusicChoice _musicChoice = _MusicChoice.aiCompose;
  File? _ownMusicFile;

  // Thể loại/giai điệu mong muốn - TUỲ CHỌN, chỉ dùng khi _musicChoice ==
  // aiCompose. Danh sách CỐ ĐỊNH, đơn giản ở phía Flutter (không cần round-
  // trip lên backend như style video vì chỉ là CHỮ nối thêm vào prompt, không
  // cần backend "dịch" sang mô tả kỹ thuật riêng như VIDEO_STYLE_PRESETS).
  static const _genreOptions = [
    'Pop', 'Ballad', 'EDM', 'Rock', 'Acoustic/mộc', 'Lo-fi chill',
    'Rap/Hip-hop', 'Nhạc trữ tình', 'Nhạc phim/Cinematic', 'Dân gian',
  ];
  static const _moodOptions = [
    'Vui tươi, sôi động', 'Nhẹ nhàng, sâu lắng', 'Buồn, da diết', 'Hào hùng, mạnh mẽ',
  ];
  final Set<String> _selectedGenres = {};
  final Set<String> _selectedMoods = {};
  bool _busy = false;
  String? _error;
  int _percent = 0;
  String _stageDetail = '';

  static const _allowedExtensions = {'mp3', 'wav', 'm4a'};
  static const _maxBytes = 15 * 1024 * 1024;

  Future<void> _pickOwnMusic() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result == null || result.files.single.path == null) return;
    if (!mounted) return;
    final path = result.files.single.path!;
    final ext = path.split('.').last.toLowerCase();
    final size = File(path).lengthSync();
    if (!_allowedExtensions.contains(ext)) {
      setState(() => _error = 'Chỉ nhận file mp3/wav/m4a.');
      return;
    }
    if (size > _maxBytes) {
      setState(() => _error = 'File quá lớn (>15MB) - đường truyền tunnel có giới hạn.');
      return;
    }
    setState(() {
      _ownMusicFile = File(path);
      _error = null;
    });
  }

  Future<void> _next() async {
    final idea = _ideaController.text.trim();
    if (idea.isEmpty) {
      setState(() => _error = 'Nhập ý tưởng hoặc vài câu lời phác thảo trước đã.');
      return;
    }
    if (_musicChoice == _MusicChoice.bringOwn && _ownMusicFile == null) {
      setState(() => _error = 'Chọn 1 file nhạc có sẵn trước đã.');
      return;
    }

    // Lời phác thảo được LƯU LẠI dù chọn đường nào - Storyboard (mục 7s) vẫn
    // dùng được để chia gợi ý hình ảnh theo cảnh, kể cả khi nhạc là do người
    // dùng tự mang tới (không qua AI, không có "lyrics" thật sự đi kèm nhạc).
    widget.project.lyrics = idea;
    // fromSample điều khiển việc VoiceScreen có hiện ghi chú "sẽ tự tách
    // giọng khỏi nhạc nền trước khi đổi giọng" hay không (xem voice_screen.
    // dart) - đúng ra PHẢI hiện cho CẢ đường "AI soạn" (apply_voice() luôn
    // chạy Demucs tách giọng bất kể nguồn gốc file - xem app.py), nhưng đó là
    // hành vi UI CÓ SẴN TỪ TRƯỚC (InputScreen cũng chỉ hiện khi fromSample=
    // true dù generate_music() cũng bị tách giọng y hệt) - KHÔNG sửa ở đây để
    // tránh lấn sang phạm vi ngoài yêu cầu. Chỉ đảm bảo IdeaScreen áp dụng
    // ĐÚNG quy ước tương tự: true khi mang nhạc có sẵn (nhiều khả năng đã có
    // giọng hát thật, ghi chú này hữu ích) - false khi để AI soạn (giống
    // generateMusic() ở InputScreen dùng false).
    widget.project.fromSample = _musicChoice == _MusicChoice.bringOwn;

    setState(() {
      _busy = true;
      _error = null;
      _percent = 0;
      _stageDetail = 'Đang bắt đầu...';
    });

    try {
      if (_musicChoice == _MusicChoice.bringOwn) {
        final result = await widget.api.uploadMusic(audioFile: _ownMusicFile!);
        widget.project.musicFilename = result['file'];
        if (!mounted) return;
        Navigator.push(context, MaterialPageRoute(builder: (_) => VoiceScreen(api: widget.api, project: widget.project)));
        return;
      }

      final poller = ProgressPoller(
        api: widget.api,
        onUpdate: (percent, stage, detail) {
          if (mounted) setState(() {
            _percent = percent;
            _stageDetail = detail;
          });
        },
      );
      poller.start();
      try {
        final s = GenerationSettings.instance;
        // Ý tưởng gõ vào là gốc của prompt - CỘNG THÊM thể loại/giai điệu đã
        // chọn (nếu có) nối vào cuối, để người dùng CHƯA hình dung ra nhạc cụ
        // thể nhưng biết mình thích thể loại/giai điệu nào vẫn định hướng
        // được AI, không chỉ phụ thuộc mỗi câu ý tưởng thô.
        final styleParts = [..._selectedGenres, ..._selectedMoods];
        final musicPrompt = styleParts.isEmpty ? idea : '$idea, thể loại: ${styleParts.join(", ")}';
        final result = await widget.api.generateMusic(
          prompt: musicPrompt,
          lyrics: idea,
          duration: s.duration,
          gpuPower: s.gpuPower,
          numVariants: s.generateVariants ? 2 : 1,
        );

        if (!mounted) return;
        final files = (result['files'] as List?)?.cast<String>();
        if (files != null && files.length > 1) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => VariantPickerScreen(api: widget.api, project: widget.project, variantFilenames: files),
            ),
          );
          return;
        }
        widget.project.musicFilename = result['file'];
        Navigator.push(context, MaterialPageRoute(builder: (_) => VoiceScreen(api: widget.api, project: widget.project)));
      } finally {
        poller.stop();
      }
    } catch (e) {
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây
      setState(() => _error = 'Lỗi: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tạo từ ý tưởng')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Gõ 1 ý tưởng thoáng qua (vd: "nỗi nhớ về một mùa hè đã qua") hoặc vài '
              'câu lời bạn mới nghĩ ra, dở dang cũng được - không cần chỉn chu.',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _ideaController,
              maxLines: 6,
              enabled: !_busy,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'vd: về nỗi nhớ quê hương, có tiếng ve, cánh diều tuổi thơ...',
              ),
            ),
            const SizedBox(height: 20),
            Text('Nhạc', style: Theme.of(context).textTheme.titleMedium),
            RadioListTile<_MusicChoice>(
              contentPadding: EdgeInsets.zero,
              title: const Text('Để AI tự soạn nhạc từ ý tưởng này'),
              value: _MusicChoice.aiCompose,
              groupValue: _musicChoice,
              onChanged: _busy ? null : (v) => setState(() => _musicChoice = v!),
            ),
            if (_musicChoice == _MusicChoice.aiCompose) ...[
              const SizedBox(height: 4),
              const Padding(
                padding: EdgeInsets.only(left: 12),
                child: Text(
                  'Chưa hình dung rõ nhạc thế nào cũng không sao - chọn thể loại/giai '
                  'điệu bạn thích bên dưới (tuỳ chọn), AI sẽ soạn theo hướng đó.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: _genreOptions.map((g) => FilterChip(
                        label: Text(g, style: const TextStyle(fontSize: 12)),
                        selected: _selectedGenres.contains(g),
                        onSelected: _busy ? null : (sel) => setState(() {
                          sel ? _selectedGenres.add(g) : _selectedGenres.remove(g);
                        }),
                      )).toList(),
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: _moodOptions.map((m) => FilterChip(
                        label: Text(m, style: const TextStyle(fontSize: 12)),
                        selected: _selectedMoods.contains(m),
                        onSelected: _busy ? null : (sel) => setState(() {
                          sel ? _selectedMoods.add(m) : _selectedMoods.remove(m);
                        }),
                      )).toList(),
                ),
              ),
            ],
            RadioListTile<_MusicChoice>(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tôi đã có sẵn nhạc, chỉ cần làm MV'),
              subtitle: const Text(
                'Dùng thẳng file nhạc của bạn, không qua AI, không tốn GPU cho bước này.',
                style: TextStyle(fontSize: 12),
              ),
              value: _MusicChoice.bringOwn,
              groupValue: _musicChoice,
              onChanged: _busy ? null : (v) => setState(() => _musicChoice = v!),
            ),
            if (_musicChoice == _MusicChoice.bringOwn) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: _busy ? null : _pickOwnMusic,
                icon: const Icon(Icons.audio_file),
                label: Text(_ownMusicFile == null
                    ? 'Chọn file nhạc'
                    : 'Đã chọn: ${_ownMusicFile!.path.split('/').last}'),
              ),
            ],
            const SizedBox(height: 24),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            if (_busy) ...[
              LinearProgressIndicator(value: _percent > 0 ? _percent / 100 : null),
              const SizedBox(height: 8),
              Text('$_percent% — $_stageDetail', style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 16),
            ],
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _busy ? null : _next,
                child: Text(_busy
                    ? 'Đang xử lý...'
                    : _musicChoice == _MusicChoice.aiCompose
                        ? 'Tạo nhạc từ ý tưởng'
                        : 'Tiếp tục'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
