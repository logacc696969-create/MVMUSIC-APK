import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../progress_poller.dart';
import 'voice_screen.dart';
import 'variant_picker_screen.dart';

class InputScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const InputScreen({super.key, required this.api, required this.project});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  bool _fromSample = false;
  final _promptController = TextEditingController();
  final _lyricsController = TextEditingController();
  File? _pickedFile;
  double _similarity = GenerationSettings.instance.similarity; // thấp = biến tấu nhiều
  bool _busy = false;
  String? _error;
  int _percent = 0;
  String _stageDetail = '';

  static const _allowedExtensions = {'mp3', 'wav', 'm4a'};
  static const _maxSampleBytes = 15 * 1024 * 1024; // 15MB - tránh làm nghẽn băng thông tunnel

  Future<void> _pickSampleFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result == null || result.files.single.path == null) return;

    final path = result.files.single.path!;
    final ext = path.split('.').last.toLowerCase();
    if (!_allowedExtensions.contains(ext)) {
      setState(() => _error = 'Chỉ hỗ trợ file .mp3, .wav, .m4a (file bạn chọn là .$ext).');
      return;
    }

    final file = File(path);
    final size = await file.length();
    if (size > _maxSampleBytes) {
      setState(() => _error =
          'File quá lớn (${(size / 1024 / 1024).toStringAsFixed(1)}MB) - giới hạn 15MB cho nhạc mẫu.');
      return;
    }

    setState(() {
      _pickedFile = file;
      _error = null;
    });
  }

  Future<void> _next() async {
    if (!_fromSample && _promptController.text.trim().isEmpty) {
      setState(() => _error = 'Nhập mô tả bài nhạc trước đã.');
      return;
    }
    if (_fromSample && _pickedFile == null) {
      setState(() => _error = 'Chọn 1 file nhạc mẫu trước đã.');
      return;
    }

    widget.project.fromSample = _fromSample;
    widget.project.textPrompt = _promptController.text.trim();
    widget.project.lyrics = _lyricsController.text.trim();
    widget.project.sampleFile = _pickedFile;

    setState(() {
      _busy = true;
      _error = null;
      _percent = 0;
      _stageDetail = 'Đang bắt đầu...';
    });

    final poller = ProgressPoller(
      api: widget.api,
      onUpdate: (percent, stage, detail) {
        if (mounted) setState(() {
          _percent = percent;
          _stageDetail = detail;
        });
      },
    );
    poller.start();

    try {
      final s = GenerationSettings.instance;
      final result = _fromSample
          ? await widget.api.remixMusic(
              sampleFile: _pickedFile!,
              stylePrompt: _promptController.text.trim(),
              similarity: _similarity,
              duration: s.duration,
              gpuPower: s.gpuPower,
              numVariants: s.generateVariants ? 2 : 1,
            )
          : await widget.api.generateMusic(
              prompt: _promptController.text.trim(),
              lyrics: _lyricsController.text.trim(),
              duration: s.duration,
              gpuPower: s.gpuPower,
              numVariants: s.generateVariants ? 2 : 1,
            );

      if (!mounted) return;

      // "files" là field MỚI - nếu backend trả về nhiều hơn 1 bản (đã bật
      // "Tạo 2 bản để chọn"), cho người dùng nghe thử/chọn trước khi tiếp
      // tục, thay vì tự động lấy bản đầu tiên như hành vi CŨ.
      final files = (result['files'] as List?)?.cast<String>();
      if (files != null && files.length > 1) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VariantPickerScreen(api: widget.api, project: widget.project, variantFilenames: files),
          ),
        );
        return;
      }

      widget.project.musicFilename = result['file'];
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VoiceScreen(api: widget.api, project: widget.project),
        ),
      );
    } catch (e) {
      setState(() => _error = 'Lỗi tạo nhạc: $e');
    } finally {
      poller.stop();
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bước 1: Nhập liệu')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Nhập text'), icon: Icon(Icons.edit)),
                ButtonSegment(value: true, label: Text('Nhạc mẫu'), icon: Icon(Icons.upload_file)),
              ],
              selected: {_fromSample},
              onSelectionChanged: (s) => setState(() => _fromSample = s.first),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _promptController,
              maxLines: 2,
              decoration: InputDecoration(
                labelText: _fromSample
                    ? 'Mô tả phong cách muốn biến tấu (vd: sôi động hơn, thêm guitar điện)'
                    : 'Mô tả bài nhạc muốn tạo (vd: nhạc pop vui tươi, có guitar)',
                border: const OutlineInputBorder(),
              ),
            ),
            if (!_fromSample) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _lyricsController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Lời bài hát (tuỳ chọn, để trống nếu chỉ cần nhạc nền)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 6),
              // Chèn nhanh nhãn cấu trúc lời bài hát - ACE-Step (model tạo
              // nhạc backend đang dùng) CHÍNH THỨC khuyến nghị cấu trúc lời
              // theo dạng này (docs: "Lyrics should be structured with tags
              // like [verse], [chorus], [bridge], etc.") - giống hệt cách
              // Suno/Udio làm, không phải tự bịa ra.
              Wrap(
                spacing: 6,
                children: [
                  '[verse]', '[chorus]', '[bridge]', '[intro]', '[outro]'
                ].map((tag) => ActionChip(
                      label: Text(tag, style: const TextStyle(fontSize: 12)),
                      onPressed: () {
                        final sel = _lyricsController.selection;
                        final text = _lyricsController.text;
                        final insertAt = sel.start >= 0 ? sel.start : text.length;
                        final newText = '${text.substring(0, insertAt)}\n$tag\n${text.substring(insertAt)}';
                        _lyricsController.value = TextEditingValue(
                          text: newText,
                          selection: TextSelection.collapsed(offset: insertAt + tag.length + 2),
                        );
                      },
                    )).toList(),
              ),
            ],
            if (_fromSample) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _pickSampleFile,
                icon: const Icon(Icons.audio_file),
                label: Text(_pickedFile == null
                    ? 'Chọn file nhạc mẫu'
                    : 'Đã chọn: ${_pickedFile!.path.split('/').last}'),
              ),
              const SizedBox(height: 16),
              Text(
                'Mức độ biến tấu: ${_similarity < 0.4 ? "Khác nhiều (~90%), giữ thể loại/giai điệu tương đương" : _similarity < 0.7 ? "Vừa phải" : "Bám sát bản gốc"}',
                style: const TextStyle(fontSize: 13),
              ),
              Row(
                children: [
                  const Text('Khác nhiều'),
                  Expanded(
                    child: Slider(
                      value: _similarity,
                      min: 0.1,
                      max: 0.9,
                      divisions: 8,
                      label: _similarity.toStringAsFixed(1),
                      onChanged: (v) => setState(() {
                        _similarity = v;
                        GenerationSettings.instance.similarity = v;
                      }),
                    ),
                  ),
                  const Text('Bám sát gốc'),
                ],
              ),
            ],
            const SizedBox(height: 24),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('Tạo 2 bản để chọn (giống Suno/Udio)'),
              subtitle: const Text(
                'Nghe thử cả 2 rồi chọn bản ưng ý nhất. Tốn gần gấp đôi thời gian '
                'GPU so với chỉ tạo 1 bản.',
                style: TextStyle(fontSize: 12),
              ),
              value: GenerationSettings.instance.generateVariants,
              onChanged: (v) => setState(() => GenerationSettings.instance.generateVariants = v ?? false),
            ),
            const SizedBox(height: 8),
            if (_error != null)
              Text(_error!, style: const TextStyle(color: Colors.red)),
            if (_busy) ...[
              const SizedBox(height: 12),
              LinearProgressIndicator(value: _percent / 100),
              const SizedBox(height: 6),
              Text('$_percent% — $_stageDetail', style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 12),
            ],
            ElevatedButton(
              onPressed: _busy ? null : _next,
              child: const Text('Tạo nhạc và tiếp tục'),
            ),
          ],
        ),
      ),
    );
  }
}
