import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../consent.dart';
import 'package:file_picker/file_picker.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../quick_mode.dart';
import '../progress_poller.dart';
import '../widgets/mv_template_picker.dart';
import 'voice_screen.dart';
import 'variant_picker_screen.dart';

import '../l10n.dart';
class InputScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const InputScreen({super.key, required this.api, required this.project});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  bool _fromSample = false;
  final _promptController = TextEditingController();
  final _lyricsController = TextEditingController();
  final _coverOriginalLyricsController = TextEditingController(); // lời GỐC (Hoa/nước ngoài) - chỉ dùng khi cover từ nhạc mẫu
  final _coverVietnameseLyricsController = TextEditingController(); // lời VIỆT - kết quả dịch (hoặc tự gõ tay), gửi vào remixMusic
  bool _translatingLyrics = false;
  String? _translateError;
  File? _pickedFile;
  double _similarity = GenerationSettings.instance.similarity; // thấp = biến tấu nhiều
  bool _busy = false;
  String? _error;
  int _percent = 0;
  String _stageDetail = '';

  static const _allowedExtensions = {'mp3', 'wav', 'm4a'};
  static const _maxSampleBytes = 15 * 1024 * 1024; // 15MB - tránh làm nghẽn băng thông tunnel

  final _youtubeUrlController = TextEditingController(); // link YouTube - dùng khi không có sẵn file nhạc
  String? _sampleFilenameOnServer; // tên file mẫu ĐÃ CÓ trên server (từ upload trước hoặc tải YouTube) - dùng để phiên âm lời + tránh upload lại lần 2 lúc tạo
  bool _uploadingSample = false; // đang tải file mẫu lên server (ngay sau khi chọn file, KHÔNG đợi tới lúc bấm Tạo)
  bool _downloadingYoutube = false;
  bool _transcribing = false;
  String _transcribeStageDetail = '';
  String? _lyricsLanguageHint; // null = để AI tự đoán ngôn ngữ (model phiên âm hiện dùng Qwen3-ASR, xem tài liệu kỹ thuật)
  String? _sampleActionError; // lỗi riêng cho khối "chuẩn bị nhạc mẫu" (khác _error dùng cho lỗi tạo nhạc)

  Future<void> _uploadPickedFileToServer(File file) async {
    if (!await ensureConsent(context, key: 'audio_rights', title: tr(kConsentAudioTitle), message: tr(kConsentAudioMessage))) return;
    if (!mounted) return;
    setState(() {
      _uploadingSample = true;
      _sampleActionError = null;
      _sampleFilenameOnServer = null; // file mới -> phải upload lại, huỷ tên file cũ (nếu có)
    });
    try {
      final result = await widget.api.uploadSampleAudio(audioFile: file);
      if (!mounted) return;
      if (result['status'] == 'ok') {
        setState(() => _sampleFilenameOnServer = result['filename'] as String);
      } else {
        setState(() => _sampleActionError = tr('Không tải file lên server được - vẫn có thể tạo, nhưng chưa lấy lời tự động được.'));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _sampleActionError = tr('Lỗi tải file lên server - vẫn có thể tạo, nhưng chưa lấy lời tự động được.'));
      }
    } finally {
      if (mounted) setState(() => _uploadingSample = false);
    }
  }

  Future<void> _downloadFromYoutube() async {
    final url = _youtubeUrlController.text.trim();
    if (url.isEmpty) return;
    if (!await ensureConsent(context, key: 'audio_rights', title: tr(kConsentAudioTitle), message: tr(kConsentAudioMessage))) return;
    if (!mounted) return;
    setState(() {
      _downloadingYoutube = true;
      _sampleActionError = null;
      _pickedFile = null; // nguồn giờ là YouTube, không phải file local nữa
      _sampleFilenameOnServer = null;
    });
    try {
      final result = await widget.api.downloadYoutubeAudio(url: url);
      if (!mounted) return;
      if (result['status'] == 'ok') {
        setState(() => _sampleFilenameOnServer = result['filename'] as String);
      } else {
        setState(() => _sampleActionError = result['note']?.toString() ?? tr('Không tải được từ link này.'));
      }
    } catch (e) {
      if (mounted) setState(() => _sampleActionError = trv('Lỗi tải từ link: {0}', [e]));
    } finally {
      if (mounted) setState(() => _downloadingYoutube = false);
    }
  }

  Future<void> _transcribeLyricsFromSample() async {
    if (_sampleFilenameOnServer == null) return;
    setState(() {
      _transcribing = true;
      _transcribeStageDetail = tr('Đang bắt đầu...');
      _translateError = null;
    });
    // MỚI - endpoint /transcribe-lyrics giờ báo tiến trình chi tiết qua
    // progress_tracker (backend chạy ĐỒNG BỘ, không phải job nền như
    // /generate-mv - nên phải tự poll /progress SONG SONG với request chính
    // đang chờ, không đợi request chính xong rồi mới poll như ProgressPoller
    // thường dùng cho job nền). Best-effort thuần UI - lỗi polling không ảnh
    // hưởng kết quả thật (vẫn lấy từ response của transcribeLyrics()).
    final pollTimer = Timer.periodic(const Duration(milliseconds: 1200), (_) async {
      try {
        final p = await widget.api.getProgress();
        if (mounted && p['stage'] == 'transcribe') {
          setState(() => _transcribeStageDetail = p['detail'] as String? ?? '');
        }
      } catch (_) {
        // Bỏ qua - chỉ là hiển thị phụ, không phải nguồn dữ liệu chính.
      }
    });
    try {
      final result = await widget.api.transcribeLyrics(
        sampleFilename: _sampleFilenameOnServer!,
        languageHint: _lyricsLanguageHint ?? '',
      );
      if (!mounted) return;
      if (result['status'] == 'ok') {
        setState(() => _coverOriginalLyricsController.text = result['transcribed_lyrics'] as String);
      } else {
        setState(() => _translateError = result['note']?.toString() ?? tr('Không lấy được lời từ nhạc.'));
      }
    } catch (e) {
      if (mounted) setState(() => _translateError = trv('Lỗi lấy lời từ nhạc: {0}', [e]));
    } finally {
      pollTimer.cancel();
      if (mounted) setState(() => _transcribing = false);
    }
  }

  Future<void> _translateLyricsToVietnamese() async {
    final original = _coverOriginalLyricsController.text.trim();
    if (original.isEmpty) return;
    setState(() {
      _translatingLyrics = true;
      _translateError = null;
    });
    try {
      final result = await widget.api.translateLyrics(lyrics: original);
      if (!mounted) return;
      if (result['status'] == 'ok') {
        setState(() => _coverVietnameseLyricsController.text = result['translated_lyrics'] as String);
      } else {
        setState(() => _translateError = result['note']?.toString() ?? tr('Không dịch được, thử lại sau.'));
      }
    } catch (e) {
      if (mounted) setState(() => _translateError = trv('Lỗi dịch lời: {0}', [e]));
    } finally {
      if (mounted) setState(() => _translatingLyrics = false);
    }
  }

  Future<void> _pickSampleFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result == null || result.files.single.path == null) return;
    if (!mounted) return;

    final path = result.files.single.path!;
    final ext = path.split('.').last.toLowerCase();
    if (!_allowedExtensions.contains(ext)) {
      setState(() => _error = trv('Chỉ hỗ trợ file .mp3, .wav, .m4a (file bạn chọn là .{0}).', [ext]));
      return;
    }

    final file = File(path);
    final size = await file.length();
    if (!mounted) return;
    if (size > _maxSampleBytes) {
      setState(() => _error =
          trv('File quá lớn ({0}MB) - giới hạn 15MB cho nhạc mẫu.', [(size / 1024 / 1024).toStringAsFixed(1)]));
      return;
    }

    setState(() {
      _pickedFile = file;
      _error = null;
    });
    _uploadPickedFileToServer(file); // tải lên nền ngay, để dùng cho phiên âm lời + tránh upload lại lần 2 lúc tạo
  }

  Future<void> _next() async {
    if (!_fromSample && _promptController.text.trim().isEmpty) {
      setState(() => _error = tr('Nhập mô tả bài nhạc trước đã.'));
      return;
    }
    if (_fromSample && _pickedFile == null && _sampleFilenameOnServer == null) {
      setState(() => _error = tr('Chọn 1 file nhạc mẫu, hoặc dán link YouTube/Suno rồi bấm Tải trước đã.'));
      return;
    }

    widget.project.fromSample = _fromSample;
    widget.project.textPrompt = _promptController.text.trim();
    widget.project.lyrics = _lyricsController.text.trim();
    widget.project.sampleFile = _pickedFile;

    setState(() {
      _busy = true;
      _error = null;
      _percent = 0;
      _stageDetail = tr('Đang bắt đầu...');
    });

    final poller = ProgressPoller(
      api: widget.api,
      onUpdate: (percent, stage, detail) {
        if (mounted) setState(() {
          _percent = percent;
          _stageDetail = detail;
        });
      },
    );
    poller.start();

    try {
      final s = GenerationSettings.instance;
      final result = _fromSample
          ? await widget.api.remixMusic(
              sampleFile: _sampleFilenameOnServer == null ? _pickedFile : null,
              sampleFilename: _sampleFilenameOnServer,
              stylePrompt: _promptController.text.trim(),
              lyrics: _coverVietnameseLyricsController.text.trim(),
              similarity: _similarity,
              duration: s.duration,
              gpuPower: s.gpuPower,
              numVariants: s.generateVariants ? 2 : 1,
            )
          : await widget.api.generateMusic(
              prompt: _promptController.text.trim(),
              lyrics: _lyricsController.text.trim(),
              duration: s.duration,
              gpuPower: s.gpuPower,
              numVariants: s.generateVariants ? 2 : 1,
            );

      if (!mounted) return;

      // "files" là field MỚI - nếu backend trả về nhiều hơn 1 bản (đã bật
      // "Tạo 2 bản để chọn"), cho người dùng nghe thử/chọn trước khi tiếp
      // tục, thay vì tự động lấy bản đầu tiên như hành vi CŨ.
      final files = (result['files'] as List?)?.cast<String>();
      if (files != null && files.length > 1) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VariantPickerScreen(api: widget.api, project: widget.project, variantFilenames: files),
          ),
        );
        return;
      }

      widget.project.musicFilename = result['file'];
      Navigator.push(context, routeAfterMusic(widget.api, widget.project));
    } catch (e) {
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây (poller.stop())
      setState(() => _error = trv('Lỗi tạo nhạc: {0}', [e]));
    } finally {
      poller.stop();
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('Bước 1: Nhập liệu'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<bool>(
              segments: [
                ButtonSegment(value: false, label: Text(tr('Nhập text')), icon: Icon(Icons.edit)),
                ButtonSegment(value: true, label: Text(tr('Nhạc mẫu')), icon: Icon(Icons.upload_file)),
              ],
              selected: {_fromSample},
              onSelectionChanged: (s) => setState(() => _fromSample = s.first),
            ),
            const SizedBox(height: 16),
            if (!_fromSample) ...[
              // MỚI (mục 53) - mẫu \"một chạm\" theo thể loại nhạc (chỉ khi tạo nhạc từ mô tả; chế độ biến tấu nhạc mẫu không dùng)
              MvTemplatePicker(
                api: widget.api,
                onPick: (t) {
                  setState(() {
                    _promptController.text = (t['music_prompt'] ?? '').toString();
                    applyMvTemplateToProject(widget.project, t);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(trv('Đã áp mẫu: {0}', [t['label'] ?? '']))));
                },
              ),
              const SizedBox(height: 12),
            ],
            TextField(
              controller: _promptController,
              maxLines: 2,
              decoration: InputDecoration(
                // labelText Material Design LUÔN ép vào ĐÚNG 1 DÒNG (khác
                // hintText - tự xuống dòng theo đúng maxLines của field) -
                // đây là NGUYÊN NHÂN THẬT của ảnh chụp màn hình người dùng
                // gửi ("tươi, có..." bị cắt) - tách câu ví dụ dài ra khỏi
                // labelText, đưa sang hintText để không còn bị cắt.
                labelText: _fromSample ? tr('Mô tả phong cách muốn biến tấu') : tr('Mô tả bài nhạc muốn tạo'),
                hintText: _fromSample ? tr('vd: sôi động hơn, thêm guitar điện') : tr('vd: nhạc pop vui tươi, có guitar'),
                border: const OutlineInputBorder(),
              ),
            ),
            if (!_fromSample) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _lyricsController,
                maxLines: 4,
                decoration: InputDecoration(
                  labelText: tr('Lời bài hát (tuỳ chọn)'),
                  hintText: tr('Để trống nếu chỉ cần nhạc nền, không lời'),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 6),
              // Chèn nhanh nhãn cấu trúc lời bài hát - ACE-Step (model tạo
              // nhạc backend đang dùng) CHÍNH THỨC khuyến nghị cấu trúc lời
              // theo dạng này (docs: "Lyrics should be structured with tags
              // like [verse], [chorus], [bridge], etc.") - giống hệt cách
              // Suno/Udio làm, không phải tự bịa ra.
              Wrap(
                spacing: 6,
                children: [
                  '[verse]', '[chorus]', '[bridge]', '[intro]', '[outro]'
                ].map((tag) => ActionChip(
                      label: Text(tag, style: const TextStyle(fontSize: 12)),
                      onPressed: () {
                        final sel = _lyricsController.selection;
                        final text = _lyricsController.text;
                        final insertAt = sel.start >= 0 ? sel.start : text.length;
                        final newText = '${text.substring(0, insertAt)}\n$tag\n${text.substring(insertAt)}';
                        _lyricsController.value = TextEditingValue(
                          text: newText,
                          selection: TextSelection.collapsed(offset: insertAt + tag.length + 2),
                        );
                      },
                    )).toList(),
              ),
            ],
            if (_fromSample) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _pickSampleFile,
                icon: const Icon(Icons.audio_file),
                label: Text(_pickedFile == null
                    ? tr('Chọn file nhạc mẫu')
                    : trv('Đã chọn: {0}', [_pickedFile!.path.split('/').last])),
              ),
              if (_uploadingSample)
                Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Row(
                    children: [
                      SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 8),
                      Text(tr('Đang tải file lên server...'), style: TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ),
              const SizedBox(height: 8),
              Text(tr('...hoặc dán link YouTube/Suno (suno.com/song/...) nếu chưa có sẵn file nhạc:'), style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _youtubeUrlController,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        hintText: tr('https://youtube.com/watch?v=... hoặc https://suno.com/song/...'),
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _downloadingYoutube
                      ? const Padding(
                          padding: EdgeInsets.all(8),
                          child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                        )
                      : IconButton.filled(
                          onPressed: _youtubeUrlController.text.trim().isEmpty ? null : _downloadFromYoutube,
                          icon: const Icon(Icons.download),
                          tooltip: tr('Tải âm thanh từ link'),
                        ),
                ],
              ),
              if (_sampleActionError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(_sampleActionError!, style: const TextStyle(color: Colors.red, fontSize: 12)),
                ),
              if (_sampleFilenameOnServer != null)
                Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text(tr('✓ Đã có nhạc mẫu sẵn sàng trên server'), style: TextStyle(color: Colors.green, fontSize: 12)),
                ),
              const SizedBox(height: 16),
              Text(
                trv('Mức độ biến tấu: {0}', [_similarity < 0.4 ? tr("Khác nhiều (~90%), giữ thể loại/giai điệu tương đương") : _similarity < 0.7 ? tr("Vừa phải") : tr("Bám sát bản gốc")]),
                style: const TextStyle(fontSize: 13),
              ),
              Row(
                children: [
                  Text(tr('Khác nhiều')),
                  Expanded(
                    child: Slider(
                      value: _similarity,
                      min: 0.1,
                      max: 0.9,
                      divisions: 8,
                      label: _similarity.toStringAsFixed(1),
                      onChanged: (v) => setState(() {
                        _similarity = v;
                        GenerationSettings.instance.similarity = v;
                      }),
                    ),
                  ),
                  Text(tr('Bám sát gốc')),
                ],
              ),
              const SizedBox(height: 20),
              // Cover lời Việt (tuỳ chọn) - chỉ hiện ở chế độ Nhạc mẫu, vì
              // đây là tính năng "cover 1 bài có sẵn thành lời Việt", không
              // áp dụng cho luồng "Nhập text" (tạo nhạc mới từ đầu, đã có ô
              // lời riêng ở nhánh đó rồi).
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('Cover lời Việt (tuỳ chọn)'), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      Text(
                        tr('Bài mẫu tiếng Hoa/nước ngoài? Bấm "Lấy lời từ nhạc" để tự nghe và viết ra lời '
                        '(hoặc tự dán lời gốc vào ô bên dưới nếu đã có), rồi bấm Dịch - app viết bản '
                        'nháp lời Việt, bạn xem/sửa lại trước khi tạo. Để trống nếu chỉ muốn biến tấu '
                        'nhạc, không đổi lời.\n'
                        '⚠ Nghe lời HÁT khó hơn nghe nói chuyện thường với AI - có thể sai nhiều chỗ, '
                        'luôn xem lại kỹ trước khi dùng.'),
                        style: TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String?>(
                        value: _lyricsLanguageHint,
                        isExpanded: true,
                        decoration: InputDecoration(
                          labelText: tr('Ngôn ngữ bài hát'),
                          hintText: tr('Nếu biết trước - giúp nghe chính xác hơn'),
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: [
                          DropdownMenuItem(value: null, child: Text(tr('Để AI tự đoán'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'zh', child: Text(tr('Tiếng Hoa'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'ko', child: Text(tr('Tiếng Hàn'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'ja', child: Text(tr('Tiếng Nhật'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'en', child: Text(tr('Tiếng Anh'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'th', child: Text(tr('Tiếng Thái'), style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'vi', child: Text(tr('Tiếng Việt'), style: TextStyle(fontSize: 13))),
                        ],
                        onChanged: (v) => setState(() => _lyricsLanguageHint = v),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: (_transcribing || _sampleFilenameOnServer == null) ? null : _transcribeLyricsFromSample,
                          icon: _transcribing
                              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.hearing, size: 18),
                          label: Text(
                            _transcribing
                                ? tr('Đang nghe và viết lời...')
                                : _sampleFilenameOnServer == null
                                    ? tr('Lấy lời từ nhạc (cần chọn nhạc mẫu trước)')
                                    : tr('Lấy lời từ nhạc mẫu'),
                          ),
                        ),
                      ),
                      // MỚI - nhãn chi tiết ("Đang tách giọng nền (Demucs)..."
                      // rồi "AI đang nghe và chép lời...") để người dùng khỏi
                      // tưởng app treo nếu bài hát dài (có thể mất cả phút).
                      if (_transcribing && _transcribeStageDetail.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            _transcribeStageDetail,
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                          ),
                        ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _coverOriginalLyricsController,
                        maxLines: 4,
                        onChanged: (_) => setState(() {}), // để nút "Dịch" bật/tắt đúng ngay khi gõ, không cần đợi rebuild từ nơi khác
                        decoration: InputDecoration(
                          labelText: tr('Lời gốc'),
                          hintText: tr('Tiếng Hoa/nước ngoài...'),
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: (_translatingLyrics || _coverOriginalLyricsController.text.trim().isEmpty)
                              ? null
                              : _translateLyricsToVietnamese,
                          icon: _translatingLyrics
                              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.translate, size: 18),
                          label: Text(_translatingLyrics ? tr('Đang dịch...') : tr('Dịch sang lời Việt')),
                        ),
                      ),
                      if (_translateError != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(_translateError!, style: const TextStyle(color: Colors.red, fontSize: 12)),
                        ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _coverVietnameseLyricsController,
                        maxLines: 5,
                        decoration: InputDecoration(
                          labelText: tr('Lời Việt (bản nháp)'),
                          hintText: tr('Sửa thoải mái trước khi tạo'),
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 24),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: Text(tr('Tạo 2 bản để chọn (giống Suno/Udio)')),
              subtitle: Text(
                tr('Nghe thử cả 2 rồi chọn bản ưng ý nhất. Tốn gần gấp đôi thời gian '
                'GPU so với chỉ tạo 1 bản.'),
                style: TextStyle(fontSize: 12),
              ),
              value: GenerationSettings.instance.generateVariants,
              onChanged: (v) => setState(() => GenerationSettings.instance.generateVariants = v ?? false),
            ),
            const SizedBox(height: 8),
            if (_error != null)
              Text(_error!, style: const TextStyle(color: Colors.red)),
            if (_busy) ...[
              const SizedBox(height: 12),
              LinearProgressIndicator(value: _percent / 100, semanticsLabel: tr('Tiến trình'), semanticsValue: '$_percent%'),
              const SizedBox(height: 6),
              Text('$_percent% — $_stageDetail', style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 12),
            ],
            ElevatedButton(
              onPressed: _busy ? null : _next,
              child: Text(tr('Tạo nhạc và tiếp tục')),
            ),
          ],
        ),
      ),
    );
  }
}
