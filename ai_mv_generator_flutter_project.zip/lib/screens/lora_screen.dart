import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../api_service.dart';
import '../generation_settings.dart';

import '../l10n.dart';
import '../muted_color.dart';
/// MỚI (mục 31) - CHỖ ĐỂ THÊM FILE LoRA của người dùng (phong cách / nhân vật).
/// Trước đây dự án KHÔNG có chỗ nào để thêm LoRA (chỉ 8 Motion LoRA mã hoá cứng). Màn này:
///  - liệt kê file `.safetensors` trong thư mục `loras/` trên Google Drive của backend (chép file vào đó bằng Drive = không giới hạn dung lượng; hoặc tải từ app tới ~90MB);
///  - cho CHỌN LoRA nào dùng cho MV (tối đa 4) và chỉnh TRỌNG SỐ từng cái;
///  - sửa thông tin: tên, HỌ MODEL NỀN (LoRA phải cùng họ với công nghệ video đang dùng), TỪ KÍCH HOẠT (tự ghép vào prompt khi dùng).
/// Huấn luyện LoRA là việc NGOÀI app (Kaggle/Colab/máy riêng): "LoRA riêng cho nhân vật" = file LoRA của nhân vật + từ kích hoạt.
/// Lựa chọn được lưu trong GenerationSettings.loraSelection và gửi cùng yêu cầu tạo MV. CHƯA biên dịch/chạy thử.
class LoraScreen extends StatefulWidget {
  final ApiService api;
  const LoraScreen({super.key, required this.api});

  @override
  State<LoraScreen> createState() => _LoraScreenState();
}

class _LoraScreenState extends State<LoraScreen> {
  final s = GenerationSettings.instance;
  static const List<String> _bases = ['any', 'sd15', 'wan21-1.3b', 'wan22-5b'];
  static const Map<String, String> _baseLabels = {
    'any': 'Không khai báo (tự chịu trách nhiệm)',
    'sd15': 'SD 1.5 (công nghệ AnimateDiff)',
    'wan21-1.3b': 'Wan 2.1 1.3B (công nghệ Wan-VACE)',
    'wan22-5b': 'Wan 2.2 5B (công nghệ Wan 2.2)',
  };

  bool _loading = true;
  bool _uploading = false;
  String? _error;
  String _dir = '';
  int _maxPerMv = 4;
  List<Map<String, dynamic>> _loras = [];

  @override
  void initState() {
    super.initState();
    _reload();
  }

  String _baseLabel(String b) => tr(_baseLabels[b] ?? b);

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _reload({bool silent = false}) async {
    // mục 53: silent = true khi kéo-để-tải-lại (giữ nguyên danh sách thay vì đổi sang vòng quay)
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final r = await widget.api.listLoras();
      if (!mounted) return;
      if (r['status'] != 'ok') {
        setState(() {
          _loading = false;
          _error = (r['note'] as String?) ?? tr('Backend không trả danh sách LoRA.');
        });
        return;
      }
      setState(() {
        _loading = false;
        _dir = (r['dir'] as String?) ?? '';
        _maxPerMv = (r['max_per_mv'] as num?)?.toInt() ?? 4;
        _loras = ((r['loras'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = trv('Không gọi được backend: {0}', [e]);
      });
    }
  }

  Future<Map<String, String>?> _askMeta({required String initialName, required String initialBase, required String initialTrigger}) async {
    final nameCtrl = TextEditingController(text: initialName);
    final trigCtrl = TextEditingController(text: initialTrigger);
    String base = _bases.contains(initialBase) ? initialBase : 'any';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(tr('Thông tin LoRA')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(controller: nameCtrl, decoration: InputDecoration(labelText: tr('Tên hiển thị'))),
                const SizedBox(height: 8),
                TextField(controller: trigCtrl, decoration: InputDecoration(labelText: tr('Từ kích hoạt (trigger word), nếu LoRA có'))),
                const SizedBox(height: 12),
                Text(tr('Họ model nền - LoRA phải CÙNG họ với công nghệ video bạn dùng, nếu không sẽ bị bỏ qua:'), style: TextStyle(fontSize: 12)),
                DropdownButton<String>(
                  value: base,
                  isExpanded: true,
                  items: [for (final b in _bases) DropdownMenuItem<String>(value: b, child: Text(_baseLabel(b)))],
                  onChanged: (v) => setD(() => base = v ?? 'any'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Lưu'))),
          ],
        ),
      ),
    );
    final result = ok == true ? <String, String>{'name': nameCtrl.text.trim(), 'base': base, 'trigger': trigCtrl.text.trim()} : null;
    nameCtrl.dispose();
    trigCtrl.dispose();
    return result;
  }

  Future<void> _pickAndUpload() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = result?.files.single.path;
    if (path == null) return;
    if (!path.toLowerCase().endsWith('.safetensors')) {
      _snack(tr('Chỉ nhận file .safetensors.'));
      return;
    }
    final fileName = path.split(Platform.pathSeparator).last;
    final meta = await _askMeta(initialName: fileName, initialBase: 'any', initialTrigger: '');
    if (meta == null || !mounted) return;
    setState(() => _uploading = true);
    String? error;
    try {
      final r = await widget.api.uploadLora(loraFile: File(path), base: meta['base'] ?? 'any', trigger: meta['trigger'] ?? '', name: meta['name'] ?? '');
      if (r['status'] != 'ok') error = (r['note'] as String?) ?? tr('Backend từ chối file này.');
    } catch (e) {
      error = trv('Không tải được: {0}', [e]);
    }
    if (!mounted) return;
    setState(() => _uploading = false);
    if (error != null) {
      _snack(error);
    } else {
      await _reload();
    }
  }

  Future<void> _editMeta(Map<String, dynamic> l) async {
    final file = l['file'] as String;
    final meta = await _askMeta(
      initialName: (l['name'] as String?) ?? file,
      initialBase: (l['base'] as String?) ?? 'any',
      initialTrigger: (l['trigger'] as String?) ?? '',
    );
    if (meta == null || !mounted) return;
    try {
      final r = await widget.api.setLoraMeta(file: file, name: meta['name'], base: meta['base'], trigger: meta['trigger']);
      if (r['status'] != 'ok') _snack((r['note'] as String?) ?? tr('Không lưu được.'));
    } catch (e) {
      _snack(trv('Không gọi được backend: {0}', [e]));
    }
    await _reload();
  }

  Future<void> _delete(String file) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Xoá LoRA này khỏi Drive?')),
        content: Text(trv('{0} sẽ bị xoá khỏi thư mục loras trên Google Drive của backend.', [file])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Xoá'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      final r = await widget.api.deleteLora(file);
      if (r['status'] == 'ok') {
        s.loraSelection.remove(file);
        await s.save();
      } else {
        _snack((r['note'] as String?) ?? tr('Không xoá được.'));
      }
    } catch (e) {
      _snack(trv('Không gọi được backend: {0}', [e]));
    }
    await _reload();
  }

  void _toggle(String file, bool on, double weight) {
    if (on && s.loraSelection.length >= _maxPerMv) {
      _snack(trv('Mỗi MV dùng tối đa {0} LoRA.', [_maxPerMv]));
      return;
    }
    setState(() {
      if (on) {
        s.loraSelection[file] = weight;
      } else {
        s.loraSelection.remove(file);
      }
    });
    s.save();
  }

  Widget _tile(Map<String, dynamic> l) {
    final file = l['file'] as String;
    final selected = s.loraSelection.containsKey(file);
    final weight = (s.loraSelection[file] ?? (l['weight'] as num?)?.toDouble() ?? 0.8).clamp(0.0, 1.5).toDouble();
    final trigger = (l['trigger'] as String?) ?? '';
    final base = (l['base'] as String?) ?? 'any';
    final subtitle = '${_baseLabel(base)} · ${l['size_mb']} MB${trigger.isEmpty ? '' : trv(' · từ kích hoạt: {0}', [trigger])}';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Checkbox(value: selected, onChanged: (v) => _toggle(file, v == true, weight)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text((l['name'] as String?) ?? file, style: const TextStyle(fontWeight: FontWeight.w500)),
                      Text(subtitle, style: TextStyle(fontSize: 12, color: mutedGrey)),
                    ],
                  ),
                ),
                IconButton(tooltip: tr('Sửa thông tin'), icon: const Icon(Icons.edit_outlined), onPressed: () => _editMeta(l)),
                IconButton(tooltip: tr('Xoá khỏi Drive'), icon: const Icon(Icons.delete_outline), onPressed: () => _delete(file)),
              ],
            ),
            if (selected)
              Row(
                children: [
                  const SizedBox(width: 12),
                  Text(tr('Độ mạnh')),
                  Expanded(
                    child: Slider(
                      value: weight,
                      min: 0,
                      max: 1.5,
                      divisions: 30,
                      label: weight.toStringAsFixed(2),
                      onChanged: (v) => setState(() => s.loraSelection[file] = v),
                      onChangeEnd: (_) => s.save(),
                    ),
                  ),
                  Text(weight.toStringAsFixed(2)),
                ],
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('LoRA của bạn')),
        actions: [IconButton(tooltip: tr('Làm mới'), icon: const Icon(Icons.refresh), onPressed: _reload)],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _uploading ? null : _pickAndUpload,
        icon: _uploading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file),
        label: Text(_uploading ? tr('Đang tải...') : tr('Tải LoRA lên')),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!)))
              : RefreshIndicator(onRefresh: () => _reload(silent: true), child: ListView(
 physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 88),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          trv('Chỗ thêm file LoRA: thư mục "{0}" trên Google Drive. Chép file .safetensors vào đó (không giới hạn dung lượng) rồi bấm Làm mới, '
                          'hoặc bấm "Tải LoRA lên" (tới ~90MB). Chọn tối đa {1} LoRA cho mỗi MV. LoRA phải CÙNG họ model nền với công nghệ video bạn dùng '
                          '(SD 1.5 cho AnimateDiff; Wan 2.1 1.3B cho Wan-VACE; Wan 2.2 5B cho Wan 2.2) - sai họ sẽ bị bỏ qua. LoRA riêng cho nhân vật: tải '
                          'file LoRA của nhân vật, điền từ kích hoạt (trigger word) - app tự ghép vào mô tả. Việc HUẤN LUYỆN LoRA làm ngoài app.', [_dir, _maxPerMv]),
                          style: TextStyle(fontSize: 12, color: mutedGrey),
                        ),
                      ),
                    ),
                    if (_loras.isEmpty)
                      Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(tr('Chưa có LoRA nào trong thư mục.')),
                      ),
                    for (final l in _loras) _tile(l),
                  ],
                )),
    );
  }
}
