import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/spring_in.dart';
import 'home_screen.dart';

import '../l10n.dart';
/// MỚI (mục 23) - màn giới thiệu 3 trang, CHỈ hiện lần đầu mở app (có nút Bỏ qua). Ghi cờ
/// `onboarding_done_v1`; lỗi ghi cờ không được chặn người dùng (chỉ khiến lần sau hiện lại).
class OnboardingScreen extends StatefulWidget {
  static const String prefsKey = 'onboarding_done_v1';

  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _page = 0;

  static const List<List<Object>> _pages = [
    [
      Icons.cloud_queue,
      'App là bộ điều khiển',
      'Việc nặng (tạo nhạc, tạo video) chạy trên GPU Google Colab của chính bạn. Ở màn đầu, '
          'dán địa chỉ backend (dạng https://xxxx.trycloudflare.com) mà Colab hiện ra sau khi chạy '
          'xong các cell khởi động.',
    ],
    [
      Icons.movie_creation_outlined,
      'Quy trình tạo MV',
      'Ý tưởng hoặc nhạc mẫu, rồi nhạc, (đổi giọng), phong cách, kịch bản từng cảnh, và tạo MV. '
          'Mỗi cảnh xong được tải về máy ngay, nên nếu bị ngắt giữa chừng vẫn tiếp tục được từ cảnh còn thiếu.',
    ],
    [
      Icons.notifications_active_outlined,
      'Để app chạy trơn tru',
      'Tạo MV có thể mất từ vài phút tới hàng giờ. Hãy cho phép thông báo và bỏ tối ưu hoá pin khi app '
          'hỏi để Android không ngắt tiến trình. Xem lại hướng dẫn ở màn Trợ giúp, và cách app xử lý dữ '
          'liệu ở Cài đặt > Quyền riêng tư.',
    ],
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(OnboardingScreen.prefsKey, true);
    } catch (_) {
      // không chặn người dùng nếu không lưu được cờ
    }
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _page == _pages.length - 1;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: _finish, child: Text(tr('Bỏ qua'))),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (context, i) {
                  final page = _pages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SpringIn(
                          key: ValueKey<int>(i),
                          child: Icon(page[0] as IconData, size: 88, color: Theme.of(context).colorScheme.primary),
                        ),
                        const SizedBox(height: 24),
                        Text(
                          tr(page[1] as String),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          tr(page[2] as String),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 14, height: 1.4),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < _pages.length; i++)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: i == _page ? 20 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: i == _page ? Theme.of(context).colorScheme.primary : Colors.grey.shade400,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (isLast) {
                      _finish();
                    } else {
                      _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                    }
                  },
                  child: Text(isLast ? tr('Bắt đầu') : tr('Tiếp')),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
