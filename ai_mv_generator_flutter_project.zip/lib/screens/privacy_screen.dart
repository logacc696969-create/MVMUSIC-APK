import 'package:flutter/material.dart';
import '../consent.dart';

import '../l10n.dart';
/// MỚI (mục 23) - mô tả MINH BẠCH cách app xử lý dữ liệu, dựa trên những gì ĐÃ KIỂM TRA trong
/// mã nguồn (không viết theo mẫu chung chung): kết nối tới backend Colab của chính người dùng qua
/// Cloudflare Tunnel, kết quả lưu ở Google Drive của họ, app không có SDK thống kê/quảng cáo.
///
/// ĐÂY LÀ MÔ TẢ KỸ THUẬT, KHÔNG PHẢI TƯ VẤN PHÁP LÝ. Nếu sau này phát hành app cho người khác
/// (vd Google Play) cần chính sách quyền riêng tư riêng do người có chuyên môn pháp lý soát.
class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  Widget _section(String title, String body) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 4),
          Text(body, style: const TextStyle(fontSize: 13, height: 1.4)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('Quyền riêng tư & dữ liệu'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section(
            tr('Dữ liệu đi đâu?'),
            tr('App chỉ là bộ điều khiển. Ý tưởng, lời bài hát, file nhạc/giọng bạn chọn được gửi tới '
                'backend chạy trên Google Colab CỦA CHÍNH BẠN (địa chỉ bạn tự dán ở màn đầu), qua một '
                'đường hầm Cloudflare Tunnel. Kết quả (nhạc, cảnh, MV) được backend lưu vào Google Drive '
                'của tài khoản đang đăng nhập Colab (thư mục mv_app_output). Không có máy chủ nào của '
                'nhà phát triển app ở giữa.'),
          ),
          _section(
            tr('Bên thứ ba liên quan'),
            tr('Google (Colab, Drive), Cloudflare (đường hầm kết nối), và các kho model AI mà backend tải '
            'về (vd Hugging Face). Nếu bạn dùng tính năng lấy nhạc từ link YouTube, backend của bạn tải '
            'âm thanh từ YouTube. Mỗi bên có chính sách riêng của họ.'),
          ),
          _section(
            tr('App lưu gì trong máy?'),
            tr('Lịch sử dự án (tên file, lời, tuỳ chọn đã chọn), file MV và ảnh thumbnail đã tải về, cài đặt '
            'của app, và nhật ký lỗi cục bộ. MV cũng được lưu vào thư viện ảnh của máy khi bạn cho phép.'),
          ),
          _section(
            tr('Có theo dõi/quảng cáo không?'),
            tr('Không. App không chứa SDK thống kê, quảng cáo hay báo lỗi tự động (đã kiểm tra danh sách '
            'thư viện của app). Nhật ký lỗi chỉ nằm trong máy; chỉ gửi đi khi chính bạn bấm Chia sẻ.'),
          ),
          _section(
            tr('Nhãn nội dung AI'),
            tr('MV tạo ra được gắn nhãn "AI-generated" trong metadata file MP4. Đây là khai báo đơn giản, '
            'KHÔNG phải chuẩn xác thực C2PA có chữ ký số.'),
          ),
          _section(
            tr('Giọng nói và bản quyền'),
            tr('Trước khi huấn luyện/tải giọng, hoặc dùng âm thanh từ file/YouTube, app hỏi bạn xác nhận '
            'quyền sử dụng (một lần). Đây là lời nhắc, không phải cơ chế kỹ thuật ngăn vi phạm: việc dùng '
            'giọng và nội dung của người khác là trách nhiệm của bạn.'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              final n = await resetAllConsents();
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(n > 0 ? trv('Đã đặt lại {0} xác nhận - lần sau app sẽ hỏi lại.', [n]) : tr('Chưa có xác nhận nào được lưu.'))),
              );
            },
            icon: const Icon(Icons.undo),
            label: Text(tr('Đặt lại các xác nhận đã đồng ý')),
          ),
          const SizedBox(height: 16),
          Text(
            tr('Đây là mô tả kỹ thuật cách app xử lý dữ liệu, không phải tư vấn pháp lý. Nếu bạn phát hành '
            'app cho người khác, hãy nhờ người có chuyên môn soát lại chính sách riêng.'),
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
