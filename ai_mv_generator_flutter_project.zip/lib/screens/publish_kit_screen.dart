import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';

import '../l10n.dart';
/// MỚI (mục 26) - "Gói đăng bài": soạn sẵn tiêu đề/mô tả có chapter/hashtag cho YouTube + nhắc KHAI BÁO nội dung AI, và tạo
/// thumbnail 1280x720 có tiêu đề. Mọi thứ do backend dựng từ mẫu cố định + dữ liệu dự án (KHÔNG gọi LLM/mạng, không tốn GPU).
/// App KHÔNG thể tự đăng hay tự bật mục khai báo AI trên YouTube Studio - chỉ nhắc và đưa sẵn nội dung để dán.
class PublishKitScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const PublishKitScreen({super.key, required this.api, required this.project});

  @override
  State<PublishKitScreen> createState() => _PublishKitScreenState();
}

class _PublishKitScreenState extends State<PublishKitScreen> {
  late final TextEditingController _titleCtrl;
  final TextEditingController _subtitleCtrl = TextEditingController();
  bool _loadingKit = false;
  bool _loadingThumb = false;
  Map<String, dynamic>? _kit;
  String? _error;
  Uint8List? _thumbBytes;

  String get _sceneDirId => widget.project.mvSceneDirId ?? '';

  @override
  void initState() {
    super.initState();
    // Gợi ý tiêu đề từ ý tưởng/mô tả bài hát (dòng đầu, tối đa 40 ký tự) - người dùng sửa tuỳ ý.
    final firstLine = widget.project.textPrompt.trim().split('\n').first.trim();
    _titleCtrl = TextEditingController(text: firstLine.length > 40 ? firstLine.substring(0, 40) : firstLine);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _subtitleCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadKit() async {
    if (_titleCtrl.text.trim().isEmpty) {
      setState(() => _error = tr('Nhập tên bài hát/MV trước.'));
      return;
    }
    setState(() {
      _loadingKit = true;
      _error = null;
    });
    try {
      final kit = await widget.api.getPublishKit(
        sceneDirId: _sceneDirId,
        title: _titleCtrl.text.trim(),
        lyrics: widget.project.lyrics,
        channel: GenerationSettings.instance.watermarkText,
      );
      if (!mounted) return;
      setState(() => _kit = kit);
    } catch (e) {
      if (mounted) setState(() => _error = trv('Không soạn được gói đăng bài: {0}', [e]));
    } finally {
      if (mounted) setState(() => _loadingKit = false);
    }
  }

  Future<void> _makeThumb() async {
    if (_titleCtrl.text.trim().isEmpty) {
      setState(() => _error = tr('Nhập tên bài hát/MV trước.'));
      return;
    }
    setState(() {
      _loadingThumb = true;
      _error = null;
    });
    try {
      final bytes = await widget.api.getTitledThumbnail(
        sceneDirId: _sceneDirId,
        title: _titleCtrl.text.trim(),
        subtitle: _subtitleCtrl.text.trim(),
      );
      if (!mounted) return;
      setState(() => _thumbBytes = Uint8List.fromList(bytes));
    } catch (e) {
      if (mounted) setState(() => _error = '$e'.replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loadingThumb = false);
    }
  }

  Future<File> _writeThumbTemp() async {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/thumb_titled_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await f.writeAsBytes(_thumbBytes!);
    return f;
  }

  Future<void> _saveThumbToGallery() async {
    try {
      final f = await _writeThumbTemp();
      final hasAccess = await Gal.hasAccess(toAlbum: true);
      if (!hasAccess) {
        final granted = await Gal.requestAccess(toAlbum: true);
        if (!granted) throw Exception('chưa được cấp quyền lưu vào thư viện ảnh');
      }
      await Gal.putImage(f.path, album: 'AI MV Generator');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Đã lưu thumbnail vào thư viện ảnh.'))));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(trv('Không lưu được: {0}', [e]))));
    }
  }

  void _copy(String label, String text) {
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(trv('Đã sao chép {0}.', [label]))));
  }

  @override
  Widget build(BuildContext context) {
    final kit = _kit;
    final titles = (kit?['titles'] as List?)?.cast<String>() ?? const <String>[];
    return Scaffold(
      appBar: AppBar(title: Text(tr('Gói đăng bài'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              tr('Soạn sẵn nội dung để đăng lên YouTube. App không thể tự đăng hay tự bật mục khai báo nội dung AI - '
              'bạn dán nội dung vào YouTube Studio.'),
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _titleCtrl,
              maxLength: 80,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: tr('Tên bài hát / MV'),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _subtitleCtrl,
              maxLength: 60,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: tr('Dòng phụ trên thumbnail (tuỳ chọn)'),
                hintText: 'vd: Official AI Music Video',
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _loadingKit ? null : _loadKit,
                    icon: _loadingKit
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.description_outlined),
                    label: Text(tr('Soạn mô tả + chapter')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _loadingThumb ? null : _makeThumb,
                    icon: _loadingThumb
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.image_outlined),
                    label: Text(tr('Thumbnail có tiêu đề')),
                  ),
                ),
              ],
            ),
            if (_thumbBytes != null) ...[
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(_thumbBytes!, semanticLabel: tr('Thumbnail có tiêu đề'), fit: BoxFit.fitWidth),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: () async {
                      final f = await _writeThumbTemp();
                      await Share.shareXFiles([XFile(f.path)]);
                    },
                    icon: const Icon(Icons.share),
                    label: Text(tr('Chia sẻ')),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: _saveThumbToGallery,
                    icon: const Icon(Icons.save_alt),
                    label: Text(tr('Lưu vào ảnh')),
                  ),
                ],
              ),
              Text(
                tr('Ảnh được phóng từ khung hình MV (độ phân giải gốc thấp) nên hơi mềm - YouTube vẫn nhận ảnh 1280×720.'),
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ],
            if (kit != null) ...[
              const Divider(height: 32),
              Text(tr('Tiêu đề gợi ý'), style: TextStyle(fontWeight: FontWeight.bold)),
              for (final t in titles)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(t),
                  trailing: IconButton(
                    tooltip: tr('Sao chép tiêu đề'),
                    icon: const Icon(Icons.copy, size: 18),
                    onPressed: () => _copy(tr('tiêu đề'), t),
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: Text(tr('Mô tả (dán nguyên khối)'), style: TextStyle(fontWeight: FontWeight.bold))),
                  TextButton.icon(
                    onPressed: () => _copy(tr('mô tả'), kit['description'] as String? ?? ''),
                    icon: const Icon(Icons.copy, size: 16),
                    label: Text(tr('Sao chép')),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: SelectableText(kit['description'] as String? ?? '', style: const TextStyle(fontSize: 13)),
              ),
              if ((kit['chapters'] as List?)?.isEmpty ?? true)
                Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text(
                    tr('Không dựng được mục lục chapter (bài quá ngắn hoặc không nhận ra ≥3 đoạn dài ≥10 giây).'),
                    style: TextStyle(fontSize: 12, color: Colors.orange),
                  ),
                )
              else
                Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text(
                    tr('Tên chương là ĐOÁN theo cấu trúc âm thanh - sửa lại nếu chưa đúng.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  border: Border.all(color: Colors.orange.shade200),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline, size: 18, color: Colors.orange.shade800),
                    const SizedBox(width: 8),
                    Expanded(child: Text(kit['disclosure_note'] as String? ?? '', style: const TextStyle(fontSize: 12))),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
