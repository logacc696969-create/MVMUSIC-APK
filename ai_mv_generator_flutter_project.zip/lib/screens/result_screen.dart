import 'dart:io';
import 'package:flutter/material.dart';
import '../feedback_widget.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import '../api_service.dart';
import '../project_data.dart';
import '../widgets/spring_in.dart';
import 'generating_screen.dart';
import 'home_screen.dart';
import 'publish_kit_screen.dart';
import 'video_with_lyrics_screen.dart';

import '../l10n.dart';
import '../muted_color.dart';
/// File MV đã được tải NỀN về máy ngay trong lúc GeneratingScreen còn chạy
/// (ngay khi artifact "final_mv" xuất hiện) - màn này chỉ hiển thị/mở/chia sẻ,
/// không cần tải lại. Lịch sử dự án đã được lưu (trạng thái "completed") ở
/// GeneratingScreen._goToResult() TRƯỚC khi điều hướng sang đây - không lưu
/// lại lần nữa ở màn này (trước đây gọi ProjectHistoryStore.add() ở đây,
/// nhưng chỉ lưu được vài trường tối thiểu, và bị trùng/mất đồng bộ với bản
/// ghi đầy đủ hơn đã lưu từ trước - xem project_history.dart).
class ResultScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const ResultScreen({super.key, required this.api, required this.project});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  bool _checkingContentId = false;
  bool _exportingTimeline = false;
  List<String> _jobNotes = <String>[]; // MỚI (mục 39) - tính năng bị tắt/bỏ qua giữa chừng (từ /progress.notes)
  List<String> _credits = <String>[]; // MỚI (mục 40) - dòng GHI CÔNG nguồn stock Pexels/Pixabay (từ /progress.credits) - điều khoản của họ bắt buộc
  Map<String, dynamic>? _usage; // MỚI (mục 39) - sổ dùng cục bộ (từ /usage)

  /// MỚI (mục 39, PDF-2 mục 4.5 "Đã tắt X vì..." thay vì im lặng) - đọc danh sách tính năng bạn bật nhưng backend đã TẮT/BỎ QUA giữa chừng (vd Real-ESRGAN chưa cài,
  /// ảnh bố cục lỗi, kiểu điều khiển pose rơi về canny...) + số MV hôm nay. Ghi chú nằm ở /progress tới khi bắt đầu job mới hoặc Colab khởi động lại - mở lại MV cũ
  /// từ Lịch sử sẽ không còn. Lỗi mạng ở đây KHÔNG ảnh hưởng gì (chỉ không hiện thẻ).
  Future<void> _loadJobNotes() async {
    try {
      final p = await widget.api.getProgress();
      final notes = (p['notes'] as List<dynamic>? ?? <dynamic>[]).map((e) => e.toString()).toList();
      final credits = (p['credits'] as List<dynamic>? ?? <dynamic>[]).map((e) => e.toString()).toList();
      Map<String, dynamic>? usage;
      try {
        final u = await widget.api.getUsage();
        if (u['status'] == 'ok') usage = u;
      } catch (_) {
        // backend cũ chưa có /usage - bỏ qua
      }
      if (!mounted) return;
      setState(() {
        _jobNotes = notes;
        _credits = credits;
        _usage = usage;
      });
    } catch (_) {
      // mạng chập chờn - không hiện thẻ
    }
  }

  String? get _usageLine {
    final u = _usage;
    if (u == null) return null;
    final today = u['today'];
    if (today is! Map) return null;
    final limit = (u['daily_limit'] as num?)?.toInt() ?? 0;
    final base = trv('Hôm nay: {0} MV, khoảng {1} phút GPU', [today['mv'], today['gpu_minutes']]);
    return limit > 0 ? trv('{0} (trần {1} MV/ngày)', [base, limit]) : base;
  }

  /// MỚI (mục 27, PDF 9.2) - TUỲ CHỌN kiểm tra nhận diện âm thanh (kiểu Content ID). Hỏi xác nhận TRƯỚC khi gửi bất cứ thứ gì: ~15 giây nhạc x 2 đoạn
  /// được GỬI cho ACRCloud bằng tài khoản CỦA BẠN trên backend (xem Cell 2.8 trong colab_setup.py). Chỉ phát hiện dùng lại BẢN THU, không phát hiện
  /// giai điệu giống nhau - "không tìm thấy" KHÔNG bảo đảm không bị gắn bản quyền.
  Future<void> _checkContentId() async {
    final audio = widget.project.voicedFilename ?? widget.project.musicFilename;
    if (audio == null) return;
    final agree = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Kiểm tra bản quyền nhạc (tuỳ chọn)')),
        content: Text(
          tr('Tính năng này GỬI khoảng 15 giây nhạc x 2 đoạn của bài hát cho dịch vụ nhận diện âm thanh ACRCloud (bên thứ ba), bằng tài khoản ACRCloud bạn đã cấu hình '
          'trên backend. Chỉ phát hiện việc dùng lại BẢN THU đã có sẵn, không phát hiện giai điệu giống nhau; "không tìm thấy" không bảo đảm YouTube sẽ không gắn bản quyền.'),
          style: TextStyle(fontSize: 13),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Không gửi'))),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Đồng ý gửi'))),
        ],
      ),
    );
    if (agree != true || !mounted) return;
    setState(() => _checkingContentId = true);
    String message;
    try {
      final r = await widget.api.checkContentId(audioFilename: audio, confirmUpload: true);
      final status = r['status'];
      if (status == 'ok') {
        final matches = (r['matches'] as List<dynamic>? ?? <dynamic>[]);
        if (matches.isEmpty) {
          message = trv('Không tìm thấy bản thu trùng khớp trong {0} đoạn đã kiểm tra.\n\n{1}', [r['windows_checked'], r['disclaimer'] ?? '']);
        } else {
          final lines = matches.map((m) => '- ${m['title']} - ${m['artists']}').join('\n');
          message = trv('CÓ khớp với bản thu đã có:\n{0}\n\nCân nhắc đổi nhạc/đổi giai điệu trước khi đăng.', [lines]);
        }
      } else {
        message = (r['note'] as String?) ?? tr('Không kiểm tra được.');
      }
    } catch (e) {
      message = trv('Không gọi được backend: {0}', [e]);
    }
    if (!mounted) return;
    setState(() => _checkingContentId = false);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Kết quả kiểm tra')),
        content: SingleChildScrollView(child: Text(message)),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng')))],
      ),
    );
  }

  /// MỚI (mục 29, PDF "MV triệu view cần gì") - xuất timeline FCPXML (dựng thô) để dựng tiếp trên máy tính. Backend ghi file vào thư mục kết quả trên Google Drive.
  Future<void> _exportTimeline() async {
    final audio = widget.project.voicedFilename ?? widget.project.musicFilename;
    setState(() => _exportingTimeline = true);
    String message;
    try {
      final r = await widget.api.exportFcpxml(audioFilename: audio);
      if (r['status'] == 'ok') {
        message = trv('Đã tạo file timeline {0} ({1} cảnh, {2} giây) trong thư mục kết quả trên Google Drive (mv_app_output).\n\n'
            'Cách dùng: tải thư mục scenes/{3} và file timeline này về máy tính, rồi mở DaVinci Resolve hoặc Final Cut Pro > Import > Timeline (XML). '
            'Nếu phần mềm báo thiếu clip, chỉ lại đường dẫn tới thư mục chứa các clip.\n\n{4}', [r['file'], r['clips'], r['duration_s'], r['scene_dir'], r['note'] ?? '']);
      } else {
        message = (r['note'] as String?) ?? tr('Không xuất được timeline.');
      }
    } catch (e) {
      message = trv('Không gọi được backend: {0}', [e]);
    }
    if (!mounted) return;
    setState(() => _exportingTimeline = false);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Xuất timeline (FCPXML)')),
        content: SingleChildScrollView(child: Text(message)),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Đóng')))],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    // MỚI (mục 23) - rung nhẹ báo "MV xong rồi" (người dùng thường đã rời màn hình trong lúc chờ lâu).
    HapticFeedback.mediumImpact();
    _loadJobNotes(); // MỚI (mục 39)
  }

  /// MỚI (mục 23) - TẠO LẠI RIÊNG VÀI CẢNH rồi ghép lại MV (không tạo lại cả bài). Tận dụng cơ
  /// chế "tiếp tục từ cảnh còn thiếu" của backend: xoá cảnh được chọn + seed mới + chạy lại.
  /// Mỗi cảnh tạo lại tốn GPU như lúc đầu.
  Future<void> _redoScenes() async {
    final p = widget.project;
    final total = p.estimatedSceneCount ?? p.downloadedSceneFiles.length;
    if (p.mvSceneDirId == null || total <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Dự án này chưa có thông tin cảnh nên chưa thể tạo lại từng cảnh.'))),
      );
      return;
    }
    final picked = <int>{};
    bool following = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(tr('Tạo lại cảnh nào?')),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    tr('Chọn các cảnh muốn sinh lại, cảnh khác giữ nguyên. Mỗi cảnh tạo lại tốn GPU '
                    'như lúc đầu.'),
                    style: TextStyle(fontSize: 12, color: mutedGrey),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      for (var i = 0; i < total; i++)
                        FilterChip(
                          label: Text('${i + 1}'),
                          selected: picked.contains(i),
                          onSelected: (v) => setLocal(() {
                            if (v) {
                              picked.add(i);
                            } else {
                              picked.remove(i);
                            }
                          }),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: following,
                    onChanged: (v) => setLocal(() => following = v ?? false),
                    title: Text(tr('Tạo lại cả các cảnh phía sau'), style: TextStyle(fontSize: 13)),
                    subtitle: Text(
                      tr('Nên bật nếu dùng "nối cảnh mượt": cảnh sau nối từ khung cuối cảnh trước, '
                      'đổi cảnh trước mà giữ cảnh sau có thể bị giật ở chỗ nối.'),
                      style: TextStyle(fontSize: 11),
                    ),
                  ),
                  if (picked.contains(0))
                    Text(
                      tr('Chọn cảnh 1 sẽ tạo lại TOÀN BỘ MV (cảnh 1 là chuẩn màu của mọi cảnh).'),
                      style: TextStyle(fontSize: 12, color: Colors.orange),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
            ElevatedButton(
              onPressed: picked.isEmpty ? null : () => Navigator.pop(ctx, true),
              child: Text(tr('Tạo lại')),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    HapticFeedback.selectionClick();
    p.estimatedSceneCount = total;
    p.redoScenes = (picked.toList()..sort()).join(',');
    p.redoFollowing = following;
    // Xoá kết quả cũ: GeneratingScreen sẽ tải lại MV/thumbnail/bản dọc/các cảnh MỚI (backend đẩy lại
    // toàn bộ artifact khi resume) - nếu không, danh sách cảnh bị cộng dồn và đếm đôi.
    p.mvLocalFile = null;
    p.mvFilename = null;
    p.mvVerticalLocalFile = null;
    p.thumbnailImagePath = null;
    p.lyricsTimestampsPath = null;
    p.savedToGallery = false;
    p.downloadedSceneFiles.clear();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: p)),
    );
  }

  @override
  void dispose() {
    // MỚI - "Eviction bộ nhớ đệm cache ảnh": màn này hiển thị ảnh tham chiếu
    // nhân vật/thumbnail qua `Image.file()` - Flutter tự giữ các ảnh đã vẽ
    // trong `PaintingBinding.imageCache` một thời gian sau khi rời màn hình.
    // Nếu người dùng tạo nhiều dự án liên tiếp rồi mở lại màn Kết quả nhiều
    // lần, bộ nhớ đệm này có thể cộng dồn - giải phóng chủ động khi rời màn.
    // Cùng cách đã áp dụng ở `_ScenePreviewPlayerState` (generating_screen.dart).
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localFile = widget.project.mvLocalFile;

    return Scaffold(

      appBar: AppBar(title: Text(tr('Kết quả'))),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SpringIn(child: Icon(Icons.check_circle, color: Colors.green, size: 72, semanticLabel: tr('Hoàn tất'))),
            const SizedBox(height: 16),
            Text(tr('MV đã tạo xong!'), style: TextStyle(fontSize: 20)),
            const SizedBox(height: 8),
            Text('File: ${widget.project.mvFilename ?? "?"}'),
            const SizedBox(height: 8),
            Text(
              trv('Đã lưu kèm {0} cảnh gốc trên máy.', [widget.project.downloadedSceneFiles.length]),
              style: TextStyle(color: mutedGrey, fontSize: 13),
            ),
            const SizedBox(height: 4),
            Text(
              widget.project.savedToGallery
                  ? tr('Đã lưu vào thư viện ảnh (Gallery) của máy.')
                  : tr('Chưa lưu được vào thư viện ảnh - vẫn có thể Mở/Chia sẻ bình thường bên dưới.'),
              style: TextStyle(
                color: widget.project.savedToGallery ? Colors.green : mutedGrey,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 24),

            // MỚI (mục 39, PDF-2 mục 4.5) - thay vì để tính năng bị tắt ngầm, nói rõ cái gì đã bị tắt/bỏ qua và vì sao
            if (_jobNotes.isNotEmpty) ...[
              Card(
                shape: RoundedRectangleBorder(side: const BorderSide(color: Colors.orange), borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.info_outline, size: 18, color: Colors.orange),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              trv('Lưu ý khi tạo MV này: tính năng bị tắt/bỏ qua hoặc cần xem lại ({0})', [_jobNotes.length]),
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      for (final n in _jobNotes)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text('• $n', style: const TextStyle(fontSize: 12)),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
            // MỚI (mục 40) - GHI CÔNG nguồn video stock (Pexels/Pixabay yêu cầu ghi công tác giả + liên kết nguồn): dán vào mô tả khi đăng MV
            if (_credits.isNotEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.movie_filter_outlined, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(tr('Ghi công video stock (nhớ dán vào mô tả khi đăng)'), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      for (final c in _credits)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(c, style: const TextStyle(fontSize: 12)),
                        ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: _credits.join('\n')));
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Đã sao chép ghi công'))));
                          },
                          icon: const Icon(Icons.copy, size: 16),
                          label: Text(tr('Sao chép ghi công')),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
            if (_usageLine != null) ...[
              Text(_usageLine!, style: TextStyle(color: mutedGrey, fontSize: 12)),
              const SizedBox(height: 16),
            ],

            if (widget.project.characterReferenceImagePath != null) ...[
              Text(tr('Ảnh tham chiếu nhân vật đã dùng cho MV này:'), style: TextStyle(fontSize: 12, color: mutedGrey)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.project.characterReferenceImagePath!),
                  semanticLabel: tr('Ảnh nhân vật tham chiếu'),
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(), // file có thể đã bị hệ thống dọn khỏi thư mục tạm - ẩn lặng lẽ, không phải lỗi nghiêm trọng
                ),
              ),
              const SizedBox(height: 24),
            ],

            // MỚI - thumbnail tự động chọn (xem post_processing_v2.
            // select_best_thumbnail phía backend) - CHỈ hiện nếu có (backend
            // cũ chưa cài post_processing_v2.py, hoặc bước này lỗi, thì field
            // này null - ẩn lặng lẽ, không phải lỗi nghiêm trọng, giống ảnh
            // tham chiếu nhân vật ở trên).
            if (widget.project.thumbnailImagePath != null) ...[
              Text(tr('Thumbnail tự động chọn (khung nét nhất):'), style: TextStyle(fontSize: 12, color: mutedGrey)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.project.thumbnailImagePath!),
                  semanticLabel: tr('Ảnh đại diện của MV'),
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
              const SizedBox(height: 24),
            ],

            // MỚI (mục 27, PDF 11.1) - đánh giá + báo lỗi qua menu chia sẻ (không máy chủ)
            FeedbackCard(mvFilename: widget.project.mvFilename),
            const SizedBox(height: 8),
            // MỚI (mục 27, PDF 9.2) - kiểm tra Content ID TUỲ CHỌN (cần tài khoản ACRCloud của bạn; luôn hỏi xác nhận trước khi gửi nhạc)
            TextButton.icon(
              onPressed: _checkingContentId ? null : _checkContentId,
              icon: _checkingContentId
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.copyright_outlined),
              label: Text(_checkingContentId ? tr('Đang kiểm tra...') : tr('Kiểm tra bản quyền nhạc (tuỳ chọn)')),
            ),
            const SizedBox(height: 8),
            // MỚI (mục 29) - xuất timeline FCPXML (dựng thô) để chỉnh tiếp bằng DaVinci Resolve/Final Cut trên máy tính
            TextButton.icon(
              onPressed: _exportingTimeline ? null : _exportTimeline,
              icon: _exportingTimeline
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.movie_creation_outlined),
              label: Text(_exportingTimeline ? tr('Đang xuất...') : tr('Xuất timeline để dựng tiếp (FCPXML)')),
            ),
            const SizedBox(height: 8),

            if (localFile != null)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => OpenFilex.open(localFile.path),
                    icon: const Icon(Icons.play_arrow),
                    label: Text(tr('Mở xem')),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    onPressed: () => Share.shareXFiles([XFile(localFile.path)]),
                    icon: const Icon(Icons.share),
                    label: Text(tr('Chia sẻ')),
                  ),
                ],
              )
            else
              Text(
                tr('Không tìm thấy file MV đã tải trên máy. Có thể quá trình tải bị lỗi - '
                'thử tạo lại dự án.'),
                style: TextStyle(color: Colors.orange),
                textAlign: TextAlign.center,
              ),

            // MỚI - bản dọc 9:16 (xem post_processing_v2.export_vertical_crop
            // phía backend, tuỳ chọn "exportVertical" ở SettingsScreen) - CHỈ
            // hiện nếu người dùng đã bật tuỳ chọn này VÀ backend tạo thành
            // công (field null nếu tắt/lỗi - ẩn lặng lẽ, không phải file MV
            // chính nên không cần thông báo lỗi riêng).
            if (widget.project.mvVerticalLocalFile != null) ...[
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => OpenFilex.open(widget.project.mvVerticalLocalFile!.path),
                    icon: const Icon(Icons.crop_portrait),
                    label: Text(tr('Mở bản dọc (9:16)')),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    onPressed: () => Share.shareXFiles([XFile(widget.project.mvVerticalLocalFile!.path)]),
                    icon: const Icon(Icons.share),
                    label: Text(tr('Chia sẻ bản dọc')),
                  ),
                ],
              ),
            ],

            // MỚI (mục 7zc4) - CHỈ hiện nút này khi có file phụ đề động (JSON
            // mốc thời gian) - "Mở xem" ở trên giao cho app ngoài xử lý, không
            // thể chồng phụ đề lên video phát ở app khác, nên cần 1 màn phát
            // RIÊNG trong chính app này mới hiện được chữ chạy.
            if (localFile != null && widget.project.lyricsTimestampsPath != null) ...[
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => VideoWithLyricsScreen(
                        videoPath: localFile.path,
                        lyricsTimestampsPath: widget.project.lyricsTimestampsPath,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.subtitles),
                label: Text(tr('Phát trong app kèm phụ đề chạy chữ')),
              ),
            ],

            // MỚI (mục 23) - chỉ hiện khi có thông tin để tạo lại (có mã thư mục cảnh + biết số cảnh)
            if (widget.project.mvSceneDirId != null &&
                (widget.project.estimatedSceneCount ?? widget.project.downloadedSceneFiles.length) > 0) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _redoScenes,
                icon: const Icon(Icons.replay),
                label: Text(tr('Tạo lại một số cảnh')),
              ),
            ],

            // MỚI (mục 26) - gói đăng bài: tiêu đề/mô tả có chapter/hashtag + thumbnail có tiêu đề + nhắc khai báo AI
            if (widget.project.mvSceneDirId != null) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PublishKitScreen(api: widget.api, project: widget.project)),
                ),
                icon: const Icon(Icons.campaign_outlined),
                label: Text(tr('Gói đăng bài (tiêu đề, mô tả, thumbnail)')),
              ),
            ],

            const SizedBox(height: 32),
            TextButton.icon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const HomeScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.add),
              label: Text(tr('Tạo dự án khác')),
            ),
          ],
        ),
        ),
      ),
    );
  }
}
