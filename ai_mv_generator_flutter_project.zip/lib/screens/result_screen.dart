import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import '../api_service.dart';
import '../project_data.dart';
import 'home_screen.dart';
import 'video_with_lyrics_screen.dart';

/// File MV đã được tải NỀN về máy ngay trong lúc GeneratingScreen còn chạy
/// (ngay khi artifact "final_mv" xuất hiện) - màn này chỉ hiển thị/mở/chia sẻ,
/// không cần tải lại. Lịch sử dự án đã được lưu (trạng thái "completed") ở
/// GeneratingScreen._goToResult() TRƯỚC khi điều hướng sang đây - không lưu
/// lại lần nữa ở màn này (trước đây gọi ProjectHistoryStore.add() ở đây,
/// nhưng chỉ lưu được vài trường tối thiểu, và bị trùng/mất đồng bộ với bản
/// ghi đầy đủ hơn đã lưu từ trước - xem project_history.dart).
class ResultScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const ResultScreen({super.key, required this.api, required this.project});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  @override
  void dispose() {
    // MỚI - "Eviction bộ nhớ đệm cache ảnh": màn này hiển thị ảnh tham chiếu
    // nhân vật/thumbnail qua `Image.file()` - Flutter tự giữ các ảnh đã vẽ
    // trong `PaintingBinding.imageCache` một thời gian sau khi rời màn hình.
    // Nếu người dùng tạo nhiều dự án liên tiếp rồi mở lại màn Kết quả nhiều
    // lần, bộ nhớ đệm này có thể cộng dồn - giải phóng chủ động khi rời màn.
    // Cùng cách đã áp dụng ở `_ScenePreviewPlayerState` (generating_screen.dart).
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localFile = widget.project.mvLocalFile;

    return Scaffold(

      appBar: AppBar(title: const Text('Kết quả')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 72),
            const SizedBox(height: 16),
            const Text('MV đã tạo xong!', style: TextStyle(fontSize: 20)),
            const SizedBox(height: 8),
            Text('File: ${widget.project.mvFilename ?? "?"}'),
            const SizedBox(height: 8),
            Text(
              'Đã lưu kèm ${widget.project.downloadedSceneFiles.length} cảnh gốc trên máy.',
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 4),
            Text(
              widget.project.savedToGallery
                  ? 'Đã lưu vào thư viện ảnh (Gallery) của máy.'
                  : 'Chưa lưu được vào thư viện ảnh - vẫn có thể Mở/Chia sẻ bình thường bên dưới.',
              style: TextStyle(
                color: widget.project.savedToGallery ? Colors.green : Colors.grey,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 24),

            if (widget.project.characterReferenceImagePath != null) ...[
              const Text('Ảnh tham chiếu nhân vật đã dùng cho MV này:', style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.project.characterReferenceImagePath!),
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(), // file có thể đã bị hệ thống dọn khỏi thư mục tạm - ẩn lặng lẽ, không phải lỗi nghiêm trọng
                ),
              ),
              const SizedBox(height: 24),
            ],

            // MỚI - thumbnail tự động chọn (xem post_processing_v2.
            // select_best_thumbnail phía backend) - CHỈ hiện nếu có (backend
            // cũ chưa cài post_processing_v2.py, hoặc bước này lỗi, thì field
            // này null - ẩn lặng lẽ, không phải lỗi nghiêm trọng, giống ảnh
            // tham chiếu nhân vật ở trên).
            if (widget.project.thumbnailImagePath != null) ...[
              const Text('Thumbnail tự động chọn (khung nét nhất):', style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.project.thumbnailImagePath!),
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
              const SizedBox(height: 24),
            ],

            if (localFile != null)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => OpenFilex.open(localFile.path),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Mở xem'),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    onPressed: () => Share.shareXFiles([XFile(localFile.path)]),
                    icon: const Icon(Icons.share),
                    label: const Text('Chia sẻ'),
                  ),
                ],
              )
            else
              const Text(
                'Không tìm thấy file MV đã tải trên máy. Có thể quá trình tải bị lỗi - '
                'thử tạo lại dự án.',
                style: TextStyle(color: Colors.orange),
                textAlign: TextAlign.center,
              ),

            // MỚI - bản dọc 9:16 (xem post_processing_v2.export_vertical_crop
            // phía backend, tuỳ chọn "exportVertical" ở SettingsScreen) - CHỈ
            // hiện nếu người dùng đã bật tuỳ chọn này VÀ backend tạo thành
            // công (field null nếu tắt/lỗi - ẩn lặng lẽ, không phải file MV
            // chính nên không cần thông báo lỗi riêng).
            if (widget.project.mvVerticalLocalFile != null) ...[
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => OpenFilex.open(widget.project.mvVerticalLocalFile!.path),
                    icon: const Icon(Icons.crop_portrait),
                    label: const Text('Mở bản dọc (9:16)'),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    onPressed: () => Share.shareXFiles([XFile(widget.project.mvVerticalLocalFile!.path)]),
                    icon: const Icon(Icons.share),
                    label: const Text('Chia sẻ bản dọc'),
                  ),
                ],
              ),
            ],

            // MỚI (mục 7zc4) - CHỈ hiện nút này khi có file phụ đề động (JSON
            // mốc thời gian) - "Mở xem" ở trên giao cho app ngoài xử lý, không
            // thể chồng phụ đề lên video phát ở app khác, nên cần 1 màn phát
            // RIÊNG trong chính app này mới hiện được chữ chạy.
            if (localFile != null && widget.project.lyricsTimestampsPath != null) ...[
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => VideoWithLyricsScreen(
                        videoPath: localFile.path,
                        lyricsTimestampsPath: widget.project.lyricsTimestampsPath,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.subtitles),
                label: const Text('Phát trong app kèm phụ đề chạy chữ'),
              ),
            ],

            const SizedBox(height: 32),
            TextButton.icon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const HomeScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Tạo dự án khác'),
            ),
          ],
        ),
      ),
    );
  }
}
