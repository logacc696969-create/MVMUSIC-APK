import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import '../api_service.dart';
import '../project_data.dart';
import '../project_history.dart';
import 'home_screen.dart';

/// File MV đã được tải NỀN về máy ngay trong lúc GeneratingScreen còn chạy
/// (ngay khi artifact "final_mv" xuất hiện) - màn này chỉ hiển thị/mở/chia sẻ,
/// không cần tải lại.
class ResultScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const ResultScreen({super.key, required this.api, required this.project});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  @override
  void initState() {
    super.initState();
    _saveToHistory();
  }

  Future<void> _saveToHistory() async {
    if (widget.project.mvFilename == null) return;
    await ProjectHistoryStore.add(ProjectHistoryEntry(
      createdAt: DateTime.now(),
      mvFilename: widget.project.mvFilename!,
      mvLocalPath: widget.project.mvLocalFile?.path,
      styleId: widget.project.styleId,
      fromSample: widget.project.fromSample,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final localFile = widget.project.mvLocalFile;

    return Scaffold(
      appBar: AppBar(title: const Text('Kết quả')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 72),
            const SizedBox(height: 16),
            const Text('MV đã tạo xong!', style: TextStyle(fontSize: 20)),
            const SizedBox(height: 8),
            Text('File: ${widget.project.mvFilename ?? "?"}'),
            const SizedBox(height: 8),
            Text(
              'Đã lưu kèm ${widget.project.downloadedSceneFiles.length} cảnh gốc trên máy.',
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 4),
            Text(
              widget.project.savedToGallery
                  ? 'Đã lưu vào thư viện ảnh (Gallery) của máy.'
                  : 'Chưa lưu được vào thư viện ảnh - vẫn có thể Mở/Chia sẻ bình thường bên dưới.',
              style: TextStyle(
                color: widget.project.savedToGallery ? Colors.green : Colors.grey,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 24),

            if (widget.project.characterReferenceImagePath != null) ...[
              const Text('Ảnh tham chiếu nhân vật đã dùng cho MV này:', style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.project.characterReferenceImagePath!),
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(), // file có thể đã bị hệ thống dọn khỏi thư mục tạm - ẩn lặng lẽ, không phải lỗi nghiêm trọng
                ),
              ),
              const SizedBox(height: 24),
            ],

            if (localFile != null)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => OpenFilex.open(localFile.path),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Mở xem'),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    onPressed: () => Share.shareXFiles([XFile(localFile.path)]),
                    icon: const Icon(Icons.share),
                    label: const Text('Chia sẻ'),
                  ),
                ],
              )
            else
              const Text(
                'Không tìm thấy file MV đã tải trên máy. Có thể quá trình tải bị lỗi - '
                'thử tạo lại dự án.',
                style: TextStyle(color: Colors.orange),
                textAlign: TextAlign.center,
              ),

            const SizedBox(height: 32),
            TextButton.icon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const HomeScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Tạo dự án khác'),
            ),
          ],
        ),
      ),
    );
  }
}
