import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'storyboard_screen.dart';

/// Màn hình "Xem lại & Xác nhận" - chèn giữa StyleScreen và StoryboardScreen
/// (StoryboardScreen mới chèn thêm TRƯỚC GeneratingScreen - xem storyboard_screen.dart).
/// Cho người dùng NGHE THỬ bản nhạc vừa tạo + xem ước tính số cảnh/tempo
/// TRƯỚC KHI tốn GPU Colab tạo MV thật - tránh bấm tạo "mù quáng" rồi không
/// ưng bản nhạc, lãng phí công suất GPU.
class ReviewScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const ReviewScreen({super.key, required this.api, required this.project});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  final _player = AudioPlayer();
  bool _loading = true;
  bool _playing = false;
  String? _loadError;

  double? _tempo;
  int? _numScenes;
  double? _freeSpaceMB; // null = chưa kiểm tra được (không chặn, chỉ không hiện cảnh báo)
  bool _repainting = false;

  static const _lowSpaceThresholdMB = 200.0; // MV cuối có thể tới ~100MB

  @override
  void initState() {
    super.initState();
    _prepare();
    _player.onPlayerStateChanged.listen((state) {
      if (mounted) setState(() => _playing = state == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String get _audioFilename => widget.project.voicedFilename ?? widget.project.musicFilename!;

  Future<void> _prepare() async {
    final s = GenerationSettings.instance;
    try {
      // Tải nhạc về máy để phát thử (file nhỏ, không đáng lo giới hạn Cloudflare).
      final res = await http.get(Uri.parse(widget.api.downloadUrl(_audioFilename)));
      if (res.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/preview_${_audioFilename.replaceAll('/', '_')}');
        await file.writeAsBytes(res.bodyBytes);
        await _player.setSource(DeviceFileSource(file.path));
      }
    } catch (e) {
      _loadError = 'Không tải được nhạc để nghe thử: $e';
    }

    try {
      final result = await widget.api.analyzeBeats(
        audioFilename: _audioFilename,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
      );
      if (result['status'] == 'ok') {
        _tempo = (result['tempo'] as num).toDouble();
        _numScenes = result['num_scenes'] as int;
        widget.project.estimatedSceneCount = _numScenes;
      }
    } catch (_) {
      // Không phân tích được cũng không sao - vẫn cho người dùng tiếp tục,
      // chỉ là không có số ước tính hiển thị trước.
    }

    try {
      _freeSpaceMB = await DiskSpacePlus().getFreeDiskSpace;
    } catch (_) {
      // Không lấy được dung lượng (thiết bị lạ/plugin lỗi) - bỏ qua, không
      // chặn người dùng chỉ vì không kiểm tra được.
    }

    if (mounted) setState(() => _loading = false);
  }

  void _togglePlay() {
    if (_playing) {
      _player.pause();
    } else {
      _player.resume();
    }
  }

  /// MỚI - "Sửa nhanh (bản nháp)" - KHÁC `_showRepaintDialog()` ở bản chất kỹ
  /// thuật: chỉ sinh đoạn NGẮN cần sửa rồi ghép crossfade (rẻ hơn, có thể
  /// nghe ra vết nối nhẹ) thay vì sinh lại theo ngữ cảnh cả bài (tốn kém như
  /// tạo mới, nhưng mượt hoàn toàn). Dùng để LẶP NHANH, RẺ cho tới khi ưng
  /// lời/hướng mới, rồi mới tốn GPU 1 LẦN làm bản hoàn chỉnh - xem
  /// `_offerQuickEditPreview()`.
  Future<void> _showQuickEditDialog() async {
    final startCtrl = TextEditingController();
    final endCtrl = TextEditingController();
    final promptCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Sửa nhanh (bản nháp)'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Tạo NHANH, ÍT TỐN GPU hơn để nghe thử hướng mới - có thể nghe ra '
                'nhẹ "vết nối" ở 2 đầu đoạn sửa (đây là bản NHÁP). Khi đã ưng, có '
                'thể chọn "Tạo bản hoàn chỉnh" để làm mượt hoàn toàn (tốn GPU hơn, '
                'chỉ nên làm 1 lần sau khi đã chốt lời/hướng).',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: startCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Từ giây'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: endCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Đến giây'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: promptCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Mô tả mong muốn',
                  hintText: 'Đoạn này bạn muốn nghe như thế nào?',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Huỷ')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tạo bản nháp')),
        ],
      ),
    );
    if (confirmed != true) return;

    final start = double.tryParse(startCtrl.text.trim());
    final end = double.tryParse(endCtrl.text.trim());
    final prompt = promptCtrl.text.trim();
    if (start == null || end == null || end <= start || prompt.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nhập đủ giây bắt đầu/kết thúc hợp lệ và mô tả đoạn cần sửa.')),
        );
      }
      return;
    }

    setState(() => _repainting = true);
    try {
      final result = await widget.api.quickEditMusicSection(
        audioFilename: _audioFilename,
        prompt: prompt,
        startTime: start,
        endTime: end,
        gpuPower: GenerationSettings.instance.gpuPower,
      );
      if (result['status'] != 'ok') {
        throw Exception(result['note'] ?? 'Không rõ lỗi');
      }
      final newFilename = result['file'] as String;
      if (!mounted) return;
      await _offerQuickEditPreview(newFilename, start, end, prompt);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tạo bản nháp thất bại: $e')));
      }
    } finally {
      if (mounted) setState(() => _repainting = false);
    }
  }

  /// Cho nghe thử bản NHÁP (từ Sửa nhanh) rồi đưa ra 3 lựa chọn - KHÁC
  /// `_offerRepaintPreview()` (chỉ 2 lựa chọn Giữ/Bỏ): thêm lựa chọn "Tạo
  /// bản hoàn chỉnh" gọi LẠI `/repaint-music-section` (tốn GPU như tạo cả
  /// bài, nhưng mượt hoàn toàn) với ĐÚNG cùng giây/mô tả đã dùng cho bản nháp
  /// - trên file GỐC (chưa ghép nháp), không phải trên chính bản nháp.
  Future<void> _offerQuickEditPreview(String draftFilename, double start, double end, String prompt) async {
    final previewPlayer = AudioPlayer();
    File? file;
    try {
      final res = await http.get(Uri.parse(widget.api.downloadUrl(draftFilename)));
      final dir = await getTemporaryDirectory();
      file = File('${dir.path}/quickedit_preview.wav');
      await file.writeAsBytes(res.bodyBytes);
      await previewPlayer.setSource(DeviceFileSource(file.path));
    } catch (_) {
      // Không tải/nghe thử được vẫn cho chọn tiếp - người dùng có thể tải lại sau.
    }

    if (!mounted) return;
    final choice = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Bản nháp đã xong - nghe thử'),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              iconSize: 48,
              icon: const Icon(Icons.play_circle_filled),
              onPressed: () => previewPlayer.resume(),
            ),
            const Expanded(child: Text('Nghe thử bản nháp - có thể còn nghe ra vết nối nhẹ.')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, 'discard'), child: const Text('Bỏ, thử lại')),
          TextButton(onPressed: () => Navigator.pop(context, 'keep_draft'), child: const Text('Dùng bản nháp này')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, 'finalize'),
            child: const Text('Tạo bản hoàn chỉnh'),
          ),
        ],
      ),
    );
    await previewPlayer.dispose();

    if (choice == 'keep_draft') {
      widget.project.musicFilename = draftFilename;
      widget.project.voicedFilename = null;
      setState(() {
        _loading = true;
        _loadError = null;
      });
      await _prepare();
    } else if (choice == 'finalize') {
      // Tốn GPU như tạo cả bài, chỉ làm 1 LẦN sau khi đã chốt qua bản nháp -
      // gọi trên file GỐC (_audioFilename hiện tại VẪN là bản gốc, vì chưa
      // ai gán draftFilename vào musicFilename ở nhánh này).
      setState(() => _repainting = true);
      try {
        final result = await widget.api.repaintMusicSection(
          audioFilename: _audioFilename,
          prompt: prompt,
          startTime: start,
          endTime: end,
          gpuPower: GenerationSettings.instance.gpuPower,
        );
        if (result['status'] != 'ok') {
          throw Exception(result['note'] ?? 'Không rõ lỗi');
        }
        if (!mounted) return;
        await _offerRepaintPreview(result['file'] as String);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tạo bản hoàn chỉnh thất bại: $e')));
        }
      } finally {
        if (mounted) setState(() => _repainting = false);
      }
    }
    // 'discard' hoặc null (đóng dialog) -> không làm gì, giữ nguyên bài gốc.
  }

  /// MỚI - "Sửa 1 đoạn không ưng" (giống Suno/Udio) - hỏi khoảng thời gian
  /// (giây, người dùng tự ước lượng bằng tai, KHÔNG có slider gắn với thời
  /// lượng thật vì màn hình này chưa track duration chính xác) + mô tả mới
  /// cho đoạn đó, gọi /repaint-music-section, rồi cho nghe thử SO SÁNH trước
  /// khi quyết định giữ bản nào - KHÔNG tự động ghi đè.
  Future<void> _showRepaintDialog() async {
    final startCtrl = TextEditingController();
    final endCtrl = TextEditingController();
    final promptCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Sửa lại 1 đoạn nhạc'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Nghe lại bài để ước lượng khoảng thời gian không ưng, rồi mô tả '
                'bạn muốn đoạn đó nghe như thế nào. Phần còn lại của bài GIỮ NGUYÊN.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: startCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Từ giây'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: endCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Đến giây'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: promptCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Mô tả mong muốn',
                  hintText: 'Đoạn này bạn muốn nghe như thế nào?',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Huỷ')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sửa lại')),
        ],
      ),
    );
    if (confirmed != true) return;

    final start = double.tryParse(startCtrl.text.trim());
    final end = double.tryParse(endCtrl.text.trim());
    if (start == null || end == null || end <= start || promptCtrl.text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nhập đủ giây bắt đầu/kết thúc hợp lệ và mô tả đoạn cần sửa.')),
        );
      }
      return;
    }

    setState(() => _repainting = true);
    try {
      final result = await widget.api.repaintMusicSection(
        audioFilename: _audioFilename,
        prompt: promptCtrl.text.trim(),
        startTime: start,
        endTime: end,
        gpuPower: GenerationSettings.instance.gpuPower,
      );
      if (result['status'] != 'ok') {
        throw Exception(result['note'] ?? 'Không rõ lỗi');
      }
      final newFilename = result['file'] as String;
      if (!mounted) return;
      await _offerRepaintPreview(newFilename);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sửa đoạn nhạc thất bại: $e')));
      }
    } finally {
      if (mounted) setState(() => _repainting = false);
    }
  }

  /// MỚI - "Chỉ sửa lời, giữ giai điệu" (mục 7zb) - KHÁC dialog repaint ở
  /// trên: không có ô mô tả phong cách mới, chỉ có ô lời mới - phản ánh đúng
  /// use-case "chỉ sửa vài chữ" (nhạc sĩ thật). Dùng LẠI _offerRepaintPreview
  /// (nghe thử + chọn giữ bản nào) - luồng xác nhận giống hệt, chỉ khác API
  /// gọi và nội dung dialog nhập liệu.
  Future<void> _showEditLyricsDialog() async {
    final startCtrl = TextEditingController();
    final endCtrl = TextEditingController();
    final lyricsCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Chỉ sửa lời (giữ giai điệu)'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Dùng khi CHỈ muốn đổi vài chữ trong lời, không muốn đổi giai điệu/'
                'phong cách đoạn đó. Hệ thống sẽ CỐ giữ nguyên giai điệu - nếu không '
                'khả dụng trên bản cài hiện tại, sẽ tự động sửa lại đoạn theo cách '
                'thường (có thể đổi khác giai điệu chút ít) và báo rõ trong kết quả.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: startCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Từ giây'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: endCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Đến giây'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lyricsCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Lời mới cho đoạn này',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Huỷ')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sửa lời')),
        ],
      ),
    );
    if (confirmed != true) return;

    final start = double.tryParse(startCtrl.text.trim());
    final end = double.tryParse(endCtrl.text.trim());
    if (start == null || end == null || end <= start || lyricsCtrl.text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nhập đủ giây bắt đầu/kết thúc hợp lệ và lời mới.')),
        );
      }
      return;
    }

    setState(() => _repainting = true);
    try {
      final result = await widget.api.editLyricsSection(
        audioFilename: _audioFilename,
        newLyrics: lyricsCtrl.text.trim(),
        startTime: start,
        endTime: end,
        gpuPower: GenerationSettings.instance.gpuPower,
      );
      if (result['status'] != 'ok') {
        throw Exception(result['note'] ?? 'Không rõ lỗi');
      }
      final newFilename = result['file'] as String;
      if (!mounted) return;
      // Báo rõ nhánh THẬT SỰ đã dùng - người dùng cần biết giai điệu có được
      // giữ hay không trước khi nghe thử, tránh hiểu nhầm "edit" luôn thành công.
      if (result['used_mode'] == 'repaint_fallback' && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(
            'Chế độ giữ giai điệu không khả dụng - đã sửa theo cách thường, giai điệu có thể đổi khác.',
          )),
        );
      }
      await _offerRepaintPreview(newFilename);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sửa lời thất bại: $e')));
      }
    } finally {
      if (mounted) setState(() => _repainting = false);
    }
  }

  /// Sau khi có bản đã sửa, tải về + phát thử NGAY trong dialog, cho người
  /// dùng nghe rồi mới quyết định "Dùng bản này" (thay musicFilename) hay
  /// "Giữ bản cũ" (bỏ qua, không đổi gì).
  Future<void> _offerRepaintPreview(String newFilename) async {
    final previewPlayer = AudioPlayer();
    File? file;
    try {
      final res = await http.get(Uri.parse(widget.api.downloadUrl(newFilename)));
      final dir = await getTemporaryDirectory();
      file = File('${dir.path}/repaint_preview.wav');
      await file.writeAsBytes(res.bodyBytes);
      await previewPlayer.setSource(DeviceFileSource(file.path));
    } catch (_) {
      // Không tải/nghe thử được vẫn cho chọn - người dùng có thể tải lại sau.
    }

    if (!mounted) return;
    final keep = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đã sửa xong - nghe thử'),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              iconSize: 48,
              icon: const Icon(Icons.play_circle_filled),
              onPressed: () => previewPlayer.resume(),
            ),
            const Expanded(child: Text('Nghe thử bản đã sửa trước khi quyết định.')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Giữ bản cũ')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Dùng bản này')),
        ],
      ),
    );
    await previewPlayer.dispose();

    if (keep == true) {
      widget.project.musicFilename = newFilename;
      widget.project.voicedFilename = null; // bản voiced (nếu có) đã lỗi thời, phải áp giọng lại
      setState(() {
        _loading = true;
        _loadError = null;
      });
      await _prepare(); // nạp lại player + phân tích nhịp cho file MỚI
    }
  }

  void _next() {
    // QUAN TRỌNG: Navigator.push KHÔNG dispose() màn hình này (nó vẫn "sống"
    // bên dưới trong stack điều hướng) - nếu không dừng nhạc tường minh ở
    // đây, nhạc sẽ tiếp tục phát ngầm khi đã chuyển sang GeneratingScreen.
    //
    // Bọc try/catch: audioplayers trên 1 số dòng Android có thể gặp lỗi đồng
    // bộ luồng (race condition) nếu gọi stop() đúng lúc player đang ở trạng
    // thái loading (file .wav chưa tải xong hẳn) - nếu người dùng bấm "Tiếp
    // tục" rất nhanh sau khi vào màn hình. CHƯA xác nhận được bằng chạy thử
    // thật (xem mục 7l) rằng lỗi này CÓ xảy ra trên thiết bị thật hay không -
    // đây là phòng thủ chủ động, không phải fix cho lỗi đã tái hiện được.
    // Dù stop() lỗi, vẫn PHẢI điều hướng tiếp - không được để lỗi phát nhạc
    // chặn luôn cả luồng chính của app.
    try {
      _player.stop();
    } catch (e) {
      debugPrint('Bỏ qua lỗi khi dừng nhạc (không chặn điều hướng): $e');
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => StoryboardScreen(api: widget.api, project: widget.project)),
    );
  }

  String _powerHint(int power) {
    if (power >= 80) return 'Tốc độ tối đa - nguy cơ bị Colab ngắt cao hơn nếu MV có nhiều cảnh.';
    if (power >= 45) return 'Cân bằng - phù hợp phần lớn trường hợp.';
    return 'An toàn hơn cho từng cảnh - nhưng THỜI GIAN TẠO SẼ DÀI HƠN (do nghỉ giữa các cảnh), '
        'nên vẫn có thể chạm giới hạn phiên Colab nếu MV có nhiều cảnh. Không phải "càng thấp càng an toàn tuyệt đối".';
  }

  @override
  Widget build(BuildContext context) {
    final s = GenerationSettings.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Xem lại & Xác nhận')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Nghe thử bản nhạc vừa tạo', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    if (_loading)
                      const SizedBox(
                        height: 56,
                        child: Center(child: CircularProgressIndicator()),
                      )
                    else if (_loadError != null)
                      Text(_loadError!, style: const TextStyle(color: Colors.orange, fontSize: 12))
                    else
                      IconButton(
                        iconSize: 56,
                        icon: Icon(_playing ? Icons.pause_circle_filled : Icons.play_circle_filled),
                        onPressed: _togglePlay,
                      ),
                    if (!_loading && _loadError == null) ...[
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed: _repainting ? null : _showQuickEditDialog,
                        icon: _repainting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.bolt),
                        label: Text(_repainting ? 'Đang xử lý...' : 'Sửa nhanh (bản nháp, rẻ hơn)'),
                      ),
                      TextButton.icon(
                        onPressed: _repainting ? null : _showRepaintDialog,
                        icon: _repainting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.edit_note),
                        label: Text(_repainting ? 'Đang sửa...' : 'Sửa 1 đoạn không ưng'),
                      ),
                      TextButton.icon(
                        onPressed: _repainting ? null : _showEditLyricsDialog,
                        icon: _repainting
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.text_fields),
                        label: Text(_repainting ? 'Đang sửa...' : 'Chỉ sửa lời (giữ giai điệu)'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Dự kiến khi tạo MV', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    if (_loading)
                      const Text('Đang phân tích...', style: TextStyle(color: Colors.grey))
                    else if (_numScenes != null)
                      Text('Video sẽ gồm khoảng $_numScenes cảnh, nhịp ~${_tempo!.toStringAsFixed(0)} BPM.')
                    else
                      const Text(
                        'Không ước tính được số cảnh trước (không ảnh hưởng việc tạo MV).',
                        style: TextStyle(color: Colors.grey),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Công suất sử dụng GPU: ${s.gpuPower}%',
                        style: Theme.of(context).textTheme.titleMedium),
                    Slider(
                      value: s.gpuPower.toDouble(),
                      min: 20,
                      max: 100,
                      divisions: 8,
                      label: '${s.gpuPower}%',
                      onChanged: (v) => setState(() => s.gpuPower = v.round()),
                    ),
                    Text(
                      _powerHint(s.gpuPower),
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_freeSpaceMB != null && _freeSpaceMB! < _lowSpaceThresholdMB)
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.withOpacity(0.4)),
                ),
                child: Text(
                  'Điện thoại chỉ còn ${_freeSpaceMB!.toStringAsFixed(0)}MB trống - '
                  'MV cuối có thể cần tới ~100MB. Nên dọn bớt dung lượng trước khi tiếp tục.',
                  style: const TextStyle(fontSize: 12, color: Colors.red),
                ),
              ),
            const Spacer(),
            // KHÔNG chặn nút này khi _loading==true - phần nghe thử/ước tính
            // chỉ là thông tin tham khảo, không phải điều kiện bắt buộc để
            // tạo MV. Người dùng không muốn đợi có thể bấm tiếp ngay. Cảnh báo
            // dung lượng cũng CHỈ LÀ CẢNH BÁO - không chặn nút, người dùng tự quyết.
            ElevatedButton(onPressed: _next, child: const Text('Bắt đầu tạo MV')),
          ],
        ),
      ),
    );
  }
}
