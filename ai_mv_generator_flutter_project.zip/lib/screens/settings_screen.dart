import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'crash_log_screen.dart';
import 'privacy_screen.dart';
import '../api_service.dart';
import '../error_reporter.dart';
import '../l10n.dart';
import '../generation_settings.dart';
import 'control_screen.dart';
import 'lora_screen.dart';

class SettingsScreen extends StatefulWidget {
  final ApiService api;

  const SettingsScreen({super.key, required this.api});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final s = GenerationSettings.instance;
  bool _uploadingControlVideo = false;
  bool _loadingComfy = false;
  List<String> _comfyNames = [];
  String _comfyNote = tr('Bấm "Làm mới" để lấy danh sách workflow từ backend.');

  late final TextEditingController _characterDescCtrl =
      TextEditingController(text: s.characterDesc);
  late final TextEditingController _hmacSecretCtrl =
      TextEditingController(text: s.hmacSecret);
  late final TextEditingController _watermarkCtrl =
      TextEditingController(text: s.watermarkText);
  late final TextEditingController _settingDescCtrl =
      TextEditingController(text: s.settingDesc); // MỚI (mục 26)
  late final TextEditingController _errorDsnCtrl = TextEditingController(text: ErrorReporter.dsn); // MỚI (mục 27)

  // Danh sách backend video lấy ĐỘNG từ server (KHÔNG hardcode tên/label ở
  // đây) - xem GET /video-backends. null = đang tải hoặc tải lỗi.
  List<Map<String, dynamic>>? _videoBackends;
  String? _videoBackendsError;

  @override
  void initState() {
    super.initState();
    _loadVideoBackends();
  }

  Future<void> _loadVideoBackends() async {
    try {
      final result = await widget.api.getVideoBackends();
      final backends = List<Map<String, dynamic>>.from(result['backends'] as List);
      if (!mounted) return;
      setState(() {
        _videoBackends = backends;
        // Chưa chọn gì trước đó -> dùng default server trả về (không hardcode).
        s.videoBackend ??= result['default'] as String?;
      });
    } catch (e) {
      if (mounted) setState(() => _videoBackendsError = trv('Không tải được danh sách công nghệ video: {0}', [e]));
    }
  }

  /// MỚI (lượt audit sau 7zc21) - kiểm tra backend video ĐANG CHỌN có hỗ trợ
  /// "Mô tả nhân vật cố định" hay không - lấy ĐỘNG qua `supports_character_reference`
  /// (đã có sẵn trong response `/video-backends` từ trước, chỉ chưa được
  /// Flutter đọc/dùng tới) - KHÔNG hardcode tên backend nào ở đây, đúng
  /// nguyên tắc chung của cả dự án. Trả `true` (mặc định lạc quan) nếu chưa
  /// tải xong danh sách hoặc chưa chọn backend nào - tránh cảnh báo nhầm lúc
  /// đang loading.
  bool get _selectedSupportsCharacterReference {
    if (_videoBackends == null || s.videoBackend == null) return true;
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return true;
    return match.first['supports_character_reference'] == true;
  }

  String _powerLabel(int power) {
    if (power >= 80) return tr('Mạnh — nhanh nhất, dễ bị Colab ngắt nếu chạy lâu');
    if (power >= 45) return tr('Vừa (khuyến nghị) — cân bằng tốc độ và độ ổn định');
    return tr('Nhẹ — chậm hơn nhưng ổn định nhất cho phiên chạy dài');
  }

  /// true nếu backend video ĐANG CHỌN hỗ trợ camera chuyển động theo nhịp -
  /// KHÔNG quan tâm CƠ CHẾ cụ thể (Motion LoRA hay mô tả chèn prompt, xem
  /// VIDEO_BACKENDS ở app.py, mục 7x) - đọc field GỘP `supports_motion_camera`
  /// server đã tính sẵn, KHÔNG hardcode "chỉ animatediff hỗ trợ" ở đây.
  bool _currentBackendSupportsMotion() {
    if (_videoBackends == null || s.videoBackend == null) return true; // chưa tải xong -> tạm cho phép, tránh nháy UI
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return true;
    return match.first['supports_motion_camera'] == true;
  }

  /// MỚI (mục 7zc5) - tương tự _currentBackendSupportsMotion() ở trên, cho
  /// tính năng "nối cảnh" (lấy khung hình cuối cảnh trước làm điều kiện sinh
  /// cảnh sau, giảm giật/nhấp nháy bối cảnh) - hiện chỉ "wan22" hỗ trợ.
  bool _currentBackendSupportsSceneContinuity() {
    if (_videoBackends == null || s.videoBackend == null) return false;
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return false;
    return match.first['supports_scene_continuity'] == true;
  }

  @override
  void dispose() {
    GenerationSettings.instance.save(); // MỚI (mục 27) - lưu ngay khi rời màn Cài đặt (không đợi app xuống nền)
    _errorDsnCtrl.dispose();
    _characterDescCtrl.dispose();
    _hmacSecretCtrl.dispose();
    _watermarkCtrl.dispose();
    _settingDescCtrl.dispose();
    super.dispose();
  }

  /// MỚI (mục 31) - lấy danh sách workflow ComfyUI từ backend + cho biết ComfyUI có đang chạy không.
  Future<void> _refreshComfy() async {
    setState(() => _loadingComfy = true);
    String note;
    List<String> names = [];
    try {
      final r = await widget.api.listComfyWorkflows();
      if (r['status'] == 'ok') {
        names = ((r['workflows'] as List?) ?? []).map((e) => (e as Map)['name'] as String).toList();
        final running = r['comfy_running'] == true;
        note = trv('{0} Thư mục workflow: {1}', [running ? tr('ComfyUI đang chạy.') : tr('ComfyUI CHƯA chạy (chạy ô "Bước 5b" trong notebook).'), r['dir']]);
      } else {
        note = (r['note'] as String?) ?? tr('Backend không trả danh sách workflow.');
      }
    } catch (e) {
      note = trv('Không gọi được backend: {0}', [e]);
    }
    if (!mounted) return;
    setState(() {
      _loadingComfy = false;
      _comfyNames = names;
      _comfyNote = note;
    });
  }

  /// MỚI (mục 30) - chọn + tải video tham chiếu chuyển động lên backend (xem GenerationSettings.controlVideoFilename).
  Future<void> _pickControlVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video);
    final path = result?.files.single.path;
    if (path == null) return;
    setState(() => _uploadingControlVideo = true);
    String? error;
    try {
      final r = await widget.api.uploadControlVideo(videoFile: File(path));
      if (r['status'] == 'ok') {
        s.controlVideoFilename = r['filename'] as String;
        s.controlVideoLabel = path.split(Platform.pathSeparator).last;
      } else {
        error = (r['note'] as String?) ?? tr('Backend từ chối video này.');
      }
    } catch (e) {
      error = trv('Không tải được video: {0}', [e]);
    }
    if (!mounted) return;
    setState(() => _uploadingControlVideo = false);
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('Cài đặt tạo dữ liệu'))),
      body: SafeArea(
        top: false,
        child: ListView(
          padding: const EdgeInsets.all(16),
        children: [
          Text(tr('Công suất sử dụng GPU remote'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('Dùng GPU càng "mạnh tay" liên tục thì càng dễ bị Colab tự bóp/ngắt '
            'giữa chừng. Kéo xuống thấp nếu bạn hay bị ngắt kết nối khi tạo MV.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Text('${s.gpuPower}% — ${_powerLabel(s.gpuPower)}', style: const TextStyle(fontSize: 13)),
          Slider(
            value: s.gpuPower.toDouble(),
            min: 20,
            max: 100,
            divisions: 8,
            label: '${s.gpuPower}%',
            onChanged: (v) => setState(() => s.gpuPower = v.round()),
          ),

          // MỚI (mục 30, PDF-2 mục 4.1) - CHẾ ĐỘ NHANH
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Chế độ Nhanh'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Bỏ qua bước Đổi giọng (giữ giọng gốc) và bước Storyboard/xem trước ảnh nhân vật: sau khi có nhạc chỉ còn '
                          'chọn phong cách rồi tạo MV. Tắt để dùng đủ các bước như thường.'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.quickMode,
                    onChanged: (v) => setState(() => s.quickMode = v),
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 30, PDF-2 mục 4.2) - ẨN/HIỆN cài đặt nâng cao
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Hiện cài đặt nâng cao'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Cảnh mượt, chỉnh màu, đổi tốc độ, hiệu ứng điện ảnh, làm mượt, upscale, xuất dọc 9:16, preset nền tảng, phụ đề, '
                          'watermark... Đang ẩn chỉ để gọn màn hình - giá trị bạn đã đặt trước đó VẪN được giữ và vẫn có tác dụng.'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.expertMode,
                    onChanged: (v) => setState(() => s.expertMode = v),
                  ),
                ],
              ),
            ),
          ),

          const Divider(height: 32),
          Text(tr('Tham số tạo nhạc / MV'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),

          _sliderTile(
            label: tr('Thời lượng nhạc'),
            value: s.duration,
            min: 10,
            max: 120,
            divisions: 22,
            display: '${s.duration.toStringAsFixed(0)}s',
            onChanged: (v) => setState(() => s.duration = v),
          ),
          _sliderTile(
            label: tr('Số beat / 1 cảnh video'),
            value: s.beatsPerScene.toDouble(),
            min: 2,
            max: 8,
            divisions: 6,
            display: '${s.beatsPerScene}',
            onChanged: (v) => setState(() => s.beatsPerScene = v.round()),
          ),
          _sliderTile(
            label: tr('Số cảnh tối đa trong MV'),
            value: s.maxScenes.toDouble(),
            min: 2,
            max: 16,
            divisions: 14,
            display: '${s.maxScenes}',
            onChanged: (v) => setState(() => s.maxScenes = v.round()),
          ),
          _sliderTile(
            label: tr('Số bước inference mỗi cảnh (chất lượng)'),
            value: s.numInferenceSteps.toDouble(),
            min: 10,
            max: 40,
            divisions: 30,
            display: '${s.numInferenceSteps}',
            onChanged: (v) => setState(() => s.numInferenceSteps = v.round()),
          ),
          _sliderTile(
            label: tr('Guidance scale (độ bám sát mô tả)'),
            value: s.guidanceScale,
            min: 1,
            max: 15,
            divisions: 28,
            display: s.guidanceScale.toStringAsFixed(1),
            onChanged: (v) => setState(() => s.guidanceScale = v),
          ),

          const Divider(height: 32),
          Text(tr('Mô tả nhân vật cố định (tuỳ chọn)'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('Chèn vào MỌI cảnh để tăng nhẹ tính nhất quán hình ảnh giữa các cảnh '
            '(vd "cô gái tóc đen dài, áo khoác đỏ, mắt nâu"). Đây chỉ là mẹo nhẹ '
            '(prompt + seed cùng gốc) - không đảm bảo nhân vật giống hệt nhau '
            'giữa các cảnh như phần mềm chuyên dụng. Để trống nếu không cần.\n'
            'ĐA NHÂN VẬT (mục 30): mỗi DÒNG = 1 nhân vật, tối đa 3. Dòng đầu là nhân vật chính (mọi công nghệ dùng); các dòng sau CHỈ Wan-VACE dùng để '
            'cho nhiều nhân vật xuất hiện cùng nhau.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _characterDescCtrl,
            maxLines: 4,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: tr('vd: cô gái tóc đen dài, áo khoác đỏ, mắt nâu'),
            ),
            onChanged: (v) => setState(() => s.characterDesc = v), // setState để cảnh báo bên dưới cập nhật ngay khi gõ
          ),
          // MỚI (lượt audit sau 7zc21) - CẢNH BÁO ĐỘNG khi backend video
          // ĐANG CHỌN không hỗ trợ tính năng này (vd Wan2.2 - kiến trúc DiT,
          // xem docstring `_generate_scene_clip_wan22` phía server) - CHỈ
          // hiện khi đã điền mô tả (tránh cảnh báo thừa lúc ô còn trống,
          // chưa ảnh hưởng gì). TRƯỚC ĐÂY field này LUÔN hiển thị bình
          // thường bất kể backend nào đang chọn - người dùng điền mô tả kỹ
          // càng rồi chọn Wan2.2 (vì lý do khác, vd "video nét/dài hơn")
          // hoàn toàn KHÔNG biết 2 lựa chọn đó XUNG ĐỘT NHAU - server đã có
          // sẵn field `supports_character_reference` (endpoint
          // /video-backends) từ trước, chỉ CHƯA được Flutter đọc/dùng tới.
          if (!_selectedSupportsCharacterReference && s.characterDesc.trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  border: Border.all(color: Colors.orange.shade200),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.warning_amber_rounded, size: 18, color: Colors.orange.shade800),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        tr('Công nghệ tạo video đang chọn KHÔNG hỗ trợ mô tả nhân vật cố định '
                        '(kiến trúc khác không tương thích) - mô tả này sẽ KHÔNG có tác dụng '
                        'cho tới khi bạn đổi sang công nghệ khác có hỗ trợ (xem mục bên dưới).'),
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          const Divider(height: 32),
          // MỚI (mục 26) - bối cảnh cố định (PDF mục 8.3)
          Text(tr('Bối cảnh cố định (tuỳ chọn)'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('Chèn vào MỌI cảnh để các cảnh cùng 1 địa điểm/thời điểm (vd "quán cà phê ban đêm, đèn vàng ấm"), '
            'tránh cảnh 1 ban ngày, cảnh 2 ban đêm. Cũng chỉ là mẹo prompt - không đảm bảo giống hệt giữa các cảnh. '
            'Để trống nếu muốn mỗi cảnh tự do theo kịch bản.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _settingDescCtrl,
            maxLines: 2,
            maxLength: 200,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: tr('vd: quán cà phê ban đêm, đèn vàng ấm, mưa ngoài cửa kính'),
            ),
            onChanged: (v) => s.settingDesc = v,
          ),

          const Divider(height: 32),
          Text(tr('Công nghệ tạo video'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('Danh sách lấy trực tiếp từ backend (Colab) - đổi/thêm công nghệ mới bên '
            'server sẽ tự hiện ở đây, không cần cập nhật app.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (_videoBackendsError != null)
            Text(_videoBackendsError!, style: const TextStyle(color: Colors.red, fontSize: 12))
          else if (_videoBackends == null)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Center(child: CircularProgressIndicator()),
            )
          else
            // KHÔNG dùng RadioListTile ở đây nữa - label các backend (đặc
            // biệt VACE, có mô tả dài kèm cảnh báo "THỬ NGHIỆM") bị
            // RadioListTile ép vào ĐÚNG 1 DÒNG, cắt cụt phần sau bằng "..."
            // (ListTile.title mặc định chỉ dành cho text ngắn 1 dòng theo
            // chuẩn Material) - đổi sang Card + Column để chữ được XUỐNG
            // DÒNG ĐẦY ĐỦ, không mất chữ nào.
            ..._videoBackends!.map((b) => Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    onTap: () => setState(() {
                      s.videoBackend = b['id'] as String;
                      final supportsMotion = b['supports_motion_camera'] == true;
                      if (!supportsMotion) s.enableMotionCamera = false;
                      final supportsContinuity = b['supports_scene_continuity'] == true; // MỚI (mục 7zc5)
                      if (!supportsContinuity) s.enableSceneContinuity = false;
                    }),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Radio<String>(
                            value: b['id'] as String,
                            groupValue: s.videoBackend,
                            onChanged: (v) => setState(() {
                              s.videoBackend = v;
                              final supportsMotion = b['supports_motion_camera'] == true;
                              if (!supportsMotion) s.enableMotionCamera = false;
                              final supportsContinuity = b['supports_scene_continuity'] == true; // MỚI (mục 7zc5)
                              if (!supportsContinuity) s.enableSceneContinuity = false;
                            }),
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 14),
                              child: Text(b['label'] as String), // KHÔNG set maxLines/overflow -> tự xuống dòng, không cắt
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )),

          // MỚI (mục 30) - nhóm CÀI ĐẶT NÂNG CAO chỉ hiện khi bật công tắc ở trên (giá trị đã lưu vẫn giữ nguyên khi ẩn)
          if (s.expertMode) ...[
          const Divider(height: 32),
          // KHÔNG dùng SwitchListTile ở đây nữa - cùng lý do đã sửa ở trên
          // (video backend): subtitle dài (giải thích cơ chế + cảnh báo
          // "chưa test thật") có thể bị cắt bởi giới hạn chiều cao mặc định
          // của ListTile - đổi sang Card + Column để chắc chắn hiện đủ chữ.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Camera chuyển động theo nhịp'), style: TextStyle(fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        Text(
                          _currentBackendSupportsMotion()
                              ? tr('Tự zoom/lia camera theo đoạn nhạc dồn dập hay êm dịu (cơ chế tuỳ '
                                'công nghệ video đang chọn - LoRA hoặc mô tả trong prompt). Chưa '
                                'test thật trên GPU - nếu thấy nạp model chậm hẳn hoặc lỗi, tắt để '
                                'dùng cách cũ (không có chuyển động camera đặc biệt).')
                              : tr('Công nghệ video đang chọn CHƯA hỗ trợ tính năng này.'),
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.enableMotionCamera && _currentBackendSupportsMotion(),
                    onChanged: _currentBackendSupportsMotion() ? (v) => setState(() => s.enableMotionCamera = v) : null,
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 7zc5) - "Nối cảnh mượt" - CHỈ hiện khi công nghệ video
          // đang chọn hỗ trợ (hiện chỉ Wan2.2 - ẨN HẲN, không phải khoá mờ,
          // ở công nghệ khác, giống cách công tắc Lipsync ẩn ở style không
          // hỗ trợ tại style_screen.dart).
          if (_currentBackendSupportsSceneContinuity())
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tr('Nối cảnh mượt (thử nghiệm)'), style: TextStyle(fontWeight: FontWeight.w500)),
                          const SizedBox(height: 4),
                          Text(
                            tr('Lấy khung hình cuối của cảnh trước làm điều kiện cho cảnh sau, '
                            'giảm giật/nhấp nháy bối cảnh giữa 2 cảnh liên tiếp. Chạy chậm hơn '
                            '1 chút (đổi qua lại giữa 2 chế độ nạp model) - CHƯA test thật trên '
                            'GPU, tắt nếu thấy lỗi hoặc video không như mong đợi.'),
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: s.enableSceneContinuity,
                      onChanged: (v) => setState(() => s.enableSceneContinuity = v),
                    ),
                  ],
                ),
              ),
            ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Cân bằng màu (Color Grading)'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Tự động khớp tông màu mọi cảnh theo đúng cảnh mở đầu, tránh MV bị '
                          'lệch màu (vàng ấm/xanh lạnh) giữa các cảnh. An toàn - tự bỏ qua '
                          'nếu lỗi, không ảnh hưởng tới việc tạo MV.'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.enableColorMatch,
                    onChanged: (v) => setState(() => s.enableColorMatch = v),
                  ),
                ],
              ),
            ),
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tr('Đổi tốc độ theo nhịp (thử nghiệm)'), style: TextStyle(fontWeight: FontWeight.w500)),
                            SizedBox(height: 4),
                            Text(
                              tr('Đổi nhẹ tốc độ phát mỗi cảnh (±6%) theo cường độ nhịp bài hát - '
                              'CHƯA kiểm chứng bằng mắt, tự tắt an toàn nếu lỗi. Không đổi thời '
                              'lượng cảnh nên không lệch nhịp với nhạc.'),
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: s.enableSpeedRamping,
                        onChanged: (v) => setState(() => s.enableSpeedRamping = v),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Formant Shifting + De-essing đã được dời sang VoiceScreen (màn
          // Chọn giọng) vì chúng chỉ có tác dụng ở bước đổi giọng RVC -
          // người dùng thấy ngay khi cần thay vì phải mò vào Cài đặt.

          // ---- MỚI (BỔ SUNG dựa trên file "Phân_tích_MV_triệu_view_-_DeepSeek.pdf"
          // - xem post_processing_v2.py + CHANGELOG_NANG_CAP.md mục 10 phía backend) ----

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tr('Hiệu ứng hậu kỳ điện ảnh'), style: TextStyle(fontWeight: FontWeight.w500)),
                            SizedBox(height: 4),
                            Text(
                              tr('Thêm vignette (tối nhẹ 4 góc) + film grain (hạt nhiễu nhẹ) + tăng '
                              'nét - giúp MV bớt cảm giác "quá mượt/quá sạch" đặc trưng của video '
                              'AI. Rẻ (chỉ vài giây), an toàn - tự bỏ qua nếu lỗi.'),
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: s.enablePostFx,
                        onChanged: (v) => setState(() => s.enablePostFx = v),
                      ),
                    ],
                  ),
                  if (s.enablePostFx) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(tr('Mức độ: '), style: TextStyle(fontSize: 13)),
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: Text(tr('Nhẹ')),
                          selected: s.postFxIntensity == 'light',
                          onSelected: (_) => setState(() => s.postFxIntensity = 'light'),
                        ),
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: Text(tr('Rõ')),
                          selected: s.postFxIntensity == 'strong',
                          onSelected: (_) => setState(() => s.postFxIntensity = 'strong'),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tr('Làm mượt chuyển động (thử nghiệm)'), style: TextStyle(fontWeight: FontWeight.w500)),
                            SizedBox(height: 4),
                            Text(
                              tr('Nội suy khung hình 24 lên 48fps, giảm cảm giác giật/lặp do clip AI '
                              'gốc rất ngắn. Khá tốn thời gian xử lý.'),
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: s.enableMotionSmoothing,
                        onChanged: (v) => setState(() => s.enableMotionSmoothing = v),
                      ),
                    ],
                  ),
                  if (s.enableMotionSmoothing) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(tr('Cách làm mượt: '), style: TextStyle(fontSize: 13)),
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: const Text('Nhanh'),
                          selected: s.motionSmoothingMethod == 'ffmpeg',
                          onSelected: (_) => setState(() => s.motionSmoothingMethod = 'ffmpeg'),
                        ),
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: Text(tr('RIFE (AI, đẹp hơn)')),
                          selected: s.motionSmoothingMethod == 'rife',
                          onSelected: (_) => setState(() => s.motionSmoothingMethod = 'rife'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      s.motionSmoothingMethod == 'rife'
                          ? tr('RIFE dùng AI chuyên nội suy chuyển động - kết quả sắc nét hơn, '
                            'ít bóng mờ hơn thuật toán cổ điển. Tự tải model (~67MB) ở lần '
                            'dùng đầu tiên, không cần cài thêm gì trên Colab.')
                          : tr('Thuật toán cổ điển của ffmpeg (minterpolate) - nhanh, luôn sẵn '
                            'có, nhưng có thể tạo bóng mờ ở cảnh chuyển động nhanh/phức tạp.'),
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ],
              ),
            ),
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Upscale bằng Real-ESRGAN (nâng cao)'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Tăng độ phân giải MV bằng AI (VD 512×288 → 1024×576). CHỈ bật nếu '
                          'Colab đang chạy GPU thật VÀ đã cài thêm "realesrgan basicsr" (xem '
                          'colab_setup.py) - trên CPU cực chậm (~49 giây/khung hình đã đo '
                          'thực tế), có thể khiến MV nhiều cảnh mất hàng giờ để xử lý xong.\n'
                          'LƯU Ý KHUÔN MẶT: model này không chuyên cho mặt người và xử lý từng '
                          'khung độc lập nên có thể làm mặt biến dạng/nhấp nháy. Vì vậy với phong '
                          'cách người thật, MV đã khớp khẩu hình, hoặc khi phát hiện có mặt, backend '
                          'TỰ BỎ QUA bước này (giữ nguyên độ phân giải gốc). Bộ phát hiện còn yếu: '
                          'có thể sót mặt nhỏ/nghiêng, và đôi khi bỏ qua cả video không có người.'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.enableRealesrganUpscale,
                    onChanged: (v) => setState(() => s.enableRealesrganUpscale = v),
                  ),
                ],
              ),
            ),
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Xuất thêm bản dọc 9:16'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Tạo THÊM 1 bản dọc cho YouTube Shorts/TikTok/Instagram Reels (không '
                          'thay thế bản ngang). Tự chọn vùng cắt có nhiều chi tiết nhất (KHÔNG '
                          'phải nhận diện người/chủ thể) - nếu khung hình có nhiều vùng chi tiết '
                          'rải rác, có thể cắt trúng chỗ không như bạn muốn; nếu không tính được '
                          'thì rơi về cắt giữa khung. Tốn thêm thời gian xử lý + dung lượng.'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.exportVertical,
                    onChanged: (v) => setState(() => s.exportVertical = v),
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 23) - phụ đề lời bài hát khắc thẳng vào video
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Khắc phụ đề lời bài hát vào video'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Để đăng lên YouTube/TikTok mà không cần app ngoài. CẦN đã nhập lời bài hát '
                    'và backend căn chỉnh được thời gian từng từ (thiếu 1 trong 2 thì tự bỏ qua, '
                    'MV vẫn ra bình thường). Chữ hiện ở giữa phía dưới, cũng áp dụng cho bản dọc. '
                    'Cần font có dấu tiếng Việt trên Colab (DejaVu Sans thường có sẵn); font thiếu '
                    'thì chữ có dấu có thể hiện ô vuông.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: Text(tr('Tắt')),
                        selected: s.burnInLyrics == '',
                        onSelected: (_) => setState(() => s.burnInLyrics = ''),
                      ),
                      ChoiceChip(
                        label: Text(tr('Chữ thường')),
                        selected: s.burnInLyrics == 'plain',
                        onSelected: (_) => setState(() => s.burnInLyrics = 'plain'),
                      ),
                      ChoiceChip(
                        label: Text(tr('Karaoke (tô sáng từng từ)')),
                        selected: s.burnInLyrics == 'karaoke',
                        onSelected: (_) => setState(() => s.burnInLyrics = 'karaoke'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 23) - cắt cảnh theo cấu trúc bài hát (THỬ NGHIỆM)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('Cắt cảnh theo cấu trúc bài hát (thử nghiệm)'), style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          tr('Dịch ranh giới giữa các cảnh về chỗ bài hát đổi đoạn (verse/điệp khúc) '
                          'thay vì giữa câu. Mới kiểm tra trên âm thanh tổng hợp, CHƯA kiểm chứng '
                          'với nhạc thật nên mặc định TẮT. Chỉ áp dụng cho dự án MỚI (dự án tiếp '
                          'tục dùng lại cảnh đã lưu).'),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.structureSnap,
                    onChanged: (v) => setState(() => s.structureSnap = v),
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 25) - watermark chữ
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Watermark chữ (tên kênh / bản quyền)'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Đóng chữ nhỏ ở góc trên bên phải video (cả bản dọc), không đè lên phụ đề. Để trống = tắt. '
                    'Chữ quá dài so với bề ngang khung sẽ được rút gọn bằng dấu "…". Cần font có dấu tiếng '
                    'Việt trên Colab (DejaVu Sans thường có sẵn).'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _watermarkCtrl,
                    maxLength: 60,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      isDense: true,
                      hintText: tr('vd: © Kênh ABC'),
                    ),
                    onChanged: (v) => s.watermarkText = v,
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 26) - hiệu ứng điện ảnh bổ sung (PDF mục 2.7)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Hiệu ứng điện ảnh bổ sung'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Làm hậu kỳ bằng ffmpeg (vài chục giây, không tốn GPU), áp sau khi làm mượt và TRƯỚC phụ đề. '
                    'Cường độ theo mục "Hiệu ứng hậu kỳ" ở trên (nhẹ/mạnh). Đã xem thử trên video thử có vật chuyển động, '
                    'CHƯA xem trên cảnh AI thật - bật thử 1 MV ngắn trước.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(tr('Mờ chuyển động nhẹ')),
                    subtitle: Text(
                      tr('Trộn khung liền kề: làm mềm vật đang di chuyển (vùng tĩnh không đổi). KHÔNG phải optical flow - '
                      'chuyển động rất mạnh có thể hiện vệt mờ nhẹ phía sau vật thể.'),
                      style: TextStyle(fontSize: 12),
                    ),
                    value: s.fxMotionBlur,
                    onChanged: (v) => setState(() => s.fxMotionBlur = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(tr('Rò sáng (light leak)')),
                    subtitle: Text(
                      tr('Mảng sáng ấm màu cam trôi chậm trên khung hình, tạo cảm giác phim.'),
                      style: TextStyle(fontSize: 12),
                    ),
                    value: s.fxLightLeak,
                    onChanged: (v) => setState(() => s.fxLightLeak = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(tr('Phát sáng (bloom)')),
                    subtitle: Text(
                      tr('Quầng sáng mềm quanh đèn/vùng sáng. Gần với "lens glow" hơn là flare nhiều lớp.'),
                      style: TextStyle(fontSize: 12),
                    ),
                    value: s.fxBloom,
                    onChanged: (v) => setState(() => s.fxBloom = v),
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 26) - preset xuất nền tảng (PDF mục 9.3)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Xuất theo preset nền tảng'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('YouTube 1080p: phóng bằng Lanczos lên 1920×1080 (KHÔNG thêm chi tiết nhưng cũng không "bịa" gì - an toàn với '
                    'khuôn mặt, khác upscale AI), đổi đúng ma trận màu BT.601→BT.709 và gắn thẻ màu, đưa moov lên đầu file, không edit '
                    'list, âm thanh AAC 48 kHz - theo trang YouTube Help về thông số tải lên. Nền tảng xếp video theo độ phân giải tải '
                    'lên nên bản 1080p thường được mã hoá lại với bitrate cao hơn bản 288p (báo cáo của người làm video - CHƯA tự đo). '
                    'File lớn hơn và xuất mất thêm vài phút. Bản dọc (nếu bật) cũng được chuẩn hoá màu.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: Text(tr('Tắt (giữ file gốc)')),
                        selected: s.exportPreset == '',
                        onSelected: (_) => setState(() => s.exportPreset = ''),
                      ),
                      ChoiceChip(
                        label: const Text('YouTube 1080p'),
                        selected: s.exportPreset == 'youtube_1080p',
                        onSelected: (_) => setState(() => s.exportPreset = 'youtube_1080p'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 49) - look màu CUỐI (PDF: upscale -> hạt phim -> chỉnh màu)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Chỉnh màu phim cuối (thử nghiệm)'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Bước cuối của hậu kỳ (sau upscale và hạt phim, trước phụ đề): đổi tông màu cả MV theo một "look" - ấm điện ảnh, lạnh '
                    'xanh, teal-cam hoặc phim cổ điển. Khác "Cân bằng màu" (chỉ khớp màu giữa các cảnh). Cường độ theo mục "Hiệu ứng điện '
                    'ảnh" (nhẹ/mạnh). Chỉ dùng ffmpeg trên CPU, tốn vài chục giây. Đã đo là dịch màu đúng hướng nhưng CHƯA nhìn trên cảnh '
                    'AI thật - thử trên 1 MV ngắn trước.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: Text(tr('Tắt')),
                        selected: s.colorLook == '',
                        onSelected: (_) => setState(() => s.colorLook = ''),
                      ),
                      ChoiceChip(
                        label: Text(tr('Ấm điện ảnh')),
                        selected: s.colorLook == 'warm',
                        onSelected: (_) => setState(() => s.colorLook = 'warm'),
                      ),
                      ChoiceChip(
                        label: Text(tr('Lạnh xanh')),
                        selected: s.colorLook == 'cool',
                        onSelected: (_) => setState(() => s.colorLook = 'cool'),
                      ),
                      ChoiceChip(
                        label: Text(tr('Teal - cam (bom tấn)')),
                        selected: s.colorLook == 'teal_orange',
                        onSelected: (_) => setState(() => s.colorLook = 'teal_orange'),
                      ),
                      ChoiceChip(
                        label: Text(tr('Phim cổ điển (mờ)')),
                        selected: s.colorLook == 'faded_film',
                        onSelected: (_) => setState(() => s.colorLook = 'faded_film'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 26) - upscale khi có mặt người
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Upscale AI khi video có mặt người'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Chỉ có tác dụng khi bật "Upscale bằng Real-ESRGAN" ở trên. "Bỏ qua" (mặc định): không upscale AI nếu có dấu hiệu '
                    'mặt người, như trước. "Bảo vệ mặt" (THỬ NGHIỆM): upscale AI cho phần nền nhưng GIỮ bản Lanczos ở vùng mặt, hộp '
                    'mặt được theo dõi qua các khung để không nhấp nháy. Chỉ chạy khi bộ dò THẤY mặt - mặt nhỏ/nghiêng mà bộ dò sót vẫn '
                    'bị xử lý bằng AI. CHƯA kiểm chứng trên mặt do AI sinh: hãy so sánh bằng `colab_verify.py facetest` trước.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: Text(tr('Bỏ qua (an toàn)')),
                        selected: s.upscaleFaceMode == 'skip',
                        onSelected: (_) => setState(() => s.upscaleFaceMode = 'skip'),
                      ),
                      ChoiceChip(
                        label: Text(tr('Bảo vệ mặt (thử nghiệm)')),
                        selected: s.upscaleFaceMode == 'protect',
                        onSelected: (_) => setState(() => s.upscaleFaceMode = 'protect'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 33) - MÔ HÌNH & CÔNG CỤ: đổi model, cài/bật ComfyUI, tải model, API miễn phí - NGAY TRÊN APP, không phải mở Colab (xem ControlScreen)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Mô hình & công cụ'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Đổi model theo từng khe, cài/bật ComfyUI, thêm node, tải file model, đặt workflow và dùng API miễn phí (Groq/Gemini/OpenRouter) - tất cả ngay trên app, không cần mở Colab. Cần khoá HMAC (backend in ở Bước 7).'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => ControlScreen(api: widget.api)));
                        if (mounted) setState(() {});
                      },
                      child: Text(tr('Mở')),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 31) - LoRA của người dùng (chỗ để thêm file LoRA) - xem LoraScreen
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('LoRA của bạn (phong cách / nhân vật)'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Thêm file LoRA (.safetensors) vào thư mục loras trên Google Drive hoặc tải từ app, chọn LoRA và độ mạnh cho MV. '
                    'Việc huấn luyện LoRA làm ngoài app. LoRA phải cùng họ model nền với công nghệ video đang dùng. CHƯA chạy thử trên GPU thật.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          s.loraSelection.isEmpty ? tr('Chưa chọn LoRA nào') : trv('Đã chọn {0} LoRA', [s.loraSelection.length]),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      TextButton(
                        onPressed: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => LoraScreen(api: widget.api)));
                          if (mounted) setState(() {});
                        },
                        child: Text(tr('Quản lý LoRA')),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 31) - chọn WORKFLOW ComfyUI (cầu nối TỔNG QUÁT: thêm model mới = thêm file JSON vào thư mục comfy_workflows trên Drive, không sửa code)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Workflow ComfyUI', style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Chỉ dùng khi chọn công nghệ video "ComfyUI". Đặt file <tên>.json (Save API Format) và <tên>.map.json (ánh xạ) vào thư mục comfy_workflows '
                    'trên Google Drive, chạy ô ComfyUI trong notebook rồi bấm Làm mới. Model nào cũng được - không cần sửa code. CHƯA chạy thử với ComfyUI thật.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButton<String>(
                          isExpanded: true,
                          hint: Text(tr('Chưa chọn workflow')),
                          value: s.comfyWorkflow.isEmpty ? null : s.comfyWorkflow,
                          items: [
                            for (final n in {..._comfyNames, if (s.comfyWorkflow.isNotEmpty) s.comfyWorkflow})
                              DropdownMenuItem<String>(value: n, child: Text(n, overflow: TextOverflow.ellipsis)),
                          ],
                          onChanged: (v) => setState(() => s.comfyWorkflow = v ?? ''),
                        ),
                      ),
                      TextButton(
                        onPressed: _loadingComfy ? null : _refreshComfy,
                        child: Text(_loadingComfy ? tr('Đang tải...') : tr('Làm mới')),
                      ),
                    ],
                  ),
                  Text(_comfyNote, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
            ),
          ),

          // MỚI (mục 30, PDF "MV triệu view cần gì" - ReShot "copy the shot, not the actors") - video tham chiếu chuyển động cho Wan-VACE
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Video tham chiếu chuyển động (Wan-VACE)'), style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Chọn 1 video vũ đạo/góc máy: mỗi cảnh lấy 1 đoạn video này, tách thành khung cạnh (canny) để ĐIỀU KHIỂN chuyển động, '
                    'còn nhân vật và phong cách vẫn là của bạn. CHỈ có tác dụng khi chọn công nghệ Wan-VACE (các công nghệ khác bỏ qua). '
                    'Video nằm ở Colab nên mất khi Colab khởi động lại - khi đó MV tự tạo không điều khiển. CHƯA chạy thử trên GPU thật.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          s.controlVideoFilename.isEmpty ? tr('Chưa chọn video') : s.controlVideoLabel,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (s.controlVideoFilename.isNotEmpty)
                        TextButton(
                          onPressed: () => setState(() {
                            s.controlVideoFilename = '';
                            s.controlVideoLabel = '';
                          }),
                          child: Text(tr('Bỏ')),
                        ),
                      TextButton(
                        onPressed: _uploadingControlVideo ? null : _pickControlVideo,
                        child: Text(_uploadingControlVideo ? tr('Đang tải...') : tr('Chọn video')),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          ],

          const Divider(height: 32),
          Text(tr('Bảo mật nâng cao (tuỳ chọn)'), style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('Từ mục 33 backend TỰ SINH khoá này (notebook Bước 5 mục a bật sẵn) và in ra ở Bước 7 cùng địa chỉ - dán vào đây. '
            'Dùng để ký yêu cầu tạo MV/train giọng và MỌI thao tác điều khiển trong "Mô hình & công cụ", chặn người khác gọi thẳng '
            'URL Colab công khai của bạn. Để trống nếu bạn đã tắt tính năng này ở backend.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _hmacSecretCtrl,
            obscureText: true,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: tr('Khoá bí mật HMAC (để trống nếu không dùng)'),
            ),
            onChanged: (v) {
              s.hmacSecret = v;
              s.saveHmacChoice();
            },
          ),

          const Divider(height: 32),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.privacy_tip_outlined),
            title: Text(tr('Quyền riêng tư & dữ liệu')),
            subtitle: Text(tr('Dữ liệu đi đâu, app lưu gì, đặt lại xác nhận đã đồng ý')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen())),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.bug_report_outlined),
            title: Text(tr('Nhật ký lỗi (lưu trong máy)')),
            subtitle: Text(tr('Xem/chia sẻ lỗi app đã ghi nhận để gửi cho người sửa lỗi')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CrashLogScreen())),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(tr('Tự gửi nhật ký lỗi về backend của bạn')),
            subtitle: Text(
              tr('Khi kết nối được backend, app tự gửi nhật ký lỗi lên Drive của bạn (thư mục crash_reports) - không cần tài khoản nào, không gửi tới ai khác.'),
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
            value: s.autoUploadCrashLog,
            onChanged: (v) => setState(() => s.autoUploadCrashLog = v),
          ),

          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('Giao diện & chia sẻ cài đặt'), style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: Text(tr('Chế độ sáng/tối'))),
                      DropdownButton<String>(
                        value: s.themeMode,
                        items: [
                          DropdownMenuItem(value: 'light', child: Text(tr('Sáng'))),
                          DropdownMenuItem(value: 'dark', child: Text(tr('Tối'))),
                          DropdownMenuItem(value: 'system', child: Text(tr('Theo hệ thống'))),
                        ],
                        onChanged: (v) {
                          if (v != null) setState(() => s.themeMode = v);
                        },
                      ),
                    ],
                  ),
                  Text(
                    tr('Chế độ tối là TUỲ CHỌN thử nghiệm: một số màn dùng màu cố định nên có thể chưa đẹp - hãy báo màn nào cần chỉnh.'),
                    style: TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(tr('Tương phản cao')),
                    subtitle: Text(
                      tr('Trợ năng: tăng độ tương phản màu của chữ, nút và viền. Mặc định tắt. Chỉ đổi bảng màu chủ đạo - chỗ nào dùng màu xám cố định vẫn giữ nguyên.'),
                      style: TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                    value: s.highContrast,
                    onChanged: (v) => setState(() => s.highContrast = v),
                  ),
                  Row(
                    children: [
                      Expanded(child: Text(tr('Ngôn ngữ giao diện'))),
                      DropdownButton<String>(
                        value: s.language,
                        items: [
                          DropdownMenuItem(value: 'vi', child: Text(tr('Tiếng Việt'))),
                          DropdownMenuItem(value: 'en', child: Text('English')),
                        ],
                        onChanged: (v) {
                          if (v != null) setState(() => s.language = v);
                        },
                      ),
                    ],
                  ),
                  Text(
                    tr('Có hiệu lực khi mở lại app. Các màn và nút chính đã có tiếng Anh; một số đoạn giải thích dài vẫn còn tiếng Việt (xem l10n.dart).'),
                    style: TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                  _sliderTile(
                    label: tr('Cỡ chữ của app'),
                    value: s.textScale,
                    min: 0.85,
                    max: 1.4,
                    divisions: 11,
                    display: '${(s.textScale * 100).round()}%',
                    onChanged: (v) => setState(() => s.textScale = v),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _exportPreset,
                          icon: const Icon(Icons.ios_share),
                          label: Text(tr('Chia sẻ cài đặt')),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _importPreset,
                          icon: const Icon(Icons.content_paste),
                          label: Text(tr('Dán cài đặt')),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(tr('Báo lỗi tự động tới Sentry (tuỳ chọn, mặc định TẮT)'), style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(
                    tr('Cần tài khoản Sentry CỦA BẠN. Dán DSN vào đây để lỗi của app được gửi về Sentry của bạn (loại lỗi, thông điệp, stack trace; KHÔNG gửi nhạc/lời/prompt). '
                    'Để trống = không gửi gì. Chỉ lỗi phía Dart, không có crash native.'),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _errorDsnCtrl,
                    decoration: InputDecoration(
                      labelText: tr('Sentry DSN (https://khoá@o123.ingest.sentry.io/456)'),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (v) {
                      ErrorReporter.setDsn(v);
                      setState(() {}); // cập nhật cảnh báo "DSN không đọc được" ngay khi gõ
                    },
                  ),
                  if (_errorDsnCtrl.text.trim().isNotEmpty && ErrorReporter.parseDsn(_errorDsnCtrl.text) == null)
                    Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text(tr('DSN này không đọc được - kiểm tra lại định dạng.'), style: TextStyle(fontSize: 12, color: Colors.orange)),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            tr('Số cảnh nhiều hơn / bước inference cao hơn → chất lượng tốt hơn nhưng '
            'chạy lâu hơn. Mỗi cảnh xong được đẩy về máy ngay lập tức, và nếu bị '
            'ngắt giữa chừng, lần tạo lại sau sẽ tiếp tục từ cảnh còn thiếu — '
            'không sinh lại từ đầu.'),
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
        ],
        ),
      ),
    );
  }

  /// MỚI (mục 27, PDF 11.2 "chia sẻ preset") - gửi toàn bộ cài đặt (trừ khoá bí mật HMAC) dưới dạng văn bản JSON qua Zalo/Telegram/...; người nhận bấm "Dán cài đặt".
  Future<void> _exportPreset() async {
    final text = const JsonEncoder.withIndent('  ').convert(s.toJson());
    try {
      await Share.share(text, subject: tr('Cài đặt AI MV Generator'));
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: text));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Đã sao chép cài đặt vào bộ nhớ tạm.'))));
    }
  }

  Future<void> _importPreset() async {
    final clip = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted) return;
    final ctrl = TextEditingController(text: clip?.text ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Dán cài đặt')),
        content: TextField(
          controller: ctrl,
          maxLines: 8,
          decoration: InputDecoration(hintText: tr('Dán nội dung JSON của cài đặt đã nhận...')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Huỷ'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Áp dụng'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      final decoded = jsonDecode(ctrl.text);
      if (decoded is! Map<String, dynamic>) throw const FormatException('không phải đối tượng JSON');
      setState(() {
        s.applyJson(decoded); // kẹp giá trị ngoài khoảng, bỏ khoá lạ/sai kiểu (xem generation_settings.dart)
        _characterDescCtrl.text = s.characterDesc;
        _watermarkCtrl.text = s.watermarkText;
        _settingDescCtrl.text = s.settingDesc;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Đã áp dụng cài đặt.'))));
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Nội dung không phải cài đặt hợp lệ.'))));
    }
  }

  Widget _sliderTile({
    required String label,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String display,
    required void Function(double) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: $display'),
          Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
        ],
      ),
    );
  }
}
