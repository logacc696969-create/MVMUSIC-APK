import 'package:flutter/material.dart';
import '../api_service.dart';
import '../generation_settings.dart';

class SettingsScreen extends StatefulWidget {
  final ApiService api;

  const SettingsScreen({super.key, required this.api});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final s = GenerationSettings.instance;
  late final TextEditingController _characterDescCtrl =
      TextEditingController(text: s.characterDesc);
  late final TextEditingController _hmacSecretCtrl =
      TextEditingController(text: s.hmacSecret);

  // Danh sách backend video lấy ĐỘNG từ server (KHÔNG hardcode tên/label ở
  // đây) - xem GET /video-backends. null = đang tải hoặc tải lỗi.
  List<Map<String, dynamic>>? _videoBackends;
  String? _videoBackendsError;

  @override
  void initState() {
    super.initState();
    _loadVideoBackends();
  }

  Future<void> _loadVideoBackends() async {
    try {
      final result = await widget.api.getVideoBackends();
      final backends = List<Map<String, dynamic>>.from(result['backends'] as List);
      if (!mounted) return;
      setState(() {
        _videoBackends = backends;
        // Chưa chọn gì trước đó -> dùng default server trả về (không hardcode).
        s.videoBackend ??= result['default'] as String?;
      });
    } catch (e) {
      if (mounted) setState(() => _videoBackendsError = 'Không tải được danh sách công nghệ video: $e');
    }
  }

  /// MỚI (lượt audit sau 7zc21) - kiểm tra backend video ĐANG CHỌN có hỗ trợ
  /// "Mô tả nhân vật cố định" hay không - lấy ĐỘNG qua `supports_character_reference`
  /// (đã có sẵn trong response `/video-backends` từ trước, chỉ chưa được
  /// Flutter đọc/dùng tới) - KHÔNG hardcode tên backend nào ở đây, đúng
  /// nguyên tắc chung của cả dự án. Trả `true` (mặc định lạc quan) nếu chưa
  /// tải xong danh sách hoặc chưa chọn backend nào - tránh cảnh báo nhầm lúc
  /// đang loading.
  bool get _selectedSupportsCharacterReference {
    if (_videoBackends == null || s.videoBackend == null) return true;
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return true;
    return match.first['supports_character_reference'] == true;
  }

  String _powerLabel(int power) {
    if (power >= 80) return 'Mạnh — nhanh nhất, dễ bị Colab ngắt nếu chạy lâu';
    if (power >= 45) return 'Vừa (khuyến nghị) — cân bằng tốc độ và độ ổn định';
    return 'Nhẹ — chậm hơn nhưng ổn định nhất cho phiên chạy dài';
  }

  /// true nếu backend video ĐANG CHỌN hỗ trợ camera chuyển động theo nhịp -
  /// KHÔNG quan tâm CƠ CHẾ cụ thể (Motion LoRA hay mô tả chèn prompt, xem
  /// VIDEO_BACKENDS ở app.py, mục 7x) - đọc field GỘP `supports_motion_camera`
  /// server đã tính sẵn, KHÔNG hardcode "chỉ animatediff hỗ trợ" ở đây.
  bool _currentBackendSupportsMotion() {
    if (_videoBackends == null || s.videoBackend == null) return true; // chưa tải xong -> tạm cho phép, tránh nháy UI
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return true;
    return match.first['supports_motion_camera'] == true;
  }

  /// MỚI (mục 7zc5) - tương tự _currentBackendSupportsMotion() ở trên, cho
  /// tính năng "nối cảnh" (lấy khung hình cuối cảnh trước làm điều kiện sinh
  /// cảnh sau, giảm giật/nhấp nháy bối cảnh) - hiện chỉ "wan22" hỗ trợ.
  bool _currentBackendSupportsSceneContinuity() {
    if (_videoBackends == null || s.videoBackend == null) return false;
    final match = _videoBackends!.where((b) => b['id'] == s.videoBackend);
    if (match.isEmpty) return false;
    return match.first['supports_scene_continuity'] == true;
  }

  @override
  void dispose() {
    _characterDescCtrl.dispose();
    _hmacSecretCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt tạo dữ liệu')),
      body: SafeArea(
        top: false,
        child: ListView(
          padding: const EdgeInsets.all(16),
        children: [
          const Text('Công suất sử dụng GPU remote', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text(
            'Dùng GPU càng "mạnh tay" liên tục thì càng dễ bị Colab tự bóp/ngắt '
            'giữa chừng. Kéo xuống thấp nếu bạn hay bị ngắt kết nối khi tạo MV.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Text('${s.gpuPower}% — ${_powerLabel(s.gpuPower)}', style: const TextStyle(fontSize: 13)),
          Slider(
            value: s.gpuPower.toDouble(),
            min: 20,
            max: 100,
            divisions: 8,
            label: '${s.gpuPower}%',
            onChanged: (v) => setState(() => s.gpuPower = v.round()),
          ),

          const Divider(height: 32),
          const Text('Tham số tạo nhạc / MV', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),

          _sliderTile(
            label: 'Thời lượng nhạc',
            value: s.duration,
            min: 10,
            max: 120,
            divisions: 22,
            display: '${s.duration.toStringAsFixed(0)}s',
            onChanged: (v) => setState(() => s.duration = v),
          ),
          _sliderTile(
            label: 'Số beat / 1 cảnh video',
            value: s.beatsPerScene.toDouble(),
            min: 2,
            max: 8,
            divisions: 6,
            display: '${s.beatsPerScene}',
            onChanged: (v) => setState(() => s.beatsPerScene = v.round()),
          ),
          _sliderTile(
            label: 'Số cảnh tối đa trong MV',
            value: s.maxScenes.toDouble(),
            min: 2,
            max: 16,
            divisions: 14,
            display: '${s.maxScenes}',
            onChanged: (v) => setState(() => s.maxScenes = v.round()),
          ),
          _sliderTile(
            label: 'Số bước inference mỗi cảnh (chất lượng)',
            value: s.numInferenceSteps.toDouble(),
            min: 10,
            max: 40,
            divisions: 30,
            display: '${s.numInferenceSteps}',
            onChanged: (v) => setState(() => s.numInferenceSteps = v.round()),
          ),
          _sliderTile(
            label: 'Guidance scale (độ bám sát mô tả)',
            value: s.guidanceScale,
            min: 1,
            max: 15,
            divisions: 28,
            display: s.guidanceScale.toStringAsFixed(1),
            onChanged: (v) => setState(() => s.guidanceScale = v),
          ),

          const Divider(height: 32),
          const Text('Mô tả nhân vật cố định (tuỳ chọn)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text(
            'Chèn vào MỌI cảnh để tăng nhẹ tính nhất quán hình ảnh giữa các cảnh '
            '(vd "cô gái tóc đen dài, áo khoác đỏ, mắt nâu"). Đây chỉ là mẹo nhẹ '
            '(prompt + seed cùng gốc) - không đảm bảo nhân vật giống hệt nhau '
            'giữa các cảnh như phần mềm chuyên dụng. Để trống nếu không cần.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _characterDescCtrl,
            maxLines: 2,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'vd: cô gái tóc đen dài, áo khoác đỏ, mắt nâu',
            ),
            onChanged: (v) => setState(() => s.characterDesc = v), // setState để cảnh báo bên dưới cập nhật ngay khi gõ
          ),
          // MỚI (lượt audit sau 7zc21) - CẢNH BÁO ĐỘNG khi backend video
          // ĐANG CHỌN không hỗ trợ tính năng này (vd Wan2.2 - kiến trúc DiT,
          // xem docstring `_generate_scene_clip_wan22` phía server) - CHỈ
          // hiện khi đã điền mô tả (tránh cảnh báo thừa lúc ô còn trống,
          // chưa ảnh hưởng gì). TRƯỚC ĐÂY field này LUÔN hiển thị bình
          // thường bất kể backend nào đang chọn - người dùng điền mô tả kỹ
          // càng rồi chọn Wan2.2 (vì lý do khác, vd "video nét/dài hơn")
          // hoàn toàn KHÔNG biết 2 lựa chọn đó XUNG ĐỘT NHAU - server đã có
          // sẵn field `supports_character_reference` (endpoint
          // /video-backends) từ trước, chỉ CHƯA được Flutter đọc/dùng tới.
          if (!_selectedSupportsCharacterReference && s.characterDesc.trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  border: Border.all(color: Colors.orange.shade200),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.warning_amber_rounded, size: 18, color: Colors.orange.shade800),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Công nghệ tạo video đang chọn KHÔNG hỗ trợ mô tả nhân vật cố định '
                        '(kiến trúc khác không tương thích) - mô tả này sẽ KHÔNG có tác dụng '
                        'cho tới khi bạn đổi sang công nghệ khác có hỗ trợ (xem mục bên dưới).',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          const Divider(height: 32),
          const Text('Công nghệ tạo video', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text(
            'Danh sách lấy trực tiếp từ backend (Colab) - đổi/thêm công nghệ mới bên '
            'server sẽ tự hiện ở đây, không cần cập nhật app.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (_videoBackendsError != null)
            Text(_videoBackendsError!, style: const TextStyle(color: Colors.red, fontSize: 12))
          else if (_videoBackends == null)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Center(child: CircularProgressIndicator()),
            )
          else
            // KHÔNG dùng RadioListTile ở đây nữa - label các backend (đặc
            // biệt VACE, có mô tả dài kèm cảnh báo "THỬ NGHIỆM") bị
            // RadioListTile ép vào ĐÚNG 1 DÒNG, cắt cụt phần sau bằng "..."
            // (ListTile.title mặc định chỉ dành cho text ngắn 1 dòng theo
            // chuẩn Material) - đổi sang Card + Column để chữ được XUỐNG
            // DÒNG ĐẦY ĐỦ, không mất chữ nào.
            ..._videoBackends!.map((b) => Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    onTap: () => setState(() {
                      s.videoBackend = b['id'] as String;
                      final supportsMotion = b['supports_motion_camera'] == true;
                      if (!supportsMotion) s.enableMotionCamera = false;
                      final supportsContinuity = b['supports_scene_continuity'] == true; // MỚI (mục 7zc5)
                      if (!supportsContinuity) s.enableSceneContinuity = false;
                    }),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Radio<String>(
                            value: b['id'] as String,
                            groupValue: s.videoBackend,
                            onChanged: (v) => setState(() {
                              s.videoBackend = v;
                              final supportsMotion = b['supports_motion_camera'] == true;
                              if (!supportsMotion) s.enableMotionCamera = false;
                              final supportsContinuity = b['supports_scene_continuity'] == true; // MỚI (mục 7zc5)
                              if (!supportsContinuity) s.enableSceneContinuity = false;
                            }),
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 14),
                              child: Text(b['label'] as String), // KHÔNG set maxLines/overflow -> tự xuống dòng, không cắt
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )),

          const Divider(height: 32),
          // KHÔNG dùng SwitchListTile ở đây nữa - cùng lý do đã sửa ở trên
          // (video backend): subtitle dài (giải thích cơ chế + cảnh báo
          // "chưa test thật") có thể bị cắt bởi giới hạn chiều cao mặc định
          // của ListTile - đổi sang Card + Column để chắc chắn hiện đủ chữ.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Camera chuyển động theo nhịp', style: TextStyle(fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        Text(
                          _currentBackendSupportsMotion()
                              ? 'Tự zoom/lia camera theo đoạn nhạc dồn dập hay êm dịu (cơ chế tuỳ '
                                'công nghệ video đang chọn - LoRA hoặc mô tả trong prompt). Chưa '
                                'test thật trên GPU - nếu thấy nạp model chậm hẳn hoặc lỗi, tắt để '
                                'dùng cách cũ (không có chuyển động camera đặc biệt).'
                              : 'Công nghệ video đang chọn CHƯA hỗ trợ tính năng này.',
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.enableMotionCamera && _currentBackendSupportsMotion(),
                    onChanged: _currentBackendSupportsMotion() ? (v) => setState(() => s.enableMotionCamera = v) : null,
                  ),
                ],
              ),
            ),
          ),

          // MỚI (mục 7zc5) - "Nối cảnh mượt" - CHỈ hiện khi công nghệ video
          // đang chọn hỗ trợ (hiện chỉ Wan2.2 - ẨN HẲN, không phải khoá mờ,
          // ở công nghệ khác, giống cách công tắc Lipsync ẩn ở style không
          // hỗ trợ tại style_screen.dart).
          if (_currentBackendSupportsSceneContinuity())
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Nối cảnh mượt (thử nghiệm)', style: TextStyle(fontWeight: FontWeight.w500)),
                          const SizedBox(height: 4),
                          const Text(
                            'Lấy khung hình cuối của cảnh trước làm điều kiện cho cảnh sau, '
                            'giảm giật/nhấp nháy bối cảnh giữa 2 cảnh liên tiếp. Chạy chậm hơn '
                            '1 chút (đổi qua lại giữa 2 chế độ nạp model) - CHƯA test thật trên '
                            'GPU, tắt nếu thấy lỗi hoặc video không như mong đợi.',
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: s.enableSceneContinuity,
                      onChanged: (v) => setState(() => s.enableSceneContinuity = v),
                    ),
                  ],
                ),
              ),
            ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Cân bằng màu (Color Grading)', style: TextStyle(fontWeight: FontWeight.w500)),
                        SizedBox(height: 4),
                        Text(
                          'Tự động khớp tông màu mọi cảnh theo đúng cảnh mở đầu, tránh MV bị '
                          'lệch màu (vàng ấm/xanh lạnh) giữa các cảnh. An toàn - tự bỏ qua '
                          'nếu lỗi, không ảnh hưởng tới việc tạo MV.',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: s.enableColorMatch,
                    onChanged: (v) => setState(() => s.enableColorMatch = v),
                  ),
                ],
              ),
            ),
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Đổi tốc độ theo nhịp (thử nghiệm)', style: TextStyle(fontWeight: FontWeight.w500)),
                            SizedBox(height: 4),
                            Text(
                              'Đổi nhẹ tốc độ phát mỗi cảnh (±6%) theo cường độ nhịp bài hát - '
                              'CHƯA kiểm chứng bằng mắt, tự tắt an toàn nếu lỗi. Không đổi thời '
                              'lượng cảnh nên không lệch nhịp với nhạc.',
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: s.enableSpeedRamping,
                        onChanged: (v) => setState(() => s.enableSpeedRamping = v),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Formant Shifting + De-essing đã được dời sang VoiceScreen (màn
          // Chọn giọng) vì chúng chỉ có tác dụng ở bước đổi giọng RVC -
          // người dùng thấy ngay khi cần thay vì phải mò vào Cài đặt.

          const Divider(height: 32),
          const Text('Bảo mật nâng cao (tuỳ chọn)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text(
            'Chỉ điền nếu bạn đã đặt "MV_APP_HMAC_SECRET" ở Cell 2.7 trong '
            'colab_setup.py - dùng để ký các yêu cầu tạo MV/train giọng, chặn '
            'người khác vô tình gọi thẳng URL Colab công khai của bạn. Để trống '
            'nếu chưa dùng tính năng này (mặc định).',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _hmacSecretCtrl,
            obscureText: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Khoá bí mật HMAC (để trống nếu không dùng)',
            ),
            onChanged: (v) => s.hmacSecret = v,
          ),

          const SizedBox(height: 16),
          const Text(
            'Số cảnh nhiều hơn / bước inference cao hơn → chất lượng tốt hơn nhưng '
            'chạy lâu hơn. Mỗi cảnh xong được đẩy về máy ngay lập tức, và nếu bị '
            'ngắt giữa chừng, lần tạo lại sau sẽ tiếp tục từ cảnh còn thiếu — '
            'không sinh lại từ đầu.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
        ],
        ),
      ),
    );
  }

  Widget _sliderTile({
    required String label,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String display,
    required void Function(double) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: $display'),
          Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
        ],
      ),
    );
  }
}
