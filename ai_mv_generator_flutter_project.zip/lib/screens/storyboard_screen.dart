import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'generating_screen.dart';

/// Màn hình "Kịch bản cảnh" (Storyboard/Shot-list) - MỚI, chèn giữa
/// ReviewScreen và GeneratingScreen. Mô phỏng quy trình các app lớn hay dùng
/// (Kling/Runway: xem/sửa từng shot trước khi tốn tài nguyên tạo thật) - khác
/// HẲN hành vi CŨ của app này (mọi cảnh dùng CHUNG 1 style_prompt). Gọi
/// /build-storyboard (CHỈ CPU, không tốn GPU) để lấy prompt gợi ý cho từng
/// cảnh, cho người dùng sửa tự do, rồi gửi kèm khi tạo MV thật.
class StoryboardScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const StoryboardScreen({super.key, required this.api, required this.project});

  @override
  State<StoryboardScreen> createState() => _StoryboardScreenState();
}

class _StoryboardScreenState extends State<StoryboardScreen> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _scenes = [];
  late List<TextEditingController> _controllers;
  List<Map<String, dynamic>> _genres = [];
  bool _llmScriptActuallyUsed = false; // phản hồi thật từ server (llm_script_used) - có thể fallback nếu LLM lỗi, xem tài liệu kỹ thuật
  bool _usedUploadedScript = false; // true nếu kịch bản đang hiện tới từ file upload, không phải AI - hiện rõ cho người dùng biết
  bool _uploadingScript = false;
  int? _expectedSceneCount; // biết trước cần đúng bao nhiêu dòng - hiện cho người dùng TRƯỚC khi họ tự viết file, tránh đoán sai

  String get _audioFilename => widget.project.voicedFilename ?? widget.project.musicFilename!;

  @override
  void initState() {
    super.initState();
    _controllers = [];
    _loadGenres();
    _loadExpectedSceneCount();
    _load();
  }

  Future<void> _loadExpectedSceneCount() async {
    final s = GenerationSettings.instance;
    try {
      final result = await widget.api.analyzeBeats(
        audioFilename: _audioFilename,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
      );
      if (mounted && result['status'] == 'ok') {
        setState(() => _expectedSceneCount = result['num_scenes'] as int);
      }
    } catch (_) {
      // Không chặn màn hình vì lỗi này - chỉ đơn giản không hiện được số cảnh gợi ý trước.
    }
  }

  Future<void> _pickAndUploadScriptFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt']);
    if (result == null || result.files.single.path == null) return;

    setState(() {
      _uploadingScript = true;
      _error = null;
    });
    try {
      final s = GenerationSettings.instance;
      final response = await widget.api.parseStoryboardFile(
        audioFilename: _audioFilename,
        styleId: widget.project.styleId!,
        scriptFile: File(result.files.single.path!),
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        characterDesc: s.characterDesc,
      );
      if (!mounted) return;
      if (response['status'] != 'ok') {
        final expected = response['expected_scenes'];
        setState(() => _error = expected != null
            ? '${response['note']}'
            : (response['note']?.toString() ?? 'Không đọc được file kịch bản.'));
        return;
      }
      final scenes = List<Map<String, dynamic>>.from(response['storyboard'] as List);
      for (final c in _controllers) {
        c.dispose();
      }
      setState(() {
        _scenes = scenes;
        _controllers = scenes.map((sc) => TextEditingController(text: sc['prompt'] as String)).toList();
        _usedUploadedScript = true;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Lỗi tải file kịch bản: $e');
    } finally {
      if (mounted) setState(() => _uploadingScript = false);
    }
  }

  Future<void> _loadGenres() async {
    try {
      final result = await widget.api.getVideoGenres();
      if (mounted) {
        setState(() => _genres = List<Map<String, dynamic>>.from(result['genres'] as List));
      }
    } catch (_) {
      // Không chặn màn hình vì lỗi này - chỉ đơn giản là không có bộ chọn
      // thể loại, storyboard vẫn tải được với thể loại mặc định của server.
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _usedUploadedScript = false; // dùng lại đường AI -> không còn hiện là "từ file upload" nữa
    });
    try {
      final s = GenerationSettings.instance;
      final result = await widget.api.buildStoryboard(
        audioFilename: _audioFilename,
        styleId: widget.project.styleId!,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        characterDesc: s.characterDesc,
        lyrics: widget.project.lyrics,
        genre: s.genre,
        useLlmScript: s.useLlmScript,
      );
      if (result['status'] != 'ok') {
        setState(() => _error = result['note']?.toString() ?? 'Không tạo được kịch bản cảnh.');
        return;
      }
      final scenes = List<Map<String, dynamic>>.from(result['storyboard'] as List);
      for (final c in _controllers) {
        c.dispose();
      }
      setState(() {
        _scenes = scenes;
        _controllers = scenes.map((s) => TextEditingController(text: s['prompt'] as String)).toList();
        _llmScriptActuallyUsed = result['llm_script_used'] == true;
      });
    } catch (e) {
      setState(() => _error = 'Không tạo được kịch bản cảnh: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _intensityColor(double intensity) {
    if (intensity > 0.66) return Colors.redAccent;
    if (intensity < 0.33) return Colors.blueAccent;
    return Colors.orangeAccent;
  }

  String _intensityLabel(double intensity) {
    if (intensity > 0.66) return 'Cao trào';
    if (intensity < 0.33) return 'Êm dịu';
    return 'Vừa phải';
  }

  void _startGenerating({required bool useEditedPrompts}) {
    if (useEditedPrompts) {
      widget.project.scenePrompts = _controllers.map((c) => c.text).toList();
    } else {
      widget.project.scenePrompts = null; // bỏ qua storyboard - dùng style_prompt chung như cũ
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: widget.project)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = GenerationSettings.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Kịch bản cảnh (Storyboard)')),
      body: Column(
        children: [
          // Bảng chọn THỂ LOẠI + kịch bản LLM - LUÔN hiện trên cùng (kể cả
          // lúc đang tải/lỗi) để người dùng đổi rồi bấm "Tải lại kịch bản"
          // ngay, không phải thoát màn hình quay lại.
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Thể loại kịch bản', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(height: 6),
                    if (_genres.isEmpty)
                      const Text('Đang tải danh sách thể loại...', style: TextStyle(fontSize: 12, color: Colors.grey))
                    else ...[
                      DropdownButton<String>(
                        isExpanded: true,
                        value: (s.genre != null && _genres.any((g) => g['id'] == s.genre)) ? s.genre : _genres.first['id'] as String,
                        items: _genres
                            .map((g) => DropdownMenuItem(
                                  value: g['id'] as String,
                                  // Menu thả xuống của Dropdown (chuẩn Material) chỉ đủ chỗ 1 dòng/mục khi
                                  // đang MỞ danh sách để chọn - chấp nhận cắt bớt ở ĐÂY, nhưng bù lại: mục
                                  // ĐANG CHỌN luôn hiện ĐẦY ĐỦ ngay bên dưới (xem Text kế tiếp), không bao
                                  // giờ bị cắt ở phần người dùng thực sự cần đọc kỹ.
                                  child: Text(g['label'] as String, style: const TextStyle(fontSize: 13), overflow: TextOverflow.ellipsis),
                                ))
                            .toList(),
                        onChanged: (v) => setState(() => s.genre = v),
                      ),
                      Builder(builder: (_) {
                        final selectedId = (s.genre != null && _genres.any((g) => g['id'] == s.genre)) ? s.genre : _genres.first['id'] as String;
                        final selectedLabel = _genres.firstWhere((g) => g['id'] == selectedId)['label'] as String;
                        return Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(selectedLabel, style: const TextStyle(fontSize: 12, color: Colors.grey)), // KHÔNG overflow/maxLines -> hiện đủ chữ
                        );
                      }),
                    ],
                    const Divider(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Viết kịch bản bằng AI (LLM)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Text(
                                widget.project.lyrics.trim().isEmpty
                                    ? 'Cần có lời bài hát mới dùng được tính năng này'
                                    : 'Đọc lời bài hát, tự viết hành động/bối cảnh - chạy chậm hơn, thử nghiệm',
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: s.useLlmScript,
                          onChanged: widget.project.lyrics.trim().isEmpty ? null : (v) => setState(() => s.useLlmScript = v),
                        ),
                      ],
                    ),
                    if (!_loading && _error == null && s.useLlmScript)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          _llmScriptActuallyUsed
                              ? '✓ Đã dùng kịch bản AI cho các cảnh dưới đây'
                              : '⚠ AI không dùng được lần này - đang dùng mẫu câu dự phòng',
                          style: TextStyle(fontSize: 11, color: _llmScriptActuallyUsed ? Colors.green : Colors.orange),
                        ),
                      ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _loading ? null : _load,
                        icon: const Icon(Icons.refresh, size: 18),
                        label: const Text('Tải lại kịch bản với lựa chọn trên'),
                      ),
                    ),
                    const Divider(height: 20),
                    Text(
                      _expectedSceneCount == null
                          ? 'Đã có sẵn kịch bản riêng? Tải file .txt lên (mỗi dòng = 1 cảnh).'
                          : 'Đã có sẵn kịch bản riêng? Tải file .txt lên - CẦN ĐÚNG $_expectedSceneCount dòng '
                              '(mỗi dòng = 1 cảnh, bài này có $_expectedSceneCount cảnh) - bỏ qua hoàn toàn bước AI.',
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _uploadingScript ? null : _pickAndUploadScriptFile,
                        icon: _uploadingScript
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.upload_file, size: 18),
                        label: Text(_uploadingScript ? 'Đang đọc file...' : 'Tải file kịch bản có sẵn (bỏ qua AI)'),
                      ),
                    ),
                    if (_usedUploadedScript)
                      const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text('✓ Đang dùng kịch bản từ file bạn tải lên - AI không can thiệp vào nội dung', style: TextStyle(fontSize: 11, color: Colors.green)),
                      ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_error!, textAlign: TextAlign.center),
                              const SizedBox(height: 16),
                              ElevatedButton(onPressed: _load, child: const Text('Thử lại')),
                              TextButton(
                                onPressed: () => _startGenerating(useEditedPrompts: false),
                                child: const Text('Bỏ qua, dùng phong cách chung như cũ'),
                              ),
                            ],
                          ),
                        ),
                      )
                    : Column(
                        children: [
                          const Padding(
                            padding: EdgeInsets.all(12),
                            child: Text(
                        'Mỗi cảnh có 1 mô tả riêng, tự gợi ý theo độ mạnh nhịp của đoạn nhạc đó '
                        '(và lời bài hát nếu có). Sửa tự do trước khi tạo MV thật - đây chỉ là '
                        'gợi ý ban đầu, KHÔNG phải phân tích nhạc chính xác tuyệt đối.',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _scenes.length,
                        itemBuilder: (context, idx) {
                          final scene = _scenes[idx];
                          final intensity = (scene['intensity'] as num).toDouble();
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text('Cảnh ${idx + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                      const SizedBox(width: 8),
                                      Text(
                                        '${scene['start']}s - ${scene['end']}s',
                                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                                      ),
                                      const Spacer(),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: _intensityColor(intensity).withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          _intensityLabel(intensity),
                                          style: TextStyle(fontSize: 11, color: _intensityColor(intensity)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  TextField(
                                    controller: _controllers[idx],
                                    maxLines: 3,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () => _startGenerating(useEditedPrompts: true),
                                    child: const Text('Xác nhận kịch bản, tạo MV'),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () => _startGenerating(useEditedPrompts: false),
                                  child: const Text('Bỏ qua, dùng phong cách chung như cũ'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}
