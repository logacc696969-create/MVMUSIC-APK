import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/skeleton.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'character_reference_screen.dart';
import 'generating_screen.dart';

import '../l10n.dart';
import '../muted_color.dart';
/// Màn hình "Kịch bản cảnh" (Storyboard/Shot-list) - MỚI, chèn giữa
/// ReviewScreen và GeneratingScreen. Mô phỏng quy trình các app lớn hay dùng
/// (Kling/Runway: xem/sửa từng shot trước khi tốn tài nguyên tạo thật) - khác
/// HẲN hành vi CŨ của app này (mọi cảnh dùng CHUNG 1 style_prompt). Gọi
/// /build-storyboard (CHỈ CPU, không tốn GPU) để lấy prompt gợi ý cho từng
/// cảnh, cho người dùng sửa tự do, rồi gửi kèm khi tạo MV thật.
class StoryboardScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const StoryboardScreen({super.key, required this.api, required this.project});

  @override
  State<StoryboardScreen> createState() => _StoryboardScreenState();
}

class _StoryboardScreenState extends State<StoryboardScreen> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _scenes = [];
  late List<TextEditingController> _controllers;
  List<Map<String, dynamic>> _genres = [];
  bool _llmScriptActuallyUsed = false; // phản hồi thật từ server (llm_script_used) - có thể fallback nếu LLM lỗi, xem tài liệu kỹ thuật
  bool _usedUploadedScript = false; // true nếu kịch bản đang hiện tới từ file upload, không phải AI - hiện rõ cho người dùng biết
  bool _uploadingScript = false;
  int? _expectedSceneCount; // biết trước cần đúng bao nhiêu dòng - hiện cho người dùng TRƯỚC khi họ tự viết file, tránh đoán sai

  // MỚI (mục 23) - camera RIÊNG từng cảnh ('' = tự động theo nhịp). PHẢI đồng bộ khoá với
  // `CAMERA_CHOICES` trong post_processing_v2.py. Luôn được đặt lại độ dài = số cảnh qua _resetCameras().
  static const List<List<String>> _cameraOptions = [
    ['', 'Tự động theo nhịp'],
    ['zoom-in', 'Zoom vào'],
    ['zoom-out', 'Zoom ra'],
    ['pan-left', 'Lia sang trái'],
    ['pan-right', 'Lia sang phải'],
    ['tilt-up', 'Nghiêng lên'],
    ['tilt-down', 'Nghiêng xuống'],
    ['rolling-clockwise', 'Xoay theo chiều kim đồng hồ'],
    ['rolling-anticlockwise', 'Xoay ngược chiều kim đồng hồ'],
    ['static', 'Giữ yên (không chuyển động)'],
    // MỚI (mục 54, PDF-2 §2.8) - 9 kiểu camera thêm; khoá PHẢI khớp `CAMERA_CHOICES` (có test). Với AnimateDiff các kiểu này chỉ xấp xỉ (app báo ở thẻ cam màn Kết quả).
    ['dolly-in', 'Dolly vào (tiến sát chủ thể)'],
    ['dolly-out', 'Dolly ra (lùi xa chủ thể)'],
    ['crane-up', 'Crane lên (nâng máy cao)'],
    ['crane-down', 'Crane xuống (hạ máy thấp)'],
    ['orbit-left', 'Quay quanh chủ thể (sang trái)'],
    ['orbit-right', 'Quay quanh chủ thể (sang phải)'],
    ['handheld', 'Cầm tay (rung nhẹ tự nhiên)'],
    ['whip-pan', 'Lia nhanh (whip pan)'],
    ['rack-focus', 'Đổi nét (rack focus)'],
  ];
  List<String> _cameras = [];

  // MỚI (mục 61, PDF-2 §8.2) - cỡ cảnh/góc máy/bố cục RIÊNG từng cảnh ('' = không ép). PHẢI đồng bộ khoá với `FRAMING_CHOICES` trong
  // post_processing_v2.py (có test). Khác camera (chuyển động): đây là khung hình tĩnh, chọn cùng lúc được.
  static const List<List<String>> _framingOptions = [
    ['', 'Không ép khung hình'],
    ['wide', 'Toàn cảnh (wide)'],
    ['medium', 'Trung cảnh (từ eo lên)'],
    ['close-up', 'Cận mặt (close-up)'],
    ['extreme-close-up', 'Đặc tả (mắt/tay)'],
    ['over-shoulder', 'Qua vai'],
    ['low-angle', 'Góc thấp (hùng tráng)'],
    ['high-angle', 'Góc cao (nhỏ bé)'],
    ['top-down', 'Nhìn từ trên xuống'],
    ['rule-of-thirds', 'Bố cục quy tắc 1/3'],
    ['shallow-dof', 'Xoá phông (nét chủ thể)'],
  ];
  List<String> _framings = [];
  int? _uploadingClipIdx; // MỚI (mục 26) - cảnh đang tải clip tự quay lên (null = không có)
  int? _uploadingRefIdx; // MỚI (mục 39) - cảnh đang tải ảnh bố cục lên (null = không có)

  /// MỚI (mục 26) - CẢNH TỰ QUAY: chọn 1 clip từ máy để DÙNG THAY cảnh AI này. Backend cắt/lặp clip cho đúng thời lượng cảnh,
  /// phóng kiểu "cover" về cỡ video, bỏ tiếng gốc (tiếng của MV là bài nhạc). Clip được giữ tạm ở Colab đến khi tạo MV - nếu
  /// Colab bị đổi phiên trước đó, cảnh này sẽ quay về sinh bằng AI.
  Future<void> _pickUserClip(int idx) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video);
    final path = result?.files.single.path;
    if (path == null) return;
    setState(() => _uploadingClipIdx = idx);
    try {
      final r = await widget.api.uploadUserClip(clipFile: File(path));
      if (!mounted) return;
      if (r['status'] == 'ok') {
        setState(() {
          widget.project.userClips[idx] = r['filename'] as String;
          widget.project.userClipLabels[idx] = path.split(Platform.pathSeparator).last;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['note'] as String? ?? tr('Không dùng được clip này.'))));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(trv('Tải clip lên lỗi: {0}', [e]))));
      }
    } finally {
      if (mounted) setState(() => _uploadingClipIdx = null);
    }
  }

  void _removeUserClip(int idx) {
    setState(() {
      widget.project.userClips.remove(idx);
      widget.project.userClipLabels.remove(idx);
    });
  }

  /// MỚI (mục 39, PDF-2 mục 8.2) - ẢNH BỐ CỤC riêng từng cảnh: chọn 1 ảnh (vị trí chủ thể, góc máy, bối cảnh) để thêm vào danh sách ảnh tham chiếu của CẢNH NÀY.
  /// Chỉ công nghệ Wan-VACE dùng; công nghệ khác sẽ bỏ qua và báo ở màn Kết quả. Ảnh giữ tạm ở Colab đến khi tạo MV.
  Future<void> _pickSceneRef(int idx) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = result?.files.single.path;
    if (path == null) return;
    setState(() => _uploadingRefIdx = idx);
    try {
      final r = await widget.api.uploadSceneReference(imageFile: File(path));
      if (!mounted) return;
      if (r['status'] == 'ok') {
        setState(() {
          widget.project.sceneRefs[idx] = r['filename'] as String;
          widget.project.sceneRefLabels[idx] = path.split(Platform.pathSeparator).last;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['note'] as String? ?? tr('Không dùng được ảnh này.'))));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(trv('Tải ảnh lên lỗi: {0}', [e]))));
      }
    } finally {
      if (mounted) setState(() => _uploadingRefIdx = null);
    }
  }

  void _removeSceneRef(int idx) {
    setState(() {
      widget.project.sceneRefs.remove(idx);
      widget.project.sceneRefLabels.remove(idx);
    });
  }

  void _resetCameras() {
    _cameras = List<String>.filled(_scenes.length, '');
    _framings = List<String>.filled(_scenes.length, '');
  }

  String get _audioFilename => widget.project.voicedFilename ?? widget.project.musicFilename!;

  @override
  void initState() {
    super.initState();
    _controllers = [];
    _loadGenres();
    _loadExpectedSceneCount();
    _load();
  }

  Future<void> _loadExpectedSceneCount() async {
    final s = GenerationSettings.instance;
    try {
      final result = await widget.api.analyzeBeats(
        audioFilename: _audioFilename,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
      );
      if (mounted && result['status'] == 'ok') {
        setState(() => _expectedSceneCount = result['num_scenes'] as int);
      }
    } catch (_) {
      // Không chặn màn hình vì lỗi này - chỉ đơn giản không hiện được số cảnh gợi ý trước.
    }
  }

  Future<void> _pickAndUploadScriptFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt']);
    if (result == null || result.files.single.path == null) return;
    if (!mounted) return;

    setState(() {
      _uploadingScript = true;
      _error = null;
    });
    try {
      final s = GenerationSettings.instance;
      final response = await widget.api.parseStoryboardFile(
        audioFilename: _audioFilename,
        styleId: widget.project.styleId!,
        scriptFile: File(result.files.single.path!),
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        characterDesc: s.characterDesc,
      );
      if (!mounted) return;
      if (response['status'] != 'ok') {
        final expected = response['expected_scenes'];
        setState(() => _error = expected != null
            ? '${response['note']}'
            : (response['note']?.toString() ?? tr('Không đọc được file kịch bản.')));
        return;
      }
      final scenes = List<Map<String, dynamic>>.from(response['storyboard'] as List);
      for (final c in _controllers) {
        c.dispose();
      }
      setState(() {
        _scenes = scenes;
        _resetCameras();
        _controllers = scenes.map((sc) => TextEditingController(text: sc['prompt'] as String)).toList();
        _usedUploadedScript = true;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _error = trv('Lỗi tải file kịch bản: {0}', [e]));
    } finally {
      if (mounted) setState(() => _uploadingScript = false);
    }
  }

  Future<void> _loadGenres() async {
    try {
      final result = await widget.api.getVideoGenres();
      if (mounted) {
        setState(() => _genres = List<Map<String, dynamic>>.from(result['genres'] as List));
      }
    } catch (_) {
      // Không chặn màn hình vì lỗi này - chỉ đơn giản là không có bộ chọn
      // thể loại, storyboard vẫn tải được với thể loại mặc định của server.
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _usedUploadedScript = false; // dùng lại đường AI -> không còn hiện là "từ file upload" nữa
    });
    try {
      final s = GenerationSettings.instance;
      final result = await widget.api.buildStoryboard(
        audioFilename: _audioFilename,
        styleId: widget.project.styleId!,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        characterDesc: s.characterDesc,
        lyrics: widget.project.lyrics,
        genre: s.genre,
        useLlmScript: s.useLlmScript,
      );
      if (!mounted) return;
      if (result['status'] != 'ok') {
        setState(() => _error = result['note']?.toString() ?? tr('Không tạo được kịch bản cảnh.'));
        return;
      }
      final scenes = List<Map<String, dynamic>>.from(result['storyboard'] as List);
      for (final c in _controllers) {
        c.dispose();
      }
      setState(() {
        _scenes = scenes;
        _resetCameras();
        _controllers = scenes.map((s) => TextEditingController(text: s['prompt'] as String)).toList();
        _llmScriptActuallyUsed = result['llm_script_used'] == true;
      });
    } catch (e) {
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây
      setState(() => _error = trv('Không tạo được kịch bản cảnh: {0}', [e]));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _intensityColor(double intensity) {
    if (intensity > 0.66) return Colors.redAccent;
    if (intensity < 0.33) return Colors.blueAccent;
    return Colors.orangeAccent;
  }

  String _intensityLabel(double intensity) {
    if (intensity > 0.66) return tr('Cao trào');
    if (intensity < 0.33) return tr('Êm dịu');
    return tr('Vừa phải');
  }

  void _startGenerating({required bool useEditedPrompts, bool preview = false}) {
    HapticFeedback.lightImpact(); // MỚI (mục 25)
    if (useEditedPrompts) {
      widget.project.scenePrompts = _controllers.map((c) => c.text).toList();
      // MỚI (mục 23) - chỉ gửi camera nếu người dùng THỰC SỰ chọn ít nhất 1 cảnh (còn lại = hành vi cũ)
      widget.project.sceneCameras =
          (_cameras.length == _scenes.length && _cameras.any((c) => c.isNotEmpty)) ? List<String>.from(_cameras) : null;
      widget.project.sceneFramings =
          (_framings.length == _scenes.length && _framings.any((c) => c.isNotEmpty)) ? List<String>.from(_framings) : null;
    } else {
      widget.project.scenePrompts = null; // bỏ qua storyboard - dùng style_prompt chung như cũ
      widget.project.sceneCameras = null;
      widget.project.sceneFramings = null;
    }
    // MỚI (mục 27, PDF 4.4) - "Xem trước 1 cảnh": chỉ dựng cảnh ĐẦU để thử chất lượng trước khi tốn GPU cả MV. Tạo MV đầy đủ sau đó phải
    // bỏ cờ xem trước và không resume vào thư mục chỉ có 1 cảnh của lần xem trước.
    if (preview) {
      widget.project.previewMaxScenes = 1;
    } else if (widget.project.previewMaxScenes != null) {
      widget.project.previewMaxScenes = null;
      widget.project.mvSceneDirId = null;
    }
    // MỚI (mục 7zc2) - có mô tả nhân vật -> cho xem trước ảnh tham chiếu
    // (Character Sheet) TRƯỚC khi tốn GPU tạo cả MV. Không có mô tả nhân vật
    // -> đi thẳng GeneratingScreen như hành vi CŨ (không có gì để xem trước).
    final hasCharacterDesc = GenerationSettings.instance.characterDesc.trim().isNotEmpty;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => hasCharacterDesc
            ? CharacterReferenceScreen(api: widget.api, project: widget.project)
            : GeneratingScreen(api: widget.api, project: widget.project),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = GenerationSettings.instance;
    return Scaffold(
      appBar: AppBar(title: Text(tr('Kịch bản cảnh (Storyboard)'))),
      body: SafeArea(
        top: false,
        child: Column(
        children: [
          // Bảng chọn THỂ LOẠI + kịch bản LLM - LUÔN hiện trên cùng (kể cả
          // lúc đang tải/lỗi) để người dùng đổi rồi bấm "Tải lại kịch bản"
          // ngay, không phải thoát màn hình quay lại.
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('Thể loại kịch bản'), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(height: 6),
                    if (_genres.isEmpty)
                      Text(tr('Đang tải danh sách thể loại...'), style: TextStyle(fontSize: 12, color: mutedGrey))
                    else ...[
                      DropdownButton<String>(
                        isExpanded: true,
                        value: (s.genre != null && _genres.any((g) => g['id'] == s.genre)) ? s.genre : _genres.first['id'] as String,
                        items: _genres
                            .map((g) => DropdownMenuItem(
                                  value: g['id'] as String,
                                  // Menu thả xuống của Dropdown (chuẩn Material) chỉ đủ chỗ 1 dòng/mục khi
                                  // đang MỞ danh sách để chọn - chấp nhận cắt bớt ở ĐÂY, nhưng bù lại: mục
                                  // ĐANG CHỌN luôn hiện ĐẦY ĐỦ ngay bên dưới (xem Text kế tiếp), không bao
                                  // giờ bị cắt ở phần người dùng thực sự cần đọc kỹ.
                                  child: Text(g['label'] as String, style: const TextStyle(fontSize: 13), overflow: TextOverflow.ellipsis),
                                ))
                            .toList(),
                        onChanged: (v) => setState(() => s.genre = v),
                      ),
                      Builder(builder: (_) {
                        final selectedId = (s.genre != null && _genres.any((g) => g['id'] == s.genre)) ? s.genre : _genres.first['id'] as String;
                        final selectedLabel = _genres.firstWhere((g) => g['id'] == selectedId)['label'] as String;
                        return Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(selectedLabel, style: TextStyle(fontSize: 12, color: mutedGrey)), // KHÔNG overflow/maxLines -> hiện đủ chữ
                        );
                      }),
                    ],
                    const Divider(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(tr('Viết kịch bản bằng AI (LLM)'), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Text(
                                widget.project.lyrics.trim().isEmpty
                                    ? tr('Cần có lời bài hát mới dùng được tính năng này')
                                    : tr('Đọc lời bài hát, tự viết hành động/bối cảnh - chạy chậm hơn, thử nghiệm'),
                                style: TextStyle(fontSize: 11, color: mutedGrey),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: s.useLlmScript,
                          onChanged: widget.project.lyrics.trim().isEmpty ? null : (v) => setState(() => s.useLlmScript = v),
                        ),
                      ],
                    ),
                    if (!_loading && _error == null && s.useLlmScript)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          _llmScriptActuallyUsed
                              ? tr('✓ Đã dùng kịch bản AI cho các cảnh dưới đây')
                              : tr('⚠ AI không dùng được lần này - đang dùng mẫu câu dự phòng'),
                          style: TextStyle(fontSize: 11, color: _llmScriptActuallyUsed ? Colors.green : Colors.orange),
                        ),
                      ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _loading ? null : _load,
                        icon: const Icon(Icons.refresh, size: 18),
                        label: Text(tr('Tải lại kịch bản với lựa chọn trên')),
                      ),
                    ),
                    const Divider(height: 20),
                    Text(
                      _expectedSceneCount == null
                          ? tr('Đã có sẵn kịch bản riêng? Tải file .txt lên (mỗi dòng = 1 cảnh).')
                          : trv('Đã có sẵn kịch bản riêng? Tải file .txt lên - CẦN ĐÚNG {0} dòng '
                              '(mỗi dòng = 1 cảnh, bài này có {1} cảnh) - bỏ qua hoàn toàn bước AI.', [_expectedSceneCount, _expectedSceneCount]),
                      style: TextStyle(fontSize: 11, color: mutedGrey),
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _uploadingScript ? null : _pickAndUploadScriptFile,
                        icon: _uploadingScript
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.upload_file, size: 18),
                        label: Text(_uploadingScript ? tr('Đang đọc file...') : tr('Tải file kịch bản có sẵn (bỏ qua AI)')),
                      ),
                    ),
                    if (_usedUploadedScript)
                      Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text(tr('✓ Đang dùng kịch bản từ file bạn tải lên - AI không can thiệp vào nội dung'), style: TextStyle(fontSize: 11, color: Colors.green)),
                      ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const SkeletonList()
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_error!, textAlign: TextAlign.center),
                              const SizedBox(height: 16),
                              ElevatedButton(onPressed: _load, child: Text(tr('Thử lại'))),
                              TextButton(
                                onPressed: () => _startGenerating(useEditedPrompts: false),
                                child: Text(tr('Bỏ qua, dùng phong cách chung như cũ')),
                              ),
                            ],
                          ),
                        ),
                      )
                    : Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(12),
                            child: Text(
                        tr('Mỗi cảnh có 1 mô tả riêng, tự gợi ý theo độ mạnh nhịp của đoạn nhạc đó '
                        '(và lời bài hát nếu có). Sửa tự do trước khi tạo MV thật - đây chỉ là '
                        'gợi ý ban đầu, KHÔNG phải phân tích nhạc chính xác tuyệt đối.'),
                        style: TextStyle(fontSize: 12, color: mutedGrey),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _scenes.length,
                        itemBuilder: (context, idx) {
                          final scene = _scenes[idx];
                          final intensity = (scene['intensity'] as num).toDouble();
                          final hasClip = widget.project.userClips.containsKey(idx);
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(trv('Cảnh {0}', [idx + 1]), style: const TextStyle(fontWeight: FontWeight.bold)),
                                      const SizedBox(width: 8),
                                      Text(
                                        '${scene['start']}s - ${scene['end']}s',
                                        style: TextStyle(fontSize: 12, color: mutedGrey),
                                      ),
                                      const Spacer(),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: _intensityColor(intensity).withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          _intensityLabel(intensity),
                                          style: TextStyle(fontSize: 11, color: _intensityColor(intensity)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  TextField(
                                    controller: _controllers[idx],
                                    maxLines: 3,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Row(
                                    children: [
                                      Icon(Icons.videocam_outlined, size: 16, color: mutedGrey),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: DropdownButton<String>(
                                          isExpanded: true,
                                          isDense: true,
                                          value: (idx < _cameras.length) ? _cameras[idx] : '',
                                          items: [
                                            for (final opt in _cameraOptions)
                                              DropdownMenuItem<String>(
                                                value: opt[0],
                                                child: Text(tr(opt[1]), style: const TextStyle(fontSize: 13)),
                                              ),
                                          ],
                                          onChanged: (v) => setState(() {
                                            if (idx < _cameras.length) _cameras[idx] = v ?? '';
                                          }),
                                        ),
                                      ),
                                    ],
                                  ),
                                  // MỚI (mục 61) - cỡ cảnh/góc máy/bố cục của cảnh này
                                  Row(
                                    children: [
                                      Icon(Icons.crop_free, size: 16, color: mutedGrey),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: DropdownButton<String>(
                                          isExpanded: true,
                                          isDense: true,
                                          value: (idx < _framings.length) ? _framings[idx] : '',
                                          items: [
                                            for (final fopt in _framingOptions)
                                              DropdownMenuItem<String>(
                                                value: fopt[0],
                                                child: Text(tr(fopt[1]), style: const TextStyle(fontSize: 13)),
                                              ),
                                          ],
                                          onChanged: (v) => setState(() {
                                            if (idx < _framings.length) _framings[idx] = v ?? '';
                                          }),
                                        ),
                                      ),
                                    ],
                                  ),
                                  // MỚI (mục 26) - cảnh tự quay: dùng clip của bạn thay vì sinh AI
                                  Row(
                                    children: [
                                      Icon(Icons.movie_creation_outlined, size: 16, color: mutedGrey),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          hasClip
                                              ? trv('Cảnh tự quay: {0}', [widget.project.userClipLabels[idx] ?? ''])
                                              : tr('Cảnh AI (tự sinh)'),
                                          style: TextStyle(fontSize: 12, color: hasClip ? null : mutedGrey),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      if (_uploadingClipIdx == idx)
                                        const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                                      else if (hasClip)
                                        IconButton(
                                          tooltip: tr('Bỏ clip tự quay, dùng cảnh AI'),
                                          icon: const Icon(Icons.close, size: 18),
                                          onPressed: () => _removeUserClip(idx),
                                        )
                                      else
                                        TextButton(
                                          onPressed: _uploadingClipIdx == null ? () => _pickUserClip(idx) : null,
                                          child: Text(tr('Dùng clip tự quay')),
                                        ),
                                    ],
                                  ),
                                  // MỚI (mục 39, PDF-2 mục 8.2) - ảnh tham chiếu bố cục riêng cảnh này (chỉ Wan-VACE)
                                  Row(
                                    children: [
                                      Icon(Icons.image_outlined, size: 16, color: mutedGrey),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          widget.project.sceneRefs.containsKey(idx)
                                              ? trv('Ảnh bố cục: {0}', [widget.project.sceneRefLabels[idx] ?? ''])
                                              : tr('Chưa có ảnh bố cục (chỉ Wan-VACE dùng)'),
                                          style: TextStyle(fontSize: 12, color: widget.project.sceneRefs.containsKey(idx) ? null : mutedGrey),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      if (_uploadingRefIdx == idx)
                                        const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                                      else if (widget.project.sceneRefs.containsKey(idx))
                                        IconButton(
                                          tooltip: tr('Bỏ ảnh bố cục'),
                                          icon: const Icon(Icons.close, size: 18),
                                          onPressed: () => _removeSceneRef(idx),
                                        )
                                      else
                                        TextButton(
                                          onPressed: _uploadingRefIdx == null ? () => _pickSceneRef(idx) : null,
                                          child: Text(tr('Thêm ảnh bố cục')),
                                        ),
                                    ],
                                  ),
                                  if (!GenerationSettings.instance.enableMotionCamera &&
                                      idx < _cameras.length &&
                                      _cameras[idx].isNotEmpty)
                                    Text(
                                      tr('Đang tắt "Tự chọn chuyển động camera" trong Cài đặt - lựa chọn này sẽ bị bỏ qua.'),
                                      style: TextStyle(fontSize: 11, color: Colors.orange),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () => _startGenerating(useEditedPrompts: true),
                                    child: Text(tr('Xác nhận kịch bản, tạo MV')),
                                  ),
                                ),
                                SizedBox(
                                  width: double.infinity,
                                  child: OutlinedButton.icon(
                                    onPressed: () => _startGenerating(useEditedPrompts: true, preview: true),
                                    icon: const Icon(Icons.visibility_outlined),
                                    label: Text(tr('Xem trước 1 cảnh (nhanh, thử chất lượng)')),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () => _startGenerating(useEditedPrompts: false),
                                  child: Text(tr('Bỏ qua, dùng phong cách chung như cũ')),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
          ),
        ],
        ),
      ),
    );
  }
}
