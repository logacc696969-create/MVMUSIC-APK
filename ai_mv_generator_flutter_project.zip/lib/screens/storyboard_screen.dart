import 'package:flutter/material.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'generating_screen.dart';

/// Màn hình "Kịch bản cảnh" (Storyboard/Shot-list) - MỚI, chèn giữa
/// ReviewScreen và GeneratingScreen. Mô phỏng quy trình các app lớn hay dùng
/// (Kling/Runway: xem/sửa từng shot trước khi tốn tài nguyên tạo thật) - khác
/// HẲN hành vi CŨ của app này (mọi cảnh dùng CHUNG 1 style_prompt). Gọi
/// /build-storyboard (CHỈ CPU, không tốn GPU) để lấy prompt gợi ý cho từng
/// cảnh, cho người dùng sửa tự do, rồi gửi kèm khi tạo MV thật.
class StoryboardScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const StoryboardScreen({super.key, required this.api, required this.project});

  @override
  State<StoryboardScreen> createState() => _StoryboardScreenState();
}

class _StoryboardScreenState extends State<StoryboardScreen> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _scenes = [];
  late List<TextEditingController> _controllers;

  String get _audioFilename => widget.project.voicedFilename ?? widget.project.musicFilename!;

  @override
  void initState() {
    super.initState();
    _controllers = [];
    _load();
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = GenerationSettings.instance;
      final result = await widget.api.buildStoryboard(
        audioFilename: _audioFilename,
        styleId: widget.project.styleId!,
        beatsPerScene: s.beatsPerScene,
        maxScenes: s.maxScenes,
        characterDesc: s.characterDesc,
        lyrics: widget.project.lyrics,
      );
      if (result['status'] != 'ok') {
        setState(() => _error = result['note']?.toString() ?? 'Không tạo được kịch bản cảnh.');
        return;
      }
      final scenes = List<Map<String, dynamic>>.from(result['storyboard'] as List);
      for (final c in _controllers) {
        c.dispose();
      }
      setState(() {
        _scenes = scenes;
        _controllers = scenes.map((s) => TextEditingController(text: s['prompt'] as String)).toList();
      });
    } catch (e) {
      setState(() => _error = 'Không tạo được kịch bản cảnh: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _intensityColor(double intensity) {
    if (intensity > 0.66) return Colors.redAccent;
    if (intensity < 0.33) return Colors.blueAccent;
    return Colors.orangeAccent;
  }

  String _intensityLabel(double intensity) {
    if (intensity > 0.66) return 'Cao trào';
    if (intensity < 0.33) return 'Êm dịu';
    return 'Vừa phải';
  }

  void _startGenerating({required bool useEditedPrompts}) {
    if (useEditedPrompts) {
      widget.project.scenePrompts = _controllers.map((c) => c.text).toList();
    } else {
      widget.project.scenePrompts = null; // bỏ qua storyboard - dùng style_prompt chung như cũ
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GeneratingScreen(api: widget.api, project: widget.project)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kịch bản cảnh (Storyboard)')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        ElevatedButton(onPressed: _load, child: const Text('Thử lại')),
                        TextButton(
                          onPressed: () => _startGenerating(useEditedPrompts: false),
                          child: const Text('Bỏ qua, dùng phong cách chung như cũ'),
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Mỗi cảnh có 1 mô tả riêng, tự gợi ý theo độ mạnh nhịp của đoạn nhạc đó '
                        '(và lời bài hát nếu có). Sửa tự do trước khi tạo MV thật - đây chỉ là '
                        'gợi ý ban đầu, KHÔNG phải phân tích nhạc chính xác tuyệt đối.',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _scenes.length,
                        itemBuilder: (context, idx) {
                          final scene = _scenes[idx];
                          final intensity = (scene['intensity'] as num).toDouble();
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text('Cảnh ${idx + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                      const SizedBox(width: 8),
                                      Text(
                                        '${scene['start']}s - ${scene['end']}s',
                                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                                      ),
                                      const Spacer(),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: _intensityColor(intensity).withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          _intensityLabel(intensity),
                                          style: TextStyle(fontSize: 11, color: _intensityColor(intensity)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  TextField(
                                    controller: _controllers[idx],
                                    maxLines: 3,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => _startGenerating(useEditedPrompts: true),
                              child: const Text('Xác nhận kịch bản, tạo MV'),
                            ),
                          ),
                          TextButton(
                            onPressed: () => _startGenerating(useEditedPrompts: false),
                            child: const Text('Bỏ qua, dùng phong cách chung như cũ'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
    );
  }
}
