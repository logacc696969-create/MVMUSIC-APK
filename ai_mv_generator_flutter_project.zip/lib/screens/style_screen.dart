import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../api_service.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import 'review_screen.dart';

/// Ảnh minh hoạ (SVG tự vẽ, không dùng ảnh có bản quyền) cho từng phong cách.
/// Style mới "nguoi_that_studio" (mục 7zc2) CHƯA có SVG riêng - tự rơi về
/// icon mặc định (xem `assetPath != null` bên dưới), không phải thiếu sót.
const Map<String, String> _styleAssets = {
  'anh_sang_truu_tuong': 'assets/styles/anh_sang_truu_tuong.svg',
  'thien_nhien': 'assets/styles/thien_nhien.svg',
  'thanh_pho_cyberpunk': 'assets/styles/thanh_pho_cyberpunk.svg',
  'anime_3d': 'assets/styles/anime_3d.svg',
};

class StyleScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const StyleScreen({super.key, required this.api, required this.project});

  @override
  State<StyleScreen> createState() => _StyleScreenState();
}

class _StyleScreenState extends State<StyleScreen> {
  List<Map<String, dynamic>> _styles = [];
  String? _selected;
  bool _navigating = false; // chặn bấm nhiều lần liên tiếp khi đang chuyển màn
  bool _loading = true;
  String? _error;

  // MỚI (mục 7zc9) - danh sách backend Lipsync CÓ THẬT lấy động từ server,
  // KHÔNG hardcode ở Flutter - cùng pattern _videoBackends ở settings_screen.dart.
  List<Map<String, dynamic>> _lipsyncBackends = [];

  @override
  void initState() {
    super.initState();
    _loadStyles();
    _loadLipsyncBackends();
  }

  Future<void> _loadLipsyncBackends() async {
    try {
      final result = await widget.api.getLipsyncBackends();
      if (!mounted) return;
      final backends = (result['backends'] as List).cast<Map<String, dynamic>>();
      setState(() {
        _lipsyncBackends = backends;
        // Nếu chưa từng chọn (null) -> dùng mặc định server trả về, KHÔNG
        // hardcode ("wav2lip") - đúng pattern videoBackend.
        GenerationSettings.instance.lipsyncBackend ??= result['default'] as String?;
      });
    } catch (e) {
      // Lỗi tải danh sách backend KHÔNG được chặn màn Chọn phong cách - đây
      // là tính năng PHỤ, lipsync vẫn hoạt động bình thường với mặc định
      // server nếu Flutter không gửi lipsync_backend (xem generateMv()).
      print('[StyleScreen] Không tải được danh sách lipsync backend: $e');
    }
  }

  Future<void> _loadStyles() async {
    try {
      final styles = await widget.api.getVideoStyles();
      if (!mounted) return;
      setState(() {
        _styles = styles;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Không tải được danh sách phong cách: $e';
        _loading = false;
      });
    }
  }

  bool get _selectedSupportsLipsync {
    if (_selected == null) return false;
    final match = _styles.where((s) => s['id'] == _selected);
    if (match.isEmpty) return false;
    return match.first['lipsync_ok'] == true;
  }

  void _selectStyle(String id) {
    setState(() => _selected = id);
    // MỚI (mục 7zc2) - đổi style mà không còn hỗ trợ Lipsync -> tự tắt công
    // tắc (giống đúng mẫu `enableMotionCamera` tự tắt khi đổi videoBackend
    // không hỗ trợ, ở settings_screen.dart).
    if (!_selectedSupportsLipsync) {
      GenerationSettings.instance.enableLipsync = false;
    }
  }

  void _next() {
    if (_navigating) return;
    if (_selected == null) {
      setState(() => _error = 'Chọn 1 phong cách MV trước đã.');
      return;
    }
    _navigating = true;
    widget.project.styleId = _selected;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewScreen(api: widget.api, project: widget.project),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bước 3: Chọn phong cách MV')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      children: _styles.map((style) {
                        final id = style['id'] as String;
                        final assetPath = _styleAssets[id];
                        final label = style['label'] as String? ?? id;
                        final isSelected = _selected == id;
                        return GestureDetector(
                          onTap: () => _selectStyle(id),
                          child: Card(
                            clipBehavior: Clip.antiAlias,
                            elevation: isSelected ? 6 : 1,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                color: isSelected ? Theme.of(context).colorScheme.primary : Colors.transparent,
                                width: 3,
                              ),
                            ),
                            child: Column(
                              children: [
                                Expanded(
                                  child: assetPath != null
                                      ? SvgPicture.asset(assetPath, fit: BoxFit.cover, width: double.infinity)
                                      : Container(color: Colors.grey.shade300, child: const Icon(Icons.movie, size: 48)),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  // MỚI (mục 7zc2) - công tắc Lipsync CHỈ hiện khi style đang
                  // chọn hỗ trợ (hiện chỉ "Người thật") - style khác thì công
                  // tắc này BIẾN MẤT HẲN (không phải hiện mờ/khoá) để tránh
                  // người dùng thắc mắc "sao bấm không được".
                  if (_selectedSupportsLipsync)
                    Card(
                      color: Colors.blue.shade50,
                      child: SwitchListTile(
                        title: const Text('Khớp khẩu hình (Lipsync)', style: TextStyle(fontSize: 14)),
                        subtitle: const Text(
                          'Thử nghiệm - chạy chậm hơn, có thể không nhận diện được mặt trong 1 số cảnh.',
                          style: TextStyle(fontSize: 11),
                        ),
                        value: GenerationSettings.instance.enableLipsync,
                        onChanged: (v) => setState(() => GenerationSettings.instance.enableLipsync = v),
                      ),
                    ),
                  // MỚI (mục 7zc9) - chọn CÔNG NGHỆ lipsync (wav2lip/musetalk...)
                  // - CHỈ hiện khi: (1) style hỗ trợ lipsync, (2) đã bật công
                  // tắc trên, (3) server có từ 2 backend trở lên (chỉ 1 thì
                  // không cần cho chọn, tự dùng backend đó luôn - tránh UI
                  // thừa). KHÔNG dùng RadioListTile - cùng lý do đã sửa ở
                  // settings_screen.dart (label dài dễ bị cắt chữ), dùng
                  // Card + InkWell + Row + Radio để chữ tự xuống dòng đầy đủ.
                  if (_selectedSupportsLipsync &&
                      GenerationSettings.instance.enableLipsync &&
                      _lipsyncBackends.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 4, bottom: 4),
                            child: Text('Công nghệ Lipsync', style: TextStyle(fontSize: 12, color: Colors.grey)),
                          ),
                          ..._lipsyncBackends.map((b) => Card(
                                margin: const EdgeInsets.only(bottom: 6),
                                child: InkWell(
                                  onTap: () => setState(() => GenerationSettings.instance.lipsyncBackend = b['id'] as String),
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Radio<String>(
                                          value: b['id'] as String,
                                          groupValue: GenerationSettings.instance.lipsyncBackend,
                                          onChanged: (v) => setState(() => GenerationSettings.instance.lipsyncBackend = v),
                                        ),
                                        const SizedBox(width: 4),
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(top: 12),
                                            child: Text(b['label'] as String, style: const TextStyle(fontSize: 12)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )),
                        ],
                      ),
                    ),
                  if (_error != null)
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _navigating ? null : _next,
                    child: const Text('Tiếp tục'),
                  ),
                ],
              ),
            ),
    );
  }
}
