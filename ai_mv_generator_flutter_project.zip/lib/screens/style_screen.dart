import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../api_service.dart';
import '../project_data.dart';
import 'review_screen.dart';

/// Ảnh minh hoạ (SVG tự vẽ, không dùng ảnh có bản quyền) cho từng phong cách.
const Map<String, String> _styleAssets = {
  'anh_sang_truu_tuong': 'assets/styles/anh_sang_truu_tuong.svg',
  'thien_nhien': 'assets/styles/thien_nhien.svg',
  'thanh_pho_cyberpunk': 'assets/styles/thanh_pho_cyberpunk.svg',
  'anime_3d': 'assets/styles/anime_3d.svg',
};

const Map<String, String> _styleLabels = {
  'anh_sang_truu_tuong': 'Ánh sáng trừu tượng',
  'thien_nhien': 'Thiên nhiên',
  'thanh_pho_cyberpunk': 'Thành phố Cyberpunk',
  'anime_3d': 'Anime 3D',
};

class StyleScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const StyleScreen({super.key, required this.api, required this.project});

  @override
  State<StyleScreen> createState() => _StyleScreenState();
}

class _StyleScreenState extends State<StyleScreen> {
  List<String> _styles = [];
  String? _selected;
  bool _navigating = false; // chặn bấm nhiều lần liên tiếp khi đang chuyển màn
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadStyles();
  }

  Future<void> _loadStyles() async {
    try {
      final styles = await widget.api.getVideoStyles();
      setState(() {
        _styles = styles;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Không tải được danh sách phong cách: $e';
        _loading = false;
      });
    }
  }

  void _next() {
    if (_navigating) return;
    if (_selected == null) {
      setState(() => _error = 'Chọn 1 phong cách MV trước đã.');
      return;
    }
    _navigating = true;
    widget.project.styleId = _selected;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewScreen(api: widget.api, project: widget.project),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bước 3: Chọn phong cách MV')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      children: _styles.map((id) {
                        final assetPath = _styleAssets[id];
                        final label = _styleLabels[id] ?? id;
                        final isSelected = _selected == id;
                        return GestureDetector(
                          onTap: () => setState(() => _selected = id),
                          child: Card(
                            clipBehavior: Clip.antiAlias,
                            elevation: isSelected ? 6 : 1,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                color: isSelected ? Theme.of(context).colorScheme.primary : Colors.transparent,
                                width: 3,
                              ),
                            ),
                            child: Column(
                              children: [
                                Expanded(
                                  child: assetPath != null
                                      ? SvgPicture.asset(assetPath, fit: BoxFit.cover, width: double.infinity)
                                      : Container(color: Colors.grey.shade300, child: const Icon(Icons.movie, size: 48)),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Text(label, textAlign: TextAlign.center),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  if (_error != null)
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _navigating ? null : _next,
                    child: const Text('Tiếp tục'),
                  ),
                ],
              ),
            ),
    );
  }
}
