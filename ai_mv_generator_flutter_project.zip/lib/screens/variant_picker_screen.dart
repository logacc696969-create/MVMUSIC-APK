import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../api_service.dart';
import '../project_data.dart';
import 'voice_screen.dart';

/// Màn hình "Chọn bản nhạc" - MỚI, chỉ xuất hiện khi backend trả về nhiều
/// hơn 1 bản (`files.length > 1`, bật ở Settings: "Tạo 2 bản để chọn").
/// Mô phỏng quy trình Suno/Udio: tạo nhiều bản trong 1 lần, nghe thử từng
/// bản rồi chọn bản ưng ý nhất, thay vì chỉ nhận đúng 1 bản "cứng".
class VariantPickerScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;
  final List<String> variantFilenames;

  const VariantPickerScreen({
    super.key,
    required this.api,
    required this.project,
    required this.variantFilenames,
  });

  @override
  State<VariantPickerScreen> createState() => _VariantPickerScreenState();
}

class _VariantPickerScreenState extends State<VariantPickerScreen> {
  final _player = AudioPlayer();
  int? _playingIndex;
  final Map<int, File> _downloaded = {};
  final Set<int> _downloading = {};
  bool _confirming = false;

  @override
  void initState() {
    super.initState();
    _player.onPlayerStateChanged.listen((state) {
      if (mounted && state != PlayerState.playing) {
        setState(() => _playingIndex = null);
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _togglePlay(int index) async {
    if (_playingIndex == index) {
      try {
        await _player.stop();
      } catch (_) {}
      if (mounted) setState(() => _playingIndex = null);
      return;
    }

    File? file = _downloaded[index];
    if (file == null) {
      setState(() => _downloading.add(index));
      try {
        final res = await http.get(Uri.parse(widget.api.downloadUrl(widget.variantFilenames[index])));
        final dir = await getTemporaryDirectory();
        file = File('${dir.path}/variant_$index.wav');
        await file.writeAsBytes(res.bodyBytes);
        _downloaded[index] = file;
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không tải được bản nhạc: $e')));
        }
        return;
      } finally {
        if (mounted) setState(() => _downloading.remove(index));
      }
    }

    try {
      await _player.stop();
      await _player.play(DeviceFileSource(file.path));
      if (mounted) setState(() => _playingIndex = index);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không phát được: $e')));
      }
    }
  }

  Future<void> _choose(int index) async {
    try {
      await _player.stop();
    } catch (_) {}
    if (!mounted) return;
    setState(() => _confirming = true);
    widget.project.musicFilename = widget.variantFilenames[index];
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => VoiceScreen(api: widget.api, project: widget.project)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chọn bản bạn thích')),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Đã tạo xong nhiều bản khác nhau từ cùng 1 mô tả - nghe thử rồi chọn '
              'bản bạn ưng ý nhất để tiếp tục.',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: widget.variantFilenames.length,
              itemBuilder: (context, index) {
                final isPlaying = _playingIndex == index;
                final isDownloading = _downloading.contains(index);
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: IconButton(
                      icon: isDownloading
                          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : Icon(isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 32),
                      onPressed: isDownloading ? null : () => _togglePlay(index),
                    ),
                    title: Text('Bản ${index + 1}'),
                    trailing: ElevatedButton(
                      onPressed: _confirming ? null : () => _choose(index),
                      child: const Text('Chọn'),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
