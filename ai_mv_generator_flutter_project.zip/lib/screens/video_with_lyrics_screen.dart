import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// MỚI (mục 7zc4) - phát MV NGAY TRONG APP (khác nút "Mở xem" ở ResultScreen,
/// vốn giao hẳn cho app ngoài xử lý - không thể chồng phụ đề lên video đang
/// phát ở 1 app KHÁC). Chỉ có ý nghĩa nếu có sẵn file phụ đề động
/// (`lyricsTimestampsPath` - xem ProjectData/generating_screen.dart) - màn
/// này vẫn phát được video bình thường nếu KHÔNG có file phụ đề (chỉ là
/// không hiện chữ chạy).
///
/// CHƯA CHẠY THỬ THẬT - cấu trúc file JSON đọc vào (`word`, `start_ms`,
/// `end_ms`) khớp với `_align_lyrics_to_audio` trong app.py - nếu backend đổi
/// cấu trúc, cần sửa lại `_loadLyrics()` bên dưới cho khớp.
class VideoWithLyricsScreen extends StatefulWidget {
  final String videoPath;
  final String? lyricsTimestampsPath;

  const VideoWithLyricsScreen({super.key, required this.videoPath, this.lyricsTimestampsPath});

  @override
  State<VideoWithLyricsScreen> createState() => _VideoWithLyricsScreenState();
}

class _VideoWithLyricsScreenState extends State<VideoWithLyricsScreen> {
  VideoPlayerController? _controller;
  bool _ready = false;
  String? _error;
  List<Map<String, dynamic>> _words = [];
  String _currentLine = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _loadLyrics();
    try {
      final controller = VideoPlayerController.file(File(widget.videoPath));
      await controller.initialize();
      controller.addListener(_onTick);
      controller.play();
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _ready = true;
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Không phát được MV: $e');
    }
  }

  Future<void> _loadLyrics() async {
    final path = widget.lyricsTimestampsPath;
    if (path == null) return;
    try {
      final content = await File(path).readAsString();
      final decoded = jsonDecode(content) as List;
      _words = decoded.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      // Lỗi đọc phụ đề KHÔNG được chặn phát video - bỏ qua lặng lẽ, phát
      // bình thường không có chữ chạy.
      _words = [];
    }
  }

  /// Gộp các từ đang "trong khung thời gian hiện tại +/- 1 câu ngắn" thành 1
  /// dòng để hiện - đơn giản hơn hẳn true karaoke (tô màu từng chữ), nhưng đủ
  /// dùng cho bản đầu tiên, dễ kiểm chứng đúng/sai khi xem thử thật.
  void _onTick() {
    final controller = _controller;
    if (controller == null || _words.isEmpty) return;
    final posMs = controller.value.position.inMilliseconds;
    final current = _words.where((w) => posMs >= (w['start_ms'] as int) && posMs <= (w['end_ms'] as int));
    if (current.isNotEmpty) {
      final idx = _words.indexOf(current.first);
      // Lấy thêm vài từ liền trước/sau để thành 1 cụm/dòng dễ đọc thay vì chỉ
      // 1 chữ đơn lẻ nhảy liên tục.
      final start = (idx - 2).clamp(0, _words.length - 1);
      final end = (idx + 3).clamp(0, _words.length);
      final line = _words.sublist(start, end).map((w) => w['word']).join(' ');
      if (line != _currentLine && mounted) setState(() => _currentLine = line);
    }
  }

  @override
  void dispose() {
    _controller?.removeListener(_onTick);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text('Đang phát MV'), backgroundColor: Colors.black),
      body: Center(
        child: _error != null
            ? Padding(
                padding: const EdgeInsets.all(16),
                child: Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
              )
            : !_ready
                ? const CircularProgressIndicator()
                : AspectRatio(
                    aspectRatio: _controller!.value.aspectRatio == 0 ? 16 / 9 : _controller!.value.aspectRatio,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        VideoPlayer(_controller!),
                        VideoProgressIndicator(_controller!, allowScrubbing: true),
                        if (_currentLine.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 24, left: 12, right: 12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.6),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                _currentLine,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
      ),
      floatingActionButton: _ready
          ? FloatingActionButton(
              onPressed: () => setState(() {
                _controller!.value.isPlaying ? _controller!.pause() : _controller!.play();
              }),
              child: Icon(_controller!.value.isPlaying ? Icons.pause : Icons.play_arrow),
            )
          : null,
    );
  }
}
