import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api_service.dart';
import '../backend_busy_tracker.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../progress_poller.dart';
import 'style_screen.dart';

class VoiceScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const VoiceScreen({super.key, required this.api, required this.project});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  List<String> _voices = [];
  String? _selected; // null = giữ nguyên giọng gốc
  bool _loading = true;
  bool _applying = false;
  bool _uploading = false;
  bool _training = false;
  bool _cancellingTrain = false;
  int _trainPercent = 0;
  String _trainStageDetail = '';
  String? _error;
  int _percent = 0;
  String _stageDetail = '';
  int _pitchShift = 0; // bán cung dịch tông cho RVC - chỉ áp dụng khi có chọn giọng

  // Formant Shifting + De-essing: state NỘI BỘ VoiceScreen (chỉ có tác dụng
  // ở bước này, không phải cài đặt chung toàn app) - tách khỏi GenerationSettings
  // để nằm đúng chỗ UX: người dùng thấy ngay khi chọn giọng, không phải vào
  // Cài đặt rồi không biết 2 công tắc đó liên quan tới màn nào.
  bool _enableFormantShift = false;
  double _formantQuefrencyMs = 1.5;
  bool _enableDeessing = false;
  late final TextEditingController _formantQuefrencyCtrl =
      TextEditingController(text: '1.5');

  @override
  void initState() {
    super.initState();
    _loadVoices();
  }

  @override
  void dispose() {
    _formantQuefrencyCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadVoices() async {
    try {
      final voices = await widget.api.getVoicePresets();
      if (!mounted) return;
      setState(() {
        _voices = voices;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Không tải được danh sách giọng: $e';
        _loading = false;
      });
    }
  }

  Future<void> _uploadNewVoice() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pth'],
    );
    if (result == null || result.files.single.path == null) return;

    final nameController = TextEditingController(
      text: result.files.single.name.replaceAll('.pth', ''),
    );
    if (!mounted) return;
    final voiceName = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đặt tên cho giọng này'),
        content: TextField(controller: nameController, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, nameController.text.trim()),
            child: const Text('Upload'),
          ),
        ],
      ),
    );
    if (voiceName == null || voiceName.isEmpty) return;
    if (!mounted) return;

    setState(() {
      _uploading = true;
      _error = null;
    });
    try {
      await widget.api.uploadVoice(
        pthFile: File(result.files.single.path!),
        voiceName: voiceName,
      );
      await _loadVoices(); // nạp lại danh sách để thấy giọng vừa upload
    } catch (e) {
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây
      // File .pth khá nặng (40-60MB) - nếu mạng chậm/không ổn định, request
      // có thể bị ngắt giữa chừng phía server/tunnel trước khi hoàn tất (không
      // phải do app tự bỏ cuộc - package http không tự đặt timeout). Gợi ý rõ
      // phương án dự phòng thay vì chỉ hiện lỗi kỹ thuật thô.
      setState(() => _error =
          'Upload giọng thất bại (có thể do mạng chậm khi tải file lớn): $e\n'
          'Thử lại bằng Wi-Fi, hoặc chép file .pth thẳng vào thư mục '
          'mv_app_voice_models trong Google Drive của bạn thay vì upload qua app.');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _trainNewVoice() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wav', 'm4a'],
    );
    if (result == null || result.files.single.path == null) return;

    if (!mounted) return;
    // Cảnh báo thời gian + chất lượng THẬT trước khi bắt đầu - tránh người
    // dùng tưởng đây là việc vài phút rồi bỏ app đi làm việc khác, mất công
    // quay lại thấy vẫn đang chạy hoặc lỗi giữa chừng mà không hiểu vì sao.
    final nameController = TextEditingController();
    final confirmed = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đặt tên cho giọng này'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: nameController, autofocus: true),
            const SizedBox(height: 12),
            const Text(
              'Lưu ý: quá trình này chạy NỀN trên Colab, có thể mất từ vài chục '
              'phút tới lâu hơn (tuỳ độ dài file ghi âm), KHÔNG phải vài phút. '
              'Nên dùng file ghi âm giọng nói SẠCH, RÕ, càng dài càng tốt (RVC '
              'khuyến nghị tối thiểu khoảng 10 phút) để chất lượng tốt hơn. '
              'Có thể rời màn hình này trong lúc chờ, tiến trình vẫn chạy trên Colab.',
              style: TextStyle(fontSize: 12, color: Colors.orange),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, nameController.text.trim()),
            child: const Text('Bắt đầu train'),
          ),
        ],
      ),
    );
    if (confirmed == null || confirmed.isEmpty) return;
    if (!mounted) return;

    setState(() {
      _training = true;
      _trainPercent = 0;
      _error = null;
    });
    // MỚI - báo cho toàn app biết GPU đang bận train giọng, để HomeScreen
    // cảnh báo nếu người dùng lỡ thoát màn này rồi bấm "Tạo dự án mới".
    BackendBusyTracker.markBusy('Đang train giọng...');

    final poller = ProgressPoller(api: widget.api, onUpdate: (_, __, ___) {});

    try {
      await widget.api.trainVoice(
        audioFile: File(result.files.single.path!),
        voiceName: confirmed,
        hmacSecret: GenerationSettings.instance.hmacSecret,
      );
      // /train-voice CHẠY NỀN (trả về ngay, không đợi tới xong như
      // /apply-voice) - phải tự poll /progress tới khi done=true.
      // `shouldStop: () => !mounted` (MỚI, lượt audit sau 7zc19) - tự thoát
      // vòng lặp poll nếu widget bị dispose giữa chừng (người dùng rời màn
      // hình trước khi train xong) - tránh tiếp tục gọi network ngầm vô ích
      // tới khi server báo done (xem docstring `waitUntilDone` trong
      // progress_poller.dart để biết vì sao cần tham số này).
      final finalProgress = await poller.waitUntilDone(
        shouldStop: () => !mounted,
        onUpdate: (percent, detail) {
          if (mounted) setState(() {
            _trainPercent = percent;
            _trainStageDetail = detail;
          });
        },
      );
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây (kể cả khi return do _cancelled_by_caller)
      if (finalProgress['error'] != null) {
        setState(() => _error = 'Train giọng thất bại: ${finalProgress['error']}');
      } else {
        await _loadVoices(); // thấy ngay giọng vừa train trong danh sách
      }
    } catch (e) {
      if (!mounted) return; // finally bên dưới VẪN chạy dù return sớm ở đây
      setState(() => _error = 'Train giọng thất bại: $e');
    } finally {
      // ĐỔI (lượt audit sau 7zc17/7zc18) - dùng markFreeAfterVerify() thay
      // markFree() trực tiếp: nếu lỗi xảy ra NGAY LÚC GỬI request khởi động
      // (`trainVoice()`, dòng đầu try), KHÔNG THỂ chắc chắn job đã bắt đầu ở
      // backend hay chưa (request có thể đã tới, chỉ response bị mất) - hàm
      // này tự hỏi lại `/progress` để xác nhận trước khi thực sự markFree().
      // Nếu lỗi xảy ra SAU KHI `waitUntilDone()` đã return (done=true chắc
      // chắn) - verify vẫn ĐÚNG (chỉ tốn thêm 1 lần gọi API không đáng kể).
      await BackendBusyTracker.markFreeAfterVerify(widget.api);
      if (mounted) setState(() {
        _training = false;
        _cancellingTrain = false;
      });
    }
  }

  /// MỚI - backend giờ hỗ trợ huỷ train giữa chừng (POST /abort-job khi
  /// stage="train_voice" sẽ terminate() đúng tiến trình CLI con đang chạy).
  /// KHÔNG tự set _training=false ở đây - đợi `poller.waitUntilDone()` trong
  /// `_trainNewVoice()` tự nhận ra qua /progress (done=true, kèm error báo
  /// "đã bị huỷ") rồi tự dọn state ở khối `finally` phía trên, tránh 2 chỗ
  /// cùng sửa chung 1 state gây lệch nhau.
  Future<void> _cancelTraining() async {
    setState(() => _cancellingTrain = true);
    try {
      await widget.api.abortJob();
    } catch (e) {
      if (mounted) {
        setState(() {
          _cancellingTrain = false;
          _error = 'Không gửi được yêu cầu huỷ: $e';
        });
      }
    }
  }

  Future<void> _next() async {
    widget.project.voiceId = _selected;

    if (_selected != null) {
      setState(() {
        _applying = true;
        _error = null;
        _percent = 0;
      });

      final poller = ProgressPoller(
        api: widget.api,
        onUpdate: (percent, stage, detail) {
          if (mounted) setState(() {
            _percent = percent;
            _stageDetail = detail;
          });
        },
      );
      poller.start();

      try {
        final result = await widget.api.applyVoice(
          audioFilename: widget.project.musicFilename!,
          voiceId: _selected!,
          // Trước đây KHÔNG gửi gpu_power (backend cũng không nhận) - slider
          // "Công suất sử dụng GPU" hoàn toàn không có tác dụng ở bước này.
          gpuPower: GenerationSettings.instance.gpuPower,
          pitchShift: _pitchShift,
          enableFormantShift: _enableFormantShift,
          formantQuefrencyMs: _formantQuefrencyMs,
          enableDeessing: _enableDeessing,
        );
        widget.project.voicedFilename = result['file'];
      } catch (e) {
        poller.stop(); // luôn dừng poller dù widget còn mounted hay không - tránh rò rỉ timer
        if (!mounted) return;
        setState(() {
          _error = 'Lỗi đổi giọng: $e';
          _applying = false;
        });
        return;
      }
      poller.stop();
    }

    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StyleScreen(api: widget.api, project: widget.project),
      ),
    );
  }

  Widget _voiceProcessingCard({
    required String title,
    required String subtitle,
    required bool value,
    required void Function(bool) onChanged,
    Widget? extraContent,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                      const SizedBox(height: 4),
                      Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                    ],
                  ),
                ),
                Switch(value: value, onChanged: onChanged),
              ],
            ),
            if (extraContent != null) extraContent,
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bước 2: Chọn giọng hát')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Tuỳ chọn - có thể bỏ qua để giữ nguyên bản nhạc gốc.'),
                  if (widget.project.fromSample) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.withOpacity(0.3)),
                      ),
                      child: const Text(
                        'Hệ thống sẽ tự tách riêng giọng hát khỏi nhạc nền trước khi đổi '
                        'giọng, nên nhạc nền sẽ không bị ảnh hưởng. Nếu bản nhạc mẫu vốn '
                        'không có giọng hát, có thể chọn "Giữ nguyên" để bỏ qua bước này.',
                        style: TextStyle(fontSize: 12, color: Colors.blueGrey),
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  Expanded(
                    child: ListView(
                      children: [
                        RadioListTile<String?>(
                          title: const Text('Giữ nguyên (không đổi giọng)'),
                          value: null,
                          groupValue: _selected,
                          onChanged: (v) => setState(() => _selected = v),
                        ),
                        ..._voices.map((v) => RadioListTile<String?>(
                              title: Text(v),
                              value: v,
                              groupValue: _selected,
                              onChanged: (val) => setState(() => _selected = val),
                            )),
                        if (_selected != null) ...[
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Dịch tông giọng: ${_pitchShift > 0 ? '+' : ''}$_pitchShift '
                                    'bán cung', style: const TextStyle(fontSize: 13)),
                                const Text(
                                  'Để 0 nếu giọng mẫu vốn đã hát (đã có cao độ bài hát). '
                                  'Nếu là giọng NÓI thường (không hát), thử tăng/giảm rồi '
                                  'nghe thử để khớp tông bài hát hơn.',
                                  style: TextStyle(fontSize: 11, color: Colors.blueGrey),
                                ),
                                Slider(
                                  value: _pitchShift.toDouble(),
                                  min: -12,
                                  max: 12,
                                  divisions: 24,
                                  label: '$_pitchShift',
                                  onChanged: (v) => setState(() => _pitchShift = v.round()),
                                ),
                                const SizedBox(height: 8),
                                // Formant Shifting + De-essing: đặt ở đây vì
                                // chỉ có tác dụng khi ĐÃ chọn giọng RVC -
                                // người dùng thấy ngay trong context đúng.
                                _voiceProcessingCard(
                                  title: 'Chỉnh formant giọng hát (thử nghiệm)',
                                  subtitle: 'Sửa giọng RVC bị "chóe"/nghẹt mũi khi âm vực lệch nhiều. '
                                      'Cần cài thêm stftpitchshift ở Colab (xem colab_setup.py). '
                                      'CHƯA nghe thử thật - nên bật/tắt so sánh trước.',
                                  value: _enableFormantShift,
                                  onChanged: (v) => setState(() => _enableFormantShift = v),
                                  extraContent: _enableFormantShift
                                      ? Padding(\
                                          padding: const EdgeInsets.only(top: 8),
                                          child: TextField(
                                            controller: _formantQuefrencyCtrl,
                                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                            decoration: const InputDecoration(
                                              border: OutlineInputBorder(),
                                              labelText: 'Quefrency (ms)',
                                              hintText: 'Mặc định 1.5 - thử tăng/giảm nếu giọng chưa tự nhiên',
                                            ),
                                            onChanged: (v) {
                                              final parsed = double.tryParse(v);
                                              if (parsed != null) setState(() => _formantQuefrencyMs = parsed);
                                            },
                                          ),
                                        )
                                      : null,
                                ),
                                const SizedBox(height: 8),
                                _voiceProcessingCard(
                                  title: 'Giảm tiếng xì giọng hát (thử nghiệm)',
                                  subtitle: 'Giảm nhẹ âm lượng ở dải 4-8kHz (tiếng "s", "x", "ch" bị rít gió). '
                                      'Khác Formant Shifting - có thể bật cả 2 cùng lúc. CHƯA nghe thử thật.',
                                  value: _enableDeessing,
                                  onChanged: (v) => setState(() => _enableDeessing = v),
                                ),
                              ],
                            ),
                          ),
                        ],
                        const Divider(),
                        Card(
                          child: InkWell(
                            onTap: _uploading ? null : _uploadNewVoice,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _uploading
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.upload_file),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Upload giọng mới (.pth)'),
                                        SizedBox(height: 2),
                                        Text('Tự thêm giọng riêng, không cần tải tay lên Drive', style: TextStyle(fontSize: 12, color: Colors.grey)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Card(
                          child: InkWell(
                            onTap: _training ? null : _trainNewVoice,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _training
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.mic),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Tự train giọng từ file ghi âm'),
                                        SizedBox(height: 2),
                                        Text(
                                          'Chọn 1 file ghi âm giọng nói sạch, càng dài càng tốt - chạy nền trên Colab, mất từ vài chục phút',
                                          style: TextStyle(fontSize: 12, color: Colors.grey), // KHÔNG maxLines -> hiện đủ, không cắt như ListTile mặc định
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        if (_training) ...[
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LinearProgressIndicator(value: _trainPercent / 100),
                                const SizedBox(height: 4),
                                Text('$_trainPercent% — $_trainStageDetail', style: const TextStyle(fontSize: 12)),
                                const SizedBox(height: 4),
                                // MỚI - backend giờ đã hỗ trợ huỷ train giữa
                                // chừng qua /abort-job (trước đây không có
                                // cách nào huỷ, phải đợi chạy hết/tự lỗi).
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: TextButton.icon(
                                    onPressed: _cancellingTrain ? null : _cancelTraining,
                                    icon: const Icon(Icons.cancel_outlined, size: 16),
                                    label: Text(_cancellingTrain ? 'Đang huỷ...' : 'Huỷ train'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_error != null)
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  if (_applying) ...[
                    LinearProgressIndicator(value: _percent / 100),
                    const SizedBox(height: 6),
                    Text('$_percent% — $_stageDetail', style: const TextStyle(fontSize: 13)),
                  ],
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _applying ? null : _next,
                    child: const Text('Tiếp tục'),
                  ),
                ],
              ),
            ),
    );
  }
}
