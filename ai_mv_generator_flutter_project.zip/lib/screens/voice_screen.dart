import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api_service.dart';
import '../backend_busy_tracker.dart';
import '../generation_settings.dart';
import '../project_data.dart';
import '../progress_poller.dart';
import 'style_screen.dart';

class VoiceScreen extends StatefulWidget {
  final ApiService api;
  final ProjectData project;

  const VoiceScreen({super.key, required this.api, required this.project});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  List<String> _voices = [];
  String? _selected; // null = giữ nguyên giọng gốc
  bool _loading = true;
  bool _applying = false;
  bool _uploading = false;
  bool _training = false;
  bool _cancellingTrain = false;
  int _trainPercent = 0;
  String _trainStageDetail = '';
  String? _error;
  int _percent = 0;
  String _stageDetail = '';
  int _pitchShift = 0; // bán cung dịch tông cho RVC - chỉ áp dụng khi có chọn giọng

  @override
  void initState() {
    super.initState();
    _loadVoices();
  }

  Future<void> _loadVoices() async {
    try {
      final voices = await widget.api.getVoicePresets();
      setState(() {
        _voices = voices;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Không tải được danh sách giọng: $e';
        _loading = false;
      });
    }
  }

  Future<void> _uploadNewVoice() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pth'],
    );
    if (result == null || result.files.single.path == null) return;

    final nameController = TextEditingController(
      text: result.files.single.name.replaceAll('.pth', ''),
    );
    if (!mounted) return;
    final voiceName = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đặt tên cho giọng này'),
        content: TextField(controller: nameController, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, nameController.text.trim()),
            child: const Text('Upload'),
          ),
        ],
      ),
    );
    if (voiceName == null || voiceName.isEmpty) return;

    setState(() {
      _uploading = true;
      _error = null;
    });
    try {
      await widget.api.uploadVoice(
        pthFile: File(result.files.single.path!),
        voiceName: voiceName,
      );
      await _loadVoices(); // nạp lại danh sách để thấy giọng vừa upload
    } catch (e) {
      // File .pth khá nặng (40-60MB) - nếu mạng chậm/không ổn định, request
      // có thể bị ngắt giữa chừng phía server/tunnel trước khi hoàn tất (không
      // phải do app tự bỏ cuộc - package http không tự đặt timeout). Gợi ý rõ
      // phương án dự phòng thay vì chỉ hiện lỗi kỹ thuật thô.
      setState(() => _error =
          'Upload giọng thất bại (có thể do mạng chậm khi tải file lớn): $e\n'
          'Thử lại bằng Wi-Fi, hoặc chép file .pth thẳng vào thư mục '
          'mv_app_voice_models trong Google Drive của bạn thay vì upload qua app.');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _trainNewVoice() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wav', 'm4a'],
    );
    if (result == null || result.files.single.path == null) return;

    if (!mounted) return;
    // Cảnh báo thời gian + chất lượng THẬT trước khi bắt đầu - tránh người
    // dùng tưởng đây là việc vài phút rồi bỏ app đi làm việc khác, mất công
    // quay lại thấy vẫn đang chạy hoặc lỗi giữa chừng mà không hiểu vì sao.
    final nameController = TextEditingController();
    final confirmed = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đặt tên cho giọng này'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: nameController, autofocus: true),
            const SizedBox(height: 12),
            const Text(
              'Lưu ý: quá trình này chạy NỀN trên Colab, có thể mất từ vài chục '
              'phút tới lâu hơn (tuỳ độ dài file ghi âm), KHÔNG phải vài phút. '
              'Nên dùng file ghi âm giọng nói SẠCH, RÕ, càng dài càng tốt (RVC '
              'khuyến nghị tối thiểu khoảng 10 phút) để chất lượng tốt hơn. '
              'Có thể rời màn hình này trong lúc chờ, tiến trình vẫn chạy trên Colab.',
              style: TextStyle(fontSize: 12, color: Colors.orange),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, nameController.text.trim()),
            child: const Text('Bắt đầu train'),
          ),
        ],
      ),
    );
    if (confirmed == null || confirmed.isEmpty) return;

    setState(() {
      _training = true;
      _trainPercent = 0;
      _error = null;
    });
    // MỚI - báo cho toàn app biết GPU đang bận train giọng, để HomeScreen
    // cảnh báo nếu người dùng lỡ thoát màn này rồi bấm "Tạo dự án mới".
    BackendBusyTracker.markBusy('Đang train giọng...');

    final poller = ProgressPoller(api: widget.api, onUpdate: (_, __, ___) {});

    try {
      await widget.api.trainVoice(
        audioFile: File(result.files.single.path!),
        voiceName: confirmed,
        hmacSecret: GenerationSettings.instance.hmacSecret,
      );
      // /train-voice CHẠY NỀN (trả về ngay, không đợi tới xong như
      // /apply-voice) - phải tự poll /progress tới khi done=true.
      final finalProgress = await poller.waitUntilDone(
        onUpdate: (percent, detail) {
          if (mounted) setState(() {
            _trainPercent = percent;
            _trainStageDetail = detail;
          });
        },
      );
      if (finalProgress['error'] != null) {
        setState(() => _error = 'Train giọng thất bại: ${finalProgress['error']}');
      } else {
        await _loadVoices(); // thấy ngay giọng vừa train trong danh sách
      }
    } catch (e) {
      setState(() => _error = 'Train giọng thất bại: $e');
    } finally {
      BackendBusyTracker.markFree();
      if (mounted) setState(() {
        _training = false;
        _cancellingTrain = false;
      });
    }
  }

  /// MỚI - backend giờ hỗ trợ huỷ train giữa chừng (POST /abort-job khi
  /// stage="train_voice" sẽ terminate() đúng tiến trình CLI con đang chạy).
  /// KHÔNG tự set _training=false ở đây - đợi `poller.waitUntilDone()` trong
  /// `_trainNewVoice()` tự nhận ra qua /progress (done=true, kèm error báo
  /// "đã bị huỷ") rồi tự dọn state ở khối `finally` phía trên, tránh 2 chỗ
  /// cùng sửa chung 1 state gây lệch nhau.
  Future<void> _cancelTraining() async {
    setState(() => _cancellingTrain = true);
    try {
      await widget.api.abortJob();
    } catch (e) {
      if (mounted) {
        setState(() {
          _cancellingTrain = false;
          _error = 'Không gửi được yêu cầu huỷ: $e';
        });
      }
    }
  }

  Future<void> _next() async {
    widget.project.voiceId = _selected;

    if (_selected != null) {
      setState(() {
        _applying = true;
        _error = null;
        _percent = 0;
      });

      final poller = ProgressPoller(
        api: widget.api,
        onUpdate: (percent, stage, detail) {
          if (mounted) setState(() {
            _percent = percent;
            _stageDetail = detail;
          });
        },
      );
      poller.start();

      try {
        final result = await widget.api.applyVoice(
          audioFilename: widget.project.musicFilename!,
          voiceId: _selected!,
          // Trước đây KHÔNG gửi gpu_power (backend cũng không nhận) - slider
          // "Công suất sử dụng GPU" hoàn toàn không có tác dụng ở bước này.
          gpuPower: GenerationSettings.instance.gpuPower,
          pitchShift: _pitchShift,
          enableFormantShift: GenerationSettings.instance.enableFormantShift,
          formantQuefrencyMs: GenerationSettings.instance.formantQuefrencyMs,
          enableDeessing: GenerationSettings.instance.enableDeessing,
        );
        widget.project.voicedFilename = result['file'];
      } catch (e) {
        setState(() {
          _error = 'Lỗi đổi giọng: $e';
          _applying = false;
        });
        poller.stop();
        return;
      }
      poller.stop();
    }

    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StyleScreen(api: widget.api, project: widget.project),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bước 2: Chọn giọng hát')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Tuỳ chọn - có thể bỏ qua để giữ nguyên bản nhạc gốc.'),
                  if (widget.project.fromSample) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.withOpacity(0.3)),
                      ),
                      child: const Text(
                        'Hệ thống sẽ tự tách riêng giọng hát khỏi nhạc nền trước khi đổi '
                        'giọng, nên nhạc nền sẽ không bị ảnh hưởng. Nếu bản nhạc mẫu vốn '
                        'không có giọng hát, có thể chọn "Giữ nguyên" để bỏ qua bước này.',
                        style: TextStyle(fontSize: 12, color: Colors.blueGrey),
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  Expanded(
                    child: ListView(
                      children: [
                        RadioListTile<String?>(
                          title: const Text('Giữ nguyên (không đổi giọng)'),
                          value: null,
                          groupValue: _selected,
                          onChanged: (v) => setState(() => _selected = v),
                        ),
                        ..._voices.map((v) => RadioListTile<String?>(
                              title: Text(v),
                              value: v,
                              groupValue: _selected,
                              onChanged: (val) => setState(() => _selected = val),
                            )),
                        if (_selected != null) ...[
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Dịch tông giọng: ${_pitchShift > 0 ? '+' : ''}$_pitchShift '
                                    'bán cung', style: const TextStyle(fontSize: 13)),
                                const Text(
                                  'Để 0 nếu giọng mẫu vốn đã hát (đã có cao độ bài hát). '
                                  'Nếu là giọng NÓI thường (không hát), thử tăng/giảm rồi '
                                  'nghe thử để khớp tông bài hát hơn.',
                                  style: TextStyle(fontSize: 11, color: Colors.blueGrey),
                                ),
                                Slider(
                                  value: _pitchShift.toDouble(),
                                  min: -12,
                                  max: 12,
                                  divisions: 24,
                                  label: '$_pitchShift',
                                  onChanged: (v) => setState(() => _pitchShift = v.round()),
                                ),
                              ],
                            ),
                          ),
                        ],
                        const Divider(),
                        Card(
                          child: InkWell(
                            onTap: _uploading ? null : _uploadNewVoice,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _uploading
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.upload_file),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Upload giọng mới (.pth)'),
                                        SizedBox(height: 2),
                                        Text('Tự thêm giọng riêng, không cần tải tay lên Drive', style: TextStyle(fontSize: 12, color: Colors.grey)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Card(
                          child: InkWell(
                            onTap: _training ? null : _trainNewVoice,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _training
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.mic),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Tự train giọng từ file ghi âm'),
                                        SizedBox(height: 2),
                                        Text(
                                          'Chọn 1 file ghi âm giọng nói sạch, càng dài càng tốt - chạy nền trên Colab, mất từ vài chục phút',
                                          style: TextStyle(fontSize: 12, color: Colors.grey), // KHÔNG maxLines -> hiện đủ, không cắt như ListTile mặc định
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        if (_training) ...[
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LinearProgressIndicator(value: _trainPercent / 100),
                                const SizedBox(height: 4),
                                Text('$_trainPercent% — $_trainStageDetail', style: const TextStyle(fontSize: 12)),
                                const SizedBox(height: 4),
                                // MỚI - backend giờ đã hỗ trợ huỷ train giữa
                                // chừng qua /abort-job (trước đây không có
                                // cách nào huỷ, phải đợi chạy hết/tự lỗi).
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: TextButton.icon(
                                    onPressed: _cancellingTrain ? null : _cancelTraining,
                                    icon: const Icon(Icons.cancel_outlined, size: 16),
                                    label: Text(_cancellingTrain ? 'Đang huỷ...' : 'Huỷ train'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_error != null)
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  if (_applying) ...[
                    LinearProgressIndicator(value: _percent / 100),
                    const SizedBox(height: 6),
                    Text('$_percent% — $_stageDetail', style: const TextStyle(fontSize: 13)),
                  ],
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _applying ? null : _next,
                    child: const Text('Tiếp tục'),
                  ),
                ],
              ),
            ),
    );
  }
}
