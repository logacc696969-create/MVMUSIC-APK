import 'package:flutter/material.dart';

import '../api_service.dart';
import '../generation_settings.dart';
import '../l10n.dart';
import '../project_data.dart';
import '../muted_color.dart';

/// MỚI (mục 53, PDF-2 mục 4.3 - "Template sẵn: MV tình ca, MV rap, MV lo-fi - chọn 1 cái là xong"): thẻ chọn MẪU "MỘT CHẠM" theo THỂ LOẠI NHẠC.
/// Dữ liệu do backend gửi (`GET /mv-templates`, nguồn ở `mv_prompts.MV_TEMPLATES`) nên đổi/thêm mẫu không cần sửa app. Lỗi tải mẫu chỉ làm thẻ biến mất (tính năng PHỤ,
/// không được chặn màn nhập). Mỗi mẫu gộp: mô tả nhạc + phong cách hình ảnh + kiểu kịch bản - người dùng vẫn sửa từng thứ sau đó.
class MvTemplatePicker extends StatefulWidget {
  final ApiService api;
  final void Function(Map<String, dynamic> template) onPick;

  const MvTemplatePicker({super.key, required this.api, required this.onPick});

  @override
  State<MvTemplatePicker> createState() => _MvTemplatePickerState();
}

class _MvTemplatePickerState extends State<MvTemplatePicker> {
  List<Map<String, dynamic>> _templates = [];
  String? _picked;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await widget.api.getMvTemplates();
      if (!mounted) return;
      final list = r['templates'];
      if (r['status'] == 'ok' && list is List) {
        setState(() => _templates = list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
      }
    } catch (_) {
      // PHỤ: backend cũ chưa có /mv-templates hoặc mất mạng - không hiện thẻ, không báo lỗi.
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_templates.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Mẫu một chạm theo thể loại nhạc'), style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              tr('Chọn một mẫu để điền sẵn mô tả nhạc, phong cách hình ảnh và kiểu kịch bản. Bạn vẫn sửa được từng thứ sau đó.'),
              style: TextStyle(fontSize: 12, color: mutedGrey),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final t in _templates)
                  ChoiceChip(
                    label: Text((t['label'] ?? '').toString()),
                    selected: _picked == t['id'],
                    onSelected: (_) {
                      setState(() => _picked = t['id']?.toString());
                      widget.onPick(t);
                    },
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Áp phần DÙNG CHUNG của mẫu vào dự án: phong cách hình ảnh (`ProjectData.styleId` - StyleScreen chọn sẵn) và kiểu kịch bản (`GenerationSettings.genre` - StoryboardScreen
/// chọn sẵn). KHÔNG đụng cài đặt nào khác; giá trị rỗng/sai kiểu thì bỏ qua (giữ nguyên lựa chọn hiện có).
void applyMvTemplateToProject(ProjectData project, Map<String, dynamic> t) {
  final style = t['style_id'];
  if (style is String && style.isNotEmpty) project.styleId = style;
  final genre = t['video_genre'];
  if (genre is String && genre.isNotEmpty) GenerationSettings.instance.genre = genre;
}
