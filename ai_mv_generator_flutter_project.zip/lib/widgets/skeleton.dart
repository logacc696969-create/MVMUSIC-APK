import 'package:flutter/material.dart';

import '../l10n.dart';
/// MỚI (mục 23) - "khung xương" (skeleton) nhấp nháy nhẹ, thay cho vòng xoay
/// `CircularProgressIndicator` ở các màn tải DANH SÁCH: người dùng thấy ngay hình dạng nội
/// dung sắp hiện nên cảm giác nhanh hơn. Tự viết bằng `FadeTransition` (không thêm package
/// shimmer) để không thêm phụ thuộc có thể lỗi phiên bản lúc build.
class SkeletonBox extends StatefulWidget {
  final double? width;
  final double height;
  final double radius;

  const SkeletonBox({super.key, this.width, this.height = 16, this.radius = 8});

  @override
  State<SkeletonBox> createState() => _SkeletonBoxState();
}

class _SkeletonBoxState extends State<SkeletonBox> with SingleTickerProviderStateMixin {
  late final AnimationController _controller =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0.35, end: 0.85)
          .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut)),
      child: Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          color: Colors.grey.shade400,
          borderRadius: BorderRadius.circular(widget.radius),
        ),
      ),
    );
  }
}

/// Danh sách thẻ skeleton giả (ảnh nhỏ + 2 dòng chữ) - dùng làm trạng thái đang tải của danh
/// sách dự án. Có nhãn "Đang tải" cho trình đọc màn hình (TalkBack).
class SkeletonList extends StatelessWidget {
  final int count;

  const SkeletonList({super.key, this.count = 5});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: tr('Đang tải'),
      child: ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(12),
        itemCount: count,
        itemBuilder: (_, __) => const Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Row(
                children: [
                  SkeletonBox(width: 80, height: 48, radius: 8),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SkeletonBox(height: 14),
                        SizedBox(height: 8),
                        SkeletonBox(width: 140, height: 12),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
