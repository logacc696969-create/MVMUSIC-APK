import 'dart:math' as math;
import 'package:flutter/material.dart';

/// MỚI (mục 24) - đường cong mô phỏng LÒ XO GIẢM CHẤN (nảy nhẹ rồi ổn định), thay cho chuyển động tuyến
/// tính. Công thức: x(t) = 1 - e^(-decay*t) * cos(2π * cycles * t). x(0)=0; vượt qua 1 một chút (nảy) rồi
/// hội tụ về 1. Flutter tự trả đúng 0.0 và 1.0 ở hai đầu (Curve.transform) nên không bị lệch cuối.
class SpringCurve extends Curve {
  /// `decay` càng LỚN càng tắt nhanh (ít nảy); `cycles` là số chu kỳ dao động trong cả chuyển động.
  const SpringCurve({this.decay = 6.0, this.cycles = 1.5});

  final double decay;
  final double cycles;

  @override
  double transformInternal(double t) {
    return 1.0 - math.exp(-decay * t) * math.cos(2.0 * math.pi * cycles * t);
  }
}

/// Hiện `child` với hiệu ứng mờ dần + phóng nhẹ theo lò xo (dùng cho biểu tượng "hoàn tất", trang giới
/// thiệu). Chỉ chạy 1 lần khi widget được dựng. Độ mờ được kẹp trong [0,1] vì lò xo có thể vượt 1.
/// Tôn trọng cài đặt "bỏ hiệu ứng chuyển động" của hệ thống (MediaQuery.disableAnimations).
class SpringIn extends StatelessWidget {
  const SpringIn({super.key, required this.child, this.duration = const Duration(milliseconds: 650)});

  final Widget child;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return child;
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: duration,
      curve: const SpringCurve(),
      builder: (context, v, c) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.scale(scale: 0.8 + 0.2 * v, child: c),
      ),
      child: child,
    );
  }
}
