import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/crash_sync.dart';

// MỚI (mục 56) - kiểm thử các hàm THUẦN của CrashSync. CHƯA chạy (không có Dart SDK ở môi trường viết code);
// `build.yml` chạy `flutter test` ở chế độ KHÔNG chặn build nên nếu sai sẽ hiện dòng đỏ ở log.
void main() {
  test('fnv1a: đúng vectơ chuẩn FNV-1a 32 bit', () {
    expect(CrashSync.fnv1a(''), 0x811C9DC5);
    expect(CrashSync.fnv1a('a'), 0xE40C292C);
    expect(CrashSync.fnv1a('foobar'), 0xBF9CF968);
  });

  test('signature: đổi nội dung thì đổi chữ ký; cùng nội dung thì cùng chữ ký', () {
    expect(CrashSync.signature('abc'), CrashSync.signature('abc'));
    expect(CrashSync.signature('abc') == CrashSync.signature('abd'), false);
    expect(CrashSync.signature('abc').startsWith('3:'), true);
  });

  test('shouldUpload: tắt / rỗng / chưa có gì mới / vừa thử xong -> không gửi; có nội dung mới -> gửi', () {
    final now = DateTime(2026, 11, 8, 12, 0, 0);
    const log = '[t] Uncaught: boom\nstack\n---\n';
    bool ask({bool enabled = true, String text = log, String? last, DateTime? lastTry}) =>
        CrashSync.shouldUpload(enabled: enabled, log: text, lastSignature: last, now: now, lastTry: lastTry);

    expect(ask(enabled: false), false);
    expect(ask(text: ''), false);
    expect(ask(text: '  \n'), false);
    expect(ask(last: CrashSync.signature(log)), false);
    expect(ask(lastTry: now.subtract(const Duration(minutes: 1))), false);
    expect(ask(), true);
    expect(ask(last: CrashSync.signature('cũ')), true);
    expect(ask(lastTry: now.subtract(const Duration(minutes: 6))), true);
  });

  test('tail: giữ phần CUỐI khi quá dài, giữ nguyên khi vừa', () {
    expect(CrashSync.tail('abcdef', max: 3), 'def');
    expect(CrashSync.tail('abc', max: 3), 'abc');
    expect(CrashSync.tail('', max: 3), '');
  });

  // ---- MỚI (mục 60) ----
  test('deviceDescription: chỉ thêm engine khi là mã 40 ký tự hex', () {
    const rev = '0123456789abcdef0123456789abcdef01234567';
    expect(CrashSync.deviceDescription('android', '5.10', '3.9.0', rev), 'android 5.10 | dart 3.9.0 | engine $rev');
    expect(CrashSync.deviceDescription('android', '5.10', '3.9.0', ''), 'android 5.10 | dart 3.9.0');
    expect(CrashSync.deviceDescription('android', '5.10', '3.9.0', 'khong-phai-ma'), 'android 5.10 | dart 3.9.0');
    expect(CrashSync.deviceDescription('android', '5.10', '3.9.0', rev.toUpperCase()), 'android 5.10 | dart 3.9.0');
  });
}
