import 'dart:convert';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/error_reporter.dart';
import 'package:ai_mv_generator/generation_settings.dart';
import 'package:ai_mv_generator/l10n.dart';

// MỚI (mục 27) - CHƯA từng chạy (không có Dart SDK ở môi trường viết code).
void main() {
  test('parseDsn đọc DSN chuẩn và dựng URL envelope đúng tài liệu Sentry', () {
    final d = ErrorReporter.parseDsn('https://examplePublicKey@o0.ingest.sentry.io/4506');
    expect(d, isNotNull);
    expect(d!.publicKey, 'examplePublicKey');
    expect(d.projectId, '4506');
    expect(d.envelopeUrl, 'https://o0.ingest.sentry.io/api/4506/envelope/');
    expect(d.authHeader, contains('sentry_key=examplePublicKey'));
    expect(d.authHeader, contains('sentry_version=7'));
  });

  test('parseDsn: cổng, tiền tố đường dẫn, khoá có secret cũ; DSN sai -> null', () {
    expect(ErrorReporter.parseDsn('http://k@localhost:9000/7')!.envelopeUrl, 'http://localhost:9000/api/7/envelope/');
    expect(ErrorReporter.parseDsn('https://k@host.example/prefix/12')!.envelopeUrl, 'https://host.example/prefix/api/12/envelope/');
    expect(ErrorReporter.parseDsn('https://k:oldsecret@host/3')!.publicKey, 'k');
    expect(ErrorReporter.parseDsn(''), isNull);
    expect(ErrorReporter.parseDsn('khong phai dsn'), isNull);
    expect(ErrorReporter.parseDsn('https://host/3'), isNull); // thiếu khoá
    expect(ErrorReporter.parseDsn('https://k@host'), isNull); // thiếu project id
    expect(ErrorReporter.parseDsn('ftp://k@host/3'), isNull);
  });

  test('buildEnvelope gồm 3 dòng JSON hợp lệ theo định dạng envelope', () {
    final id = ErrorReporter.newEventId(Random(1));
    expect(id.length, 32);
    final body = ErrorReporter.buildEnvelope(
        eventId: id, now: DateTime.utc(2026, 10, 16, 1, 2, 3), kind: 'FlutterError', message: 'lỗi thử', stack: 'dòng1\ndòng2');
    final lines = body.split('\n');
    expect(jsonDecode(lines[0])['event_id'], id);
    expect(jsonDecode(lines[1])['type'], 'event');
    final event = jsonDecode(lines.sublist(2).join('\n')) as Map<String, dynamic>;
    expect(event['level'], 'error');
    expect(event['message']['formatted'], 'FlutterError: lỗi thử');
    expect(event['event_id'], id);
  });

  test('allowSend chặn bão lỗi: cách nhau >=5s, cùng thông điệp không lặp trong 5 phút', () {
    final t0 = DateTime(2026, 10, 16, 12);
    expect(ErrorReporter.allowSend('a-moi', t0), true);
  });

  test('tr(): mặc định giữ tiếng Việt; "en" dịch chuỗi có trong từ điển, chuỗi lạ giữ nguyên', () {
    final s = GenerationSettings.instance;
    final old = s.language;
    s.language = 'vi';
    expect(tr('Tạo dự án mới'), 'Tạo dự án mới');
    s.language = 'en';
    expect(tr('Tạo dự án mới'), 'Create new project');
    expect(tr('Chuỗi chưa có trong từ điển'), 'Chuỗi chưa có trong từ điển');
    expect(tr('Có {n} dự án đang tạo dở').replaceAll('{n}', '3'), '3 project(s) in progress');
    s.language = old;
  });

  test('themeMode chỉ nhận light/dark/system, giá trị lạ về light, và lưu/nạp qua JSON', () {
    final s = GenerationSettings.instance;
    final old = s.themeMode;
    s.themeMode = 'dark';
    expect(GenerationSettings.themeModeNotifier.value, 'dark');
    s.themeMode = 'neon';
    expect(s.themeMode, 'light');
    s.applyJson(<String, dynamic>{'themeMode': 'system'});
    expect(s.themeMode, 'system');
    s.applyJson(<String, dynamic>{'themeMode': 'neon'});
    expect(s.themeMode, 'system');
    expect(s.toJson()['themeMode'], 'system');
    s.themeMode = old;
  });

  test('highContrast (mục 54): mặc định tắt, notifier đồng bộ, lưu/nạp qua JSON, giá trị sai kiểu bị bỏ qua', () {
    final s = GenerationSettings.instance;
    final old = s.highContrast;
    s.highContrast = false;
    expect(GenerationSettings.highContrastNotifier.value, false);
    s.highContrast = true;
    expect(GenerationSettings.highContrastNotifier.value, true);
    expect(s.toJson()['highContrast'], true);
    s.applyJson(<String, dynamic>{'highContrast': 'yes'}); // sai kiểu -> giữ nguyên
    expect(s.highContrast, true);
    s.applyJson(<String, dynamic>{'highContrast': false});
    expect(s.highContrast, false);
    s.highContrast = old;
  });

  test('applyJson: language chỉ nhận vi/en', () {
    final s = GenerationSettings.instance;
    final old = s.language;
    s.applyJson(<String, dynamic>{'language': 'en'});
    expect(s.language, 'en');
    s.applyJson(<String, dynamic>{'language': 'klingon'});
    expect(s.language, 'en');
    s.language = old;
  });
}
