import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/eta_format.dart';

// MỚI (mục 26) - CHƯA từng được chạy (không có Dart SDK ở môi trường viết code; xem project_history_test.dart).
void main() {
  test('formatDuration: giây / phút / giờ', () {
    expect(formatDuration(0), '0 giây');
    expect(formatDuration(45), '45 giây');
    expect(formatDuration(89), '89 giây');
    expect(formatDuration(90), '2 phút');
    expect(formatDuration(600), '10 phút');
    // mục 46: kỳ vọng cũ `5399 -> '90 phút'` MÂU THUẪN với chính formatDuration (test này chưa từng chạy nên không ai thấy): 5399/60 = 89.98 ->
    // round() = 90, mà nhánh phút chỉ nhận `minutes < 90` nên 5399 s rẽ sang nhánh giờ -> '1 giờ 30 phút' (giống 5400 s - nhất quán hơn kỳ vọng cũ).
    // Phút cuối cùng còn ở nhánh phút là 5369 s (89.48 -> 89).
    expect(formatDuration(5369), '89 phút');
    expect(formatDuration(5399), '1 giờ 30 phút');
    expect(formatDuration(5400), '1 giờ 30 phút');
    expect(formatDuration(7200), '2 giờ');
    expect(formatDuration(7170), '2 giờ'); // 119.5 phút -> phần phút làm tròn thành 60 -> nhánh `m == 60`
    expect(formatDuration(-5), '0 giây');
  });
}
