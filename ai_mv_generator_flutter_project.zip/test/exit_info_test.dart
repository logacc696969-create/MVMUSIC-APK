import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/exit_info.dart';

// MỚI (mục 57) - kiểm thử các hàm THUẦN của ExitInfoReporter. CHƯA chạy (không có Dart SDK ở môi trường viết code);
// `build.yml` chạy `flutter test` ở chế độ KHÔNG chặn build nên nếu sai sẽ hiện dòng đỏ ở log.
void main() {
  Map<String, dynamic> e(String reason, int ts, {int importance = 100, String desc = ''}) =>
      {'reason': reason, 'timestamp': ts, 'importance': importance, 'status': 0, 'description': desc, 'processName': 'p', 'rss': 1};

  test('isNoteworthy: sự cố chắc chắn luôn ghi; bị giết chỉ ghi khi đang làm việc; còn lại bỏ', () {
    for (final r in ['CRASH', 'CRASH_NATIVE', 'ANR', 'INITIALIZATION_FAILURE', 'EXCESSIVE_RESOURCE_USAGE']) {
      expect(ExitInfoReporter.isNoteworthy(r, 400), true); // kể cả nằm trong bộ nhớ đệm
    }
    for (final r in ['SIGNALED', 'LOW_MEMORY']) {
      expect(ExitInfoReporter.isNoteworthy(r, 100), true); // tiền cảnh
      expect(ExitInfoReporter.isNoteworthy(r, 300), true); // dịch vụ
      expect(ExitInfoReporter.isNoteworthy(r, 400), false); // bộ nhớ đệm: chuyện thường ngày
      expect(ExitInfoReporter.isNoteworthy(r, 0), false); // không rõ mức
    }
    for (final r in ['EXIT_SELF', 'USER_REQUESTED', 'USER_STOPPED', 'PERMISSION_CHANGE', 'OTHER', 'UNKNOWN', 'REASON_99', '']) {
      expect(ExitInfoReporter.isNoteworthy(r, 100), false);
    }
  });

  test('selectNew: chỉ mục MỚI hơn mốc và đáng ghi, mới nhất trước, tối đa max', () {
    final raw = [
      e('CRASH', 100),
      e('USER_REQUESTED', 500),
      e('ANR', 300),
      e('LOW_MEMORY', 400, importance: 400),
      e('CRASH_NATIVE', 200),
      e('SIGNALED', 600, importance: 125),
    ];
    final out = ExitInfoReporter.selectNew(raw, 150);
    expect(out.map((x) => x['timestamp']).toList(), [600, 300, 200]);
    expect(ExitInfoReporter.selectNew(raw, 1000), isEmpty);
    expect(ExitInfoReporter.selectNew(raw, 0, max: 2).length, 2);
    expect(ExitInfoReporter.selectNew([], 0), isEmpty);
  });

  test('format: có đủ reason/status/importance/process/rss/at/desc và cắt mô tả quá dài', () {
    final line = ExitInfoReporter.format(e('CRASH_NATIVE', 1700000000000, desc: 'x' * 500));
    expect(line.contains('reason=CRASH_NATIVE'), true);
    expect(line.contains('importance=100'), true);
    expect(line.contains('process=p'), true);
    expect(line.contains('at=2023-'), true);
    expect(line.length < 500, true);
    expect(ExitInfoReporter.format({}).contains('at=?'), true); // thiếu dữ liệu không làm ném lỗi
  });

  // ---- MỚI (mục 58) ----
  test('format: ANR kèm thread dump (cắt ở maxAnrChars); không ANR thì 1 dòng', () {
    final plain = ExitInfoReporter.format(e('CRASH', 1700000000000));
    expect(plain.contains('\n'), false);
    final anr = ExitInfoReporter.format({...e('ANR', 1700000000000), 'traceText': 'x' * 10000});
    expect(anr.contains('--- ANR thread dump ---'), true);
    expect(anr.length < 7000, true);
  });

  test('tombstoneLine: chỉ khi có traceB64; backend nhận ra "b64="', () {
    expect(ExitInfoReporter.tombstoneLine(e('CRASH_NATIVE', 5)), '');
    final line = ExitInfoReporter.tombstoneLine({...e('CRASH_NATIVE', 5), 'traceB64': 'QUJDREVGR0g='});
    expect(line, 'ts=5 bytes=9 b64=QUJDREVGR0g=');
    expect(line.contains(' b64='), true);
  });

  test('hasExitInfoApi: chỉ Android 11+ (API 30); không rõ phiên bản -> false (dùng cách dự phòng)', () {
    expect(ExitInfoReporter.hasExitInfoApi(null), false);
    expect(ExitInfoReporter.hasExitInfoApi(29), false);
    expect(ExitInfoReporter.hasExitInfoApi(30), true);
    expect(ExitInfoReporter.hasExitInfoApi(34), true);
  });

  // ---- MỚI (mục 60) ----
  test('xcrashKind: nhận ra loại tombstone xCrash theo đuôi tên file', () {
    expect(ExitInfoReporter.xcrashKind('tombstone_00001700000000__1.0__com.example.app.native.xcrash'), 'native');
    expect(ExitInfoReporter.xcrashKind('tombstone_1__1.0__com.example.app.anr.xcrash'), 'anr');
    expect(ExitInfoReporter.xcrashKind('tombstone_1__1.0__com.example.app.java.xcrash'), 'java');
    expect(ExitInfoReporter.xcrashKind('tombstone_1__1.0__x.xcrash'), 'other');
    expect(ExitInfoReporter.xcrashKind(''), 'other');
  });
}
