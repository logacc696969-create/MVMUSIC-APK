import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/foreground_marker.dart';

// MỚI (mục 58) - kiểm thử các hàm THUẦN của ForegroundMarker. CHƯA chạy (không có Dart SDK ở môi trường viết code);
// `build.yml` chạy `flutter test` ở chế độ KHÔNG chặn build nên nếu sai sẽ hiện dòng đỏ ở log.
void main() {
  test('encode/diedInForeground/timestampOf: vòng khứ hồi', () {
    expect(ForegroundMarker.encode(true, 123), 'fg:123');
    expect(ForegroundMarker.encode(false, 456), 'bg:456');
    expect(ForegroundMarker.diedInForeground('fg:123'), true);
    expect(ForegroundMarker.diedInForeground('bg:456'), false);
    expect(ForegroundMarker.diedInForeground(null), false);
    expect(ForegroundMarker.diedInForeground(''), false);
    expect(ForegroundMarker.timestampOf('fg:123'), 123);
    expect(ForegroundMarker.timestampOf('bg:'), 0);
    expect(ForegroundMarker.timestampOf('rác'), 0);
    expect(ForegroundMarker.timestampOf(null), 0);
  });

  test('describe: có lý do DIED_IN_FOREGROUND và nói rõ không biết nguyên nhân', () {
    final line = ForegroundMarker.describe('fg:1700000000000');
    expect(line.contains('reason=DIED_IN_FOREGROUND'), true);
    expect(line.contains('cause unknown'), true);
    expect(line.contains('last_seen=2023-'), true);
    expect(ForegroundMarker.describe('fg:abc').contains('last_seen=?'), true);
  });

  // ---- MỚI (mục 59) ----
  test('classifyPrevious: none / updated / rebooted / died', () {
    const seen = 1000000;
    final fg = ForegroundMarker.encode(true, seen);
    expect(ForegroundMarker.classifyPrevious(null), 'none');
    expect(ForegroundMarker.classifyPrevious(ForegroundMarker.encode(false, seen)), 'none');
    expect(ForegroundMarker.classifyPrevious(fg), 'died'); // không biết giờ cập nhật/khởi động -> không loại trừ được
    expect(ForegroundMarker.classifyPrevious(fg, lastUpdateMs: seen + 5000), 'updated');
    expect(ForegroundMarker.classifyPrevious(fg, lastUpdateMs: seen - 5000), 'died');
    expect(ForegroundMarker.classifyPrevious(fg, bootMs: seen + 120000), 'rebooted');
    expect(ForegroundMarker.classifyPrevious(fg, bootMs: seen + 30000), 'died'); // trong dung sai 60 giây
    expect(ForegroundMarker.classifyPrevious(fg, bootMs: seen - 100000), 'died'); // máy khởi động TRƯỚC lần thấy cuối
    // cả hai: cập nhật được xét trước
    expect(ForegroundMarker.classifyPrevious(fg, lastUpdateMs: seen + 1, bootMs: seen + 500000), 'updated');
  });
}
