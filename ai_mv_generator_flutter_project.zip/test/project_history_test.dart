import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/project_history.dart';

// MỚI (mục 23) - test đầu tiên của phía Flutter. CHƯA từng được chạy (môi trường viết code không
// có Dart SDK) - bước `flutter test` trong build.yml chạy ở chế độ KHÔNG chặn build; nếu test lỗi
// vì sai API, sửa test chứ không phải nghi ngờ app ngay.
void main() {
  test('toJson -> fromJson giữ nguyên các trường quan trọng', () {
    final now = DateTime.utc(2026, 10, 11, 12, 0, 0);
    final e = ProjectHistoryEntry(
      id: 'abc',
      createdAt: now,
      updatedAt: now,
      status: 'completed',
      fromSample: true,
      musicFilename: 'm.mp3',
      styleId: 'cinematic',
      lyrics: 'lời bài hát',
      estimatedSceneCount: 6,
      scenePrompts: ['cảnh 1', 'cảnh 2'],
      mvSceneDirId: 'job1',
      mvFilename: 'mv_1.mp4',
      mvLocalPath: '/x/mv.mp4',
      thumbnailImagePath: '/x/t.jpg',
      mvVerticalLocalPath: '/x/v.mp4',
      lyricsTimestampsPath: '/x/l.json',
      downloadedSceneFiles: ['/x/s0.mp4'],
    );
    final back = ProjectHistoryEntry.fromJson(e.toJson());
    expect(back.id, 'abc');
    expect(back.createdAt, now);
    expect(back.fromSample, true);
    expect(back.estimatedSceneCount, 6);
    expect(back.scenePrompts, ['cảnh 1', 'cảnh 2']);
    expect(back.mvSceneDirId, 'job1');
    expect(back.thumbnailImagePath, '/x/t.jpg');
    expect(back.mvVerticalLocalPath, '/x/v.mp4');
    expect(back.lyricsTimestampsPath, '/x/l.json');
    expect(back.downloadedSceneFiles, ['/x/s0.mp4']);
  });

  test('bản ghi CŨ thiếu trường vẫn đọc được với giá trị mặc định an toàn', () {
    final e = ProjectHistoryEntry.fromJson({
      'createdAt': '2026-01-01T00:00:00.000Z',
      'mvFilename': 'old.mp4',
    });
    expect(e.status, 'completed');
    expect(e.lyrics, '');
    expect(e.downloadedSceneFiles, isEmpty);
    expect(e.thumbnailImagePath, isNull);
    expect(e.mvVerticalLocalPath, isNull);
  });
}
