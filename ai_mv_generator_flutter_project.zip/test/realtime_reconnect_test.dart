import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/realtime_client.dart';

// MỚI (mục 55) - kiểm thử hàm THUẦN `reconnectDelay` (lùi cấp số nhân + nhiễu). CHƯA chạy (không có Dart SDK ở môi trường viết code);
// `build.yml` chạy `flutter test` ở chế độ KHÔNG chặn build nên nếu sai sẽ hiện dòng đỏ ở log.
void main() {
  test('reconnectDelay: lùi theo cấp số nhân 2,4,8,16,32 rồi trần 60 giây (jitter giữa = không lệch)', () {
    expect(reconnectDelay(0, 0.5), const Duration(seconds: 2));
    expect(reconnectDelay(1, 0.5), const Duration(seconds: 4));
    expect(reconnectDelay(2, 0.5), const Duration(seconds: 8));
    expect(reconnectDelay(3, 0.5), const Duration(seconds: 16));
    expect(reconnectDelay(4, 0.5), const Duration(seconds: 32));
    expect(reconnectDelay(5, 0.5), const Duration(seconds: 60));
    expect(reconnectDelay(9, 0.5), const Duration(seconds: 60));
  });

  test('reconnectDelay: nhiễu nằm trong 0.75x .. 1.25x và không bao giờ vượt 75 giây', () {
    expect(reconnectDelay(0, 0.0), const Duration(milliseconds: 1500));
    expect(reconnectDelay(0, 1.0), const Duration(milliseconds: 2500));
    expect(reconnectDelay(5, 0.0), const Duration(milliseconds: 45000));
    expect(reconnectDelay(5, 1.0), const Duration(milliseconds: 75000));
    for (var a = 0; a < 40; a++) {
      for (final j in [0.0, 0.25, 0.5, 0.75, 1.0]) {
        final d = reconnectDelay(a, j);
        expect(d.inMilliseconds >= 1500, true);
        expect(d.inMilliseconds <= 75000, true);
      }
    }
  });

  test('reconnectDelay: đầu vào ngoài khoảng bị kẹp, không ném lỗi; không giảm khi tăng số lần thử', () {
    expect(reconnectDelay(-5, 0.5), const Duration(seconds: 2));
    expect(reconnectDelay(1000, 0.5), const Duration(seconds: 60));
    expect(reconnectDelay(0, -3.0), reconnectDelay(0, 0.0));
    expect(reconnectDelay(0, 9.0), reconnectDelay(0, 1.0));
    var prev = Duration.zero;
    for (var a = 0; a < 15; a++) {
      final d = reconnectDelay(a, 0.5);
      expect(d >= prev, true);
      prev = d;
    }
  });

  test('kMaxReconnectAttempts = 10 (cùng mức rxws; sau đó app vẫn polling bình thường)', () {
    expect(kMaxReconnectAttempts, 10);
  });
}
