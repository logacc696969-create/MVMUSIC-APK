import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/generation_settings.dart';
import 'package:ai_mv_generator/project_data.dart';

// MỚI (mục 23) - CHƯA từng được chạy (xem ghi chú ở project_history_test.dart).
void main() {
  test('tuỳ chọn mới của mục 23 mặc định TẮT (không đổi hành vi cũ)', () {
    final s = GenerationSettings.instance;
    expect(s.burnInLyrics, '');
    expect(s.structureSnap, false);
    expect(s.watermarkText, '');
    expect(s.exportVertical, false);
  });

  test('tuỳ chọn mới của mục 26 mặc định TẮT (không đổi hành vi cũ)', () {
    final s = GenerationSettings.instance;
    expect(s.fxMotionBlur, false);
    expect(s.fxLightLeak, false);
    expect(s.fxBloom, false);
    expect(s.exportPreset, '');
    expect(s.upscaleFaceMode, 'skip');
    expect(s.settingDesc, '');
  });

  test('ProjectData: cảnh tự quay mặc định rỗng và độc lập giữa các dự án', () {
    final a = ProjectData();
    final b = ProjectData();
    a.userClips[2] = 'x.mp4';
    expect(a.userClips.length, 1);
    expect(b.userClips, isEmpty);
    expect(b.userClipLabels, isEmpty);
  });

  test('ProjectData: cờ tạo lại cảnh và camera mặc định rỗng', () {
    final p = ProjectData();
    expect(p.redoScenes, '');
    expect(p.redoFollowing, false);
    expect(p.sceneCameras, isNull);
  });
}
