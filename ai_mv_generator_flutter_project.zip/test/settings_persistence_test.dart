import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/generation_settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

// MỚI (mục 27) - CHƯA từng được chạy (không có Dart SDK ở môi trường viết code; xem ghi chú ở project_history_test.dart).
// Mỗi test tự khôi phục giá trị mặc định ở cuối vì GenerationSettings là singleton dùng chung giữa các test.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  textScaleTests();

  test('toJson KHÔNG chứa hmacSecret kể cả khi bật ghi nhớ khoá (khoá lưu ở khoá prefs riêng)', () {
    final s = GenerationSettings.instance;
    final oldSecret = s.hmacSecret;
    final oldRemember = s.rememberHmac;
    s.hmacSecret = 'bi-mat';
    s.rememberHmac = true;
    expect(s.toJson().containsKey('hmacSecret'), false);
    expect(s.toJson().containsKey('rememberHmac'), false);
    expect(jsonEncode(s.toJson()).contains('bi-mat'), false);
    s.hmacSecret = oldSecret;
    s.rememberHmac = oldRemember;
  });

  test('toJson không chứa khoá bí mật hmacSecret', () {
    final s = GenerationSettings.instance;
    final old = s.hmacSecret;
    s.hmacSecret = 'bi-mat';
    expect(s.toJson().containsKey('hmacSecret'), false);
    s.hmacSecret = old;
  });

  test('applyJson: nhận giá trị hợp lệ, kẹp giá trị ngoài khoảng, bỏ giá trị sai kiểu/lạ', () {
    final s = GenerationSettings.instance;
    final before = s.toJson();
    s.applyJson(<String, dynamic>{
      'gpuPower': 5, // dưới 20 -> kẹp lên 20
      'maxScenes': 500, // trên 64 -> kẹp xuống 64
      'duration': 'abc', // sai kiểu -> giữ nguyên
      'enableLipsync': 'true', // sai kiểu -> giữ nguyên
      'postFxIntensity': 'strong',
      'exportPreset': 'khong_ton_tai', // ngoài danh sách -> giữ nguyên
      'videoBackend': 'wan22',
      'khoa_la': 123, // khoá lạ -> bỏ qua
    });
    expect(s.gpuPower, 20);
    expect(s.maxScenes, 64);
    expect(s.duration, before['duration']);
    expect(s.enableLipsync, before['enableLipsync']);
    expect(s.postFxIntensity, 'strong');
    expect(s.exportPreset, before['exportPreset']);
    expect(s.videoBackend, 'wan22');
    s.applyJson(before);
  });

  test('mục 30: quickMode/expertMode/controlVideoFilename đi qua toJson và applyJson (CHƯA từng chạy)', () {
    final s = GenerationSettings.instance;
    final before = s.toJson();
    s.quickMode = true;
    s.expertMode = true;
    s.controlVideoFilename = 'control_abc_ref.mp4';
    s.controlVideoLabel = 'ref.mp4';
    final saved = s.toJson();
    expect(saved['quickMode'], true);
    expect(saved['expertMode'], true);
    expect(saved['controlVideoFilename'], 'control_abc_ref.mp4');
    s.applyJson(before);
    expect(s.quickMode, before['quickMode']);
    expect(s.expertMode, before['expertMode']);
    expect(s.controlVideoFilename, before['controlVideoFilename']);
    s.applyJson(saved);
    expect(s.quickMode, true);
    expect(s.expertMode, true);
    expect(s.controlVideoFilename, 'control_abc_ref.mp4');
    expect(s.controlVideoLabel, 'ref.mp4');
    s.applyJson(before);
  });

  test('mục 31: loraSelection/comfyWorkflow đi qua toJson và applyJson; lorasJson đúng định dạng (CHƯA từng chạy)', () {
    final s = GenerationSettings.instance;
    final before = s.toJson();
    expect(s.lorasJson, '');
    s.loraSelection = <String, double>{'girl.safetensors': 0.8, 'film.safetensors': 1.25};
    s.comfyWorkflow = 'ltx_q4';
    final saved = s.toJson();
    expect(saved['loraSelection'], {'girl.safetensors': 0.8, 'film.safetensors': 1.25});
    expect(saved['comfyWorkflow'], 'ltx_q4');
    final decoded = jsonDecode(s.lorasJson) as List;
    expect(decoded.length, 2);
    expect((decoded.first as Map)['file'], 'girl.safetensors');
    expect((decoded.first as Map)['weight'], 0.8);
    s.applyJson(before);
    expect(s.loraSelection.isEmpty, true);
    expect(s.comfyWorkflow, before['comfyWorkflow']);
    s.applyJson(saved);
    expect(s.loraSelection['film.safetensors'], 1.25);
    expect(s.comfyWorkflow, 'ltx_q4');
    // dữ liệu rác (từ cài đặt dán của người khác) không làm hỏng: khoá/giá trị sai kiểu bị bỏ qua
    s.applyJson(<String, dynamic>{'loraSelection': <String, dynamic>{'ok.safetensors': 0.5, 'bad.safetensors': 'x', '7': 1}});
    expect(s.loraSelection.keys.toList(), ['ok.safetensors', '7']);
    s.applyJson(before);
  });

  test('applyJson: khoá null đặt lại các trường String? về null', () {
    final s = GenerationSettings.instance;
    final before = s.toJson();
    s.videoBackend = 'wan22';
    s.applyJson(<String, dynamic>{'videoBackend': null});
    expect(s.videoBackend, isNull);
    s.applyJson(before);
  });

  test('save rồi load khôi phục đúng cài đặt', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final s = GenerationSettings.instance;
    final before = s.toJson();
    s.gpuPower = 40;
    s.fxBloom = true;
    s.settingDesc = 'quán cà phê ban đêm';
    await s.save();
    s.gpuPower = 90;
    s.fxBloom = false;
    s.settingDesc = '';
    await s.load();
    expect(s.gpuPower, 40);
    expect(s.fxBloom, true);
    expect(s.settingDesc, 'quán cà phê ban đêm');
    s.applyJson(before);
  });

  test('load với dữ liệu hỏng không ném lỗi và không đổi cài đặt', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{GenerationSettings.prefsKey: '{không phải json'});
    final s = GenerationSettings.instance;
    final before = s.toJson();
    await s.load();
    expect(s.toJson(), before);
  });
}

// MỚI (mục 27) - cỡ chữ tuỳ chỉnh: kẹp 0.85-1.4 và được lưu/nạp như các cài đặt khác. CHƯA chạy.
void textScaleTests() {
  test('textScale kẹp khoảng 0.85-1.4 và phát ra qua notifier', () {
    final s = GenerationSettings.instance;
    final before = s.textScale;
    s.textScale = 3.0;
    expect(s.textScale, 1.4);
    expect(GenerationSettings.textScaleNotifier.value, 1.4);
    s.textScale = 0.1;
    expect(s.textScale, 0.85);
    s.textScale = before;
  });

  test('applyJson nạp textScale hợp lệ, bỏ giá trị sai kiểu', () {
    final s = GenerationSettings.instance;
    final before = s.textScale;
    s.applyJson(<String, dynamic>{'textScale': 1.2});
    expect(s.textScale, 1.2);
    s.applyJson(<String, dynamic>{'textScale': 'lớn'});
    expect(s.textScale, 1.2);
    s.textScale = before;
  });

  // MỚI (mục 49) - CHƯA từng chạy (không có Dart SDK ở môi trường viết code). Kiểm tĩnh tương ứng: kiem_thu/test_mv_v41.py + test_mv_v39.py.
  test('colorLook: mặc định tắt, chỉ nhận danh sách cho phép, sai kiểu thì bỏ qua (không ném lỗi)', () {
    final s = GenerationSettings.instance;
    final before = s.colorLook;
    s.colorLook = '';
    expect(s.colorLook, '');
    s.applyJson(<String, dynamic>{'colorLook': 'warm'});
    expect(s.colorLook, 'warm');
    expect(s.toJson()['colorLook'], 'warm');
    s.applyJson(<String, dynamic>{'colorLook': 'neon'}); // không nằm trong danh sách -> giữ nguyên
    expect(s.colorLook, 'warm');
    s.applyJson(<String, dynamic>{'colorLook': 42}); // sai kiểu -> giữ nguyên, KHÔNG ném lỗi
    expect(s.colorLook, 'warm');
    s.applyJson(<String, dynamic>{'colorLook': 'faded_film'});
    expect(s.colorLook, 'faded_film');
    s.colorLook = before;
  });
}
