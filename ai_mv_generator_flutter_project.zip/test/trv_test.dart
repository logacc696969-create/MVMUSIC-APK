import 'package:flutter_test/flutter_test.dart';
import 'package:ai_mv_generator/generation_settings.dart';
import 'package:ai_mv_generator/l10n.dart';

// MỚI (mục 46) - CHƯA từng chạy (không có Dart SDK ở môi trường viết code). Phần kiểm TĨNH tương ứng nằm ở kiem_thu/test_mv_v38.py.
void main() {
  test('trv: thay {0},{1} theo vị trí; tiếng Việt giữ nguyên mẫu, tiếng Anh dùng từ điển', () {
    final s = GenerationSettings.instance;
    final old = s.language;
    s.language = 'vi';
    expect(trv('Sửa lời thất bại: {0}', ['mạng lỗi']), 'Sửa lời thất bại: mạng lỗi');
    expect(trv('Video sẽ gồm khoảng {0} cảnh, nhịp ~{1} BPM.', [12, '120']), 'Video sẽ gồm khoảng 12 cảnh, nhịp ~120 BPM.');
    s.language = 'en';
    expect(trv('Sửa lời thất bại: {0}', ['network']), 'Editing the lyrics failed: network');
    expect(trv('Video sẽ gồm khoảng {0} cảnh, nhịp ~{1} BPM.', [12, '120']), 'The video will have about 12 scenes at ~120 BPM.');
    s.language = old;
  });

  test('trv: thay MỘT lượt - giá trị chứa {1} không bị thay lại; thiếu đối số thì giữ chỗ giữ; null in ra "null"', () {
    final s = GenerationSettings.instance;
    final old = s.language;
    s.language = 'vi';
    expect(trv('A {0} B {1}', ['{1}', 'đúng']), 'A {1} B đúng');
    expect(trv('x {0} {2}', ['a']), 'x a {2}');
    expect(trv('v {0}', [null]), 'v null');
    s.language = old;
  });

  test('trv: mẫu lạ (không có trong từ điển) ở chế độ en vẫn thay đúng chỗ giữ', () {
    final s = GenerationSettings.instance;
    final old = s.language;
    s.language = 'en';
    expect(trv('Mẫu chưa có trong từ điển {0}', [5]), 'Mẫu chưa có trong từ điển 5');
    s.language = old;
  });
}
