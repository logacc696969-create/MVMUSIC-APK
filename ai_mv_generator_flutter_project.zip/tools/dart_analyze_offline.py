#!/usr/bin/env python3
"""
dart_analyze_offline.py  (mục 69) - PHÂN TÍCH KIỂU DART THẬT khi không có Flutter SDK chính thức / pub.dev.

Vì sao: từ trước tới mục 68 Dart chỉ được kiểm CÚ PHÁP (`dart format`) và bằng test tĩnh bằng mã Python; kiểu/ngữ nghĩa chỉ biết sau khi GitHub Actions build.
Môi trường kiểm thử không vào được pub.dev và storage.googleapis.com, nhưng vào được GitHub + conda-forge. Script này dựng bộ phân tích từ đó:
  1. Dart SDK từ conda-forge (nếu máy chưa có `dart`);
  2. mã nguồn Flutter (bản `--flutter-tag`, mặc định 3.35.7 - bản mới hơn cần gói `listen` không lấy được) + engine `dart:ui` từ GitHub;
  3. các gói nền (collection, characters, meta, vector_math, crypto, http...) từ GitHub, tự viết `.dart_tool/package_config.json` + gói giả `sky_engine`;
  4. chạy `dart analyze lib` và PHÂN LOẠI kết quả.

GIỚI HẠN (nói thẳng): 17 gói plugin (file_picker, share_plus, video_player, shared_preferences, ...) KHÔNG có nguồn -> mọi tên lấy từ chúng báo "undefined_*"/"uri_does_not_exist"
(đây là NHIỄU, đã ghi trong BASELINE_NOISE) và kiểu của chúng thành dynamic nên chỗ dùng chúng không được kiểm kiểu. Mọi thứ còn lại (Flutter framework, lớp/hàm của chính app,
http, crypto) được kiểm kiểu THẬT: lỗi gán sai kiểu, tên tham số/hàm/lớp của app sai... Đã thử bằng tệp canary cố ý sai: bị bắt.
KẾT QUẢ: thoát 0 nếu không có lỗi nào ngoài nhiễu đã biết; 1 nếu có lỗi thật hoặc TÊN MỚI chưa biết (xem lại: có thể là gói pub mới thêm vào pubspec hoặc lỗi gõ tên).

Dùng:  python3 tools/dart_analyze_offline.py [--work /tmp/mv_dart_ws] [--flutter-tag 3.35.7]      (chạy từ thư mục dự án Flutter, cần mạng tới GitHub/conda-forge)
Mọi thư mục dựng nằm ở --work (mặc định /tmp/mv_dart_ws); `.dart_tool/package_config.json` tạm trong dự án được XOÁ khi xong (không đưa vào APK/zip).
"""
import argparse
import io
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

# Tên bị báo "không định nghĩa" CHỈ vì gói pub tương ứng không có nguồn (đo ở mục 69 trên dự án thật). Tên mới ngoài danh sách này = xem lại.
BASELINE_NOISE = {
    "AndroidForegroundType", "ConnectivityResult", "FilePicker", "FileType", "Gal", "OpenFilex", "Permission", "PhotoManager", "PlayerState", "RequestType", "Share",
    "SharedPreferences", "SvgPicture", "VideoPlayerController", "WakelockPlus", "WebSocketChannel", "ArchiveFile", "AssetEntity", "InputFileStream", "OutputFileStream",
    "ServiceInstance", "AndroidConfiguration", "FlutterBackgroundService", "IosConfiguration", "ZipDecoder", "AudioPlayer", "Connectivity", "DeviceFileSource",
    "DiskSpacePlus", "FilterOptionGroup", "VideoPlayer", "VideoProgressIndicator", "XFile", "ZipFileEncoder", "getApplicationDocumentsDirectory", "getTemporaryDirectory",
    "AndroidServiceInstance",
}
NOISE_CODES = {"undefined_identifier", "undefined_class", "undefined_function", "undefined_method", "undefined_getter", "undefined_prefixed_name", "uri_does_not_exist",
               "non_type_as_type_argument", "type_test_with_undefined_name", "extends_non_class", "undefined_annotation"}
CONDA_DART = "https://conda.anaconda.org/conda-forge/linux-64/"


def sh(cmd, cwd=None, timeout=300, check=True):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    if check and r.returncode != 0:
        raise SystemExit(f"LỆNH LỖI: {' '.join(cmd)}\n{(r.stderr or r.stdout)[-600:]}")
    return r


def ensure_dart(work):
    found = shutil.which("dart")
    if found:
        return os.path.dirname(found)
    root = os.path.join(work, "dartsdk")
    if not os.path.exists(os.path.join(root, "bin", "dart")):
        import zstandard  # pip install zstandard
        import tarfile
        os.makedirs(root, exist_ok=True)
        cur = json.loads(urllib.request.urlopen(CONDA_DART + "current_repodata.json", timeout=240).read())
        pk = {**cur.get("packages", {}), **cur.get("packages.conda", {})}
        name = sorted(k for k, v in pk.items() if v["name"] == "dart-sdk")[-1]
        data = urllib.request.urlopen(CONDA_DART + name, timeout=600).read()
        z = zipfile.ZipFile(io.BytesIO(data))
        for n in z.namelist():
            if n.startswith("pkg-") and n.endswith(".tar.zst"):
                with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(z.read(n))) as r:
                    tarfile.open(fileobj=r, mode="r|").extractall(root)
        with open(os.path.join(root, "version"), "w") as fh:     # bản conda thiếu tệp này -> analysis server sập nếu không có
            fh.write(name.split("-")[2] + "\n")
    return os.path.join(root, "bin")


def clone(url, dest, extra=(), sparse=None, tag=None):
    if os.path.isdir(dest):
        return
    cmd = ["git", "clone", "-q", "--depth", "1"] + (["--branch", tag] if tag else []) + list(extra) + [url, dest]
    sh(cmd, timeout=280)
    if sparse:
        sh(["git", "sparse-checkout", "set"] + sparse, cwd=dest)


def build_workspace(work, tag, dart_bin, project):
    os.makedirs(work, exist_ok=True)
    flutter = os.path.join(work, "flutter_src")
    clone("https://github.com/flutter/flutter.git", flutter, ["--filter=blob:none", "--sparse"], ["packages/flutter", "engine/src/flutter/lib/ui"], tag)
    core = os.path.join(work, "pk_core"); clone("https://github.com/dart-lang/core.git", core)
    vm = os.path.join(work, "pk_vm"); clone("https://github.com/google/vector_math.dart.git", vm)
    mcu = os.path.join(work, "pk_mcu"); clone("https://github.com/material-foundation/material-color-utilities.git", mcu)
    sdk = os.path.join(work, "pk_sdk"); clone("https://github.com/dart-lang/sdk.git", sdk, ["--filter=blob:none", "--sparse"], ["pkg/meta"])
    http = os.path.join(work, "pk_http"); clone("https://github.com/dart-lang/http.git", http)
    web = os.path.join(work, "pk_web"); clone("https://github.com/dart-lang/web.git", web)
    # gói giả sky_engine: `dart:ui` + toàn bộ thư viện VM của SDK (EmbedderSdk thay thế hẳn bản đồ thư viện chuẩn nên phải liệt kê đủ)
    sky = os.path.join(work, "skyeng"); os.makedirs(os.path.join(sky, "lib"), exist_ok=True)
    ui_link = os.path.join(sky, "lib", "ui")
    if not os.path.exists(ui_link):
        os.symlink(os.path.join(flutter, "engine", "src", "flutter", "lib", "ui"), ui_link)
    sdk_lib = os.path.join(os.path.dirname(dart_bin), "lib")
    libs = json.load(open(os.path.join(sdk_lib, "libraries.json"), encoding="utf-8"))
    entries = {}
    for sec in ("vm_common", "vm"):
        for k, v in libs[sec]["libraries"].items():
            entries[k] = v["uri"]
    with open(os.path.join(sky, "lib", "_embedder.yaml"), "w", encoding="utf-8") as fh:
        fh.write("embedded_libs:\n" + "".join(f'  "dart:{k}": "{os.path.join(sdk_lib, u)}"\n' for k, u in entries.items()) + '  "dart:ui": "ui/ui.dart"\n')
    with open(os.path.join(sky, "pubspec.yaml"), "w", encoding="utf-8") as fh:
        fh.write("name: sky_engine\nversion: 0.0.0\nenvironment:\n  sdk: '>=3.0.0 <4.0.0'\n")

    def pk(name, root, ver="3.3"):
        return {"name": name, "rootUri": "file://" + root, "packageUri": "lib/", "languageVersion": ver}
    pkgs = [pk("ai_mv_generator", project), pk("flutter", os.path.join(flutter, "packages", "flutter"), "3.8"), pk("sky_engine", sky, "3.8"),
            pk("characters", core + "/pkgs/characters"), pk("collection", core + "/pkgs/collection"), pk("crypto", core + "/pkgs/crypto"),
            pk("typed_data", core + "/pkgs/typed_data"), pk("path", core + "/pkgs/path"), pk("async", core + "/pkgs/async"), pk("convert", core + "/pkgs/convert"),
            pk("meta", sdk + "/pkg/meta"), pk("vector_math", vm), pk("material_color_utilities", mcu + "/dart"), pk("http", http + "/pkgs/http"),
            pk("http_parser", http + "/pkgs/http_parser"), pk("web", web + "/web")]
    os.makedirs(os.path.join(project, ".dart_tool"), exist_ok=True)
    with open(os.path.join(project, ".dart_tool", "package_config.json"), "w", encoding="utf-8") as fh:
        json.dump({"configVersion": 2, "packages": pkgs}, fh, indent=1)


def classify(text):
    real, new_names, noise = [], set(), 0
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith(("error", "warning")):
            continue
        code = line.rsplit(" - ", 1)[-1].strip()
        if code in NOISE_CODES:
            m = re.search(r"'([^']+)'", line)
            name = m.group(1) if m else ""
            if code == "uri_does_not_exist" or name in BASELINE_NOISE:
                noise += 1
            else:
                new_names.add(name or line[:80])
        else:
            real.append(line)
    return real, sorted(new_names), noise


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--work", default=os.environ.get("MV_DART_WS", "/tmp/mv_dart_ws"))
    ap.add_argument("--flutter-tag", default="3.35.7")
    ap.add_argument("--project", default=os.getcwd())
    args = ap.parse_args()
    project = os.path.abspath(args.project)
    if not os.path.exists(os.path.join(project, "pubspec.yaml")):
        raise SystemExit("Chạy từ thư mục dự án Flutter (có pubspec.yaml) hoặc đặt --project.")
    dart_bin = ensure_dart(args.work)
    env = dict(os.environ, PATH=dart_bin + os.pathsep + os.environ["PATH"])
    cfg = os.path.join(project, ".dart_tool", "package_config.json")
    existed = os.path.exists(cfg)
    try:
        build_workspace(args.work, args.flutter_tag, dart_bin, project)
        r = subprocess.run(["dart", "analyze", "lib"], cwd=project, capture_output=True, text=True, env=env, timeout=600)
        out = r.stdout + r.stderr
    finally:
        if not existed:
            shutil.rmtree(os.path.join(project, ".dart_tool"), ignore_errors=True)
    real, new_names, noise = classify(out)
    print(f"Nhiễu do thiếu gói pub (đã biết): {noise} dòng")
    if new_names:
        print("TÊN MỚI chưa biết (gói pub mới thêm? hay gõ sai tên?):", ", ".join(new_names))
    for line in real:
        print("LỖI THẬT:", line[:240])
    if not real and not new_names:
        print("ĐẠT: không có lỗi kiểu/ngữ nghĩa ngoài nhiễu đã biết.")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
