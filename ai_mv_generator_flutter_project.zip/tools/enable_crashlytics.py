"""
enable_crashlytics.py  (MỚI mục 27) - chạy bởi bước TUỲ CHỌN "Bật Firebase Crashlytics" trong build.yml (chỉ khi bạn tích chọn `crashlytics` lúc chạy workflow).
Làm 2 việc trên khung Android do `flutter create` sinh ra:
  1. ghi secret GOOGLE_SERVICES_JSON thành android/app/google-services.json;
  2. thêm 2 plugin Gradle (com.google.gms.google-services 4.4.0 + com.google.firebase.crashlytics 2.9.9) theo kiểu khai báo (Plugin DSL) mà tài liệu Flutter
     "Deprecated imperative apply of Flutter's Gradle plugins" mô tả: vào khối `plugins {}` của android/settings.gradle(.kts) (apply false) và của
     android/app/build.gradle(.kts). Hỗ trợ cả Groovy lẫn Kotlin DSL. KHÔNG tìm thấy chỗ chèn -> báo lỗi RÕ và thoát mã 1 (không build ra APK "nửa vời").
Phiên bản plugin lấy theo ví dụ trong tài liệu Flutter - có thể đã cũ; nếu Gradle báo không tìm thấy/không tương thích thì nâng số ở 2 hằng bên dưới.
CHƯA chạy thật trên GitHub Actions. Mặc định build KHÔNG gọi file này.
"""
import os
import re
import sys

GMS_VERSION = "4.4.0"
CRASHLYTICS_VERSION = "2.9.9"


def _kts(path: str) -> bool:
    return path.endswith(".kts")


def patch_settings(text: str, kotlin: bool) -> str:
    """Thêm 2 plugin (apply false) ngay sau dòng plugin kotlin.android trong settings.gradle(.kts). Đã có thì giữ nguyên."""
    if "com.google.firebase.crashlytics" in text:
        return text
    if kotlin:
        add = (f'    id("com.google.gms.google-services") version "{GMS_VERSION}" apply false\n'
               f'    id("com.google.firebase.crashlytics") version "{CRASHLYTICS_VERSION}" apply false\n')
        pat = re.compile(r'^(\s*id\("org\.jetbrains\.kotlin\.android"\)[^\n]*\n)', re.M)
    else:
        add = (f'    id "com.google.gms.google-services" version "{GMS_VERSION}" apply false\n'
               f'    id "com.google.firebase.crashlytics" version "{CRASHLYTICS_VERSION}" apply false\n')
        pat = re.compile(r'^(\s*id\s+"org\.jetbrains\.kotlin\.android"[^\n]*\n)', re.M)
    new, n = pat.subn(lambda m: m.group(1) + add, text, count=1)
    if n != 1:
        raise ValueError("không tìm thấy dòng plugin 'org.jetbrains.kotlin.android' trong settings.gradle(.kts)")
    return new


def patch_app_build(text: str, kotlin: bool) -> str:
    """Thêm 2 plugin (áp dụng) ngay sau dòng dev.flutter.flutter-gradle-plugin trong android/app/build.gradle(.kts). Đã có thì giữ nguyên."""
    if "com.google.firebase.crashlytics" in text:
        return text
    if kotlin:
        add = '    id("com.google.gms.google-services")\n    id("com.google.firebase.crashlytics")\n'
        pat = re.compile(r'^(\s*id\("dev\.flutter\.flutter-gradle-plugin"\)[^\n]*\n)', re.M)
    else:
        add = '    id "com.google.gms.google-services"\n    id "com.google.firebase.crashlytics"\n'
        pat = re.compile(r'^(\s*id\s+"dev\.flutter\.flutter-gradle-plugin"[^\n]*\n)', re.M)
    new, n = pat.subn(lambda m: m.group(1) + add, text, count=1)
    if n != 1:
        raise ValueError("không tìm thấy dòng plugin 'dev.flutter.flutter-gradle-plugin' trong android/app/build.gradle(.kts)")
    return new


def _find(base: str, names):
    for n in names:
        p = os.path.join(base, n)
        if os.path.exists(p):
            return p
    return None


def main(android_dir: str = "android") -> int:
    secret = os.environ.get("GOOGLE_SERVICES_JSON", "").strip()
    if not secret:
        print("::error::Chưa có secret GOOGLE_SERVICES_JSON (GitHub: Settings > Secrets and variables > Actions). Dán nguyên nội dung google-services.json "
              "tải từ Firebase Console (Project settings > Your apps > Android, đúng package name của app).")
        return 1
    settings = _find(android_dir, ["settings.gradle.kts", "settings.gradle"])
    app_build = _find(os.path.join(android_dir, "app"), ["build.gradle.kts", "build.gradle"])
    if not settings or not app_build:
        print(f"::error::Không thấy settings.gradle(.kts) hoặc app/build.gradle(.kts) trong {android_dir}.")
        return 1
    try:
        for path, fn in ((settings, patch_settings), (app_build, patch_app_build)):
            with open(path, encoding="utf-8") as f:
                old = f.read()
            new = fn(old, _kts(path))
            with open(path, "w", encoding="utf-8") as f:
                f.write(new)
            print(f"Đã vá {path}")
    except ValueError as exc:
        print(f"::error::{exc}. Khung Android do phiên bản Flutter hiện hành sinh ra khác dự kiến - cần chỉnh tay (xem tài liệu Flutter).")
        return 1
    with open(os.path.join(android_dir, "app", "google-services.json"), "w", encoding="utf-8") as f:
        f.write(secret)
    print("Đã ghi android/app/google-services.json")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "android"))
