// Kiểm tra độc lập logic lib/manifest_merge.dart (mục 69). Chạy: dart tools/manifest_merge_check.dart   (chỉ cần Dart SDK; KHÔNG dùng `dart run` vì nó đòi pub get). Thoát 1 nếu có ca sai.
import 'dart:convert';
import 'dart:io';

import '../lib/manifest_merge.dart';

int failures = 0;
void check(bool ok, String name) {
  if (!ok) {
    failures++;
    stdout.writeln('SAI: $name');
  }
}

void main() {
  final saved = <String, dynamic>{
    'v': 1,
    'env': {'MV_A': '1', 'MV_B': 'x'},
    'models': {'video': 'Wan-AI/x'},
    'features': ['musetalk', 'realesrgan'],
  };
  final fresh = ManifestMerge.empty();
  check(ManifestMerge.isEmpty(fresh), 'rỗng');
  check(ManifestMerge.isEmpty(null), 'null = rỗng');
  check(ManifestMerge.isEmpty(<String, dynamic>{'v': 2, 'env': {'A': '1'}}), 'sai phiên bản = rỗng');

  // backend mới trống: KHÔNG làm mất bản đã lưu; diff liệt kê đủ những gì thiếu
  final d = ManifestMerge.diff(saved, fresh);
  check(!d.isEmpty && d.total == 5, 'diff với backend trống = 5 mục (${d.total})');
  check(d.env.join(',') == 'MV_A,MV_B' && d.models.join(',') == 'video' && d.features.join(',') == 'musetalk,realesrgan', 'diff đúng tên');
  check(jsonEncode(ManifestMerge.normalize(ManifestMerge.merge(saved, fresh))) == jsonEncode(ManifestMerge.normalize(saved)), 'merge với backend trống giữ nguyên');

  // backend đã khôi phục xong: không còn gì thiếu
  final restored = <String, dynamic>{
    'v': 1,
    'env': {'MV_A': '1', 'MV_B': 'x', 'MV_C': 'mới'},
    'models': {'video': 'Wan-AI/x'},
    'features': ['musetalk', 'realesrgan', 'seedvr2'],
  };
  check(ManifestMerge.diff(saved, restored).isEmpty, 'đã đủ -> diff rỗng');
  final m2 = ManifestMerge.merge(saved, restored);
  check((m2['env'] as Map).length == 3 && (m2['features'] as List).length == 3, 'merge thêm mục mới của backend');

  // khác giá trị = thiếu
  final changed = <String, dynamic>{'v': 1, 'env': {'MV_A': '2', 'MV_B': 'x'}, 'models': {'video': 'Wan-AI/x'}, 'features': ['musetalk', 'realesrgan']};
  check(ManifestMerge.diff(saved, changed).env.join(',') == 'MV_A', 'giá trị khác bị tính là thiếu');
  check((ManifestMerge.merge(saved, changed)['env'] as Map)['MV_A'] == '2', 'backend ghi đè giá trị khi hợp nhất');

  // xoá chủ động
  check(!(ManifestMerge.removeEnv(saved, 'MV_A')['env'] as Map).containsKey('MV_A'), 'bỏ cài đặt');
  check((ManifestMerge.removeModel(saved, 'video')['models'] as Map).isEmpty, 'đặt lại model');
  check((saved['env'] as Map).containsKey('MV_A'), 'không sửa đối tượng gốc');

  // dữ liệu bẩn (từ bộ nhớ máy) không làm hỏng
  final dirty = <String, dynamic>{'v': 1, 'env': {'A': 1, 'B': 'ok'}, 'models': 'sai', 'features': ['f', 3, null, 'f']};
  final n = ManifestMerge.normalize(dirty);
  check(jsonEncode(n) == '{"v":1,"env":{"B":"ok"},"models":{},"features":["f"]}', 'chuẩn hoá bỏ mục sai kiểu: ${jsonEncode(n)}');
  check(jsonDecode(jsonEncode(saved)) is Map, 'khứ hồi JSON');

  if (failures > 0) {
    stdout.writeln('$failures ca sai.');
    exit(1);
  }
  stdout.writeln('ĐẠT: tất cả ca kiểm tra manifest_merge.');
}
